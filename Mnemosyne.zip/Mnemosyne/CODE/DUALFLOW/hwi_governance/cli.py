"""Explicit operator CLI. No implicit model run, auto-approval, key generation or publication."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sqlite3
import stat
import sys
from .display import readable_json
from .task_fitness import (FITNESS_REF_PREFIX, FitnessError, assess, digest, fitness_ref,
                           signing_message, validate_contract, verify_owner_decision)
from .fitness_policy import load_fitness_pin
from .decommission import decommission
from .gate_store import GateStore
from .gate_recovery import recover_bindings
from .repository import (DEFINITE_REJECTIONS, Repository, RepositoryError, normalize_proposal_request,
                         open_workspace)
from .review_queue import (SPEC_FIELDS, QueueError, list_entries, status_projection,
                           render_review_section,
                           review_entry, submit_proposal, restore_as_proposal,
                           history_view, apply_review, signing_payload)


def read_json(path):
    p = Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_size > 2_000_000:
        raise ValueError('Expected ordinary bounded JSON file')
    def reject_duplicate(pairs):
        data = {}
        for key, value in pairs:
            if key in data:
                raise ValueError('Duplicate JSON key')
            data[key] = value
        return data
    return json.loads(p.read_text('utf-8'), object_pairs_hook=reject_duplicate)

def read_private(path):
    p = Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_size > 4096:
        raise ValueError('Private key metadata must be an ordinary bounded file')
    st = p.stat(follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or (os.name == 'posix' and st.st_mode & 0o077):
        raise ValueError('Operator pin/key file must be private (0600)')
    return p.read_bytes()

def public_key_bytes(path):
    data = read_private(path)
    if len(data) == 32:
        return data
    if len(data.strip()) == 64:
        try:
            return bytes.fromhex(data.decode('ascii').strip())
        except ValueError:
            pass
    raise ValueError('32-byte raw or 64-hex Ed25519 public key required')

def write_once(path, data):
    if type(data) is not bytes:
        data = data.encode('utf-8')
    file_path = Path(path)
    if file_path.parent.is_symlink() or not file_path.parent.is_dir():
        raise ValueError('Output folder must exist and not be a symlink')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os,'O_NOFOLLOW',0)
    fd = os.open(file_path, flags, 0o600)
    with os.fdopen(fd,'wb') as handle:
        handle.write(data)
    return str(file_path)

def emit(data, output=None, *, raw=False):
    if raw:
        encoded = data
    else:
        encoded = (readable_json(data)+'\n').encode('utf-8')
    if output:
        write_once(output,encoded)
        print('Created (no overwrite):',output)
    else:
        # Exact UTF-8 bytes regardless of terminal locale; text fallback for redirected streams.
        buffer = getattr(sys.stdout, 'buffer', None)
        if buffer is not None:
            sys.stdout.flush()
            buffer.write(encoded)
            buffer.flush()
        else:
            sys.stdout.write(encoded.decode('utf-8'))

def check_spec(spec):
    """Exact spec shape before any gate logic, so malformed input is REJECTED, not a traceback.

    Returns the spec normalised exactly as the ledger will store it, so every
    later check, the saved recovery intent and the committed record agree.
    """
    if type(spec) is not dict or set(spec) != SPEC_FIELDS:
        raise QueueError('Submit specification fields must be exact: ' + ', '.join(sorted(SPEC_FIELDS)))
    spec = normalize_proposal_request(spec)
    if spec['author_origin'] not in ('human','agent'):
        raise FitnessError('Unrecognized origin')
    if type(spec['task_id']) is not str or type(spec['operation']) is not str:
        raise QueueError('task_id and operation must be strings')
    refs = spec['source_refs']
    if type(refs) is not list or any(type(r) is not str for r in refs):
        raise QueueError('source_refs must be a list of strings')
    if any(r.startswith(FITNESS_REF_PREFIX) for r in refs):
        raise FitnessError('Fitness references are added by the gate, never supplied in a spec')
    if not 1 <= len(refs) <= 11:
        raise QueueError('1 to 11 evidence source references required (the gate adds the fitness reference)')
    return spec

def task_approval(args, repo, spec):
    """Verify the owner-signed scope against the workspace pin. Returns (verified, assessment, decision, key)."""
    # Required regardless of claimed origin: author_origin is untrusted.
    required = ('contract','results','assessment','owner_decision','owner_public_key')
    if any(not getattr(args,key) for key in required):
        raise FitnessError('Proposal requires a task-specific signed owner fitness decision')
    contract, results = read_json(args.contract),read_json(args.results)
    expected = assess(contract, results)
    if expected != read_json(args.assessment):
        raise FitnessError('Submitted assessment differs from exact task replay')
    pin = load_fitness_pin(repo.root, args.notebook, repo.scope())
    decision, key = read_json(args.owner_decision), public_key_bytes(args.owner_public_key)
    verified = verify_owner_decision(expected, decision, key, pin)
    if (contract['task_id'] != spec['task_id'] or contract['notebook'] != args.notebook or
        spec['operation'] not in contract['allowed_operations']):
        raise FitnessError('Task, notebook or proposal operation outside signed fitness scope')
    return verified, expected, decision, key

def gated_submit(args, repo, spec):
    verified, assessment, decision, key = task_approval(args, repo, spec)
    sha = verified['assessment_sha256']
    with GateStore(repo.root, args.notebook, repo.scope(), create=True) as store:
        # Receipt + slot reservation: one SQLite transaction (serializes submitters).
        slot = store.reserve(assessment, decision, verified, key, verified['max_proposals'],
                             intent_spec=spec)
        try:
            entry = submit_proposal(repo, args.notebook,
                                    {**spec, 'source_refs':spec['source_refs'] + [fitness_ref(sha)]})
        except (QueueError,) + DEFINITE_REJECTIONS:
            # Definite pre-commit rejection by HWI-07/HWI-05 (validation, stale
            # revision, duplicate; the ledger rolls back): the slot is returned.
            # Any other failure may follow a commit, so the slot stays consumed.
            store.release(sha, slot)
            raise
        except (OSError, sqlite3.Error, RuntimeError, ValueError) as exc:
            # A generic I/O/runtime error may happen before OR AFTER the
            # HWI-07 COMMIT; neither calling it REJECTED nor releasing the
            # quota slot is justified. Operator reconciliation is required.
            raise SubmissionOutcomeUnknown(sha, slot, exc) from exc
        try:
            store.bind(sha, slot, entry['proposal_id'])
        except (OSError, ValueError, sqlite3.Error) as exc:
            raise SubmittedWithoutGateRecord(entry['proposal_id'], exc) from exc
    return entry, {**verified, 'scope_slot':slot}


class SubmissionOutcomeUnknown(Exception):
    """Could not determine whether the independently committed ledger write succeeded."""
    def __init__(self, sha, slot, cause):
        super().__init__(sha, slot, cause)
        self.sha, self.slot, self.cause = sha, slot, cause


class SubmittedWithoutGateRecord(Exception):
    """The ledger committed the proposal but its gate usage record was not written."""
    def __init__(self, proposal_id, cause):
        super().__init__(proposal_id, cause)
        self.proposal_id, self.cause = proposal_id, cause

def main(argv=None):
    parser = argparse.ArgumentParser(description='HWI task fitness and signed wiki review (no automatic approval)')
    sub = parser.add_subparsers(dest='command', required=True)
    pins = sub.add_parser('fitness-pins',help='Print contract_sha256/configuration_sha256 for a results file (read-only)')
    pins.add_argument('--contract',required=True)
    fit = sub.add_parser('fitness-assess',help='Evaluate pinned task-specific test evidence')
    fit.add_argument('--contract',required=True)
    fit.add_argument('--results',required=True)
    fit.add_argument('--output')
    payload = sub.add_parser('fitness-signing-payload',help='Exact message for offline owner signing')
    payload.add_argument('--assessment',required=True)
    payload.add_argument('--output')
    verify = sub.add_parser('fitness-verify',help='Validate exact signed owner task-scope decision')
    verify.add_argument('--assessment',required=True)
    verify.add_argument('--owner-decision',required=True)
    verify.add_argument('--owner-public-key',required=True)
    verify.add_argument('--workspace',required=True,help='Private NotebookWorkspace holding fitness_policy/')
    verify.add_argument('--notebook',required=True)
    for cmd in ('queue-init','queue-list','queue-status','queue-search','queue-review','queue-revision',
                'queue-export','queue-submit','queue-gate-recover','queue-history','queue-reject','queue-withdraw',
                'queue-restore-proposal','queue-signing-payload','queue-apply',
                'queue-decommission'):
        item = sub.add_parser(cmd)
        item.add_argument('--workspace',required=True,help='Private NotebookWorkspace physical path')
        item.add_argument('--notebook',required=True,help='Named notebook')
        if cmd == 'queue-export': item.add_argument('--output',required=True)
        if cmd == 'queue-search': item.add_argument('--query',required=True)
        if cmd == 'queue-revision': item.add_argument('--reference',required=True)
        if cmd in ('queue-review','queue-reject','queue-withdraw'):
            item.add_argument('--proposal-id',required=True)
            if cmd in ('queue-reject','queue-withdraw'):
                item.add_argument('--actor-claim',required=True)
                item.add_argument('--reason',required=True)
        if cmd == 'queue-gate-recover':
            item.add_argument('--apply',action='store_true',
                              help='Explicit operator repair only for uniquely matched pending slots')
        if cmd == 'queue-submit':
            item.add_argument('--spec',required=True)
            for name in ('contract','results','assessment','owner_decision','owner_public_key'):
                item.add_argument('--'+name.replace('_','-'))
        if cmd == 'queue-history': item.add_argument('--post-id',required=True)
        if cmd == 'queue-restore-proposal':
            item.add_argument('--current-ref',required=True)
            item.add_argument('--historical-ref',required=True)
            item.add_argument('--reason',required=True)
        if cmd in ('queue-signing-payload','queue-apply'):
            item.add_argument('--proposal-id',required=True)
            if cmd == 'queue-signing-payload': item.add_argument('--output')
            if cmd == 'queue-apply':
                item.add_argument('--signature-hex',required=True)
                item.add_argument('--reviewer-public-key',required=True)
                item.add_argument('--accept-unverified-gate',action='store_true',
                                  help='Required to apply a proposal whose fitness gate is not VERIFIED '
                                       '(e.g. restore proposals, which are UNGATED by design)')
    args = parser.parse_args(argv)
    try:
        if args.command == 'fitness-pins':
            contract = read_json(args.contract)
            validate_contract(contract)
            emit({'contract_sha256':digest(contract),
                  'configuration_sha256':digest(contract['configuration']),
                  'case_ids':[case['case_id'] for case in contract['cases']],
                  'results_schema':'hwi.task_fitness.results.v2'})
        elif args.command == 'fitness-assess':
            emit(assess(read_json(args.contract),read_json(args.results)),args.output)
        elif args.command == 'fitness-signing-payload':
            emit(signing_message(read_json(args.assessment)),args.output,raw=True)
        else:
            name = args.notebook
            repo = Repository(open_workspace(args.workspace), name)
            ws = repo
            if args.command == 'fitness-verify':
                assessment = read_json(args.assessment)
                if type(assessment) is not dict or assessment.get('notebook') != name:
                    raise FitnessError('Assessment names a different notebook than --notebook')
                pin = load_fitness_pin(repo.root, name, repo.scope())
                emit(verify_owner_decision(assessment,read_json(args.owner_decision),
                                           public_key_bytes(args.owner_public_key),pin))
            elif args.command == 'queue-init':
                emit({'status':'PROPOSAL_LEDGER_READY','notebook':name,
                      'notebook_scope':repo.init_ledger(),'wiki_modified':False})
            elif args.command == 'queue-list':
                emit(list_entries(ws,name))
            elif args.command == 'queue-status':
                emit(status_projection(ws,name))
            elif args.command == 'queue-search':
                emit(repo.search(args.query))
            elif args.command == 'queue-revision':
                emit(repo.revision(args.reference))
            elif args.command == 'queue-review':
                emit(review_entry(repo,name,args.proposal_id))
            elif args.command in ('queue-reject','queue-withdraw'):
                record=repo.close_proposal(args.proposal_id,
                                           action='reject' if args.command == 'queue-reject' else 'withdraw',
                                           actor_claim=args.actor_claim,reason=args.reason)
                emit({'status':record['state'],'proposal':record,
                      'actor_authenticated':False,'wiki_modified':False})
            elif args.command == 'queue-export':
                records = render_review_section(list_entries(ws,name))
                write_once(args.output,(json.dumps(records,indent=2,ensure_ascii=True)+'\n').encode('ascii'))
                print('Created read-only PERSONAL.WIKI import file:',args.output)
            elif args.command == 'queue-gate-recover':
                emit(recover_bindings(repo, apply=args.apply))
            elif args.command == 'queue-submit':
                spec=check_spec(read_json(args.spec))
                entry,fitness=gated_submit(args,repo,spec)
                emit({'status':'PENDING_HUMAN_REVIEW','proposal':entry,
                      'task_scope_check':fitness,'wiki_modified':False})
            elif args.command == 'queue-history':
                emit(history_view(ws,name,args.post_id))
            elif args.command == 'queue-restore-proposal':
                entry=restore_as_proposal(ws,name,current_ref=args.current_ref,
                                          historical_ref=args.historical_ref,reason=args.reason)
                emit({'status':'RESTORE_PROPOSAL_PENDING_SIGNATURE','proposal':entry,
                      'fitness_gate':'UNGATED (restore helper); queue-apply needs --accept-unverified-gate',
                      'wiki_modified':False})
            elif args.command == 'queue-signing-payload':
                emit(signing_payload(ws,name,args.proposal_id),args.output,raw=True)
            elif args.command == 'queue-decommission':
                emit(decommission(repo))
            elif args.command == 'queue-apply':
                gate=review_entry(ws,name,args.proposal_id)['fitness_gate']
                if gate['status'] != 'VERIFIED' and not args.accept_unverified_gate:
                    raise QueueError(f"Fitness gate is {gate['status']} ({gate['detail']}); "
                                     'review the proposal, then re-run with --accept-unverified-gate')
                result=apply_review(ws,name,args.proposal_id,args.signature_hex,
                                    public_key_bytes(args.reviewer_public_key))
                emit({'status':'APPLIED_WITH_SIGNED_REVIEW','receipt':result,'fitness_gate':gate,
                      'unverified_gate_accepted':gate['status'] != 'VERIFIED',
                      'pvs_approved':False,'execution_authorized':False})
    except SubmittedWithoutGateRecord as exc:
        print(f'SUBMITTED_WITHOUT_GATE_RECORD: {exc.proposal_id} was recorded in the ledger, but its '
              f'gate binding outcome is uncertain ({type(exc.cause).__name__}: {exc.cause}). '
              'The quota slot stays consumed. Do not resubmit; inspect queue-review and '
              'queue-gate-recover before any operator --apply.', file=sys.stderr)
        return 3
    except SubmissionOutcomeUnknown as exc:
        print(f'SUBMISSION_OUTCOME_UNKNOWN: assessment={exc.sha} slot={exc.slot}; '
              f'ledger COMMIT may have occurred ({type(exc.cause).__name__}: {exc.cause}). '
              'The quota slot remains consumed. Do not resubmit; inspect '
              'queue-gate-recover without --apply first.', file=sys.stderr)
        return 3
    except (ValueError,PermissionError,RuntimeError,OSError,sqlite3.Error) as exc:
        print(f'REJECTED: {type(exc).__name__}: {exc}',file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    sys.exit(main())
