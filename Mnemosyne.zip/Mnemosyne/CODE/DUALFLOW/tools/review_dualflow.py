#!/usr/bin/env python3
"""WL-04 offline regression evidence and non-authorizing review annotations.

Executes only synthetic scenarios through WL-02's deterministic simulator. A
passing result attests to a local comparison with *supplied* expectations, not
to source truth, independent evaluation, human identity, or authorization.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
from typing import Any

from check_dualflow_design import (
    DesignError, _items, _need, _object, _reject_constant, _symbol,
    _unique_object, load_design,
)
from patch_dualflow import load_patch, propose_revision
from simulate_dualflow import SCHEMA as SIMULATION_SCHEMA, canonical_digest, simulate

SUITE_SCHEMA = "hwi.dualflow.regression.v0"
NOTE_SCHEMA = "hwi.dualflow.review_note.v0"
MAX_SUITE_BYTES = 512_000
MAX_NOTE_BYTES = 16_000
MAX_CASES = 16
FLOW_STATUSES = frozenset({"SUCCESS", "FAILURE", "UNKNOWN"})
DISPOSITIONS = frozenset({"REQUEST_REVISION", "DEFER", "RECOMMEND_FOR_OWNER_DECISION"})


def _strict_json(path: str | Path, maximum: int) -> dict:
    path = Path(path)
    _need(path.stat().st_size <= maximum, "review file exceeds byte limit")
    with path.open("r", encoding="utf-8") as source:
        return json.load(source, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)


def load_suite(path: str | Path) -> dict:
    return _strict_json(path, MAX_SUITE_BYTES)


def load_review_note(path: str | Path) -> dict:
    return _strict_json(path, MAX_NOTE_BYTES)


def _sha(value: Any, where: str) -> str:
    _need(type(value) is str and len(value) == 64 and
          all(ch in "0123456789abcdef" for ch in value),
          f"{where}: expected lowercase SHA-256 hex")
    return value


def _expected(value: Any, design: dict, where: str) -> dict:
    _need(type(value) is dict, f"{where}: expected object")
    kind = value.get("kind")
    if kind == "simulate":
        _object(value, {"kind", "status", "terminal_stock", "flow_statuses",
                        "knowledge_ids"}, where)
        _need(type(value["status"]) is str and
              value["status"] in {"SIMULATED_TERMINAL", "SIMULATION_INCOMPLETE"},
              f"{where}: invalid simulation status")
        terminal = value["terminal_stock"]
        _need((type(terminal) is str and terminal in design["terminal_stocks"])
              if value["status"] == "SIMULATED_TERMINAL" else terminal is None,
              f"{where}: invalid expected terminal")
        statuses = value["flow_statuses"]
        _need(type(statuses) is list and 1 <= len(statuses) <= design["resources"]["max_steps"]
              and all(type(s) is str and s in FLOW_STATUSES for s in statuses),
              f"{where}: invalid flow outcome sequence")
        _items(value["knowledge_ids"], f"{where}.knowledge_ids", minimum=0,
               maximum=design["resources"]["max_artifacts"], artifact=True)
    elif kind == "reject":
        _object(value, {"kind", "error_contains"}, where)
        reason = value["error_contains"]
        _need(type(reason) is str and 8 <= len(reason) <= 120 and
              reason.isprintable(), f"{where}: invalid expected rejection reason")
    else:
        raise DesignError(f"{where}: unsupported expectation kind")
    return value


def _validate_suite(base: dict, patch: dict, proposal: dict, suite: Any) -> list[dict]:
    _object(suite, {"schema", "workflow_id", "base_sha256", "patch_sha256",
                    "candidate_sha256", "cases"}, "regression_suite")
    _need(suite["schema"] == SUITE_SCHEMA, "unsupported regression schema")
    _need(type(suite["workflow_id"]) is str and
          suite["workflow_id"] == base["workflow_id"], "regression workflow_id mismatch")
    for field in ("base_sha256", "patch_sha256", "candidate_sha256"):
        _need(_sha(suite[field], field) == proposal[field], f"{field}: stale evidence pin")
    cases = suite["cases"]
    _need(type(cases) is list and 1 <= len(cases) <= MAX_CASES,
          "cases: expected 1..16 test cases")
    ids: list[str] = []
    positive_count = 0
    for i, case in enumerate(cases):
        _object(case, {"test_id", "scenario", "expected"}, f"case[{i}]")
        test_id = _symbol(case["test_id"], f"case[{i}].test_id")
        ids.append(test_id)
        expected = _expected(case["expected"], proposal["candidate_design"],
                             f"case[{i}].expected")
        scenario = case["scenario"]
        _need(type(scenario) is dict, f"case[{i}]: scenario must be an object")
        _need(scenario.get("schema") == SIMULATION_SCHEMA and
              scenario.get("workflow_id") == base["workflow_id"],
              f"case[{i}]: scenario envelope mismatch")
        # Even rejection tests must reference an actual base or candidate
        # identity, rather than an arbitrary ill-formed document.
        pair = (scenario.get("revision"), scenario.get("design_sha256"))
        allowed = ((base["revision"], proposal["base_sha256"]),
                   (proposal["candidate_revision"], proposal["candidate_sha256"]))
        _need(type(pair[0]) is int and pair in allowed,
              f"case[{i}]: scenario must pin base or candidate identity")
        if expected["kind"] == "simulate":
            _need(pair == allowed[1], f"case[{i}]: simulation must pin candidate")
            if (expected["status"] == "SIMULATED_TERMINAL" and
                    all(s == "SUCCESS" for s in expected["flow_statuses"])):
                positive_count += 1
    _need(len(ids) == len(set(ids)), "duplicate regression test IDs")
    _need(set(ids) == set(patch["tests_to_run"]),
          "regression cases must cover precisely the proposed test IDs")
    _need(positive_count >= 1, "regression suite requires a simulated successful terminal path")
    return cases


def assess_revision(base: Any, patch: Any, suite: Any) -> dict[str, Any]:
    """Produce deterministic *local* test comparisons without accepting a revision.

    Malformed suites / stale identities are rejected. Valid cases with unmet
    expectations return an explicit blocked report, not an exception. No input
    object is mutated. Rejection cases match only deliberate DesignError paths.
    """
    proposal = propose_revision(base, patch)
    cases = _validate_suite(base, patch, proposal, suite)
    candidate = proposal["candidate_design"]
    results = []
    for case in cases:
        expect = case["expected"]
        observed: dict[str, Any]
        trace_hash = None
        try:
            replay = simulate(candidate, case["scenario"])
        except DesignError as exc:
            observed = {"kind": "reject", "error": str(exc)[:240]}
            matched = (expect["kind"] == "reject" and
                       expect["error_contains"] in str(exc))
        else:
            ids = sorted(artifact for artifact, info in replay["lineage"].items()
                         if info["origin"] != "initial")
            observed = {"kind": "simulate", "status": replay["status"],
                        "terminal_stock": replay["terminal_stock"],
                        "flow_statuses": [t["status"] for t in replay["trace"]],
                        "knowledge_ids": ids}
            trace_hash = replay["trace_sha256"]
            matched = expect["kind"] == "simulate" and observed == expect
        results.append({"test_id": case["test_id"], "outcome": "MATCH" if matched else "MISMATCH",
                        "scenario_sha256": canonical_digest(case["scenario"]),
                        "expected": copy.deepcopy(expect), "observed": observed,
                        "trace_sha256": trace_hash})

    passed = sum(r["outcome"] == "MATCH" for r in results)
    report = {
        "schema": "hwi.dualflow.regression_report.v0",
        "status": "READY_FOR_OWNER_REVIEW" if passed == len(results) else "REGRESSION_MISMATCH",
        "workflow_id": proposal["workflow_id"],
        "base_sha256": proposal["base_sha256"],
        "patch_sha256": proposal["patch_sha256"],
        "candidate_sha256": proposal["candidate_sha256"],
        "suite_sha256": canonical_digest(suite),
        "cases_passed": passed,
        "cases_total": len(results),
        "results": results,
        "review_outcome": "PENDING_OWNER_REVIEW",
        "tests_executed_in_synthetic_simulator": True,
        "expected_results_independently_verified": False,
        "observations_independently_verified": False,
        "reviewer_identity_verified": False,
        "owner_accepted": False,
        "workflow_published": False,
        "execution_authorized": False,
        "knowledge_approved": False,
    }
    report["evidence_sha256"] = canonical_digest(report)
    return report


def attach_review_note(report: Any, note: Any) -> dict[str, Any]:
    """Bind untrusted review annotations to an exact report, never authorize."""
    _need(type(report) is dict and report.get("schema") ==
          "hwi.dualflow.regression_report.v0", "invalid report type")
    _need(report.get("status") in {"READY_FOR_OWNER_REVIEW", "REGRESSION_MISMATCH"}
          and report.get("review_outcome") == "PENDING_OWNER_REVIEW",
          "invalid review report disposition")
    for field in ("owner_accepted", "workflow_published", "execution_authorized",
                  "knowledge_approved", "reviewer_identity_verified",
                  "observations_independently_verified",
                  "expected_results_independently_verified"):
        _need(report.get(field) is False, "report cannot claim approval or independent verification")
    report_hash = report.get("evidence_sha256")
    _need(_sha(report_hash, "evidence_sha256") ==
          canonical_digest({k: v for k, v in report.items() if k != "evidence_sha256"}),
          "report digest mismatch")
    _object(note, {"schema", "candidate_sha256", "evidence_sha256",
                   "disposition", "reason", "reviewed_test_ids"}, "review_note")
    _need(note["schema"] == NOTE_SCHEMA, "unsupported review note schema")
    _need(_sha(note["candidate_sha256"], "candidate_sha256") == report["candidate_sha256"],
          "review note candidate mismatch")
    _need(_sha(note["evidence_sha256"], "evidence_sha256") == report_hash,
          "stale review report")
    _need(type(note["disposition"]) is str and note["disposition"] in DISPOSITIONS,
          "invalid non-authorizing review disposition")
    reason = note["reason"]
    _need(type(reason) is str and 10 <= len(reason) <= 1000 and
          all(ch.isprintable() or ch == "\n" for ch in reason),
          "invalid review reason")
    ids = _items(note["reviewed_test_ids"], "reviewed_test_ids",
                 minimum=1, maximum=MAX_CASES)
    all_ids = {r["test_id"] for r in report["results"]}
    _need(set(ids).issubset(all_ids), "review note references unlisted test ID")
    if note["disposition"] == "RECOMMEND_FOR_OWNER_DECISION":
        _need(report["status"] == "READY_FOR_OWNER_REVIEW" and set(ids) == all_ids,
              "cannot recommend decision with failures or incomplete case review")
    return {
        "status": "REVIEW_ANNOTATION_ONLY_NOT_AUTHORIZATION",
        "report_sha256": report_hash,
        "note_sha256": canonical_digest(note),
        "note": copy.deepcopy(note),
        "reviewer_identity_verified": False,
        "owner_accepted": False,
        "workflow_published": False,
        "execution_authorized": False,
        "knowledge_approved": False,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_design", type=Path)
    parser.add_argument("patch", type=Path)
    parser.add_argument("suite", type=Path)
    parser.add_argument("--review-note", type=Path)
    args = parser.parse_args(argv)
    try:
        report = assess_revision(load_design(args.base_design), load_patch(args.patch),
                                 load_suite(args.suite))
        payload = report
        if args.review_note:
            payload = {"evidence_report": report,
                       "review_annotation": attach_review_note(
                           report, load_review_note(args.review_note))}
    except (DesignError, OSError, ValueError, UnicodeError, RecursionError) as exc:
        print(f"REGRESSION_REJECTED: {ascii(str(exc))}", file=sys.stderr)
        return 2
    print(json.dumps(payload, ensure_ascii=True, sort_keys=True))
    return 0 if report["status"] == "READY_FOR_OWNER_REVIEW" else 1


if __name__ == "__main__":
    raise SystemExit(main())
