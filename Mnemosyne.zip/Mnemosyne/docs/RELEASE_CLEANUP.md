# HWI GitHub source-publication cleanup

This is a **source-first repackaging** of `HWI_STABILISATION_47b9e7f_2026-11-13.zip`. It is **not** the original signed/accepted research archive, nor an independently accepted production release. The original archive remains unchanged outside this folder.

## Excluded from the public source tree

- `BASELINE` (1 files, 19,351,742 bytes): Embedded 19 MB historical release snapshot; original supplied archive remains the provenance source.
- `GIT` (4 files, 2,087,791 bytes): Historical Git bundles should be managed in a separate archive, not a fresh source repository.
- `BUILD_VERIFICATION.json` (1 files, 4,500 bytes): Packaging verification of the original consolidated distribution, invalid after source cleanup.
- `USER_MANUAL.pdf` (1 files, 333,376 bytes): Generated duplicate of the kept editable Markdown manual.
- `USER_MANUAL.docx` (1 files, 31,350 bytes): Generated duplicate of the kept editable Markdown manual.
- `CODE/APPROVED_WIKI_CORE/personal_wiki_core-0.0.0+hwi02.dist-info` (5 files, 11,826 bytes): Installed wheel metadata, not source code; authoritative CC0 legal code copied to root LICENSE.
- `CODE/DUALFLOW/hwi_i02` (24 files, 152,225 bytes): Older duplicated launcher, content-evaluation, and documentation snapshot.
- `CODE/DUALFLOW/accepted_corrections` (3 files, 59,799 bytes): Historical patch files for accepted candidate, not live code.
- `CODE/DUALFLOW/refactor` (118 files, 607,119 bytes): Historical refactor reports, diff snapshots, patches and logs (not needed by normal runtime/tests).
- `CODE/DUALFLOW/tools/verify_refactor_checkpoints.py` (1 files, 4,493 bytes): Historical refactor verifier depends on removed GOALS.json.
- `CONTENT_EVAL/PRIOR_V3_SEMANTIC_REFINEMENT_REFERENCE.zip` (1 files, 37,565 bytes): Nested historical comparison ZIP, not active source or a test fixture.

Historical acceptance records were moved into `docs/history/`. `USER_MANUAL.md`, source code, tests, simulation fixtures, human-review code, and main launcher scripts were retained. The original `README_FIRST.md` has been retained as `docs/history/CONSOLIDATED_ARCHIVE_README.md` for provenance (its original run instructions refer to the archived package, not this source tree).

The source-only package regenerates `SHA256_MANIFEST.json` so `VERIFY_ARCHIVE.py` checks the **new** package, not the removed historical bundles. This is a technical integrity check and does **not** convey approval of governance/formation additions. Do not use the new manifest as evidence of acceptance of the archived baseline or current code.

Only licensing metadata, documentation and packaging were edited. The remaining Python runtime, wiki, governance, formation, and evaluation source files were not intentionally modified. Run the offline suites in your target environments before publishing or deploying.
