#!/bin/bash
# Advisory-only formation; requires explicit operator confirmation; never edits wiki.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT/CODE/DUALFLOW:$ROOT/CODE/APPROVED_WIKI_CORE:$ROOT/CODE/APPROVED_AGENT_PROVIDER${PYTHONPATH:+:$PYTHONPATH}"
exec "${HWI_PYTHON:-python3}" -B -m hwi_formation "$@"
