#!/bin/sh
# HWI install: records this machine's role once (host_profile.json).
# Never creates keys, policies or notebooks. POSIX sh; Linux and macOS.
#   sh INSTALL.sh                       interactive: asks for this machine's role
#   sh INSTALL.sh --profile FILE        rebuild from a saved host_profile.json
#   sh INSTALL.sh --help                all options
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
case "$(uname -s)" in
  Linux|Darwin|FreeBSD|NetBSD|OpenBSD) ;;
  *) echo "INSTALL REFUSED: unsupported platform $(uname -s); supported: Linux, macOS" >&2; exit 2 ;;
esac
PY=${HWI_PYTHON:-python3}
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "INSTALL REFUSED: $PY not found; install Python 3.11 or newer" >&2; exit 2
fi
if ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
  echo "INSTALL REFUSED: Python 3.11 or newer is required ($("$PY" -V 2>&1))" >&2; exit 2
fi
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH="$ROOT/CODE/DUALFLOW:$ROOT/CODE/APPROVED_WIKI_CORE:$ROOT/CODE/APPROVED_AGENT_PROVIDER"
export PYTHONDONTWRITEBYTECODE PYTHONPATH
exec "$PY" -B -m hwi_governance.install "$@"
