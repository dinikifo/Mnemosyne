# HWI — Formation DiagnosticRule experiment

This is a complete **experimental** HWI candidate snapshot based on CMR-12
`ceb6191` plus diagnostic-rule commit `48f29fc`. It is NOT production accepted.

Changed feature: `CODE/DUALFLOW/hwi_formation/diagnostic_rules.py` and
`good_practices.py`. The diagnostic rule chain handles missing purpose
fields and possibly broad tasks; advisory output is unchanged. The current
router, Formation state machine, governance/writer permissions, and approved
agent and wiki sources remain untouched.

Run `python3 VERIFY_ARCHIVE.py` first. The file checks SHA-256 hashes and
exact payload inventory. Approved provider/wiki code is under
`CODE/APPROVED_AGENT_PROVIDER` and `CODE/APPROVED_WIKI_CORE`. Old release
hash metadata is stored under
`ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY`; it is NOT the verifier for this
new snapshot. The Git bundle at `GIT/HWI_DIAGNOSTIC_RULES.bundle` contains the
complete source history and the new feature branch.

To run the diagnostic tests with dependencies installed:

```
PYTHONPATH="CODE/DUALFLOW:CODE/DUALFLOW/tools:CODE/APPROVED_AGENT_PROVIDER:CODE/APPROVED_WIKI_CORE" \
  python3 -B -m unittest -q hwi_formation.test_diagnostic_rules \
    hwi_formation.test_good_practices
```

This snapshot is for offline review; it does not install components,
change notebooks, commission agents, or confer authority.
