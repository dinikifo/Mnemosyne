# HWI CMR-05 — Consolidated codebase snapshot

This is a **consolidation snapshot**, not a new accepted or production-approved release.

- **Checkpoint:** CMR-05 (transition/effect contract planning complete).
- **Progress:** 5/12 stages = 41.67%; router implementation not started (0/11 implementation stages).
- **Source branch:** `plan/typed-router-consolidation`.
- **Source commit:** `694bf7e7dd0ef1c0e19b6a8abc9dff1e2f15a8a8`.
- **Original baseline:** `47b9e7fe9d64a7cdb6a9d725e3191c46cf715ddd`.

## Directory map

- `CODE/DUALFLOW/`: complete tracked worktree from the CMR-05 planning branch (262 baseline files + 20 CMR planning/contract files).
- `CODE/APPROVED_AGENT_PROVIDER/`: byte-preserved approved agent provider from the original release archive.
- `CODE/APPROVED_WIKI_CORE/`: byte-preserved approved wiki core from the original release archive.
- Top-level launchers, evidence, documentation, and historical Git reference bundles: preserved from the original source archive.
- `GIT/HWI_CMR05_TYPED_ROUTER_PLANNING.bundle`: recoverable Git planning history for the new checkpoint.

## Integrity and acceptance distinction

The original release archive passed its own 385/385 SHA-256 verification before composition. The original release verifier, original SHA-256 manifest and build verification are retained under `ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY/` for provenance, **not** for verifying this altered snapshot. Use this package's `VERIFY_PACKAGE.py` and `PACKAGE_SHA256.json` instead.

The approved core code, Dual-Flow runtime code, and accepted baseline remain unchanged. The snapshot adds planning documents and contract tests only. It is not an independent macOS or production validation.

For source-tracked CMR progress, see `CODE/DUALFLOW/docs/consolidation/PROGRESS.json`. The companion artifact ZIP contains checkpoint documents, tests, logs, and historical planning bundles.
