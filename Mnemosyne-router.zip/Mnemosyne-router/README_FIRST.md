# HWI consolidated release — governance candidate with recovery and Formation experiments

**12 November 2026** (consolidated with governance review fixes, the repository interface, interrupted-submission recovery and an experimental Formation branch, 13 November 2026)

This release combines the previously accepted **10/10 HWI Dual-Flow research
baseline** (`e1af2e0`) with a **new, separately unaccepted governance candidate**.
There is **no** new human acceptance, deployment, production certification,
PVS/SEC-02 permission, protected wiki write, or independent proof of LLM truth.
The new source is committed only on local feature and experiment Git branches
for reproducibility (see below). The accepted base is unchanged.

## New capability

- Task-specific fitness contract (v2): exact model/configuration pins, per-case
  expected evidence digests, at least one mandatory critical case, a pass floor
  of 50%, an expiry date and a proposal quota.
- Separate owner signature for a task-fitness assessment, verified against an
  operator-provisioned workspace pin (`fitness_policy/`); does not grant
  execution or wiki authority.
- Human review queue backed by the unchanged approved HWI-07 proposal ledger.
- PERSONAL.WIKI JSON import artifact titled **For Human Review and Approval**;
  proposal content rendered inert, manually imported; **not** a live wiki view
  or authority. Each proposal shows whether its fitness gate re-verifies.
- Exact before/after review; signed wiki application through unchanged HWI-08
  one-use revision-checked writer; history inspection and propose-to-restore.
- Restoration of an active record requires another signed proposal and retains
  append-only history; no deleted-record restoration through this helper.

Governance review fixes of 13 November 2026 are listed in
`GOVERNANCE_RELEASE_NOTES.md`.
The repository interface (single boundary to the approved core, wiki contract
tests, SQLite gate store, `queue-decommission`, `INSTALL.sh`) follows on top;
see the same file. Check each machine with `bash RUN_GATE_A_NATIVE.command --label <name>`,
then set it up with `sh INSTALL.sh`.

## Latest additions (13 November 2026, experimental, not accepted)

- **Interrupted-submission recovery.** Each gated submission saves its exact
  request with its quota slot; `queue-gate-recover` diagnoses an interruption
  read-only and, with `--apply`, binds only unique exact matches. Recovered
  bindings stay visibly marked `OPERATOR_RECOVERY`. No slot is ever released by
  recovery, and the two databases are still not one transaction (USER_MANUAL §9).
- **`queue-status`:** a compact read-only summary of proposals, gate status
  and binding, without proposal text.
- **Agent Formation** (`RUN_AGENT_FORMATION.command`, `hwi_formation/`): an
  advisory first-run purpose conversation and advisory good-practice review,
  through the same repository boundary. Experimental; its practice-card design
  is open for user testing.

## Start here

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_ALL_OFFLINE.command
bash RUN_GOVERNANCE.command --help
bash RUN_GATE_A_NATIVE.command --label <this-machine>
```

For use with real notebooks, complete the operator key enrollment and wiki
initialization steps in `USER_MANUAL.pdf` or `USER_MANUAL.docx`. All task-evidence
and signing inputs are explicitly supplied by the operator. Offline tests use
synthetic temporary notebooks, **never** the user's PERSONAL.WIKI stores.

## Source and approvals

- `CODE/DUALFLOW` = exact `experiment/gate-interruption-recovery` tree at
  `47b9e7f` (Formation conversation as an explicit state machine, on top of
  `79c45ea`: Ollama-independent outage test, on top of `e536e48`: macOS
  temp-symlink test fix, on top of `46339d3`: resume at a
  stored model question, on top of `c4f3547`: guided
  questions kept with their answers, on top of `a4d2012`:
  model-written Formation questions off by default, on top of
  `def6435`: fresh-only session creation and a stricter question check on
  `d61e988`, the deterministic contract test 9 on `bcd7103`, the Formation
  concurrency and review fixes on top of `dc5adc5`,
  which holds the review fixes on top of the recovery commit `df6ec53`, the
  Formation merge `ab51cd7` and the governance candidate `061c9cc`).
- `CODE/APPROVED_WIKI_CORE`, `CODE/APPROVED_AGENT_PROVIDER` = byte-identical
  separately approved source from the accepted HWI 10/10 package.
- `GIT/HWI_DUALFLOW_GOVERNANCE_CANDIDATE.bundle` = accepted history **plus**
  the separately unaccepted candidate commits `9f38af5`, `b00411b` and `061c9cc`.
- `GIT/HWI_SQLITE_FORMATION_INTEGRATED_EXPERIMENT.bundle` = Formation branches
  and their merge onto `061c9cc` (`ab51cd7`).
- `GIT/HWI_GATE_INTERRUPTION_RECOVERY_2026-11-13.bundle` = complete history of
  `experiment/gate-interruption-recovery` up to `47b9e7f`.
- `GIT/HWI_DUALFLOW_ACCEPTED_10_OF_10.bundle` = original accepted history.
- `ACCEPTANCE_DECISION.md`, `ACCEPTANCE_LEDGER.json` = prior accepted 10/10
  checkpoint and **not an approval of the new governance candidate**.

A human reviewer must still accept the new scope, native Mac tests, credential
custody, and production environment before deployment. Independent HWI C1–C14
and Linux RC-05 gates remain open, as applicable.
