# HWI-I02 — owner acceptance, local Git checkpoint (2026-11-12)

## Decision and limits

The owner explicitly instructed: “consolidate the codebase and mark it accepted.
any other fixes i will tackle during production along with any other”. This is
authorization to accept and commit the **fixed ten-goal dual-flow research
workstream**, including HWI-I02, with acknowledged limitations moved to the
production-hardening backlog. It is **not** a claim that the unverified model
output is correct or that the local human review worksheet has been approved.

The resulting scoped roadmap is **10/10 accepted and locally committed (100%)**.
The original HWI C1–C14 program and Linux RC-05 acceptance gates remain separate
and are not changed or overridden. No deployment, remote push, protected
PERSONAL.WIKI write, PVS approval, or expanded SEC-02 execution permission is
authorized by this acceptance.

## Exact implementation lineage

- Prior scoped baseline, 9/10 accepted: `126c4db5d39b8c5c4a41ab343912fd015452bb1e`.
- Consolidated HWI-I02 implementation commit:
  `c320f8b6ec8be2e34e8f3f5433ebd16b367c6f2c`.
- This acceptance-checkpoint commit follows the implementation commit.
- The approved CR03 agent source and PERSONAL.WIKI core distributed for Mac
  testing are supplied unchanged from the prior sealed handoff, and are **not**
  re-approved, modified or vendor-updated by this checkpoint.

## Evidence used, without exaggerating the result

1. Genuine local `llama3.1:8b` patch trial v0: 0/3 structurally accepted.
   A prompt-contract v1 change yielded 3/3 structurally valid **identical**
   alternative patches, 0/3 exact synthetic reference matches. The trial
   report digest was
   `ed7b2de1fdefda564f399fc48a8e9ad3b412b07e24a48f77fb285db9fa6a93e6`.
2. The first real content trial matched the two predeclared labels and exact
   quotations, but its model-written summary called the `NOT_CONFLICT` issue
   a conflict. The original report digest was
   `57399007ab3dde7b1cc05eb810027cc2818015a2e315c4e26e398f44ada970b9`.
3. The corrected content format removes the free-text overall summary and
   deterministically derives the classification ledger. In the later native
   Mac v1 trial, `platform_scope` was classified `UNRESOLVED` instead of the
   predeclared `NOT_CONFLICT`; the result was correctly
   `CONTENT_CHECK_FAILED`, digest
   `7643fcb33e56638de8bd776d5400973b4dd42b85ae783e551bac573b9f7efa99`.
4. The failed-v1 worksheet and re-audit path was corrected to preserve
   mechanical failure with pending human verdicts; acceptance is **not** a
   retroactive approval of that trial. User's original report remains
   unchanged, and raw responses are not committed as acceptance authority.
5. Offline regression evidence: 335 dual-flow tests, 65 content tests and 16
   Mac-launcher tests pass in the Linux-based packaging environment. A prior
   native Mac package passed 331 dual-flow and 16 launcher tests (4 skips),
   while the latest failed-v1 review correction has not yet been natively
   rechecked on Mac. Fixture and HTTP mock tests do not attest real-model
   semantic reliability.

## Deferred, non-waived work

See `PRODUCTION_HARDENING_BACKLOG.md`. Open items include semantic
classification robustness, adversarial/held-out evidence tests, native macOS
recheck of the latest package, Linux RC-05 qualification, authentication of
human reviewer and model identity, and production monitoring/recovery.

**Status at acceptance:** Scoped HWI-I02 research implementation ACCEPTED;
model claims not independently verified; trials not approved for knowledge
publication; real-world execution and protected write authority unchanged.
