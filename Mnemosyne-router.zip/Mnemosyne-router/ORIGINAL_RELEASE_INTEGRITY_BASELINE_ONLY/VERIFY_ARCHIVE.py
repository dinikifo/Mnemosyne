#!/usr/bin/env python3
"""Check every released file against SHA-256 manifest, fail closed."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest['schema']=='hwi.dualflow.release_integrity.v1'
expected=manifest['files']
actual={}
for p in root.rglob('*'):
    if p.is_symlink():raise SystemExit('SYMLINK_FORBIDDEN '+str(p))
    if not p.is_file() or p.name=='SHA256_MANIFEST.json':continue
    rel=p.relative_to(root).as_posix()
    if any(part in ('.','..') for part in p.relative_to(root).parts):raise SystemExit('BAD_PATH '+rel)
    actual[rel]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
if expected!=actual:
    absent=sorted(set(expected)-set(actual))
    extraneous=sorted(set(actual)-set(expected))
    mismatch=sorted(k for k in expected.keys()&actual.keys() if expected[k]!=actual[k])
    raise SystemExit(f'VERIFY_FAILED missing={absent[:4]} extra={extraneous[:4]} mismatched={mismatch[:4]}')
print(f'VERIFIED {len(actual)}/{len(expected)} payloads SHA-256 matched')
