#!/usr/bin/env python3
"""Verify this staging package against its own SHA-256 manifest."""
from pathlib import Path
import hashlib
import json
import sys
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'PACKAGE_SHA256.json').read_text(encoding='utf-8'))
assert manifest['schema'] == 'hwi.cmr.package.sha256.v1'
expected = manifest['files']
actual = {}
for file in sorted(root.rglob('*')):
    if file.is_symlink():
        raise SystemExit('SYMLINK_FORBIDDEN ' + str(file))
    if not file.is_file() or file.name == 'PACKAGE_SHA256.json':
        continue
    rel = file.relative_to(root).as_posix()
    actual[rel] = {'bytes': file.stat().st_size, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()}
if expected != actual:
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    bad = sorted(k for k in expected.keys() & actual.keys() if expected[k] != actual[k])
    raise SystemExit(f'FAILED missing={missing[:10]} extra={extra[:10]} mismatch={bad[:10]}')
print(f'VERIFIED {len(actual)}/{len(expected)} files')
