# Production follow-up for HWI governance candidate

This is not a universal-model-competence checklist. Each deployment needs a
**task-specific fitness assessment** with representative cases and independently
reviewed evidence; evaluate new models/targets/tasks within their own scope.

1. **Human acceptance of this governance extension** after native macOS tests
   and independent review of signed-write and restoration security boundaries.
2. **Operator identity and secret custody**: independent Ed25519 enrollment,
   recovery/rotation, revocation policy, private key isolation, and security
   testing of the runtime and file permissions. Signatures do not prove consent.
3. **Wiki UX**: optional live read-only review-section provider, refreshing
   pinned queue snapshots without automatically editing wiki content. The
   current release uses manual JSON import with content made inert inside a
   fenced code block. Consider, under separate core approval, teaching the
   approved PERSONAL.WIKI renderer to honour `type: text/plain`.
4. **Task fitness**: real representative test runs and human-reviewed evidence;
   revised acceptance thresholds whenever task, model, tools or sources change.
   No requirement to test unrelated domains to claim fitness for one task.
5. **Semantic expectations**: task-defined report/workflow obligations;
   independently verify that successful simulations correspond to real outcomes.
6. **Operational recovery**: restore rehearsal, backup verification, signed
   application receipt reconciliation and uncertain-outcome runbook.
7. **Environment gates**: native Mac verification, original HWI C1–C14 and
   Linux RC-05 where applicable, and explicit least-privilege deployment review.
8. **Optional extension**: separately reviewed deleted-post re-creation
   through a new proposal, never unrestricted history rollback.
9. **Residual gate limits (from the 13 Nov 2026 review)**: the fitness gate
   lives in the CLI; direct HWI-07/library submissions remain possible and are
   shown as `UNGATED` (or `UNVERIFIED` if they copy a real reference). Gate
   records live in the operator workspace: a process that can write there is
   outside this control's threat model. Homoglyphs and combining-mark
   overlays in review text are not flagged. Quota reservations use SQLite
   locking in the per-installation governance database; like any SQLite file it must live on a local disk, not a network
   filesystem.
   Fitness-key rotation/revocation: re-pinning a new key turns old receipts
   `UNVERIFIED` by design; a documented rotation procedure is still needed.
   Listing/export pages through at most ~10,100 ledger proposals (HWI-07
   offset bound) and fails closed beyond that; archival is not designed yet.

10. **Core release candidates (A2)** pinned by `test_wiki_contract.py`:
   renderer honours `type: text/plain`; a public read-only HWI-08 receipt query
   (removes the repository's raw SQL); the ledger accepting gate records inside
   its own transaction (removes the exit-3 gap); a "generated page" import mode.
10. **Notebook instance identity (A2, found 13 Nov 2026)**: scope = path +
   device + inode, and filesystems can reuse inode numbers after delete +
   restore (about 1 in 20 on ext4), so a restored notebook can inherit the old
   ledger. Fix: a stored instance ID in the notebook. Until then:
   `queue-decommission` before deleting or replacing a notebook.

Accepted Dual-Flow 10/10 status is unchanged. This extension is a candidate.
