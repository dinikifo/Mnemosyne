#!/bin/bash
# Gate A native verification for THIS machine (macOS, Linux PC, Raspberry Pi).
# Temporary folders and throwaway keys only; never touches real notebooks, keys,
# policies or ~/.config/hwi. Writes a JSON report to ~/hwi-gate-a/.
#   bash RUN_GATE_A_NATIVE.command --label mac-m2
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
export PYTHONDONTWRITEBYTECODE=1
exec "${HWI_PYTHON:-python3}" -I -B "$ROOT/CODE/DUALFLOW/tools/gate_a_native.py" "$@"
