#!/bin/bash
# Full offline checks, no model calls, network access or real notebooks.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT/CODE/DUALFLOW:$ROOT/CODE/APPROVED_WIKI_CORE:$ROOT/CODE/APPROVED_AGENT_PROVIDER${PYTHONPATH:+:$PYTHONPATH}"
export HWI_PYTHON="${HWI_PYTHON:-python3}"
bash RUN_ON_MAC.command offline
bash RUN_CONTENT_EVAL.command offline
"$HWI_PYTHON" -B -m unittest -q hwi_governance.test_governance hwi_governance.test_wiki_contract hwi_governance.test_repository_layer hwi_governance.test_install hwi_governance.test_gate_recovery
"$HWI_PYTHON" -B -m unittest -q hwi_formation.test_formation hwi_formation.test_formation_fixes hwi_formation.test_dialogue_machine hwi_formation.test_good_practices hwi_formation.test_repository_integration
