# RC-04 test evidence (not acceptance)

| Group | Completed tests passed | Additional subtests | Notes |
|---|---:|---:|---|
| RC-04 application, RC-03 interaction, supervised/closed SEC-02, C6 guard, HWI-03 | 222 | 0 | `refactor/rc04_test_logs/application_security.log` |
| Agent recovery, SEC-02 recovery and runtime | 166 | 9 | `refactor/rc04_test_logs/recovery_security.log` |
| C4, C13, C14 | 47 | 15 | `refactor/rc04_test_logs/pvs_c4_c13_c14.log` |
| C5 independent review | 33 | 7 | `refactor/rc04_test_logs/pvs_c5.log` |
| C6 real PVS/C7 startup | 13 | 10 | `refactor/rc04_test_logs/pvs_c6_c7.log` |
| **Distinct completed tests** | **481** | **41** | No skips credited |

Additional independent checkpoint-tool suite: **19 tests and 11 subtests passed**. The initial tool run found stale RC-01-only assertions; revised tests verify the frozen source lock through the recorded RC-02/RC-03/RC-04 overlays.

An earlier combined PVS attempt timed out; saved partial output is **not** a pass. Full optional-dependency suite, independent human acceptance and genuine-model behavior are out of scope. Refactor tool checks and manifest checks are recorded separately.
