#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$ROOT/CODE/APPROVED_AGENT_PROVIDER:$ROOT/CODE/APPROVED_WIKI_CORE${PYTHONPATH:+:$PYTHONPATH}"
RUNNER="$ROOT/CODE/DUALFLOW/tools/run_dualflow_local.py"
for ARG in "$@"; do
 if [[ "$ARG" == "--list-models" || "$ARG" == "--help" || "$ARG" == "-h" ]]; then
  exec python3 "$RUNNER" "$@"
 fi
done
BASE="$ROOT/CODE/DUALFLOW/docs/dualflow/examples"
exec python3 "$RUNNER" \
 --design "$BASE/evidence_review.json" \
 --task-file "$BASE/evidence_review.model_task.txt" \
 --reference-patch "$BASE/evidence_review.patch.json" \
 --regression "$BASE/evidence_review.regression.json" \
 --application "$BASE/evidence_review.application.json" \
 "$@"
