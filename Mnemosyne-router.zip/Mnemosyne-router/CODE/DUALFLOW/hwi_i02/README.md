# HWI-I02 — accepted source components (local, scoped)

This directory contains the content-evaluation source, macOS launcher source,
fixtures and tests accepted for the **dual-flow research roadmap**. The Git
repository's `tools/` and `docs/dualflow/` contain the corresponding local
Ollama workflow-patch evaluator and benchmark workflow.

The macOS distribution overlays this single Git source tree into `CODE/DUALFLOW/`
and copies these assets into `CONTENT_EVAL/`, `MAC_TOOLS/`, and the distribution
root (`RUN_*.command`, `MAC_SETUP.command`). The unchanged approved agent and
wiki sources are supplied as separately governed dependencies from the sealed
CR03 handoff, **not** as newly accepted or modified source.

The sources here are not intended to run the macOS launcher directly from this
folder: its root-relative `CODE/` layout is established by the distribution
packaging step. Run the packaged release to exercise the full integration.

Accepted research increment does not mean that all model classifications are
correct, that semantic ground truth has been established, that Linux RC-05 has
passed, or that any deployment/protected knowledge writes are authorized.
See `docs/dualflow/HWI_I02_ACCEPTANCE_2026-11-12.md` for limitations and
production follow-ups.
