#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT/CODE/APPROVED_AGENT_PROVIDER:$ROOT/CODE/APPROVED_WIKI_CORE${PYTHONPATH:+:$PYTHONPATH}"
cd "$ROOT/CODE/DUALFLOW"
exec python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
