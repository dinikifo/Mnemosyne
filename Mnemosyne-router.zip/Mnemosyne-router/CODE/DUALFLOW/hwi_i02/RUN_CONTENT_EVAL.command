#!/bin/bash
# Offline source-content evaluation, or explicit local Ollama inference. No writes to HWI stores.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PY="${HWI_PYTHON:-python3}"
if [[ $# -eq 0 || "${1:-}" == 'offline' ]]; then
  export PYTHONPATH="$ROOT/CONTENT_EVAL${PYTHONPATH:+:$PYTHONPATH}"
  "$PY" -B -m unittest discover -s "$ROOT/CONTENT_EVAL" -p 'test_content*.py' -v
  exit 0
fi
if [[ "$1" == 'trial' ]]; then
  shift
  MODEL="${1:-}"
  [[ -n "$MODEL" ]] || { echo 'Usage: bash RUN_CONTENT_EVAL.command trial MODEL' >&2; exit 2; }
  shift
  if [[ $# -ne 0 ]]; then echo 'Unexpected extra arguments' >&2; exit 2; fi
  mkdir -p "$HOME/HWI-DualFlow-Trials"
  stamp="$(date -u '+%Y%m%dT%H%M%SZ')"
  # Existing result cannot be overwritten; loop makes the filename practically unique.
  report="$HOME/HWI-DualFlow-Trials/content-$stamp-$$.json"
  status=0
  "$PY" -B "$ROOT/CONTENT_EVAL/evaluate_report_content.py" --model "$MODEL" --output "$report" || status=$?
  if [[ -f "$report" ]]; then
    echo "Result saved privately: $report"
    echo "Next: inspect result and generate worksheet with --worksheet and --output."
  fi
  exit "$status"
fi
exec "$PY" -B "$ROOT/CONTENT_EVAL/evaluate_report_content.py" "$@"
