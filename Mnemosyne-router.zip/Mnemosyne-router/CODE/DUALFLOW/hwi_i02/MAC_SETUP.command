#!/bin/bash
# Explicit optional setup. Does NOT download or run any Ollama models.
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:/Library/Frameworks/Python.framework/Versions/Current/bin:$PATH"
VENV="$HOME/Library/Application Support/HWI-DualFlow/venv"
PY="${HWI_PYTHON:-}"
if [[ -z "$PY" ]]; then
  for candidate in python3.14 python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; assert sys.version_info >= (3,11)' >/dev/null 2>&1; then PY="$(command -v "$candidate")"; break; fi
  done
fi
if [[ -z "$PY" ]]; then
  echo 'Python 3.11+ not found. Install from https://www.python.org/downloads/macos/ (Apple Silicon or universal2).' >&2
  exit 2
fi
printf 'Mac system: %s  hardware: %s\n' "$(uname -s)" "$(uname -m)"
"$PY" -c 'import platform,sys; print("Python:", sys.version.split()[0], "architecture:",platform.machine(),"executable:",sys.executable)'
echo "Will create a venv OUTSIDE the verified archive: $VENV"
echo 'Will use pip to install the HTTP dependency requests>=2.28,<3 (network may be required).'
if [[ ${1:-} != '--yes' ]]; then
  if [[ ! -t 0 ]]; then echo 'Run interactively or pass --yes for noninteractive setup.' >&2; exit 2; fi
  read -r -p 'Proceed with local Python setup? [y/N] ' answer
  [[ "$answer" == 'y' || "$answer" == 'Y' ]] || exit 0
fi
mkdir -p -m 700 "$(dirname "$VENV")"
if [[ ! -e "$VENV/bin/python3" ]]; then "$PY" -m venv "$VENV"; fi
"$VENV/bin/python3" -m pip install 'requests>=2.28,<3'
echo 'Python environment ready. Run RUN_ON_MAC.command or bash RUN_ON_MAC.command doctor.'
if [[ -t 0 ]]; then read -r -p 'Press Return to close this window...' unused || true; fi
