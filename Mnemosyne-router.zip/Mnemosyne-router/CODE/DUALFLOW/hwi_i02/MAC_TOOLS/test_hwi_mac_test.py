"""Portable contract tests for Mac testing launcher (no actual Ollama or Mac needed)."""
from __future__ import annotations
import argparse
import contextlib
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import hwi_mac_test as mac


class LauncherContract(unittest.TestCase):
    def test_cloud_tag_rejected(self):
        for model in ('x:cloud','x:ClOuD','gpt-oss:120b-cloud','x-cloud'):
            with self.subTest(model=model), self.assertRaises(mac.MacHarnessError):
                mac.valid_model(model)

    def test_normal_local_model_names_pass(self):
        for model in ('llama3.2:3b','gemma3:4b','qwen2.5:7b','model/latest'):
            self.assertEqual(mac.valid_model(model), model)

    def test_model_shell_injection_denied(self):
        for model in ('model; touch pwned', 'x$(id)', 'x\n--output', '--model'):
            with self.subTest(model=model), self.assertRaises(mac.MacHarnessError):
                mac.valid_model(model)

    def test_cloud_rejected_before_subprocess_or_report(self):
        args=argparse.Namespace(model=['x:cloud'],repeats=1,output=None,pin_model=[])
        with patch.object(mac.importlib.util, 'find_spec', return_value=object()),\
             patch.object(mac,'run_tool') as runner:
            with self.assertRaises(mac.MacHarnessError):
                mac.trial(args)
            runner.assert_not_called()

    def test_repeats_bounded(self):
        args=argparse.Namespace(model=['gemma3:4b'],repeats=0,output=None,pin_model=[])
        with patch.object(mac.importlib.util, 'find_spec', return_value=object()),\
             patch.object(mac,'run_tool') as runner:
            with self.assertRaises(mac.MacHarnessError):
                mac.trial(args)
            runner.assert_not_called()

    def test_no_overwrite_of_existing_trial_report(self):
        with tempfile.TemporaryDirectory() as td:
            existing=Path(td)/'report.json'
            existing.write_text('DO NOT CHANGE')
            args=argparse.Namespace(model=['gemma3:4b'],repeats=1,output=str(existing),pin_model=[])
            with patch.object(mac.importlib.util, 'find_spec', return_value=object()),\
                 patch.object(mac,'run_tool') as runner:
                with self.assertRaises(mac.MacHarnessError):
                    mac.trial(args)
                runner.assert_not_called()
                self.assertEqual(existing.read_text(),'DO NOT CHANGE')

    def test_output_created_exclusively_and_private(self):
        with tempfile.TemporaryDirectory() as td:
            file=Path(td)/'case.json'
            mac.save_new_private(file,'{}\n')
            self.assertEqual(file.read_text(),'{}\n')
            self.assertEqual(file.stat().st_mode & 0o777,0o600)
            with self.assertRaises(FileExistsError):
                mac.save_new_private(file,'hijack')

    def test_model_tags_do_not_follow_remote_redirect(self):
        import urllib.request
        from unittest.mock import MagicMock
        with patch.object(urllib.request.OpenerDirector,'open', side_effect=urllib.error.HTTPError(mac.ENDPOINT+'/api/tags', 302, 'redirect', {}, None)):
            with self.assertRaises(mac.MacHarnessError):
                mac.local_tags()

    def test_model_metadata_does_not_use_proxy_handler_env(self):
        class FakeReply:
            status=200
            def read(self,n):
                return b'{"models": []}'
            def __enter__(self):return self
            def __exit__(self,*a):return False
        class FakeOpener:
            def open(self, request, timeout):
                self.request=request
                return FakeReply()
        fake=FakeOpener()
        with patch.object(mac.urllib.request,'build_opener',return_value=fake) as build:
            self.assertEqual(mac.local_tags(), {'models':[]})
            self.assertEqual(fake.request.full_url, 'http://127.0.0.1:11434/api/tags')
            self.assertIsInstance(build.call_args.args[0], mac.urllib.request.ProxyHandler)
            self.assertIsInstance(build.call_args.args[1], mac.RefuseRedirect)

    def test_launch_subprocess_no_shell_and_explicit_python(self):
        from subprocess import CompletedProcess
        with patch.object(mac.subprocess,'run',return_value=CompletedProcess([],0)) as run:
            mac.run_tool(['--help'])
            args,kwargs=run.call_args
            self.assertEqual(args[0][:3],[sys.executable,'-B','--help'])
            self.assertNotIn('shell',kwargs)
            self.assertEqual(kwargs['env']['PYTHONPATH'].split(':')[0],str(mac.ROOT/'CODE'/'APPROVED_AGENT_PROVIDER'))
            self.assertEqual(kwargs['env']['PYTHONDONTWRITEBYTECODE'],'1')

    def test_review_requires_report_and_valid_json(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'input.json'; p.write_text('{}')
            destination=Path(td)/'out.json'
            from subprocess import CompletedProcess
            args=argparse.Namespace(report=str(p),output=str(destination))
            with patch.object(mac,'run_tool',return_value=CompletedProcess([],0,stdout='not-json',stderr='')):
                with self.assertRaises(json.JSONDecodeError):
                    mac.review(args,assess=False)
            self.assertFalse(destination.exists())

    def test_review_requires_all_trial_report_pins_unchanged(self):
        # Integration smoke with the real synthetic fixture and auditor (no model).
        report=mac.EXAMPLES/'synthetic_http_fixture.local_trial.json'
        self.assertTrue(report.is_file())
        with tempfile.TemporaryDirectory() as td:
            worksheet=Path(td)/'review.json'
            args=argparse.Namespace(report=str(report),output=str(worksheet))
            self.assertEqual(mac.review(args,assess=False),0)
            data=json.loads(worksheet.read_text())
            self.assertTrue(all(j['verdict']=='PENDING' for j in data['judgments']))
            self.assertFalse(data['approval_requested'])
            assessment=Path(td)/'assessment.json'
            args2=argparse.Namespace(report=str(report),review=str(worksheet),output=str(assessment))
            self.assertEqual(mac.review(args2,assess=True),0)
            self.assertFalse(json.loads(assessment.read_text())['hwi_i02_acceptance_established'])


class ResponseDiagnosticTests(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0, str(mac.TOOLS))
        import diagnose_model_failure as d
        from check_dualflow_design import load_design
        self.d = d
        self.base = load_design(mac.EXAMPLES/'evidence_review.json')
        self.good = json.loads((mac.EXAMPLES/'evidence_review.patch.json').read_text())

    def test_valid_patch_categorized_without_model_text(self):
        result = self.d.categorize(json.dumps(self.good), self.base)
        self.assertEqual(result['category'], 'STRUCTURALLY_VALID_NOT_INDEPENDENTLY_VERIFIED')
        self.assertNotIn('raw_output', result)

    def test_invalid_json_and_duplicate_keys(self):
        for value in ('{', '{"a":1,"a":2}'):
            with self.subTest(value=value):
                self.assertEqual(self.d.categorize(value,self.base)['category'],
                                 'INVALID_JSON_OR_DUPLICATE_KEYS')

    def test_wrong_base_reports_safe_contract_error(self):
        broken = dict(self.good, base_sha256='0'*64)
        result = self.d.categorize(json.dumps(broken),self.base)
        self.assertEqual(result['category'],'PATCH_CONTRACT_REJECTED')
        self.assertIn('stale base SHA-256',result['validator_rule'])

    def test_single_trial_diagnostic_does_not_persist_response(self):
        from dataclasses import dataclass
        @dataclass
        class Reply:
            content: str
            model: str = 'local-fixture'
            prompt_tokens: int = 10
            completion_tokens: int = 30
        class Provider:
            def chat(self,**kwargs):
                return Reply(json.dumps(self_good))
        self_good = self.good
        result = self.d.one_shot(provider=Provider(), model='local-fixture',
             base=self.base, task='Add explicit contradiction checks to reports.')
        self.assertEqual(result['status'],'VALID_CANDIDATE_UNTESTED')
        self.assertFalse(result['raw_model_text_saved'])
        self.assertFalse(result['workflow_executed'])
        self.assertFalse(result['knowledge_approved'])


if __name__=='__main__':
    unittest.main()
