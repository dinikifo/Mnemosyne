#!/usr/bin/env python3
"""One-shot local Ollama schema diagnostic. No raw model output is persisted.

This is NOT a model acceptance test, workflow executor, or proof of factual
correctness. The diagnostic uses the existing HWI-I02 prompt and validator.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'CODE' / 'DUALFLOW' / 'tools'))

from check_dualflow_design import DesignError, _unique_object, _reject_constant, load_design
from patch_dualflow import propose_revision
from evaluate_dualflow_model import evaluate_model_proposal
from run_dualflow_local import installed_models, validate_loopback_endpoint
from simulate_dualflow import canonical_digest


class CaptureInMemory:
    """Transiently holds the previous response, never writes it to a file."""
    def __init__(self, provider):
        self.provider = provider
        self.response = None

    def chat(self, **kwargs):
        value = self.provider.chat(**kwargs)
        self.response = getattr(value, 'content', None)
        return value


def categorize(output, base):
    """Explain rejection using validation only; never return model text."""
    if type(output) is not str or not output or len(output) > 128_000:
        return {'category': 'INVALID_RESPONSE_TEXT'}
    try:
        patch = json.loads(output, object_pairs_hook=_unique_object,
                           parse_constant=_reject_constant)
    except (ValueError, TypeError, UnicodeError):
        return {'category': 'INVALID_JSON_OR_DUPLICATE_KEYS'}
    try:
        propose_revision(base, patch)
    except (DesignError, TypeError, ValueError) as exc:
        # Validator errors are contract templates, not model prose.
        detail = str(exc)[:180]
        if not all(c.isprintable() for c in detail):
            detail = 'Nonprintable validation detail omitted'
        return {'category': 'PATCH_CONTRACT_REJECTED', 'validator_rule': detail}
    return {'category': 'STRUCTURALLY_VALID_NOT_INDEPENDENTLY_VERIFIED'}


def one_shot(*, provider, model, base, task):
    spy = CaptureInMemory(provider)
    result = evaluate_model_proposal(provider=spy, model=model, task=task,
                                     base=base, provider_kind='LOCAL_OLLAMA')
    output = spy.response
    details = categorize(output, base) if output is not None else {
        'category': 'NO_MODEL_RESPONSE_CAPTURED'}
    return {'diagnostic_schema':'hwi.mac.local_model_diagnostic.v0',
            'model': model, 'status': result['status'],
            'failure_class': result['failure_class'],
            'model_response_sha256': result['model_response_sha256'],
            'diagnosis': details,
            'raw_model_text_saved': False,
            'workflow_executed': False,
            'knowledge_approved': False,
            'independent_model_verification': False}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model', required=True)
    args = p.parse_args(argv)
    from autogpt_lite.llm.ollama import OllamaProvider
    try:
        from hwi_mac_test import valid_model
        valid_model(args.model)
        base = load_design(ROOT/'CODE/DUALFLOW/docs/dualflow/examples/evidence_review.json')
        task = (ROOT/'CODE/DUALFLOW/docs/dualflow/examples/evidence_review.model_task.txt').read_text()
        endpoint = validate_loopback_endpoint('http://127.0.0.1:11434')
        provider = OllamaProvider(base_url=endpoint)
        provider._session.trust_env = False
        provider._session.max_redirects = 0
        known = {entry['name'] for entry in installed_models(provider)}
        if args.model not in known:
            raise DesignError('Requested model is not installed locally')
        print(json.dumps(one_shot(provider=provider, model=args.model, base=base,task=task),
                         sort_keys=True, indent=2, ensure_ascii=True))
        return 0
    except (DesignError, RuntimeError, ConnectionError, TimeoutError, OSError) as exc:
        print('MAC_DIAGNOSTIC_UNAVAILABLE_OR_REJECTED: ' + type(exc).__name__, file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
