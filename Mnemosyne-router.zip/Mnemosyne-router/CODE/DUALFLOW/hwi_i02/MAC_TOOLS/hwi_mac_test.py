#!/usr/bin/env python3
"""macOS-oriented, read-only HWI Dual-Flow offline and Ollama trial launcher.

Does not download models, install dependencies, grant authority, or write wiki data.
Model trials are loopback-only, and reports are kept outside the archive.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import uuid
import urllib.error
import urllib.request
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
DUALFLOW = ROOT / 'CODE' / 'DUALFLOW'
TOOLS = DUALFLOW / 'tools'
EXAMPLES = DUALFLOW / 'docs' / 'dualflow' / 'examples'
ENDPOINT = 'http://127.0.0.1:11434'
MODEL_NAME_MAX = 128
MAX_TAGS = 1024 * 1024
REPORT_HOME = Path.home() / 'HWI-DualFlow-Trials'
VENV = Path.home() / 'Library' / 'Application Support' / 'HWI-DualFlow' / 'venv'


class MacHarnessError(Exception):
    pass


class RefuseRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def local_tags() -> dict:
    """Read bounded local metadata without using proxy env or following redirects."""
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), RefuseRedirect())
    request = urllib.request.Request(ENDPOINT + '/api/tags', method='GET')
    try:
        with opener.open(request, timeout=2.5) as response:
            if response.status != 200:
                raise MacHarnessError('Unexpected local Ollama status')
            body = response.read(MAX_TAGS + 1)
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        raise MacHarnessError('Ollama local service not accessible on 127.0.0.1:11434') from exc
    if len(body) > MAX_TAGS:
        raise MacHarnessError('Local model metadata too large')
    try:
        data = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise MacHarnessError('Ollama local model metadata is invalid JSON') from exc
    if not isinstance(data, dict) or not isinstance(data.get('models'), list):
        raise MacHarnessError('Ollama local response does not contain model list')
    return data


def is_cloud_model(name: str) -> bool:
    """Exclude officially labeled Ollama cloud models from this local-only harness."""
    return name.lower().endswith(':cloud') or name.lower().endswith('-cloud')


def valid_model(name: str) -> str:
    if (not isinstance(name, str) or not 1 <= len(name) <= MODEL_NAME_MAX or
            not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]*', name)):
        raise MacHarnessError('Invalid model name')
    if is_cloud_model(name):
        raise MacHarnessError('Cloud model excluded: only on-device model names are allowed')
    return name


def child_env() -> dict[str, str]:
    env = os.environ.copy()
    env['PYTHONPATH'] = os.pathsep.join((
        str(ROOT / 'CODE' / 'APPROVED_AGENT_PROVIDER'),
        str(ROOT / 'CODE' / 'APPROVED_WIKI_CORE'),
    ))
    env['PYTHONNOUSERSITE'] = '1'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['NO_PROXY'] = '*'
    env['no_proxy'] = '*'
    return env


def run_tool(args: list[str], *, cwd: Path = DUALFLOW, capture: bool = False) -> subprocess.CompletedProcess:
    # Never use a shell, even when a model name or filename came from a user.
    return subprocess.run([sys.executable, '-B', *args], cwd=cwd,
                          env=child_env(), text=True, capture_output=capture, check=False)


def save_new_private(path: Path, payload: str) -> None:
    path = path.expanduser().resolve()
    # Caller decides the location. Existing files are never overwritten.
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as file:
        file.write(payload)


def default_path(kind: str) -> Path:
    REPORT_HOME.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return REPORT_HOME / f'{kind}-{stamp}-{uuid.uuid4().hex[:8]}.json'


def doctor() -> int:
    print('HWI Dual-Flow — Mac preflight (no model invocation)')
    print('OS:                    ', platform.system(), platform.release())
    print('Machine:               ', platform.machine(), '(arm64 = Apple Silicon, x86_64 = Intel)')
    print('Python:                ', platform.python_version(), sys.executable)
    print('Python 3.11+:          ', sys.version_info >= (3, 11))
    print('requests import:       ', 'present' if importlib.util.find_spec('requests') else 'missing')
    print('Ollama CLI:            ', shutil.which('ollama') or 'not on PATH (Mac app may still be installed)')
    print('Ollama app:            ',
          any((p / 'Ollama.app').exists() for p in (Path('/Applications'), Path.home() / 'Applications')))
    print('Report folder:         ', REPORT_HOME)
    try:
        data = local_tags()
        names = [e.get('name', '(unnamed)') for e in data['models'] if isinstance(e, dict)]
        print('Loopback Ollama API:   available')
        print('Installed model tags: ', len(names))
        print('Local candidate tags: ', ', '.join(n for n in names if not is_cloud_model(n)) or '(none)')
        cloud = [n for n in names if is_cloud_model(n)]
        if cloud:
            print('Excluded cloud tags:   ', ', '.join(cloud))
    except MacHarnessError as exc:
        print('Loopback Ollama API:   unavailable —', exc)
        print('To start Ollama on macOS, open the Ollama app. Do not start a second server if one is running.')
    if platform.system() != 'Darwin':
        print('NOTE: This is a non-macOS check; native macOS behavior is not verified here.')
    if sys.version_info < (3, 11):
        return 2
    return 0


def offline() -> int:
    if importlib.util.find_spec('requests') is None:
        raise MacHarnessError('requests not installed: run MAC_SETUP.command first')
    print('Running complete offline dual-flow test suite (including trial-review tests).', flush=True)
    result = run_tool(['-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_dualflow*.py', '-q'])
    if result.returncode:
        return result.returncode
    print('Running Mac launcher contract tests (portable; not native Mac validation).', flush=True)
    mac_result = run_tool(['-m', 'unittest', 'discover', '-s', 'MAC_TOOLS',
                           '-p', 'test_hwi_mac_test.py', '-q'], cwd=ROOT)
    return mac_result.returncode


def models() -> int:
    if importlib.util.find_spec('requests') is None:
        raise MacHarnessError('requests not installed: run MAC_SETUP.command first')
    result = run_tool([str(TOOLS / 'run_dualflow_local.py'), '--list-models'], capture=True)
    if result.returncode:
        print(result.stderr.strip(), file=sys.stderr)
        return result.returncode
    result_data = json.loads(result.stdout)
    names = result_data.get('installed_models', [])
    filtered = [m for m in names if not is_cloud_model(m['name'])]
    print(json.dumps({'endpoint':ENDPOINT,'installed_local_candidates':filtered,
                      'excluded_cloud_tags':len(names)-len(filtered)},indent=2))
    return 0


def trial(args: argparse.Namespace) -> int:
    if importlib.util.find_spec('requests') is None:
        raise MacHarnessError('requests not installed: run MAC_SETUP.command first')
    if not (1 <= len(args.model) <= 8):
        raise MacHarnessError('Select 1–8 local models')
    for model in args.model: valid_model(model)
    if len(args.model) != len(set(args.model)):
        raise MacHarnessError('Duplicate model selection')
    if not 1 <= args.repeats <= 12:
        raise MacHarnessError('Repeats must be 1–12')
    for pin in args.pin_model:
        if '=' not in pin:
            raise MacHarnessError('Expected --pin-model NAME=SHA256')
        valid_model(pin.split('=', 1)[0])
    filename = Path(args.output).expanduser() if args.output else default_path('trial')
    if filename.exists():
        raise MacHarnessError('Refusing to overwrite existing report: ' + str(filename))
    if not filename.parent.is_dir():
        raise MacHarnessError('Output directory does not exist: ' + str(filename.parent))
    command=[str(TOOLS / 'run_dualflow_local.py'),
             '--design', str(EXAMPLES/'evidence_review.json'),
             '--task-file', str(EXAMPLES/'evidence_review.model_task.txt'),
             '--reference-patch', str(EXAMPLES/'evidence_review.patch.json'),
             '--regression', str(EXAMPLES/'evidence_review.regression.json'),
             '--application', str(EXAMPLES/'evidence_review.application.json'),
             '--repeats', str(args.repeats), '--output', str(filename)]
    for name in args.model:
        command.extend(['--model',name])
    for pin in args.pin_model:
        command.extend(['--pin-model',pin])
    print('Running local Ollama model(s):',', '.join(args.model), flush=True)
    print('Output (private, never overwritten):',filename, flush=True)
    result=run_tool(command)
    if result.returncode:
        print('Trial failed; no successful local-model result is being claimed.',file=sys.stderr)
    return result.returncode


def diagnose(args: argparse.Namespace) -> int:
    """One-shot local response diagnosis; never writes raw model output."""
    if importlib.util.find_spec('requests') is None:
        raise MacHarnessError('requests not installed: run MAC_SETUP.command first')
    valid_model(args.model)
    result = run_tool([str(ROOT/'MAC_TOOLS'/'diagnose_model_failure.py'),
                       '--model', args.model], cwd=ROOT, capture=True)
    if result.returncode:
        print(result.stderr.strip() or 'Local diagnostic failed', file=sys.stderr)
        return result.returncode
    details = json.loads(result.stdout)
    if (type(details) is not dict or
            details.get('diagnostic_schema') != 'hwi.mac.local_model_diagnostic.v0' or
            details.get('raw_model_text_saved') is not False):
        raise MacHarnessError('Unexpected diagnostic result')
    print(json.dumps(details, sort_keys=True, indent=2))
    return 0

def review(args: argparse.Namespace, *, assess: bool) -> int:
    report = Path(args.report).expanduser()
    if not report.is_file():
        raise MacHarnessError('Trial report does not exist')
    command=[str(TOOLS/'assess_dualflow_trials.py'), str(report)]
    if assess:
        if not args.review:
            raise MacHarnessError('Assessment requires a reviewed worksheet (--review PATH)')
        command.extend(['--review',str(Path(args.review).expanduser())])
    else:
        command.append('--make-review-template')
    destination=Path(args.output).expanduser() if args.output else default_path('assessment' if assess else 'review')
    if destination.exists() or not destination.parent.is_dir():
        raise MacHarnessError('Output location unavailable or already exists')
    result = run_tool(command, capture=True)
    if result.returncode:
        print(result.stderr.strip(), file=sys.stderr)
        return result.returncode
    # Ensure generated report is proper JSON before persisting it.
    json.loads(result.stdout)
    save_new_private(destination, result.stdout)
    print(('Assessment' if assess else 'Review worksheet') + ' saved:',destination)
    if not assess:
        print('Edit verdicts and evidence notes in the worksheet, then run the assess command.')
    return 0


def menu() -> int:
    while True:
        print('\nHWI macOS local test menu')
        print('1) Check environment and Ollama availability')
        print('2) Run offline tests (no model needed)')
        print('3) List installed local Ollama models')
        print('4) Run an Ollama workflow-revision trial')
        print('5) Create human-review worksheet from a trial report')
        print('6) Diagnose one local model output (in-memory)')
        print('7) Exit')
        try:
            option = input('Choice [1-7]: ').strip()
        except EOFError:
            return 0
        if option == '7': return 0
        if option == '1': result=doctor()
        elif option == '2': result=offline()
        elif option == '3': result=models()
        elif option == '4':
            try:
                name=input('Exact local model name (from option 3): ').strip()
                repeats_text=input('Repetitions [3]: ').strip() or '3'
                result=trial(argparse.Namespace(model=[name],repeats=int(repeats_text),output=None,pin_model=[]))
            except (ValueError, MacHarnessError) as exc:
                print('Unable to run trial:',exc)
                result=2
        elif option == '6':
            try:
                name = input('Exact local model name (from option 3): ').strip()
                result = diagnose(argparse.Namespace(model=name))
            except MacHarnessError as exc:
                print('Unable to run diagnostic:', exc)
                result = 2
        elif option == '5':
            try:
                filename=input('Full path to trial JSON: ').strip()
                result=review(argparse.Namespace(report=filename,output=None),assess=False)
            except MacHarnessError as exc:
                print('Unable to prepare review:',exc)
                result=2
        else:
            print('Unknown choice')
            continue
        print('Result code:',result)


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='action')
    sub.add_parser('doctor',help='preflight: no model invocation')
    sub.add_parser('offline',help='run full offline regression suite')
    sub.add_parser('models',help='list local Ollama model tags')
    t=sub.add_parser('trial',help='run local pinned synthetic workflow-revision cases')
    t.add_argument('--model',action='append',required=True)
    t.add_argument('--pin-model',action='append',default=[])
    t.add_argument('--repeats',type=int,default=3)
    t.add_argument('--output',help='new output path (never overwritten)')
    r=sub.add_parser('review',help='make a private review worksheet for a trial report')
    r.add_argument('--report',required=True)
    r.add_argument('--output')
    a=sub.add_parser('assess',help='assess a reviewed worksheet')
    a.add_argument('--report',required=True)
    a.add_argument('--review',required=True)
    a.add_argument('--output')
    d=sub.add_parser('diagnose',help='single in-memory local model rejection diagnostic')
    d.add_argument('--model',required=True)
    sub.add_parser('menu',help='interactive Mac terminal menu')
    args=parser.parse_args(argv)
    os.umask(0o077)
    try:
        return {'doctor':lambda:doctor(), 'offline':lambda:offline(),
                'models':lambda:models(), 'trial':lambda:trial(args),
                'diagnose':lambda:diagnose(args),
                'review':lambda:review(args,assess=False),
                'assess':lambda:review(args,assess=True),
                'menu':lambda:menu(), None:lambda:menu()}[args.action]()
    except MacHarnessError as exc:
        print('HWI_MAC_TEST_REJECTED:', exc, file=sys.stderr)
        return 2
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print('HWI_MAC_TEST_ERROR:', type(exc).__name__, file=sys.stderr)
        return 3


if __name__=='__main__':
    raise SystemExit(main())
