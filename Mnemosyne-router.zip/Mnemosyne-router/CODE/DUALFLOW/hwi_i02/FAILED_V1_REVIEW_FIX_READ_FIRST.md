# HWI-I02 — Failed-v1-review correction (uncommitted)

## What the Mac report established

The real local `llama3.1:8b` content trial `content-20261112T171427Z-10220.json` uses
`hwi.dualflow.cited_content_report.v1`. Its report digest is
`7643fcb33e56638de8bd776d5400973b4dd42b85ae783e551bac573b9f7efa99`.

The model quoted both issue source pairs exactly. It labeled the synthetic ALPHA-17 discrepancy
`CONFLICT` correctly, but labeled `platform_scope` as `UNRESOLVED` instead of the packet's
researcher-predeclared `NOT_CONFLICT`. As a result, the result remains `CONTENT_CHECK_FAILED`.
The open Linux RC-05 gate is an incomplete acceptance requirement, **not a contradiction**
with successful bounded Mac verification. The model's explanation correctly distinguishes the
gates, yet its classification appears to conflate gate completion with logical compatibility.

## Why this patch exists

The previous v1 implementation intentionally adds `classification_summary` only to a report
whose mechanical checks pass. However, its `worksheet()` routine unconditionally required that
summary for every v1 result. A real failed trial therefore could not be reviewed or re-audited,
even though failures are precisely what reviewers need to inspect.

The narrow change:

1. Treat a failed v1 report with recorded mechanical errors and **no** derived summary as
   reviewable evidence, but keep its `CONTENT_CHECK_FAILED` status.
2. Continue strictly requiring and integrity-rechecking the derived summary on **passing** v1
   trials; reject a forged summary on failed trials, even if a local result digest was recomputed.
3. Prevent a mechanically failed v1 trial from setting `all_supported_by_review_claim=True`,
   regardless of the local review notes.
4. Allow `--audit-report` for failed v1 reports, without changing the original result.
5. Leave the expected classifications, evidence packet, model prompt and approved source code
   unchanged. No owner approval or knowledge publication authority is implied.

## Reproduce on Mac

Extract the new ZIP into a different folder and open Terminal inside its extracted root.
The original trial report remains in `~/HWI-DualFlow-Trials/`.

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_CONTENT_EVAL.command offline

python3 CONTENT_EVAL/evaluate_report_content.py \
  --worksheet "$HOME/HWI-DualFlow-Trials/content-20261112T171427Z-10220.json" \
  --output "$HOME/HWI-DualFlow-Trials/review-failed-v1-new.json"

python3 CONTENT_EVAL/evaluate_report_content.py \
  --audit-report "$HOME/HWI-DualFlow-Trials/content-20261112T171427Z-10220.json" \
  --output "$HOME/HWI-DualFlow-Trials/audit-failed-v1-new.json"
```

Use unique output filenames; no file overwrites are permitted by the tool. Review judgments
remain `PENDING` until a human inspects and edits them. No new Ollama inference is required
to reproduce this review-path correction.

## Test claims and scope

On the available Linux environment, 335 existing dual-flow tests, 16 launcher-contract tests,
and 65 content-evaluation tests passed (416 total). Checks from the Mac-specific native runtime
have not yet been repeated for the corrected review-path code. The user-provided actual Mac
report was checked against the exact packet, model-response and report digests, and the patched
worksheet / re-audit / pending-assessment paths were exercised against its original bytes.

The prior accepted 9/10 roadmap remains unchanged. HWI-I02 is **uncommitted, unaccepted**.
The model's classification mistake still requires substantive review and broader evaluation;
this patch does not turn the failing model answer into a passing result.
