#!/bin/bash
# macOS Finder/Terminal launcher. No implicit installs or writes to wiki.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PATH="/opt/homebrew/bin:/usr/local/bin:/Library/Frameworks/Python.framework/Versions/Current/bin:$PATH"
VENV="$HOME/Library/Application Support/HWI-DualFlow/venv/bin/python3"
PY="${HWI_PYTHON:-}"
if [[ -z "$PY" && -x "$VENV" ]]; then PY="$VENV"; fi
if [[ -z "$PY" ]]; then
  for candidate in python3.14 python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; assert sys.version_info >= (3,11)' >/dev/null 2>&1; then
      PY="$(command -v "$candidate")"
      break
    fi
  done
fi
if [[ -z "$PY" ]]; then
  echo 'Python 3.11 or newer is needed. Install a macOS Python from python.org, then run MAC_SETUP.command.' >&2
  exit 2
fi
if [[ $# -eq 0 ]]; then
  "$PY" -B "$ROOT/MAC_TOOLS/hwi_mac_test.py" menu
else
  "$PY" -B "$ROOT/MAC_TOOLS/hwi_mac_test.py" "$@"
fi
status=$?
if [[ -t 0 ]]; then
  echo
  read -r -p 'Press Return to close this window...' unused || true
fi
exit "$status"
