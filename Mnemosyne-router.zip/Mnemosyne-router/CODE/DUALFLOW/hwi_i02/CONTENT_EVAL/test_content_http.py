"""Loopback protocol integration with approved OllamaProvider, no model inference."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import unittest
import evaluate_report_content as ev
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

class Handler(BaseHTTPRequestHandler):
    scenario='good'
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path!='/api/tags':
            self.send_error(404);return
        data={'models':[{'name':'local-fixture:8b','digest':'sha256:'+'1'*64}]}
        encoded=json.dumps(data).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(encoded)));self.end_headers();self.wfile.write(encoded)
    def do_POST(self):
        if self.path!='/api/chat':self.send_error(404);return
        length=int(self.headers.get('Content-Length','0'))
        data=json.loads(self.rfile.read(length))
        assert data['model']=='local-fixture:8b' and data['format']=='json'
        if self.scenario=='redirect':
            self.send_response(302);self.send_header('Location','https://example.org/not-allowed');self.end_headers();return
        obj=ev.load_json(HERE/'GOOD_REPORT_FIXTURE.json')
        if self.scenario=='wrong':obj['findings'][0]['status']='NOT_CONFLICT'
        if self.scenario=='extra':obj['execution_authorized']=True
        content=json.dumps(obj)
        result={'message':{'role':'assistant','content':content},'prompt_eval_count':200,'eval_count':300}
        enc=json.dumps(result).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(enc)));self.end_headers();self.wfile.write(enc)

class LocalHttpProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
        cls.endpoint='http://127.0.0.1:'+str(cls.server.server_port)
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=2)
    def setUp(self):self.packet=ev.load_json(HERE/'EVIDENCE_PACKET.json');Handler.scenario='good'
    def test_real_provider_loopback_good(self):
        report,elapsed,tokens=ev.local_model(self.packet,'local-fixture:8b',self.endpoint,ROOT)
        self.assertEqual(ev.inspect_report(self.packet,report)['status'],'CONTENT_CHECK_PASSED_PENDING_HUMAN_REVIEW')
        self.assertEqual(tokens['prompt'],200)
        self.assertGreaterEqual(elapsed,0)
    def test_real_provider_loopback_wrong_label(self):
        Handler.scenario='wrong'
        report,_,_=ev.local_model(self.packet,'local-fixture:8b',self.endpoint,ROOT)
        self.assertEqual(ev.inspect_report(self.packet,report)['status'],'CONTENT_CHECK_FAILED')
    def test_real_provider_loopback_rejects_approval_field(self):
        Handler.scenario='extra'
        report,_,_=ev.local_model(self.packet,'local-fixture:8b',self.endpoint,ROOT)
        self.assertEqual(ev.inspect_report(self.packet,report)['status'],'CONTENT_CHECK_FAILED')
    def test_not_installed_model_refused(self):
        with self.assertRaises(ev.ContentError):ev.local_model(self.packet,'not-installed',self.endpoint,ROOT)
    def test_wrong_endpoint_refused(self):
        with self.assertRaises(Exception):ev.local_model(self.packet,'local-fixture:8b','https://example.org',ROOT)
    def test_redirect_not_followed(self):
        Handler.scenario='redirect'
        with self.assertRaises(Exception):ev.local_model(self.packet,'local-fixture:8b',self.endpoint,ROOT)

if __name__=='__main__':unittest.main()
