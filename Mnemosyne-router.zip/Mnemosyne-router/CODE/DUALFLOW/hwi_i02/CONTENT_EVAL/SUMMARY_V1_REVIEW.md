# HWI-I02 content-summary consistency correction — review candidate

## Why this exists

The user's genuine `llama3.1:8b` content trial (`content-20261112T165307Z-10016.json`) passed the v0 mechanical checks, yet its free-text summary called `platform_scope` a conflict while the associated finding was `NOT_CONFLICT`. Mechanical citations and expected-label checks did not examine the overall prose summary.

## Bounded correction

* New model-facing report schema `hwi.dualflow.cited_content_report.v1` contains `schema`, `packet_sha256`, and `findings` only. Model-authored top-level `summary` is forbidden.
* The deterministic evaluator constructs `classification_summary` as an *explicitly derived presentation* from the validated finding labels. It preserves separate rows for `CONFLICT`, `NOT_CONFLICT`, and `UNRESOLVED`, in evidence-packet issue order. It never changes the model-authored finding explanations.
* The review tool re-checks the derived summary's rows, text, and provenance when the report is opened. A changed summary with a recomputed local result digest cannot pass the internal consistency check.
* Legacy `v0` trial results and human review worksheets remain readable; an existing free-text summary is now labeled `CONTENT_CHECK_LEGACY_SUMMARY_PENDING_REVIEW`, even if its original local status said `CONTENT_CHECK_PASSED_PENDING_HUMAN_REVIEW`. We do not claim to infer semantic correctness from arbitrary legacy prose.
* `--audit-report EXISTING.json --output NEW_AUDIT.json` checks a historical trial against the pinned packet **without rewriting the original**. The review audit of the user's historical report is included in `EVIDENCE/LEGACY_USER_TRIAL_REAUDIT.json`, with no private report contents reproduced.
* Strict source citation, model-output shape, packet pinning, human review, execution and publication boundaries remain unchanged.

## What this is NOT

The derived summary is consistent with the **model's reported statuses**, and the statuses are checked against researcher-predeclared labels. None of this proves real-world truth, the semantic quality of an explanation, or the independence of the researcher's expectations. The model can still write an incorrect explanation in a finding; that remains a matter for substantive human review.

## New Mac trial

From the extracted package folder:

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_CONTENT_EVAL.command offline
bash RUN_CONTENT_EVAL.command trial 'llama3.1:8b'
```

The saved `content-*.json` should now have a `candidate_report` with `schema=hwi.dualflow.cited_content_report.v1` and no model-authored `summary`, plus a top-level `classification_summary` built by the evaluator. Any `CONTENT_CHECK_FAILED` must be reviewed before proceeding. The model request has changed; previous success rates are not evidence of v1 output success.

Re-audit the older local trial, if still present:

```sh
python3 CONTENT_EVAL/evaluate_report_content.py \
  --audit-report "$HOME/HWI-DualFlow-Trials/content-20261112T165307Z-10016.json" \
  --output "$HOME/HWI-DualFlow-Trials/content-legacy-audit-new.json"
```

Use a unique output path each time. The command fails closed on stale or inconsistent identity pins and does not authenticate the old trial's origin. Existing files are not overwritten.

## Evidence and acceptance

- Offline Linux replay (bytecode writing disabled to preserve the sealed archive): 335 existing dual-flow tests, 16 Mac-launcher tests and 58 content tests all passed (409 total).
- Includes a regression case preserving the exact class of the Mac failure: v0 labels `platform_scope` as `NOT_CONFLICT` but calls it a conflict in the prose summary. Its legacy status is downgraded to a separate-review requirement; v1 cannot contain such a top-level model-authored summary.
- This is an **uncommitted** HWI-I02 candidate, not a signed approval or a tested native macOS v1 inference.
- The original CR03 code, approved wiki and Ollama provider are unmodified. HWI remains 9/10 accepted and committed; HWI-I02 remains open.
