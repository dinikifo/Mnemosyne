# CMR-06 — Isolated Deterministic Router: Implementation and Exit Evidence

**Date:** 2026-11-13

**Branch:** `plan/typed-router-consolidation`
**Status:** Technical implementation checkpoint, **not production acceptance**.

## 1. Purpose, scope and boundaries

This introduces `hwi_router` as a separate candidate module. It implements
CMR-04's five strict v1 message kinds and CMR-05's eight exact advisory
transitions **without changing any existing Formation, wiki, governance,
Dual-Flow or agent runtime source files**. The previous release's sealed
approved components remain untouched.

The router coordinates ephemeral advisory activity. It does **not** own
Formation dialogue/session state, knowledge revision checks, user authorization,
fitness limits, quota reservation, signed approvals, repository writes, agent
execution, or model transport. No service is invoked by its effect descriptors.

## 2. Code additions

- `hwi_router/core.py` — trusted bootstrap registries, source/session/flow
  identity handles; v1 schema/bounds parser with duplicate-key rejection;
  recursive immutability; exact transition matching, guard and parent
  validation; synchronous pure handlers; admissible effect descriptors;
  bounded, process-local replay cache; conservative failure verdicts.
- `hwi_router/test_router.py` — source spoofing, duplicate/replay/conflict,
  consent guard, immutable payload, parentage, invalid state, forbidden
  effects, recursion, handler interruption, deadline, malformed input and
  valid-path tests.
- `hwi_router/benchmark.py` — repeatable isolated dispatch cost against a
  trivial direct Python function call.
- `hwi_router/README.md` — integration API, ownership, limitations and
  restrictions on downstream adapters.

There are **no new CLI commands, persistent files, background workers,
network listeners, database connections or imports of protected components**.
The implementation uses `jsonschema` 4.x for exact CMR-04 validation.

## 3. Transition and effect invariants

The registry reads the previously committed schema, producer matrix,
transition matrix and effect policy. It rejects duplicate transition keys,
unknown producer identities, missing handlers/guards or allowlist mismatches
at bootstrap. It has no priority-based ambiguity resolution; only one exact
`(phase, kind, verified_source)` may match.

The trusted caller holds identity-only source and session handles. The router
checks the **object identity** of a registered source handle and of the
registered flow, compares envelope origin and correlation to those handles,
validates required parent ID, evaluates each trusted guard, then invokes one
pure handler with a recursively frozen payload. A successfully validated
handler must return exactly the matrix's effect-intent list; no alternate
callback can become privileged through model prose. The phase changes only
after input, guard, handler-output and deadline checks pass.

Phase states are in-memory only. An exact duplicate `(session scope, message
ID, canonical digest)` returns the cached verdict without executing the
handler a second time. An ID/digest conflict returns `F10`; cache exhaustion
rejects new packets, rather than evicting previously protected IDs. An
interrupted handler aborts the transient flow and forbids automatic retry.

## 4. CMR-06 acceptance tests

`python -B -m unittest -q hwi_router.test_router`: **41/41 passed**.
Negative cases include:

| Required threat | Exercised protection | Remaining limitation |
|---|---|---|
| Forged source / wrong origin | source-handle identity and origin match | handles rely on trusted in-process bootstrap |
| Unknown/duplicate rules | startup rejects conflicting route IDs/keys | no dynamic rule installation |
| Malformed input / unknown kinds | duplicate-key, schema, size, depth and nodes caps | no signature on serialized messages |
| Bad phase / response parent | exact phase, correlation and causation check | phase not persisted between restarts |
| Consent/scope missing | pre-handler guard callbacks reject | real Formation/broker guard callbacks are CMR-07/08 |
| Replay / ID conflict | process-local cached verdict or conflict rejection | no crash-durable exactly-once guarantee |
| Unapproved effect / handler output | only three exact advisory descriptors; `F05` otherwise | malicious Python handlers not sandboxed |
| Interrupt / deadline | abort or reject, no retry, unchanged phase | synchronous blocked handler cannot be preempted |
| Excessive recursion / hops | nested dispatch rejected; bounded hops | single-thread synchronous prototype |
| Immutable payload | nested mappings and arrays frozen | trusted handlers still have arbitrary Python privileges |

**Baseline regression:** 636/636 previously defined offline suite tests were
rerun successfully across separate invocations on Linux, once the packaged
release layout was used for Mac/content/governance/Formation suites. This is
not native macOS or live Ollama verification. The initial attempt to invoke
Mac/content tests from the bare Git root failed because their fixtures and
relative imports require the full release layout; the corrected runs passed.
CMR-04 schema tests: **11/11**, CMR-05 protocol tests: **17/17**,
and focused existing Formation dialogue/practice tests: **40/40**.

**Performance:** see `CMR-06_TEST_EVIDENCE.json` for the median Python-no-op
and router-dispatch microsecond measurements across 3 x 500 runs. The direct
call is a trivial no-op and is not equivalent to schema checking or real I/O;
this measurement only quantifies prototype dispatch overhead.

## 5. Constraints on subsequent checkpoints

- **CMR-07:** adapt *one* Formation advisory interaction behind an opt-in/shadow
  boundary; implement real consent and session guards, maintain guided
  fallback and existing purpose-confirmation semantics; perform A/B fixtures
  and human usefulness review.
- **CMR-08:** implement verified read-only broker adapters, pinned-scope/revision
  checks and hardened loopback-only Ollama transport before exposing real
  private transcripts to model calls.
- **CMR-09/10:** no privileged write, gate reconciliation, signature or
  task execution through the router; keep the existing trusted review service.
- **CMR-12:** independent production/native acceptance, recovery and
  operational authorization remain open.

**Known non-goals:** A message bus, arbitrary ELIZA text parsing between
components, a universal task stack, persistence layer, authorization token,
virtual machine sandbox, and real side-effect executor.

## 6. Checkpoint decision

**CMR-06 technical exit: COMPLETE (isolated prototype only).** No existing
runtime modules were modified, no production access was exercised, and no
release permission was granted. Integration progress remains zero until
CMR-07 begins. Preserve CMR-05 as the rollback baseline.
