# CMR-04 — Typed Message Envelope and Type Contracts v1

**Status:** Technical contract checkpoint only (design, schema, compatibility); no runtime integration or release approval. **Prior stage:** CMR-03 at `86b46a7`. **Date:** 2026-11-13.

## Scope and source alignment

CMR-03 identified Formation's read-only practice retrieval and optional local-model clarification as the first decoupling seams. The existing `hwi_formation.dialogue` state machine, `FormationStore`, wiki broker through `hwi_governance.repository`, Ollama provider and governed writer retain their internal authority and state. This schema is for advisory coordination only: **no confirmation, write, fitness, execution, or signed-approval message**. Dual-Flow and governance contract kinds are postponed until their own reviewed stages. Nothing in CMR-04 routes a live message.

## Envelope

[`CMR-04_MESSAGE_SCHEMA_V1.json`](CMR-04_MESSAGE_SCHEMA_V1.json) is the normative **shape** contract (JSON Schema Draft 2020-12). Its `.invalid` `$id` is an inert identifier, not an accessible endpoint.

```json
{
  "schema_id": "hwi.router.message.v1",
  "version": 1,
  "kind": "formation.practice.request",
  "message_id": "11111111111111111111111111111111",
  "correlation_id": "22222222222222222222222222222222",
  "causation_id": null,
  "origin": "formation",
  "sensitivity": "confidential",
  "trace_ref": null,
  "payload": {"query": "observable success criteria", "limit": 2}
}
```

All 10 top-level fields are mandatory; IDs shown are test placeholders. No unknown kind, version, field, coercion or payload extension is accepted. The `schema_id` and `version` are exact, not negotiated through an LLM. `message_id` is a unique cryptographically generated 128-bit hex value, `correlation_id` identifies the trusted workflow, and `causation_id` is null at trusted entry or names a parent message in the same workflow. `trace_ref` is null or a 1–96-character opaque audit locator without path separators, *not* a file path or credential. `sensitivity` is `internal` or `confidential`, with confidential default for private queries, model prompts and evidence; a producer cannot lower sensitivity.

`origin` is a **trusted ingress attestation**, not a security claim established by JSON. A source label such as `model_adapter` supplied by a model or human must be rejected or overwritten by a trusted receiver. Even a genuine user chat turn is **not** a signed review/confirmation. The router has no authority to promote it.

### Five version-one kinds

| Message kind | Trusted producer | Exact payload | Consumer | Scope |
|---|---|---|---|---|
| `formation.practice.request` | Formation | `query` (1–100 printable chars); `limit` (integer 1–3) | Existing read-only knowledge adapter | Requires prior, explicit operator-selected notebook/query consent |
| `knowledge.practice.result` | Knowledge adapter | `practices` (0–3 pinned `{field, question, ref, revision_sha256}` cards) | Formation advisory assembler | Broker pins/record identity remain authoritative |
| `formation.model_question.request` | Formation | `field`, `prompt` (1–300 chars), `practice_refs` (0–3 unique refs) | Local-model adapter | Requires `--model-questions` opt-in; no new wiki-data sharing |
| `model.question.result` | Model adapter | `question` (1–300 printable chars) | Formation advisory assembler | Deterministic `check_question()` and guided fallback still apply |
| `formation.question.suggestion` | Formation | `field`, `question`, `practice_refs` | Formation dialogue adapter | Advisory, never triggers purpose confirmation |

Purpose field names match `hwi_formation.good_practices.FIELDS`: `initial_task`, `domain`, `input_sources`, `expected_outputs`, `success_criteria`, `boundaries`. Wiki practice refs have the `hwi05://<64 hex>/<32 hex>@<positive revision>` form, with separate lowercase 64-hex `revision_sha256`. **Valid ref syntax is not evidence authentication**: the existing read-only broker still checks revision, notebook scope and actual content. Any card citations in a suggestion are attached by trusted code using retrieved records; the model cannot self-certify evidence. [`CMR-04_COMPATIBILITY.json`](CMR-04_COMPATIBILITY.json) lists the exact producer/consumer edges. Existing direct calls remain available during migration.

## Validation and ingress boundary (implementation obligation for CMR-05/06)

At each entry point, bind trusted `IngressContext` with actual adapter/session identity, workflow, human consent, scope and sensitivity clearance. The receiver must *not* accept untrusted `origin`, IDs, trace ref or approval assertions. If receiving serialized envelopes, independently compare them with this context. Shape checks alone cannot prevent a properly formed spoof.

Ingress order: (1) bind real source/consent/scope; (2) limit UTF-8 bytes before parse; (3) parse with duplicate-key rejection and no coercion; (4) limit depth, nodes and text controls; (5) assign/verify IDs and origin; (6) enforce kind and schema; (7) check correlation, causation, current state and recipient clearance; (8) immutable deep-copy/freeze of accepted data; only then select a handler. A failed check must not dispatch, mutate session state or invoke a privileged operation.

| Invariant | Candidate v1 bound | Enforcer |
|---|---|---|
| Full envelope | <= 16,384 encoded UTF-8 bytes | Future ingress, not JSON Schema |
| JSON nesting / aggregate nodes | <= 8 levels (root included) / <= 256 JSON nodes | Future ingress |
| Input types | Exact required fields; no extra properties; `limit` excludes bool/float | JSON Schema and ingress |
| Question strings | <= 300 characters; no C0/DEL control characters | Schema; semantic `check_question()` after model result |
| Practice cards / refs | <= 3; exact typed fields, unique references | Schema plus trusted broker/assembler |
| Mutable data | Recursively freeze or deep-copy after validation; no shared mutable frames | Future runtime |
| Replay | Canonical byte SHA-256 digest for comparison; not an origin signature | Future audit implementation |
| Logs | IDs, trusted origin, message kind, verdict, digest and sensitivity only by default | Future audit implementation |
| Delivery | In-process advisory routing for the initial spike; no network bus or background retries | CMR-06 scope |

**Security constraints:** Logs must not retain private user transcripts or full wiki evidence by default. No dynamic handler import from a model-supplied string, no arbitrary workspace or DB handle in payload, no implicit wiki request after resume, and no shared blackboard. The Ollama redirect/proxy issue remains independently open before sensitive model trials. The reviewed repository/writer is the only existing route for protected changes.

## Version and compatibility policy

1. Exact `(schema_id, version, kind)` identifies a v1 contract. Unknown or malformed versions and unregistered kinds **fail closed** without LLM fallback.
2. Required fields, allowed origin, size limits, meaning and receiving component are part of a contract. No permissive unknown fields or inferred defaults.
3. Introducing a kind requires registry/schema/compatibility review and negative tests. Incompatible payload changes require new version plus explicit migration; old readers cannot silently reinterpret new messages.
4. During shadow migration, unsupported message contracts may use the unchanged direct-call path only if the previous consent/scope checks still hold; no write or privileged fallback is allowed.
5. Message origin, correlation and checksums are not credentials, signatures, approvals or authorization tokens.

## Verification and deferred work

[`CMR-04_CONTRACT_TESTS.py`](CMR-04_CONTRACT_TESTS.py) checks schema and producer/consumer consistency **without importing the HWI runtime**. [`CMR-04_NEGATIVE_TESTS.md`](CMR-04_NEGATIVE_TESTS.md) distinguishes exercised shape cases from not-yet-implemented origin/spoof/replay/consent/state tests. JSON Schema cannot authenticate a sender, enforce duplicate-key parse policy, verify workflow parentage, or prove immutability; these remain open for CMR-05/06. Transition effects, idempotency, retries and failures belong to CMR-05; handler execution belongs to CMR-06; consent and behavior parity belong to CMR-07/08.

**Technical exit:** schema v1, compatibility table, bounded data model, trusted provenance policy, and specified negative tests all tracked together with a reproducible schema-only test run. No runtime modification and **no production acceptance** follows from this checkpoint.
