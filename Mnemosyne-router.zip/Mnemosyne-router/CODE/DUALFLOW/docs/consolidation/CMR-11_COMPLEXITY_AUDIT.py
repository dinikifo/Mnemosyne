#!/usr/bin/env python3
"""Reproducible static audit of CMR-11 read-profile consolidation."""
from __future__ import annotations
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PATHS = ('hwi_governance/read_ports.py', 'tools/dualflow_read_ports.py',
         'hwi_router/read_protocol.py')


def inspect():
    counts = {'read_profile_bootstrap_locations': 0,
              'eager_router_imports_in_direct_read_modules': 0,
              'profile_loader_entries': 0}
    for rel in PATHS:
        text = (ROOT / rel).read_text('utf-8')
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id == 'AdvisoryRouter':
                    counts['read_profile_bootstrap_locations'] += 1
            if isinstance(node, ast.ImportFrom) and rel != 'hwi_router/read_protocol.py':
                if node.lineno < next((n.lineno for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))), 10**9):
                    if (node.module or '').startswith('hwi_router'):
                        counts['eager_router_imports_in_direct_read_modules'] += 1
        if rel == 'hwi_router/read_protocol.py':
            counts['profile_loader_entries'] = text.count("'CMR-09': {") + text.count("'CMR-10': {")
    return counts


if __name__ == '__main__':
    got = inspect()
    assert got == {'read_profile_bootstrap_locations': 1,
                   'eager_router_imports_in_direct_read_modules': 0,
                   'profile_loader_entries': 2}, got
    print(json.dumps(got, indent=2))
