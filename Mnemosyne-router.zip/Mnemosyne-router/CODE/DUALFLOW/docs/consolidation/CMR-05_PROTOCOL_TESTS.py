#!/usr/bin/env python3
"""CMR-05 design-consistency tests. NOT a router, security test, or live effect runner.

Requires standard library only. Run: python -B docs/consolidation/CMR-05_PROTOCOL_TESTS.py
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent

def load(name):
    return json.loads((HERE/name).read_text(encoding='utf-8'))

M = load('CMR-05_TRANSITION_MATRIX.json')
P = load('CMR-05_EFFECT_POLICY.json')
COMPAT = load('CMR-04_COMPATIBILITY.json')
SCHEMA = load('CMR-04_MESSAGE_SCHEMA_V1.json')


def check(m=M, p=P):
    """Reject inconsistent *design* matrices; contains no runtime enforcement."""
    compatibility = {r['kind']: r for r in COMPAT['messages']}
    schema_kinds = {r['properties']['kind']['const'] for r in SCHEMA['oneOf']}
    assert set(compatibility) == schema_kinds, 'CMR-04 kinds disagree'
    assert p['authority']=='advisory_only' and p['no_router_writes'] is True
    assert p['default_effect_policy']=='deny'
    assert p['no_automatic_fallback_dispatch'] is True
    phases = set(m['phases'])
    assert m['initial_phase']=='READY' and len(phases)==len(m['phases'])
    assert set(m['terminal_phases']) <= phases
    registered = set()
    effects = {r['id']:r for r in p['allowed_effects']}
    assert len(effects)==len(p['allowed_effects'])
    assert not effects.keys() & set(p['explicitly_denied_effects'])
    assert all(e['auto_retry'] is False for e in effects.values())
    by_kind = defaultdict(list)
    edges = defaultdict(set)
    for t in m['transitions']:
        identity = (t['phase'], t['kind'], t['trusted_origin'])
        assert identity not in registered, 'ambiguous exact-match route'
        registered.add(identity)
        assert t['phase'] in phases and t['next_phase'] in phases
        assert t['phase'] not in m['terminal_phases'], 'terminal state emits messages'
        assert t['kind'] in compatibility, 'unregistered message kind'
        assert t['trusted_origin'] == compatibility[t['kind']]['producer'], 'forged origin mapping'
        assert t['authority'] == 'advisory_only'
        assert t['parent_rule'] in ('root', 'pending_request', 'latest_result')
        if t['parent_rule']=='root':
            assert t['phase']=='READY' and t['trusted_origin']=='formation'
        else:
            assert t['phase']!='READY', 'orphan child response'
        assert all(effect in effects for effect in t['effect_intents']), 'unknown/disallowed effect'
        for e in t['effect_intents']:
            assert effects[e]['input_kind']==t['kind'], 'effect bound to wrong request kind'
            assert set(effects[e]['required_guards']) <= set(t['guards']), 'missing effect guard'
        by_kind[t['kind']].append(t)
        edges[t['phase']].add(t['next_phase'])
    assert set(by_kind)==schema_kinds, 'CMR-04 kind not routed'
    for k in ('knowledge.practice.result','model.question.result'):
        assert len(by_kind[k])==1 and by_kind[k][0]['parent_rule']=='pending_request'
        assert not by_kind[k][0]['effect_intents']
    assert all(t['parent_rule']=='latest_result' for t in m['transitions']
               if t['phase'] in ('HAVE_PRACTICE','HAVE_MODEL'))
    assert len([t for t in by_kind['formation.practice.request']])==1
    assert len(by_kind['formation.model_question.request'])==2
    assert len(by_kind['formation.question.suggestion'])==3
    for t in by_kind['formation.practice.request']:
        assert {'explicit_practice_query','notebook_scope_pin'} <= set(t['guards'])
    for t in by_kind['formation.model_question.request']:
        assert {'model_questions_opt_in','guidance_sharing_opt_in_if_refs','transport_hardened_for_sensitive_input'} <= set(t['guards'])
    for t in by_kind['formation.question.suggestion']:
        assert t['next_phase']=='SUGGESTED' and t['effect_intents']==['formation.question.deliver']
    for t in by_kind['model.question.result']:
        assert 'deterministic_question_validation' in t['guards']
    # Acyclic choreography within one correlation: no hidden unbounded recursion.
    visited, visiting = set(), set()
    def visit(phase):
        assert phase not in visiting, 'workflow cycle without a new correlation'
        if phase in visited: return
        visiting.add(phase)
        for dest in edges[phase]: visit(dest)
        visiting.remove(phase); visited.add(phase)
    visit('READY')
    assert phases <= visited, 'unreachable phase'
    limits=p['limits']
    assert limits['max_envelope_bytes'] <= 16384
    assert limits['max_json_depth'] <= 8 and limits['max_json_nodes'] <= 256
    assert 0 < limits['max_dispatch_hops'] <= 8
    assert limits['max_inflight_effects']==1 and limits['max_nested_router_invocations']==0
    assert limits['max_auto_retries']==0
    assert sum(e['timeout_ms'] for e in effects.values()) <= limits['max_workflow_deadline_ms']
    idem=p['idempotency']
    assert idem['replay_key']==['trusted_session_scope','message_id']
    assert 'without rerun' in idem['same_id_same_digest']
    assert idem['same_id_different_digest']=='reject'
    assert 'do not automatically redispatch' in idem['restart_or_unknown']
    failures={f['case']:f for f in p['failures']}
    assert len(failures)==len(p['failures'])
    required={'parse_or_shape_rejected','origin_or_parent_rejected','no_match_or_ambiguous_match',
              'consent_or_scope_missing','handler_output_rejected','external_timeout',
              'handler_interrupted','external_outcome_unknown','same_id_same_digest_duplicate',
              'same_id_different_digest','stale_broker_revision','model_question_rejected','limits_exceeded'}
    assert set(failures)==required
    assert all(f['auto_retry'] is False for f in failures.values())
    assert failures['external_outcome_unknown']['recovery']=='owner_guided_fallback_no_retry'
    assert 'raw private transcript by default' in p['audit_prohibitions']
    return True


class CMR05DesignConsistencyTests(unittest.TestCase):
    def test_full_design_contract(self): self.assertTrue(check())

    def test_v1_kinds_are_covered(self):
        self.assertEqual({r['kind'] for r in M['transitions']},
                         {r['kind'] for r in COMPAT['messages']})

    def test_no_runtime_privileged_effects(self):
        self.assertTrue(set(P['explicitly_denied_effects']))
        self.assertFalse({r['id'] for r in P['allowed_effects']} & set(P['explicitly_denied_effects']))

    def test_default_reject_instead_of_model_fallback(self):
        self.assertEqual(P['default_effect_policy'],'deny')
        self.assertTrue(P['no_automatic_fallback_dispatch'])

    def test_competing_patterns_are_rejected(self):
        m=deepcopy(M);m['transitions'].append(deepcopy(m['transitions'][0]))
        with self.assertRaisesRegex(AssertionError,'ambiguous'): check(m)

    def test_unregistered_effect_rejected(self):
        m=deepcopy(M); m['transitions'][0]['effect_intents']=['governance.queue.apply']
        with self.assertRaisesRegex(AssertionError,'effect'): check(m)

    def test_wrong_origin_rejected(self):
        m=deepcopy(M); m['transitions'][1]['trusted_origin']='model_adapter'
        with self.assertRaisesRegex(AssertionError,'origin'): check(m)

    def test_orphan_response_rejected(self):
        m=deepcopy(M);m['transitions'][1]['phase']='READY'
        with self.assertRaises(AssertionError): check(m)

    def test_missing_broker_consent_rejected(self):
        m=deepcopy(M);m['transitions'][0]['guards'].remove('explicit_practice_query')
        with self.assertRaisesRegex(AssertionError,'guard'): check(m)

    def test_missing_model_consent_rejected(self):
        m=deepcopy(M); m['transitions'][2]['guards'].remove('model_questions_opt_in')
        with self.assertRaisesRegex(AssertionError,'guard'): check(m)

    def test_removed_kind_rejected(self):
        m=deepcopy(M);m['transitions']=[t for t in m['transitions'] if t['kind']!='model.question.result']
        with self.assertRaises(AssertionError): check(m)

    def test_unbounded_cycle_rejected(self):
        m=deepcopy(M);m['transitions'][4]['next_phase']='READY'
        with self.assertRaises(AssertionError): check(m)

    def test_automatic_retry_rejected(self):
        p=deepcopy(P);p['allowed_effects'][0]['auto_retry']=True
        with self.assertRaises(AssertionError):check(M,p)

    def test_unknown_outcome_recovery_must_be_conservative(self):
        p=deepcopy(P)
        next(f for f in p['failures'] if f['case']=='external_outcome_unknown')['recovery']='blind_replay'
        with self.assertRaises(AssertionError):check(M,p)

    def test_missing_failure_class_rejected(self):
        p=deepcopy(P);p['failures']=p['failures'][:-1]
        with self.assertRaises(AssertionError):check(M,p)

    def test_invalid_limits_rejected(self):
        p=deepcopy(P); p['limits']['max_dispatch_hops']=100
        with self.assertRaises(AssertionError):check(M,p)

    def test_no_actual_authority_promotion(self):
        self.assertTrue(all(r['authority']=='advisory_only' for r in M['transitions']))
        self.assertTrue(all(r['authority']=='advisory_only' for r in COMPAT['messages']))

if __name__ == '__main__':
    unittest.main(verbosity=2)
