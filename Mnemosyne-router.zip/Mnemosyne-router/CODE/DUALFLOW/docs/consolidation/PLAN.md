# HWI — Typed Message Router & Codebase Consolidation Plan

> **Status:** Planning, baseline and contracts verified; isolated CMR-06 router tested; CMR-07 shadow audited; operator accepted the revised CMR-07 read-only PracticeReader delivery candidate on 2026-11-14; CMR-08 model/transport and CMR-09 Dual-Flow read-port consolidation technically verified, and CMR-10 governance read-only integration technically verified; CMR-11 packaging verified, CMR-12 independent offline review concluded with REWORK decision; no production acceptance. **Branch:** `plan/typed-router-consolidation` (experimental code, no protected-source changes). **Date:** 2026-11-14.

## Progress — independent CMR track

**Completed: 12 / 12 review stages (100%).** Implementation: **6 / 11 (54.55%)**. The revised CMR-07 port was operator-accepted on 2026-11-14; CMR-08 adapter/transport and CMR-09 Dual-Flow read-port technical exits are verified. Production acceptance for new candidate: **not granted**.

Progress is checkpoint-count based, **not** effort weighted. Completed stages include planning, baseline, design contracts, a tested isolated router and opt-in Formation knowledge/model ports; protected approved-source files remain unchanged. `PROGRESS.json` is the machine-readable source of truth; update both files in the same reviewed commit. All other HWI, RC and SEC milestones retain their previous statuses.

## Architecture: abstract → concrete

**Purpose:** Reduce integration coupling by making component boundaries explicit, independently testable and safely replaceable. Not a redesign of trusted authority.

**Invariant principles**

1. Components own state and internal control flow; the router owns neither state nor permissions.
2. The router selects handlers from versioned typed messages using deterministic rules. Free-text ELIZA-style matching is allowed at the human edge, not as an inter-module protocol.
3. A trusted ingress assigns origin/provenance; no model/tool payload can claim human approval. A human chat reply is not a signed authorization.
4. Transition contracts validate input, output, source, current state, bounds and effects. Rejected transitions do not mutate internal state or run protected operations.
5. Handlers describe side effects; existing trusted services decide and execute them. Signed wiki writes, fitness checks, ledger consistency and human review are not reimplemented by the router.
6. Fail closed on unrecognized, ambiguous or invalid messages; retain the current guided fallback only at explicitly supported advisory interfaces.
7. Prefer a queue for regular dispatch; add a bounded call stack **only** after a measured nested-workflow need. No global mutable blackboard.
8. New work stays in the experimental candidate. The accepted Dual-Flow baseline and approved wiki/agent source remain byte-for-byte unchanged unless separately reviewed and authorized.

**Target responsibilities**

| Boundary | Owner / existing seam | Candidate role |
|---|---|---|
| Conversation | `hwi_formation/dialogue.py`, `core.py` | Publish/consume advisory typed events; keep current state machine |
| Knowledge | `hwi_formation/wiki_adapter.py` via `hwi_governance/repository.py` | Request/result adapter; no new database handle |
| Model | `hwi_formation/model.py` via `autogpt_lite.llm.ollama` | Bounded request/result adapter; never call as a validator |
| Dual-Flow | `tools/`, `hwi_i02/` | Candidate message integration for reporting/review and read paths |
| Fitness / proposals | `hwi_governance/` and approved HWI-07/HWI-08 | Request/status/proposal events only; trusted services retain authority |
| Agent runtime | `autogpt_lite/agent.py`, components and persistence | Optional consumer/producer; keep runtime state ownership |

**Illustrative envelope (schema intent, not implementation):**

```json
{"version": 1, "kind": "knowledge.practice.request", "correlation_id": "<opaque-id>", "causation_id": "<opaque-id-or-null>", "origin": "<trusted-ingress-identity>", "payload": {"ambiguity": "missing_success_criteria"}}
```

This is not an authority-bearing token. Define sensitivity, idempotency, limits, storage and error semantics in CMR-04/05 before implementation.

## Checkpoints (from abstract to specific)

| Stage | Layer | Checkpoint | Status |
|---|---|---|---|
| CMR-01 | Architecture | Adopt architecture charter | ✅ Complete |
| CMR-02 | Baseline | Freeze source lineage and current behavior | ✅ Complete |
| CMR-03 | Baseline | Map dependencies and identify consolidation seams | ✅ Complete |
| CMR-04 | Contract | Specify message envelopes and type contracts | ✅ Complete |
| CMR-05 | Contract | Specify transition and effect protocols | ✅ Complete |
| CMR-06 | Core spike | Prototype deterministic router in isolation | ✅ Complete |
| CMR-07 | Vertical slice | Migrate one Formation advisory interaction | ✅ Revised port accepted 2026-11-14 |
| CMR-08 | Vertical slice | Consolidate read-only knowledge and model adapters | ✅ Technical exit verified |
| CMR-09 | Migration | Integrate Dual-Flow reporting and agent-side read paths | ✅ Technical exit verified |
| CMR-10 | Migration | Integrate governance proposal boundary without write bypass | ✅ Technical exit verified |
| CMR-11 | Consolidation | Consolidate packaging and remove proven duplication | ✅ Technical exit verified |
| CMR-12 | Acceptance | Independent verification and release decision | ✅ Review complete; **REWORK**, production not approved |

## Detailed work and closure evidence

### CMR-01 — Adopt architecture charter

**Status:** COMPLETE (planning decision only).

**Work:** Adopt coordination-vs-authority split; preserve state ownership, approved code and human authorization; identify this as a planning decision only.

**Exit evidence:** ADR-001 accepted as the planning charter; no runtime or approved-core modifications.

### CMR-02 — Freeze source lineage and current behavior

**Status:** COMPLETE — technical evidence only; new production/owner acceptance not granted.

**Work:** Inventory packages, branch/commit pins, approved copies, module owners, test gates and external dependencies; hash the baseline and capture reproducible passing/blocked test results.

**Exit evidence:** [`CMR-02_BASELINE_FREEZE.md`](CMR-02_BASELINE_FREEZE.md) and [`CMR-02_SOURCE_LOCK.json`](CMR-02_SOURCE_LOCK.json): 385/385 manifest verification, 262/262 packaged Git-tracked source parity, and 636/636 independently rerun Linux offline tests across five suites. Native Mac/other production gates remain open.

### CMR-03 — Map dependencies and identify consolidation seams

**Status:** COMPLETE — static dependency and architectural mapping only; no runtime or independent release approval.

**Work:** Map cross-package imports/calls, duplicated adapters, direct SQLite access and state ownership. Select the smallest seams; record interfaces that must stay direct.

**Exit evidence:** [`CMR-03_DEPENDENCY_MAP.md`](CMR-03_DEPENDENCY_MAP.md) + AST inventory [`CMR-03_DEPENDENCIES.json`](CMR-03_DEPENDENCIES.json), reproducible via [`CMR-03_inventory.py`](CMR-03_inventory.py). Static before graph: 36 cross-group import occurrences across 114 non-test-named files (28 candidate / 8 separately approved); 5 candidate Ollama-provider import sites. Ownership, safe/prohibited edges, ranked seam targets and complexity metrics documented. No implementation change.

### CMR-04 — Specify message envelopes and type contracts

**Status:** COMPLETE — design and schema tests only; no runtime or production acceptance.

**Work:** Define versioned kind, schema_id, correlation_id, causation_id, origin assigned by trusted ingress, bounded immutable payload, trace reference and sensitivity classification. Distinguish conversation from authorization.

**Exit evidence:** [`CMR-04_MESSAGE_CONTRACTS.md`](CMR-04_MESSAGE_CONTRACTS.md), [`CMR-04_MESSAGE_SCHEMA_V1.json`](CMR-04_MESSAGE_SCHEMA_V1.json), [`CMR-04_COMPATIBILITY.json`](CMR-04_COMPATIBILITY.json), [`CMR-04_NEGATIVE_TESTS.md`](CMR-04_NEGATIVE_TESTS.md) and reproducible [`CMR-04_CONTRACT_TESTS.py`](CMR-04_CONTRACT_TESTS.py): 11/11 schema-shape test methods pass. Trusted ingress spoof/replay/consent tests explicitly deferred; no router implemented. Existing Formation focused regression: 40/40 passed with approved dependencies supplied. Evidence: [`CMR-04_TEST_EVIDENCE.json`](CMR-04_TEST_EVIDENCE.json).

### CMR-05 — Specify transition and effect protocols

**Status:** COMPLETE — design contract and static verification only; no router runtime, live security tests or production acceptance.

**Work:** Defined six ephemeral coordination phases and eight versioned, deterministic advisory transitions with explicit parent/correlation, trusted origin, consent, effect allowlist, limits and default-deny rules. Separate authorization stays with trusted owning adapters. Described pre-validation, effect execution, interruption/uncertainty, no automatic retries, and recovery/rollback without claiming distributed atomicity. Internal error verdicts are not new CMR-04 wire message kinds.

**Exit evidence:** [`CMR-05_TRANSITIONS_AND_EFFECTS.md`](CMR-05_TRANSITIONS_AND_EFFECTS.md), [`CMR-05_TRANSITION_MATRIX.json`](CMR-05_TRANSITION_MATRIX.json), [`CMR-05_EFFECT_POLICY.json`](CMR-05_EFFECT_POLICY.json), [`CMR-05_NEGATIVE_TESTS.md`](CMR-05_NEGATIVE_TESTS.md), design tests [`CMR-05_PROTOCOL_TESTS.py`](CMR-05_PROTOCOL_TESTS.py): **17/17 pass**; CMR-04 schema tests **11/11 pass**; existing Formation focused tests **40/40 pass**. Evidence, hashes and remaining security work in [`CMR-05_TEST_EVIDENCE.json`](CMR-05_TEST_EVIDENCE.json). No runtime source changes or approved-source mutation.

### CMR-06 — Prototype deterministic router in isolation

**Status:** COMPLETE — isolated technical prototype; not deployed, integrated, or independently accepted for production.

**Work:** Added `hwi_router` with trusted source/session handles, exact route registry from CMR-05 matrices, CMR-04 schema and payload bounds, recursive payload freeze, pre-handler guards and parent validation, local replay-cache, effect descriptors only, fail-closed rejects and no nested calls/stack. Existing Formation/wiki/governance/approved source remains unchanged.

**Exit evidence:** [`CMR-06_ROUTER_SPIKE.md`](CMR-06_ROUTER_SPIKE.md), [`CMR-06_TEST_EVIDENCE.json`](CMR-06_TEST_EVIDENCE.json), `hwi_router/test_router.py` (**41/41 pass**), `hwi_router/benchmark.py` (3 × 500 overhead measurement); CMR-04 **11/11**, CMR-05 **17/17**; five isolated baseline suites **636/636** on Linux in proper packaged layout. Source code and test locations are pinned in the evidence record. No live I/O, hard synchronous cancellation, crash-durable replay or semantic acceptance is claimed.

### CMR-07 — Migrate one Formation advisory interaction

**Status:** COMPLETED — revised read-only port accepted by the operator on 2026-11-14; no production approval.

**Work:** Use adapter/shadow mode for Formation -> practice retrieval -> optional model -> question suggestion, retaining dialogue.py state machine, explicit RAG and model consent, guided fallback and non-commissioning contract.

**Historical shadow-candidate evidence (reworked and superseded):** [`CMR-07_FORMATION_SHADOW.md`](CMR-07_FORMATION_SHADOW.md), [`CMR-07_TEST_EVIDENCE.json`](CMR-07_TEST_EVIDENCE.json), 15/15 shadow tests including 12 A/B fixtures, same saved/CONFIRMED purpose contract, same pinned broker results; 636/636 legacy offline tests passing in clean release layout. **Previously required, since resolved by operator acceptance of revised implementation:** operator usefulness/coupling assessment in [`CMR-07_USEFULNESS_REVIEW.md`](CMR-07_USEFULNESS_REVIEW.md). Independent AST audit (`CMR-07_COUPLING_AUDIT.json`, 7/7 audit tests) finds zero concrete knowledge/model call replacements and two additional lazy router imports; `CMR-07_ENGINEERING_REVIEW.md` therefore recommends REWORK, not acceptance. No reduction in direct imports yet; model path disabled in shadow; no new authorization.

**CMR-07 rework evidence:** [`CMR-07_REWORK_IMPLEMENTATION.md`](CMR-07_REWORK_IMPLEMENTATION.md), [`CMR-07_REWORK_COUPLING_AUDIT.json`](CMR-07_REWORK_COUPLING_AUDIT.json), `hwi_formation/knowledge_port.py` and `hwi_router/formation_knowledge.py`. Actual PracticeReader substitution removes the direct `retrieve_practices` call site from Formation CLI (1→0) while retaining one read-only trusted broker delegate. 12 paired cases and explicit CONFIRM parity, adversarial errors, a real broker read-only parity test and offline legacy suites passed. **Accepted:** operator explicitly accepted the revised candidate on 2026-11-14; CMR-08 authorized.

### CMR-08 — Consolidate read-only knowledge and model adapters

**Status:** COMPLETE — technical exit verified; no production approval.

**Work:** Route advisory knowledge and model calls through a bounded API without duplicating repository or broker access; address transport redirect/proxy risk before sensitive Ollama trials.

**Exit evidence:** [`CMR-08_ADAPTER_CONSOLIDATION.md`](CMR-08_ADAPTER_CONSOLIDATION.md), [`CMR-08_TEST_EVIDENCE.json`](CMR-08_TEST_EVIDENCE.json), [`CMR-08_ADAPTER_AUDIT.py`](CMR-08_ADAPTER_AUDIT.py): two substitutable model ports; T03/T05/T08 opt-in model questions; numeric-loopback proxy/redirect hardening for Formation only; no direct wiki DB access, same broker references, 19/19 new cases, 96/96 integrated adapter tests, 636 legacy cases (635 pass, 1 skip), 11/11 schema + 17/17 protocol tests. No live Ollama/native Mac release verification; draft remains a separate validated, non-routed contract.

### CMR-09 — Integrate Dual-Flow reporting and agent-side read paths

**Status:** COMPLETE — candidate engineering technical exit; no protected-source modification or production approval.

**Work:** Use typed messages for simulation/review/report request/result flows where they reduce coupling. Keep agent internal state and persistence in owning modules; do not move runtime authority into router.

**Exit evidence:** [`CMR-09_DUALFLOW_READ_INTEGRATION.md`](CMR-09_DUALFLOW_READ_INTEGRATION.md), [`CMR-09_TEST_EVIDENCE.json`](CMR-09_TEST_EVIDENCE.json), [`CMR-09_COUPLING_AUDIT.py`](CMR-09_COUPLING_AUDIT.py): selected high-level direct read/simulation import edges **2→0** with unchanged lower-level implementations; request/result pins and no authorization effects; real broker and WL-04 fixture parity. 17/17 new tests, 89/89 router, 28/28 contracts, legacy 636 executed (635 passed, 1 skipped). No approved agent runtime modification; only the candidate model-evaluation read path migrated.

### CMR-10 — Integrate governance proposal boundary without write bypass

**Status:** COMPLETE — technical exit verified; no new submission or write authorization.

**Work:** Add proposal/read-only status adapters only; signed review, fitness assessment, queue reconciliation and wiki write remain under current trusted services. Do not make event origin an approval token.

**Exit evidence:** [`CMR-10_GOVERNANCE_READ_BOUNDARY.md`](CMR-10_GOVERNANCE_READ_BOUNDARY.md), [`CMR-10_TEST_EVIDENCE.json`](CMR-10_TEST_EVIDENCE.json), [`CMR-10_COUPLING_AUDIT.py`](CMR-10_COUPLING_AUDIT.py). Opt-in `queue-status` and `queue-review` use a substitutable read-only port; original reads remain the default. Four message kinds, four transitions, two read-only intents, no write/approval effects. Selected CLI direct read call sites **2→0** while preserving trusted review services. Scratch-notebook parity for UNGATED, UNVERIFIED, VERIFIED and exact CLI outputs; no protected mutations, forged claim/replay/interruption negative tests. **31/31** CMR-10, **636** legacy executed (**635 passed, 1 skip**), **106/106** router, **28/28** contracts and **82/82** protected source files identical. `queue-submit`, `queue-apply`, fitness/gate, recovery and signed writer retain existing execution authority. Cross-database atomicity remains unresolved.

### CMR-11 — Consolidate packaging and remove proven duplication

**Status:** COMPLETE — candidate technical exit; not production acceptance.

**Work:** Deduplicate CMR-09/10 profile bootstrap and dispatch checks with `hwi_router/read_protocol.py`, while keeping component-local result and authority validation. Preserve lazy import in direct CLI paths, default routing opt-out, and hardcoded profile allowlist. Package a complete release-layout snapshot over frozen CMR-05, retaining unchanged approved sources and original baseline-integrity history.

**Exit evidence:** [`CMR-11_PACKAGING_AND_DEDUP.md`](CMR-11_PACKAGING_AND_DEDUP.md), [`CMR-11_TEST_EVIDENCE.json`](CMR-11_TEST_EVIDENCE.json), [`CMR-11_COMPLEXITY_AUDIT.py`](CMR-11_COMPLEXITY_AUDIT.py), `hwi_router/test_read_protocol_cmr11.py`, `tools/test_cmr11_snapshot.py`, `tools/build_cmr11_snapshot.py`. The two read adapters lose 42 source lines together; a 74-line shared helper is added (+32 runtime lines net), trading a small increase in lines for a single hardened profile boundary. All offline suites pass, release snapshot integrity and Git rollback rehearsed; 82 approved files unchanged. The first Mac-harness attempt exposed an eager-router-import regression, corrected by lazy importing; final clean rerun passed. CMR-12 must decide if consolidation benefits justify total added implementation complexity.

### CMR-12 — Independent verification and release decision

**Status:** COMPLETE as an independent offline **REWORK** decision; **not** an accepted production release.

**Work:** Run all offline suites, native environment gates and security regression; compare source-lineage, failures, logs, operational restore and actual code complexity. Require human approval for new candidate scope.

**Exit evidence:** [`CMR-12_INDEPENDENT_REVIEW.md`](CMR-12_INDEPENDENT_REVIEW.md), [`CMR-12_TEST_EVIDENCE.json`](CMR-12_TEST_EVIDENCE.json), [`CMR-12_RELEASE_DECISION.json`](CMR-12_RELEASE_DECISION.json). A fresh CMR-11 snapshot verified 470/470 payload files, 82/82 approved sources unchanged, 816/817 distinct tests passed with one documented skip, synthetic shared-provider HTTP redirect leak reproduced outside the secured Formation path, and source rollback verified. The explicit engineering release decision is **REWORK**. Native macOS, live Ollama, cross-database atomicity, persistent identity and human authorization are unresolved. Completing the review track does **not** accept the candidate.

## Consolidation sequencing and gates

**Hard gates:** CMR-02/03 before new module choices; CMR-04/05 completed before routing code; CMR-06 before switching any real call; CMR-07 advisory and in shadow mode before CMR-08/09; CMR-10 cannot loosen governance restrictions; CMR-12 requires independent review. Any failure blocks the next stage.

**Rollback:** Existing direct-call behavior stays available until each migrated seam passes parity tests. Enable new routing only for explicitly selected experiments; on failure revert the seam, not the accepted baseline. Record observed failure, fix rationale and fresh evidence before reattempt.

**Do not conflate checkpoint tracks:** CMR progress is independent of the existing 14-checkpoint HWI integration roadmap, the 10/10 accepted Dual-Flow research baseline, refactor RC-05, and pending governance/Formation human acceptance. A CMR milestone is not a waiver of any of those gates.

**Known security/operations blockers carried forward (not closed by this plan):** Ollama redirect/proxy data boundary; cross-database gate/ledger atomicity and interrupted submissions; notebook-instance identity; revocation and signing custody; native macOS verification; approved-writer preservation; Formation commissioning remains explicitly excluded.

**Metrics at CMR-03 and CMR-11:** Count forbidden cross-component imports, direct capability-specific adapter duplicates, router versus direct-call lines/concepts, number of integration tests, and parity failures. A router is a candidate only if it lowers *observed* coupling without introducing a global coordinator that knows component internals.

## Rules for updating progress

1. Each stage starts `pending`; a reviewer records exact artifacts/tests and acceptance evidence before setting it `completed`.
2. Update `PROGRESS.json` stage status and evidence, recompute `completed_stages / total_stages * 100`, and update this plan in the same commit.
3. Do not mark implementation stages complete for design intent alone; a passing unit test is not human acceptance of a protected boundary.
4. If a stage fails its exit criteria, mark it `blocked` or keep `pending`; completed count does not increase. Reopen a stage if its evidence is invalidated.
5. Protect new scope: no deployment or production-ready claim without CMR-12 and the existing independent release approvals.

**CMR track review complete: 12/12 (100%). Explicit outcome: REWORK / production NOT_APPROVED.** There is no automatic next CMR checkpoint. Remediation requires separate scope and acceptance; shared provider hardening, transaction safety, native-platform tests and human authorization remain open.
