# CMR-07 — Formation opt-in advisory shadow integration

**Date:** 2026-11-13  
**Branch:** `plan/typed-router-consolidation`  
**Decision:** TECHNICAL CANDIDATE VERIFIED; **checkpoint not yet accepted** (human usefulness review outstanding). No production authorization.

## Scope and comparison

This is the first **opt-in, read-only observational** seam between the existing Formation CLI and the CMR-06 typed router. Use `--router-shadow` with `start` or `resume` to observe the advisory transition. The default remains exactly the preexisting direct path. The flag is not persisted in the session and must be requested for each process invocation.

1. After the first Formation answer, the normal state machine selects the `initial_task` guided question. The adapter issues a candidate `formation.question.suggestion` message under the existing T06 contract, verifies the resulting **descriptor** is `formation.question.deliver`, and compares the suggested text with the original guided question. The CLI still displays and saves its own original prompt. This avoids mapping the separate, unrepresented `purpose` field into the message schema.
2. When the operator *already* explicitly requested a practice query and the normal CLI has confirmed the notebook's existing scope pin, the existing read-only repository is called **once**. Only after that call returns, the shadow observer mirrors the T01→T02→T07 transitions using the first advisory check from each returned typed practice (up to three). No additional wiki read occurs. With no cards, the router observes T01→T02 and the existing guided flow remains in place.
3. Model effects are **disabled** in the CMR-07 adapter regardless of the router's registration. `--model-questions` retains its existing independent behavior; this experiment introduces no new Ollama call or guidance sharing. The previously identified redirect/proxy boundary remains open for CMR-08.

The router's handlers return *effect descriptors only*. The integration never executes those descriptors, changes the Formation state machine, modifies the purpose draft, grants fitness, or performs writes. Diagnostic output is a fixed status phrase (no user answer, private wiki text, paths, or message IDs).

### Opt-in example (offline)

```sh
PYTHONPATH="<candidate checkout>:<approved wiki root>:<approved provider root>" \
python -B -m hwi_formation --state-dir "<private local state dir>" start --manual --router-shadow
```

The trusted CLI is still responsible for real operator/session checks and scope inspection. Identity-bound CMR-06 handles have *in-process* meaning only; they do not authenticate hostile Python modules. Shadow checks rely on the existing broker's pinned-current-revision read and do **not** independently re-query or prove freshness. Router failures cannot be silently upgraded into permissions; the normal Formation path carries on without executing router effects.

## Verification — current source overlaid into frozen release layout

| Suite | Result |
|---|---:|
| Dual-Flow | 335/335 pass |
| Mac launcher contract tests (Linux emulation; no native Mac) | 16/16 pass |
| Content evaluator | 65/65 pass |
| Governance | 112/112 pass |
| Formation | 108/108 pass |
| **Legacy total** | **636/636 pass** |
| Router existing + Formation shadow | **56/56 pass (41 + 15)** |
| CMR-04 schema | 11/11 pass |
| CMR-05 protocol | 17/17 pass |

The candidate is tested from a **fresh extracted copy of the CMR-05 release layout** with only `hwi_formation/cli.py`, the new `hwi_router` candidate, and the previously committed contract docs overlaid. The original approved agent and wiki directories were not modified. The direct bare-checkout governance invocation failed one install-layout test because its hardcoded ancestor `INSTALL.sh` is absent there; the same test passed in the correct release layout.

Specific A/B and negative tests:

- 12 predeclared initial-answer cases: saved Formation records and draft content field-for-field equivalent for shadow on and off.
- Explicit `CONFIRM` case: confirmed session and returned purpose contract equal, including `FORMED_NOT_COMMISSIONED`, `NOT_TESTED`, false execution and wiki-write flags.
- Real read-only practice broker: identical practice IDs/revisions, identical `review_draft` outputs, and unchanged notebook file bytes after opt-in and baseline read paths.
- Malformed ref and revision hashes, authority spoofing, missing session, missing notebook pin, missing broker read, wrong field and over-budget practice cards: rejected without new effects.
- Shadow failure injection: existing Formation question/record and practice retrieval continue unchanged; exceptions do not leak into operator diagnostic output.
- Router T03/T04/T05/T08 model routes are registered but their real guard hooks are explicitly disabled by this adapter. No model semantic or transport validation is claimed.

## Complexity, coupling and usefulness decision

This is a **shadow implementation**, not a completed migration: the Formation CLI gains an optional reference to `hwi_router.formation_shadow`, while the existing direct `retrieve_practices` and model call paths remain. **No reduction in direct cross-component imports is claimed.** The first guided-question path selects an identical question by design; A/B parity does not prove improved question usefulness, nor does it justify the new router's complexity.

See [`CMR-07_USEFULNESS_REVIEW.md`](CMR-07_USEFULNESS_REVIEW.md) for the required human assessment. That review must explicitly decide whether contract observability and isolated testability justify this additional seam, and whether CMR-08 should proceed, change the design, or drop the experiment.

**CMR-07 remains pending** until a human usefulness review is recorded. Accordingly overall checkpoint count is **6/12 (50.00%)**, not 7/12. The accepted research baseline, fitness governance and protected wiki writer are unchanged.
