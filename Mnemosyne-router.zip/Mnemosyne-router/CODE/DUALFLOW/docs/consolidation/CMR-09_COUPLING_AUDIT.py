"""Static source-only seam audit for CMR-09; execute from a Git checkout.

Counts direct imports/calls in the two migrated high-level consumers; this is
NOT a claim of reduction in repository-wide imports or total code complexity.
"""
from __future__ import annotations
import ast
import json
from pathlib import Path
import subprocess

BASELINE = '88d63368909b21362370eb9d0c02049b1ed918b1'  # CMR-08
ROOT = Path(__file__).resolve().parents[2]
TARGETS = {
    'tools/review_dualflow.py': ('simulate_dualflow', 'simulate'),
    'tools/evaluate_dualflow_model.py': ('read_dualflow_wiki', 'select_pinned_workflow'),
}


def measure(source: str, module: str, call: str) -> dict[str, int]:
    tree = ast.parse(source)
    direct_imports = sum(isinstance(node, ast.ImportFrom) and node.module == module
                         or isinstance(node, ast.Import) and any(alias.name == module
                         for alias in node.names)
                         for node in ast.walk(tree))
    direct_calls = sum(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                       and node.func.id == call for node in ast.walk(tree))
    return {'direct_import_statements': direct_imports, 'direct_call_sites': direct_calls}


def audit() -> dict:
    paths = {}
    for path, (module, call) in TARGETS.items():
        before = subprocess.check_output(['git', 'show', f'{BASELINE}:{path}'],
                                         cwd=ROOT, text=True)
        after = (ROOT/path).read_text(encoding='utf-8')
        paths[path] = {'dependency': module, 'call': call,
                       'before': measure(before, module, call),
                       'after': measure(after, module, call)}
    before = sum(p['before']['direct_import_statements'] for p in paths.values())
    after = sum(p['after']['direct_import_statements'] for p in paths.values())
    assert before == 2 and after == 0, 'CMR-09 required coupling reduction missing'
    assert all(p['before']['direct_call_sites'] == 1 and
               p['after']['direct_call_sites'] == 0 for p in paths.values())
    return {'baseline_commit': BASELINE,
            'scope': 'Only two selected high-level import edges, NOT global imports',
            'direct_import_edges_before': before, 'direct_import_edges_after': after,
            'cross_component_call_sites_before': 2,
            'cross_component_call_sites_after': 0,
            'delegates_still_call_original_implementations': True,
            'repository_wide_import_reduction_established': False,
            'targets': paths}


if __name__ == '__main__':
    print(json.dumps(audit(), indent=2, sort_keys=True))
