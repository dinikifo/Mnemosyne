# CMR-09 — Dual-Flow reporting and agent-side read-only port integration

**Technical status:** Verified offline on 2026-11-14. **Release status:** Experimental candidate, no new production acceptance, agent execution, signed review or write permission.

## Scope / migration

Two existing, previously direct cross-component read operations now cross substitutable Python ports:

| High-level consumer | CMR-08 direct seam | CMR-09 port | Actual underlying service |
|---|---|---|---|
| `tools/review_dualflow.py` `assess_revision()` | `simulate_dualflow.simulate` | `SimulationReader.replay()` | `DirectSimulationReader` delegates to the *same* deterministic simulator; optional `RoutedSimulationReader` validates identities |
| `tools/evaluate_dualflow_model.py` `evaluate_pinned_wiki_model()` | `read_dualflow_wiki.select_pinned_workflow` | `PinnedWorkflowReader.select()` | `DirectPinnedWorkflowReader` delegates to the *same* HWI-05 exact-revision broker bridge; optional `RoutedPinnedWorkflowReader` validates identities |

The default readers retain previous semantics without routing. Opt-in uses **explicit trusted Python injection**, not an automatic CLI toggle or a new authority-bearing command. The model evaluation bridge is an **agent-side candidate evaluation/read path**; **the approved `autogpt_lite.agent` runtime was not integrated or modified**. The existing simulator controls its own synthetic state; the existing wiki/broker keeps scope, freshness and trusted read-only enforcement.

The two high-level direct read imports and calls both changed **2 → 0**. The new `tools/dualflow_read_ports.py` keeps those two implementation imports, intentionally centralizing (not eliminating) them. The total repository import-edge count is **not** claimed to have fallen; the selected high-level edges have fallen. Reproduce with `python -B docs/consolidation/CMR-09_COUPLING_AUDIT.py` in the Git checkout. New code and router specialization increase overall source complexity; CMR-11 must remeasure whether that cost is justified.

## Typed message profile and authority boundary

CMR-09 defines an **independent** read-only profile `hwi.router.read.v1`, rather than quietly widening Formation's `hwi.router.message.v1`. Four exact kinds:

1. `dualflow.regression.request` (trusted review owner; design/scenario SHA-256)
2. `dualflow.regression.result` (trusted simulator adapter; design/trace SHA-256)
3. `agent.pinned_read.request` (trusted evaluation owner; exact HWI-05 ref, source-revision and design pins)
4. `agent.pinned_read.result` (trusted wiki adapter; exact pins plus selection SHA-256)

Two request transitions yield *descriptors*, `dualflow.simulation.read` and `agent.pinned_read`, both `external_read`; two result transitions yield **no effects**. Message payloads carry **identities only**, not wiki texts, scenario contents, model outputs or report bodies. The owning trusted adapter explicitly calls its injected reader **once after** an accepted request verdict; it checks returned digests, authority-false fields and pins **before** dispatching a result. The router does not itself read, simulate, generate model content, sign, approve, write, or execute any agent component. Signed operations, governance and wiki-write effects remain denied by the original CMR-05 policy and absent from the CMR-09 allowlist.

A narrowly additive change to `hwi_router/core.py` allows only pre-listed, trusted profile source names, uses the profile's fixed schema/version for issued messages, and treats any successfully validated pending-request result as the latest result. The default Formation v1 profile, guards and routes remain unchanged. Session and source handles remain trusted, in-process objects, **not security credentials or cryptographic proofs**.

## Failures, replay and evidence

- Malformed or cross-profile messages, extra authority flags, wrong origin, wrong parent, stale broker references and forged result pins reject without protected actions.
- Identical message replay in the same ephemeral router session returns the cached verdict; changed content with the same message ID fails. **Restart/cross-process replay is still out of scope.**
- A thrown simulator `DesignError` propagates unchanged to the pre-existing regression-report intentional-rejection path. Other interrupted/invalid reader outcomes are **not retried**, and an invalid pinned-read result is rejected before it can reach the model.
- No new wiki writes, actual agent tool calls or live-model requests occur in these tests. A real read-only HWI-05 broker was exercised with temporary notebooks; before/after file SHA-256 inventories match, and one authorized selection produces one broker read.
- Recorded WL-04 simulation fixtures and pinned wiki/model-review fixtures give byte-identical direct-vs-routed reports (including report digests and **false** authority fields).

**Verification:** See `CMR-09_TEST_EVIDENCE.json` and logs. The full packaged five-suite legacy set ran **636 cases (635 passed, 1 documented governance skip)**. The router regression set passed **89/89**, CMR-09 added **17/17**, CMR-04 schema passed **11/11**, CMR-05 protocol passed **17/17**. Approved wiki and agent copies remained byte-identical to the pre-migration package. Native macOS, live Ollama, independent user trials and production acceptance have **not** been tested.

## Limitations / next stage

These are Python protocol and opt-in injection boundaries, **not** process sandboxing or comprehensive redesign of the agent runtime. Any malicious Python extension with access to trusted readers/source handles is outside the current threat model. Request timeout budgets in policy are not hard cancellation of blocking Python handlers; interruption and restart outcomes need durable recovery before production. Error handling does not automatically reissue reads or model calls.

CMR-10 may add **read-only proposal/status** request flows only. It must not inherit a write callback, let an agent message authorize approval, or weaken fitness gates, revision pins or signed wiki writers.
