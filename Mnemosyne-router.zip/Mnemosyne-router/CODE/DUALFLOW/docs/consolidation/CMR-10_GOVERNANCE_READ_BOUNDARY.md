# CMR-10 — Governance proposal-status read boundary

**Engineering checkpoint:** Technical exit verified offline on 2026-11-14. **Not** a release, reviewer-signature authorization, production deployment, or agent commissioning approval.

## Scope and actual substitution

CMR-10 introduces `hwi_governance/read_ports.py`, with a `GovernanceReadPort` protocol, `DirectGovernanceReadPort` retaining existing read behavior, and opt-in `RoutedGovernanceReadPort` validating a separate read-only message profile. Only two operator CLI calls have been replaced:

| Operator command | Before | After / fallback |
|---|---|---|
| `queue-status` | `emit(status_projection(ws, notebook))` | `emit(port.status(repo))`; default `DirectGovernanceReadPort` calls the **same** `review_queue.status_projection` |
| `queue-review` | `emit(review_entry(repo, notebook, proposal_id))` | `emit(port.review(repo, proposal_id))`; default `DirectGovernanceReadPort` calls the **same** `review_queue.review_entry` |

`--routed-read` is recognized **only** by those two read commands, requires the existing private workspace/notebook arguments, and is **off by default**. `queue-submit`, `queue-apply`, `queue-signing-payload`, `queue-gate-recover`, `queue-restore-proposal`, and `queue-reject` retain their original wiring, task fitness checks, quotas, signed approval, revision checks and trusted wiki writer. The `queue-apply` preflight deliberately continues to call `review_entry` directly in the trusted governance path. No new external router runtime service, autonomous command processing, or notebook state owner exists.

Reproducible static audit: `python -B docs/consolidation/CMR-10_COUPLING_AUDIT.py`. Selected direct `emit(status_projection(...))` and `emit(review_entry(...))` CLI call sites went **1+1 → 0+0**; there is a new port dependency in their place. This is *localized replaceability*, not a claim of reduced total imports, less code, or eliminated governance SQL/read logic. Review that cost in CMR-11.

## Typed v1 profile and trust boundary

`hwi.router.governance.v1` has exactly four message kinds:

1. `governance.status.request` — `governance_operator` → read adapter; notebook and **trusted repository scope hash**.
2. `governance.status.result` — `governance_projection` → read adapter; same scope and digest/counters of the returned read-only projection.
3. `governance.review.request` — `governance_operator` → read adapter; notebook, scope hash and exact proposal ID.
4. `governance.review.result` — `governance_projection` → read adapter; same pins, digest and existing gate-status category.

The exact transition matrix `G01..G04` is request→read descriptor→result; two terminal states. Allowed descriptors are only `governance.status.read` and `governance.proposal.review_read`, each `external_read`. No submit/apply/approval/write/model/tool effect exists. Malformed fields, unauthorized sources, wrong parent, wrong workflow, wrong notebook scope, invalid kinds and forged authority flags fail closed. Trusted Python creates fresh source/session handles; a model-supplied `origin` field does **not** authenticate a human or authorize a write. The router emits *descriptors* and never executes external effects.

The adapter first checks a trusted request verdict; then calls its delegated read **once**, bounds and validates the returned shape and false authority flags, calculates a content digest privately, and validates the result transition before returning the unchanged read result. Message payloads contain only read metadata and SHA-256 digests, not proposal reasoning, before/after wiki bodies, fitness signatures, reviewer keys or untrusted wiki text. A failed/uncertain read never triggers auto-retry or a hidden fallback. Outgoing status/review reports are still **advisory** and cannot be fed into the signed writer as authorization tokens.

## Adversarial and parity verification

- Real scratch-workspace `status_projection` and `review_entry`: empty ledger, ungated legacy proposal, forged fitness reference (`UNVERIFIED`), and owner-signed fitness (`VERIFIED`) are preserved with direct-vs-routed parity. `VERIFIED` denotes *fitness scope*, **not** human review approval; the read result still carries `human_authorized: false`, `may_mutate_wiki: false`, or `approval_authorized: false`, respectively.
- For authenticated CLI read commands, direct and `--routed-read` outputs are byte-identical in the tested cases. Filesystem SHA-256 inventories are unchanged before/after authorized reads (including the existing ledger and wiki).
- Invalid proposal IDs are rejected before the read, forged source handles/origins/writes fail, wrong parents/result digests fail, interrupting a read triggers no retry, and malicious data claiming human approval, changed proposal IDs, false totals or invented gate status are refused.
- The opt-in flag is not accepted on privileged CLI operations. Existing governance tests independently cover signed/revision-gated application, fitness gates, stale writes, quota exhaustion and uncertain post-commit gate records; no such logic was rewritten in CMR-10.
- **CMR-10 dedicated:** 31/31 passed. **Legacy offline:** 636 executed, 635 passed, one documented governance skip. **Router + CMR-09 profile:** 106/106 passed. **Contracts:** 11/11 CMR-04 and 17/17 CMR-05. The Mac-contract suite passed from the packaged release-root harness, and Formation passed when rerun independently. See `CMR-10_TEST_EVIDENCE.json` for the early working-directory errors and the observed parallel Formation assertion failure; those are not silently erased.
- All 31 approved agent-provider and 51 approved wiki-core source files match the prior package byte-for-byte; there were no modifications to either approved component.

## Limits, outstanding risks and rollback

This does not authenticate the underlying result independently of the trusted governance delegate, and digest equality does **not** prove identity or authorization. Handles and replay protection are process-local; blocking Python reads are not forcibly cancelled. A snapshot can go stale immediately and cannot authorize a later writer operation. Disallowed/out-of-shape results fail the opt-in path; the user may explicitly issue the original direct command, but there is no automatic replay or retry.

**Still open:** governance gate/ledger cross-database atomicity; operator reconciliation for interrupted/uncertain submissions; reviewer key custody, protected notebook identity; Linux-only test platform (no native Mac), live-model or production trial; broader shared provider transport still needs hardening. No writer path, fitness policy, signed receipt check, gate recovery or approved source code changed. CMR-11 must assess duplication/complexity, packaging, backwards compatibility and rollback.

**CMR-10 technical exit:** COMPLETE. Route remains opt-in and advisory. No new production approval. **Next:** CMR-11.
