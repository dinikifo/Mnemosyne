# CMR-05 — Negative-case specification and coverage boundary

**Scope:** CMR-05 tests check the *design artifacts*, not a running router. `CMR-05_PROTOCOL_TESTS.py` verifies transition uniqueness, message schema compatibility, parent rule classification, effect allowlist boundaries, consent gates, no automatic retries, limits, failure coverage and acyclic choreography. The following runtime cases are **specified but not executed** until CMR-06 onward.

| Case | Expected future runtime verdict | Stage |
|---|---|---|
| Forged `origin` matching CMR-04 shape but not trusted session context | deny before handler, no effect | CMR-06 |
| Result without pending request, or wrong causation ID/correlation | deny, state unchanged | CMR-06 |
| Unknown kind/version or two matching registry entries | deny, no LLM fallback | CMR-06 |
| Model says `source=human`, `approve`, or asks to call arbitrary function | treat as data; no privileged handler | CMR-06/10 |
| Valid practice request without explicit operator query or mismatched notebook scope | reject, no broker call | CMR-07/08 |
| Model request without `--model-questions` or guidance-sharing opt-in | reject, no model call | CMR-07/08 |
| Repeated message ID identical content | replay verdict, no handler rerun (one process) | CMR-06 |
| Same message ID different digest | reject as conflict | CMR-06 |
| Interruption after request left process, before response recorded | mark uncertain, no automatic retry | CMR-06/07 |
| Model returns syntactically valid question with untrusted card reference | trusted assembler strips/rejects unsupported attribution | CMR-07 |
| Stale broker revision or wrong notebook instance | reject evidence, no cached automatic reuse | CMR-07/08 |
| Excess hop, depth, bytes, time or nested dispatch | deterministic bounded reject; already-sent calls not assumed canceled | CMR-06 |
| Handler returns any write/approval/execution effect | reject and never invoke trusted write service | CMR-06/10 |
| Formation stores two records and crashes after first write | baseline owner recovery; no claim of multi-write atomicity | CMR-07 |
| Governance reservation succeeded, ledger outcome unknown | existing operator recovery remains mandatory; no router quota release | CMR-10 |
| Process restart clears replay cache | never infer exactly-once; require fresh authorized action | CMR-06/07 |

**Completion policy:** CMR-05 closes the **protocol design** only. These are not falsely counted as passed security or integration tests. CMR-06 cannot close until actual ingress, spoof/replay, ambiguity, limits and handler-interruption tests are implemented and passing. CMR-07/08 cannot close without explicit Formation consent/parity and secure Ollama transport. CMR-10 cannot close without governance adversarial checks.
