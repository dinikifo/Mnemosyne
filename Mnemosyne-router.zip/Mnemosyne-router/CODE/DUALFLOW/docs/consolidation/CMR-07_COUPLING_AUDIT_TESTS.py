"""Offline tests for the CMR-07 static coupling audit, no app imports."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SCRIPT = HERE / 'CMR-07_coupling_audit.py'
SPEC = importlib.util.spec_from_file_location('cmr07_audit', SCRIPT)
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


class CouplingAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = AUDIT.audit(REPO)

    def test_pins_are_exact(self):
        self.assertEqual(self.result['comparison']['baseline'], AUDIT.BASE)
        self.assertEqual(self.result['comparison']['candidate'], AUDIT.CANDIDATE)

    def test_knowledge_call_not_replaced(self):
        self.assertEqual(self.result['cli_static_before']['direct_retrieve_practices_calls'], 1)
        self.assertEqual(self.result['cli_static_after']['direct_retrieve_practices_calls'], 1)
        self.assertFalse(self.result['runtime_seam_result']['existing_direct_knowledge_call_replaced'])

    def test_model_calls_not_replaced(self):
        for k in ('direct_model_question_calls', 'direct_model_propose_calls'):
            self.assertEqual(self.result['cli_static_before'][k], 1)
            self.assertEqual(self.result['cli_static_after'][k], 1)
        self.assertFalse(self.result['runtime_seam_result']['existing_direct_model_call_replaced'])

    def test_shadow_adds_optional_imports(self):
        self.assertEqual(self.result['runtime_seam_result']['new_optional_router_import_occurrences'], 2)
        self.assertEqual(self.result['cli_static_after']['observe_guided_calls'], 1)
        self.assertEqual(self.result['cli_static_after']['observe_practices_calls'], 1)

    def test_scoped_diff_reproducible(self):
        self.assertEqual(self.result['changes']['hwi_formation/cli.py'],
                         {'added_lines': 32, 'removed_lines': 3})
        self.assertEqual(self.result['new_shadow_adapter_lines'], 179)

    def test_repeated_runs_deterministic(self):
        self.assertEqual(self.result, AUDIT.audit(REPO))

    def test_record_matches_fresh_result(self):
        saved = json.loads((HERE / 'CMR-07_COUPLING_AUDIT.json').read_text(encoding='utf-8'))
        self.assertEqual(saved, self.result)


if __name__ == '__main__':
    unittest.main()
