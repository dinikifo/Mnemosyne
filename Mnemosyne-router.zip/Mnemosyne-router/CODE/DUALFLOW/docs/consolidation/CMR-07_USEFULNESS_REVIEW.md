# CMR-07 — Human usefulness and coupling review (rework candidate pending)

**Status:** Operator accepted the independent REWORK recommendation on 2026-11-14 and requested engineering continuation. This is NOT a final acceptance of the revised CMR-07 candidate. Final review still pending.

## New technical evidence (not operator acceptance)

An independent, reproducible AST audit and engineering recommendation are now available in
[`CMR-07_ENGINEERING_REVIEW.md`](CMR-07_ENGINEERING_REVIEW.md) and
[`CMR-07_COUPLING_AUDIT.json`](CMR-07_COUPLING_AUDIT.json).
The engineering recommendation is **REWORK**: the shadow adds two optional router
imports to the Formation CLI but replaces zero concrete knowledge/model call sites.
This does **not** check any operator-decision box below, nor authorize CMR-08.

## Scope for reviewer

Inspect `hwi_router/formation_shadow.py`, the opt-in changes to `hwi_formation/cli.py`, and `CMR-07_FORMATION_SHADOW.md`. Read a few of the 12 A/B fixture cases in `hwi_router/test_formation_shadow.py`. No private notebook or live model is required for this review.

Judge these **separate** criteria, recording YES/NO and rationale for each:

1. **Interface value:** Does T06/T01→T02→T07 make the existing advisory dependencies and origins easier to audit or replace than the previous direct call?
2. **Cost:** Is an additional adapter, typed-envelope serialization, guard setup and new tests proportionate to that value? Consider lines and concepts added, not only tests passing.
3. **Operator usability:** Are `--router-shadow` diagnostics comprehensible, limited, and easy to ignore or disable? Is unchanged question wording acceptable as the first experiment?
4. **Safety:** Does the comparison preserve explicit operator query, notebook pin, guided fallback, separate confirmation, and NO new permissions or writes?
5. **Future migration:** Should CMR-08 proceed to a real read-only adapter behind the same typed interface, proceed with revisions, or abandon this routing seam?

### A/B fixture labels (automatically parity-tested, not human-scored)

| Case | Opening objective | Initial task answer |
|---|---|---|
| 01 | Help with my notes | Organize |
| 02 | Research | Research all entries |
| 03 | I need a weekly summary | Summarize meeting notes |
| 04 | A task with a clear goal | Classify incoming notes by topic |
| 05 | Improve my workflow | Extract references from selected notes |
| 06 | Unknown objective | Not yet specified |
| 07 | Organize research findings | Tag research claims |
| 08 | Review project records | Compare two cited records |
| 09 | Help me with my notes | Identify duplicate paragraphs |
| 10 | I need a domain assistant | List the source documents |
| 11 | Track outcomes | Report completed checklist items |
| 12 | Build a knowledge index | Identify missing source citations |

All 12 compare **stored-data parity**, not question quality. Neither baseline nor shadow uses a model-generated question; their guided prompts are identical by design. Any claimed usefulness improvement must come from evaluated integration value or later experiments, not inferred from these fixture results.

**Operator decision:** [ ] ACCEPT CMR-07   [ ] REWORK CMR-07   [ ] REJECT ROUTER SEAM

**Reviewer / date:** ____________________________

**Evidence and rationale:** ____________________________________________________

**CMR-08 authorized to start:** [ ] YES  [ ] NO

## Revised candidate (2026-11-14)

The operator-authorized rework introduces `PracticeReader`, a broker-backed default, and opt-in `--router-practices` that actually delivers typed practices on the T01→T02→T07 path. See `CMR-07_REWORK_IMPLEMENTATION.md` and the updated source audit. The old shadow observer remains available independently.

**Updated review questions:** Is the single knowledge-port replacement sufficiently clearer/testable to offset its new adapter complexity? Is failing back to the prior read-only path before any read acceptable? Is the fail-closed no-repeat behavior after a read satisfactory? Are the new status labels understandable? Should this port become a foundation for CMR-08, subject to the separate Ollama transport security gate?

**Revised-candidate operator decision:** [ ] ACCEPT CMR-07   [ ] REWORK further   [ ] REJECT seam

**CMR-08 authorized:** [ ] YES   [ ] NO (default)

Neither checkbox has been decided by the earlier “accepted.continue” instruction; that approved the rework direction rather than the post-rework candidate.

## Operator acceptance of revised implementation (2026-11-14)

The operator replied **“accepted.continue”** after reviewing the CMR-07 rework deliverables. This is recorded as acceptance of the **revised substitutable read-only knowledge port**, allowing CMR-08 to begin. It is not acceptance of the earlier shadow-only candidate, a release approval, or commissioning authority.
