# CMR-11 — Consolidated packaging and proven adapter duplication

**Status:** Technical checkpoint verified offline on 2026-11-14. **Not production acceptance.**

## Scope and dependency graph

Before CMR-11, both `tools/dualflow_read_ports.py` (CMR-09) and
`hwi_governance/read_ports.py` (CMR-10) independently loaded four local JSON
profiles, registered source/session capabilities, guard callbacks and pure
handler decisions, and checked dispatch verdicts. Their **read-result and
state-validation rules are different and remain owned locally**.

After CMR-11:

- Direct CLI and current default ports still call their trusted delegates.
  Neither direct port eagerly imports `hwi_router` (essential for independent
  Dual-Flow subprocesses and the original launcher environment).
- Opt-in routed ports lazily call `hwi_router.read_protocol.open_read_profile()`
  for one of two hardcoded reviewed profiles, `CMR-09` or `CMR-10`. This helper
  has **one** router bootstrap site and no arbitrary profile-file path input.
- The shared `dispatch_read_message()` checks the exact transition ID,
  accepted/non-replayed verdict and exact effect-descriptor tuple. Only the
  existing component-specific guards decide whether any frame is valid.
- The helper never performs a wiki read, simulation, model call, proposal
  submission, approval, write or effect execution.
- The previous `_router`/`_dispatch`/`_route` adapter entrypoints remain for
  historical tests and interface compatibility; no public interface was
  silently removed. Neither signed review nor agent execution is changed.

**Before:** `Dual-Flow reader -> local bootstrap; governance reader -> local bootstrap`.

**After:** `Dual-Flow reader -> shared pinned bootstrap <- governance reader`,
with separate guards and validation in each reader. The Formation runtime
retains its existing independent owner and is not migrated here.

## Complexity delta

| Measure | CMR-10 baseline | CMR-11 candidate |
|---|---:|---:|
| Read-profile bootstrap implementations | 2 | 1 |
| Direct-path eager imports of router | 0 | 0 |
| Governance read-port source lines | 213 | 191 |
| Dual-Flow read-port source lines | 177 | 157 |
| New shared helper lines | 0 | 74 |
| Combined read-only runtime lines | 390 | 422 |
| Net runtime LOC change | — | **+32** |
| New focused tests | — | 9 |

**This is deduplication, not a decrease in total runtime LOC.** The shared
helper is an additional abstraction. It earns its place only if CMR-12 accepts
the consistency, replaceability and audit benefits relative to its code and
operational cost. Separate payload validators and signed operations are
intentionally *not* consolidated.

## Packaging and provenance

`tools/build_cmr11_snapshot.py` builds a new source ZIP from the frozen
CMR-05 **complete release archive**, overlaying **only Git-tracked candidate
files** into `CODE/DUALFLOW/`. The original 31 approved agent-provider and 51
approved wiki-core files are retained byte-for-byte. An optional CMR-11 Git
bundle is included; root `MANIFEST.sha256` lists all payloads and the
`VERIFY_CONSOLIDATED.py` script validates both exact file inventory and
contents in an extracted ZIP. The old `PACKAGE_SHA256.json` and
`VERIFY_PACKAGE.py` are preserved under
`ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY/`, where they cannot be confused
with current integrity metadata. Zip members have fixed timestamps for
reproducibility. No installation, external I/O or production deployment is
performed by the builder.

The approved code paths remain `CODE/APPROVED_AGENT_PROVIDER/` and
`CODE/APPROVED_WIKI_CORE/`. The candidate `hwi_router` is delivered in
`CODE/DUALFLOW/hwi_router/`. The original release launcher scripts remain
unmodified; the ZIP remains an experimental candidate rather than an accepted
package. A Git bundle records branch history independently of source ZIP.

## Verification and compatibility

The release-layout offline suites run in separate processes. Final results:

- Dual-Flow: 335/335 passed (repeated in the Mac offline harness).
- Portable Mac launcher contract: 16/16 passed; **not native macOS validation**.
- Content evaluation: 65/65 passed.
- Governance: 111 passed, 1 existing documented skip (112 executed).
- Formation: 108/108 passed.
- Routed/adapters, CMR-09/10 and CMR-11: 146/146 passed, including 9 new tests.
- CMR-04 and CMR-05 contract tests: 11/11 + 17/17 passed.

**Investigation retained:** The first macOS launcher regression attempt had
13 failures and 2 errors because the new common helper was eagerly imported
by `dualflow_read_ports.py`; standalone Python subprocesses deliberately run
without the router package. This was a real compatibility regression and was
fixed using a lazy import only in routed mode. The final rerun passed. The
initial combined test driver exceeded its time limit during the 335-case
suite; that was a harness timeout, not a correctness result. All accepted
counts are from completed, standalone test runs (log digests are in the
machine-readable evidence file).

## Rollback rehearsal

The pre-CMR-11 commit is `5f533bda91852bf988fcc24a72e2ff1632756ff8`.
In a fresh Git-bundle clone, a checkout to that commit restores the former
adapters without requiring changes to approved agent or wiki packages.
The default direct ports retain their original trusted delegate and caller
behavior in both revisions. This is source rollback only; no migration of
live notebooks, databases or signed records was performed or required.

## Remaining gates

CMR-12 must independently assess packaging, native macOS operation, live
Ollama semantics and shared-provider transport, interrupted ledger/gate
atomicity, notebook identity, security limits on process-local message
capabilities, rollback and release-signature acceptance. **No production
approval, agent commissioning, or new wiki-write authority is implied.**
