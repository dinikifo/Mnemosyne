# CMR-02 — Frozen source lineage, current behavior and verification matrix

**Date:** 2026-11-13
**Checkpoint:** CMR-02 — source-lineage and behavior baseline, **technical evidence complete**.
**Scope:** Experimental planning branch only. No production acceptance, governance approval, new agent authority, or changes to protected source.

## 1. Immutable source pins

| Source | Immutable identifier | Purpose / status |
|---|---|---|
| HWI experimental candidate | `47b9e7fe9d64a7cdb6a9d725e3191c46cf715ddd` | Current governance + Formation integration; experimental, not separately accepted |
| Experimental Git tree | `3e01c71d11027ade67da8c6098ee2663ec91e607` | Exact 262-file tracked source snapshot |
| Dual-Flow accepted research | `e1af2e048ae07d4482c407bc3101604729083cee` | **10/10 scoped research acceptance only**; not production approval or acceptance of governance/Formation |
| Protected approved provider / wiki reference | `061c9cc` (release provenance report) | Approved provider/wiki snapshots are sealed separately and not edited here |
| ZIP archive SHA-256 | `5e9188bd8660082342126b06154a529241ac9d4cd0134f0e1994cf3a073bf8bf` | `HWI_STABILISATION_47b9e7f_2026-11-13(1).zip`; 22,682,478 bytes |
| Release manifest SHA-256 | `7bdfddfbe48ee7c689bee2c6c0c46c4c9758990e6523b06ba2fb0cd24688ed99` | All 385 paths and sizes checked against manifest |

**Independent checks performed now:** `VERIFY_ARCHIVE.py` reports **385/385 verified**; a second SHA-256/size check passed for every manifest entry; **262/262** files in packaged `CODE/DUALFLOW` match Git object IDs at `47b9e7f` (0 differences). The manifest seals the provider and wiki source copies, which are not tracked in the CMR planning Git branch. The aggregate source-subtree digests below cover the SHA-256 of sorted `relative-path\tfile-sha256\n` records, not a Git tree ID.

| Release source root | Count | Aggregate path+content SHA-256 |
|---|---:|---|
| `CODE/APPROVED_AGENT_PROVIDER` | 31 | `e5a499bd33444dde88bddfca6213873282cef186f7277fd290971559db7a88ed` |
| `CODE/APPROVED_WIKI_CORE` | 51 | `bd324961b890fc042c3c416e0f8d450b52d70c66922c7f9967cdec1108051e43` |
| `CODE/DUALFLOW` | 262 | `74110058678bc4dc0e430f47962e3fa9c4f75593b818c2392c443563fd579124` |

Machine-readable pins and suite evidence: [`CMR-02_SOURCE_LOCK.json`](CMR-02_SOURCE_LOCK.json). These hashes certify this handoff's bytes only, not release authority or application correctness.

## 2. Component inventory and ownership boundaries

| Component | Authoritative package in handoff | Responsibility / boundary | Acceptance status |
|---|---|---|---|
| AutoGPT Lite agent runtime | `CODE/APPROVED_AGENT_PROVIDER/autogpt_lite` | Agent planning, state, tool dispatch, model transport; protected provider source | Prior approved copy; not changed by CMR |
| PERSONAL.WIKI and HWI services | `CODE/APPROVED_WIKI_CORE/hwi`, `personal_wiki_core` | Knowledge store, broker, revisions, approved proposal ledger and signed revision-checked write authority | Prior approved copy; not changed by CMR |
| Formation | `CODE/DUALFLOW/hwi_formation` | Conversation/draft state, local consent, advisory wiki use via repository, optional Ollama; **not commissioning** | Experimental, owner acceptance pending |
| Governance / task fitness / queue | `CODE/DUALFLOW/hwi_governance` | Repository adapter, fitness, quota/gate, proposal-review orchestration and recovery; approved wiki writer remains authoritative | Experimental, owner acceptance pending |
| Dual-Flow and tooling | `CODE/DUALFLOW/tools`, `hwi_i02` | Simulations, trials, model/content evaluation, reports, release checks | Research scope accepted at 10/10, not broader permission |
| Refactor evidence | `CODE/DUALFLOW/refactor` | Prior refactor goals, source-lineage locks, test logs | RC-05 clean environment remains open |
| Test launchers / acceptance docs | Release-root `RUN_*.command`, `CODE/DUALFLOW/docs`, `ACCEPTANCE_LEDGER.json` | Offline commands and scope-limited acceptance provenance | Not an independent native release gate |

**Owning boundary rule:** A new CMR router may only adapt coordination; it does not own Formation sessions, knowledge persistence, model transport security, proposal authorization, approvals, wiki writes or agent execution. Cross-component import/call graph and duplicated adapters are deferred to **CMR-03**.

## 3. Environment-specific test matrix

This checkpoint reran independent suites against the **unchanged extracted handoff**, using Linux x86_64, Python 3.13.5, `-B`, `PYTHONDONTWRITEBYTECODE=1`, and `PYTHONPATH=CODE/DUALFLOW:CODE/APPROVED_WIKI_CORE:CODE/APPROVED_AGENT_PROVIDER`. Test logs are retained in the companion CMR-02 test-logs artifact; the per-log SHA-256 digests appear in `CMR-02_SOURCE_LOCK.json`.

| Test suite | Passed / total | Execution | Evidence / limitation |
|---|---:|---|---|
| Dual-Flow | 335 / 335 | PASS | Linux offline unit/fixture suite; no verified real-model correctness |
| Mac launcher contract | 16 / 16 | PASS | Mac-oriented **contract tests on Linux**, not a native Mac execution |
| Content evaluation | 65 / 65 | PASS | Fixture + mock HTTP tests; no human-reviewed live semantic trial |
| Governance/recovery | 112 / 112 | PASS | Synthetic local stores; not operator-credential or production transaction proof |
| Formation/RAG | 108 / 108 | PASS | Synthetic sessions/notebooks and optional model mocks; not commissioning |
| **Total** | **636 / 636** | **PASS** | **5 separate invocations**, not evidence that the monolithic runner completed |

The archive's earlier `BUILD_VERIFICATION.json` independently *reports* 636 passes and native Mac Gate A evidence at `79c45ea`. That reported prior native evidence is **not** a native re-run at the current CMR-02 checkpoint. Native macOS, Raspberry Pi, pinned clean-environment dependency installation, and live local Ollama semantics are **NOT RUN / NOT CERTIFIED** here.

### Reproduction

From the extracted archive root with Python 3.11+:

```sh
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/CODE/DUALFLOW:$PWD/CODE/APPROVED_WIKI_CORE:$PWD/CODE/APPROVED_AGENT_PROVIDER"
python3 -B VERIFY_ARCHIVE.py
```

Re-run suite commands from `CMR-02_SOURCE_LOCK.json` (the Dual-Flow command runs from the extracted `CODE/DUALFLOW` working directory). Avoid live notebook paths or credentials in the reproducibility environment.

## 4. Frozen known gaps — deliberately not waived

1. Shared Ollama HTTP transport redirect/proxy leakage risk identified in prior review; loopback-only *initial URL* is not a complete network boundary. Security regression required before real transcript experiments.
2. Governance quota reservation and approved proposal ledger use separate SQLite databases; recovery is operator-driven, conservative and **not atomic**.
3. PERSONAL.WIKI notebook-instance identity based on filesystem path/device/inode can be confused after a delete/restore inode reuse.
4. Formation purpose confirmation is advisory (`FORMED_NOT_COMMISSIONED`), not execution, fitness, signature or wiki-write approval.
5. Prior research semantic trials have unresolved errors; no independently certified Ollama semantics or general claim of model truth.
6. Native environment verification, clean pinned RC-05 environment, review identity/secret custody and operational deployment authorization remain open.
7. Approved provider/wiki bytes are external sealed release inputs rather than tracked files in the CMR planning tree. Never replace these with unreviewed router code.

See sealed release `README_FIRST.md`, `BUILD_VERIFICATION.json`, `PRODUCTION_HARDENING_BACKLOG.md`, `GOVERNANCE_PRODUCTION_BACKLOG.md`, and `ACCEPTANCE_DECISION.md` for the distinction between accepted research and unaccepted extensions.

## 5. Checkpoint decision and handoff

**CMR-02 technical exit: COMPLETE.** Inventory, immutable pins, SHA-256 verification, tests and unresolved environment/security gaps are documented. This does **not** constitute new human/production acceptance. No source files changed, and no deployment or remote push is authorized.

**Next: CMR-03 — dependency graph and consolidation seams.** Record actual edges, duplicate capability adapters, permissible/forbidden calls, state ownership and before-migration metrics. Do not implement message routing before CMR-03/04/05 acceptance criteria.
