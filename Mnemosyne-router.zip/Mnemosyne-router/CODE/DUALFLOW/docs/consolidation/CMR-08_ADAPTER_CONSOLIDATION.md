# CMR-08 — Read-only knowledge + model adapter consolidation

**Status:** Technical checkpoint implemented and offline-verified, 2026-11-14. No new production, governance, wiki-write or agent-execution authorization.

## Preconditions and outcome

The operator explicitly accepted the **revised CMR-07 PracticeReader** implementation on 2026-11-14. This closed CMR-07, advanced the CMR tracker to 7/12 and authorized CMR-08. The acceptance was committed separately as `71f4ae0`.

CMR-08 extends the established `PracticeReader` seam with two replaceable trusted Formation model ports, and closes the specific Formation HTTP redirect/proxy leak found in the original review. The router is not made responsible for access, state, persistence or model drafting semantics.

## Implementation

| Boundary | Previous | Current | Security/ownership |
|---|---|---|---|
| Formation → read-only wiki practices | `PracticeReader` from CMR-07 | Unchanged; broker-backed reader remains the only implementation opening wiki access | Explicit query + instance pin, one read; no router DB access |
| Formation → model question | Direct CLI `question()` | Injected `ModelQuestionReader.ask`; default calls unchanged validated `question()` service | `--model-questions` still opt-in; optional `--router-model-questions` adds T03→T05→T08, guarded model effect descriptor, one model call |
| Formation → purpose draft | Direct CLI `propose()` | Injected `ModelDraftReader.draft`; default delegates to unchanged validated `propose()` | CMR-04 has **no draft-message kind**: purpose drafts intentionally do not reuse the question contract; manual review/CONFIRM unchanged |
| Formation → Ollama HTTP | Approved provider's ambient `requests.Session` | Formation-owned `_LocalSession` underneath the same approved provider | Numeric loopback, no DNS for `localhost`, `trust_env=False`, no proxy, no redirect, exact `/api/chat` or `/api/tags`; question <=120 s and existing JSON-draft <=300 s *request* timeouts |

Both new question and draft readers can be replaced with deterministic trusted Python doubles for tests; no message can supply an adapter implementation. Runtime Formation `cli.py` no longer directly calls `question()`, `propose()` or `retrieve_practices()` (previously one call site each). The broker reader still delegates to the same `good_practices.retrieve_practices()`; the Formation model service still owns its two provider `.chat()` operations. This is **reduced coordination coupling**, not removal of the underlying services or net reduction in source complexity.

The model route is a separate T03 root workflow; the existing CMR-07 knowledge route T01→T02→T07 is not reopened or replayed. The model request may include only previously parsed, bounded broker-card refs and **only after** the independent model-guidance opt-in. No authorization is inferred from a ref, checksum, or model result. T04 cross-flow model continuation remains out of scope, as does any typed draft-message kind; both need separate contract review.

## Fail-closed behavior

- No `--model-questions` → no model-generated question and no model router operation; the CLI also rejects `--router-model-questions` without the explicit model opt-in before opening storage.
- No model mode, session not in progress, hardened transport guard false, malformed source ref or missing guidance-sharing consent → zero model calls.
- If T03 rejects, no model call. If T05/T08 rejects, the model is **not called again**; no unverified model text reaches the dialogue machine.
- On model transport or provider failure the existing Formation guided/manual fallback applies. Question-shape failures keep the filtered guided-question fallback; draft failures keep the existing manual-draft fallback.
- Redirects (including 307/308 preserving POST bodies) are refused, including redirects to another loopback listener. `HTTP_PROXY`, `ALL_PROXY` and `NO_PROXY` do not change the actual target. Only the initial explicitly configured numeric loopback host/port and fixed Ollama API paths can receive a request.
- The source provider and approved wiki tree remain untouched. CMR-08 adds no wiki DB connection, write, review signature, fitness approval or agent execution callback.

## Verification

New CMR-08 tests: **19/19** (12 model port/route tests, 7 transport tests). Combined router/shadow/knowledge/model/transport suite: **96/96**. CMR-04 shape **11/11**, CMR-05 policy **17/17**, CMR-07 earlier source audit tests **7/7**.

Legacy Linux release-layout suites re-executed with candidate Formation/router overlay: Dual-Flow **335/335**, Mac launcher contract **16/16** (not native macOS), content **65/65**, governance **112 executed / 111 passed + 1 skip**, Formation **108/108**; **636 executed, 635 passed, 1 skip** total. See `CMR-08_TEST_EVIDENCE.json` and separate retained logs.

The new tests include real local HTTP servers and checks that an actual model-request transcript is **never received** by a redirect target for HTTP 301/302/307/308, that a model-list GET redirect is not followed, that hostile proxy variables do not redirect traffic, that incorrect method/path/destination are denied, and that question/draft timeout budgets are capped. No real Ollama, native Mac, Raspberry Pi, distributed replay, independent semantic scoring, or production-release trial was performed.

## Residual constraints and next steps

1. Redirect/proxy protection is **Formation-only**: other users of the shared approved Ollama provider retain their existing behavior until separately reviewed. This wrapper relies on trusted in-process components and does not prevent malicious Python code from replacing its HTTP session.
2. The requests timeout is per HTTP operation and cannot forcibly cancel a synchronous handler at an exact wall-clock deadline. The router's deadline, replay cache and source handles also remain process-local.
3. A `transport_hardened` flag in the trusted router adapter records the **Formation-owned adapter's** configuration. It is not cryptographic attestation; arbitrary malicious Python callers are outside the threat model.
4. The bridge's T03 model-question route does not independently reauthenticate stored wiki evidence: only fresh, already scoped broker output is passed by Formation. Durable shared correlation, T04 cross-flow continuation and model-draft messages require future contract changes.
5. More modules and validation overhead have been added; reduced direct CLI dependencies do not prove reduced total system complexity or runtime latency. Continue measuring at CMR-11.

**CMR-08 technical exit:** Complete if the source diff, 96 experimental tests, 28 schema/protocol checks, 636 legacy executions, pinned source hashes and verified commit bundle agree. This is **not** a waiver of any production or final CMR-12 acceptance gate. Next: **CMR-09** Dual-Flow reporting and agent-side read paths.
