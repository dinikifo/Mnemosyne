#!/usr/bin/env python3
"""CMR-07 reproducible *static* coupling/complexity comparison.

This evidence tool runs only git/AST operations; it never imports application
modules, invokes a model, opens a notebook, or performs an application write.
The refs intentionally pin the CMR-06 and CMR-07 technical commits so that
subsequent documentation commits do not change the comparison.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

BASE = '81839a39ecc95340d30e49d5e21ffc6df68e34bd'
CANDIDATE = '526a00a5c87831b2e5b90e52cd231389901b1ec9'
FILES = ('hwi_formation/cli.py', 'hwi_router/formation_shadow.py',
         'hwi_router/test_formation_shadow.py', 'hwi_router/README.md')


def git(repo: Path, *arguments: str) -> str:
    return subprocess.run(['git', '-C', str(repo), *arguments],
                          check=True, text=True, capture_output=True,
                          timeout=20).stdout


def source(repo: Path, commit: str, path: str) -> str:
    try:
        return git(repo, 'show', f'{commit}:{path}')
    except subprocess.CalledProcessError:
        return ''  # Newly introduced at CMR-07 (absent from base tree)


def static_facts(src: str) -> dict:
    tree = ast.parse(src)
    imports = []
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module or '')
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                calls.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                calls.append(node.func.attr)
    return {
        'hwi_router_import_occurrences': sum(module.startswith('hwi_router') for module in imports),
        'direct_retrieve_practices_calls': calls.count('retrieve_practices'),
        'direct_model_question_calls': calls.count('question'),
        'direct_model_propose_calls': calls.count('propose'),
        'observe_guided_calls': calls.count('observe_guided'),
        'observe_practices_calls': calls.count('observe_practices'),
    }


def audit(repo: Path) -> dict:
    base = git(repo, 'rev-parse', '--verify', f'{BASE}^{{commit}}').strip()
    candidate = git(repo, 'rev-parse', '--verify', f'{CANDIDATE}^{{commit}}').strip()
    assert candidate in git(repo, 'rev-list', '--ancestry-path', f'{base}..{candidate}').splitlines()
    old_cli = source(repo, base, FILES[0])
    new_cli = source(repo, candidate, FILES[0])
    if not old_cli or not new_cli:
        raise ValueError('source pins inaccessible')
    changes = {}
    for line in git(repo, 'diff', '--numstat', base, candidate, '--', *FILES).splitlines():
        added, removed, filename = line.split('\t')
        changes[filename] = {'added_lines': int(added), 'removed_lines': int(removed)}
    new_shadow = source(repo, candidate, FILES[1])
    # This audits code growth, not actual dependency substitution or runtime latency.
    return {
        'schema': 'hwi.cmr07.coupling_audit.v1',
        'comparison': {'baseline': base, 'candidate': candidate},
        'scope': list(FILES),
        'cli_static_before': static_facts(old_cli),
        'cli_static_after': static_facts(new_cli),
        'cli_sha256_before': hashlib.sha256(old_cli.encode()).hexdigest(),
        'cli_sha256_after': hashlib.sha256(new_cli.encode()).hexdigest(),
        'new_shadow_adapter_lines': len(new_shadow.splitlines()),
        'changes': changes,
        'runtime_seam_result': {
            'existing_direct_knowledge_call_replaced': (
                static_facts(old_cli)['direct_retrieve_practices_calls'] >
                static_facts(new_cli)['direct_retrieve_practices_calls']),
            'existing_direct_model_call_replaced': (
                sum(static_facts(old_cli)[f'direct_model_{k}_calls'] for k in ('question','propose')) >
                sum(static_facts(new_cli)[f'direct_model_{k}_calls'] for k in ('question','propose'))),
            'new_optional_router_import_occurrences': (
                static_facts(new_cli)['hwi_router_import_occurrences'] -
                static_facts(old_cli)['hwi_router_import_occurrences']),
            'observation_only': True,
            'runtime_authority_reviewed': False,
        },
        'interpretation_limits': [
            'Static AST/import/call-site counts are not a runtime dependency trace.',
            'New adapter has no effect execution and cannot demonstrate real component substitution.',
            'Human usefulness and operator approval are not tested here.',
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path, default=None)
    args = parser.parse_args()
    doc = json.dumps(audit(args.repo.resolve()), indent=2, sort_keys=True) + '\n'
    if args.output:
        args.output.write_text(doc, encoding='utf-8')
    else:
        print(doc, end='')


if __name__ == '__main__':
    main()
