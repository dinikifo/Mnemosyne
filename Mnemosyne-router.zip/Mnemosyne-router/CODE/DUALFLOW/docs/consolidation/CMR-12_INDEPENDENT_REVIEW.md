# CMR-12 — Independent offline verification and release decision

**Candidate:** `bb607fd` (CMR-11). **Review date:** 2026-11-14. **Decision: REWORK.**

**Meaning:** The 12-checkpoint consolidation *review process* is complete. The candidate is **not production accepted**, not commissioned and not allowed new write or approval authority. The original approved baseline remains unchanged. This is a fresh artifact-based technical verification by the assistant, not certification by a distinct human organization.

## Verification methodology

- Extracted `HWI_CODEBASE_CMR11_2026-11-14.zip` into a separate directory and verified its complete SHA-256 manifest: **470/470** payloads. An unexpected file and a one-file mutation were both detected and rejected; restoring the clean snapshot passed again.
- Byte-compared the protected provider and wiki sources against the independent CMR-05 archive: **82/82 unchanged** (31 provider + 51 wiki).
- Ran all offline suites serially against this fresh CMR-11 extraction using Python 3.13.5 on Linux. See `CMR-12_TEST_EVIDENCE.json` for exact commands, exit codes, durations and SHA-256 log digests (full logs are shipped separately).
- Verified the embedded CMR-11 Git bundle, cloned it at the expected commit, and checked out CMR-10 `5f533bd` to rehearse *source* rollback; no production notebook or database was restored.
- Reviewed changed component boundaries and ran a two-loopback-server, synthetic-transcript HTTP redirect check comparing shared Ollama provider behavior with the scoped Formation wrapper. No real transcript or remote server was involved.

## Test results

| Test group | Executed | Passed | Skipped | Result |
|---|---:|---:|---:|---|
| Dual-Flow | 335 | 335 | 0 | PASS |
| Mac launcher contract (Linux harness) | 16 | 16 | 0 | PASS |
| Content evaluation | 65 | 65 | 0 | PASS |
| Governance | 112 | 111 | 1 | PASS with documented skip |
| Formation | 108 | 108 | 0 | PASS |
| Router/adapters and packaging | 146 | 146 | 0 | PASS |
| CMR-04 schema and CMR-05 protocol | 28 | 28 | 0 | PASS |
| Formation loopback transport (separate) | 7 | 7 | 0 | PASS |
| **Distinct test cases** | **817** | **816** | **1** | **0 failures** |

The `RUN_ON_MAC.command offline` command actually executes 351 cases: 335 are the same Dual-Flow tests also run above, and 16 are distinct launcher-contract cases. They are not double-counted. Running that shell command on Linux does **not** prove native macOS Finder, permission, installer or hardware behavior.

## Architecture and complexity assessment

The selected high-level call sites removed direct calls from Formation knowledge (1), Formation model question/draft (2), Dual-Flow reporting and model evaluation (2), and governance reads (2): **seven selected direct edges reduced to zero**. The owning service logic remains behind ports. Read governance operations cannot apply signed wiki writes, and the router emits effect descriptors rather than granting authorization. Its origin handles and replay cache are only process-local.

Measured from the CMR-05 design baseline to CMR-11: **+1,567 net Python runtime lines** across 17 changed runtime files, excluding tests, documentation, and the packaging builder. CMR-11 itself removed duplicated profile bootstrap sites (2 → 1), but increased the two-port-plus-helper runtime total by **32 lines**. This is meaningful interface substitution and improved auditability, not a proven reduction in total system complexity or operating cost. The default path remains direct and the new routed paths remain opt-in.

## Release-gate findings

| Gate | Outcome | Consequence |
|---|---|---|
| Archive integrity and protected source parity | PASS | Reproducible candidate source, no protected-file mutation |
| Offline parity and contract tests | PASS | Experimental interfaces are testable under the examined fixtures |
| Source rollback | PASS | Git code can revert to CMR-10; live state rollback not demonstrated |
| Formation-only loopback transport | PASS | Blocks model POST and listing GET redirects/proxy inheritance in its scoped adapter |
| **Shared Ollama provider HTTP redirects** | **FAIL** | Local 307 redirects forwarded a synthetic transcript to a second server; other provider consumers remain exposed |
| Persistent replay/source authentication | OPEN | Router uses in-process handles/caches, not a durable multi-process security boundary |
| Gate/ledger cross-database atomicity | OPEN | Interrupted submissions can retain uncertain reservations; recovery is conservative but not atomic |
| Notebook-instance identity | OPEN | Scope still depends on path/device/inode metadata; persistent identifier not implemented |
| Native macOS and live Ollama end-to-end | NOT RUN | No tested native behavior, live semantic accuracy, or realistic transport reliability |
| Signing custody, revocation and independent release authorization | NOT GRANTED | Protected operations remain governed by previously accepted services |

The redirect finding was observed **against the unchanged shared provider**; the Formation-scoped transport rejected the same attempt. This does not invalidate the scoped fix, but blocks a claim that the entire system is local-only safe.

## Technical release decision — REWORK

The candidate is sound enough to **retain as an experimental, opt-in research branch**, but it **must not be represented as production-ready**. Before reconsidering production:

1. Apply a separately approved, shared-provider transport fix (redirect rejection, proxy inheritance control, strict destination/endpoint policy) for **all** affected model consumers, with hostile redirect and proxy regression tests.
2. Resolve or formally risk-accept the independent SQLite gate/ledger commit and interrupted recovery boundary; verify recovery on copies without changing the authoritative wiki.
3. Establish persistent notebook identity, signer/key custody and revocation policies with migration and restoration testing.
4. Complete actual native macOS and live Ollama integration/security tests, including rollback of realistic persisted state and explicit independent human acceptance.
5. Re-evaluate code growth (+1,567 runtime lines) against measurable interface replacement, operator burden and audit cost before enabling routed paths by default.

**Review completion is not release acceptance.** No production deployment, operator signing, network installation, protected write or agent commissioning occurred. Subsequent remediation should be a separately authorized plan, not an implied CMR-13.
