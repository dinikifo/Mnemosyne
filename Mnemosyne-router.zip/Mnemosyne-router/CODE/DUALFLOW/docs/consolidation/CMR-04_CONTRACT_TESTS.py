#!/usr/bin/env python3
"""Offline design-stage shape checks only. Requires jsonschema 4.x, not HWI."""
from __future__ import annotations
import json
from pathlib import Path
import unittest
from jsonschema import Draft202012Validator

PATH = Path(__file__).resolve().parent
SCHEMA = json.loads((PATH / 'CMR-04_MESSAGE_SCHEMA_V1.json').read_text())
COMPAT = json.loads((PATH / 'CMR-04_COMPATIBILITY.json').read_text())
VALIDATOR = Draft202012Validator(SCHEMA)
REF = 'hwi05://' + 'a' * 64 + '/' + 'b' * 32 + '@1'


def example(kind='formation.practice.request'):
    payloads = {
        'formation.practice.request': ('formation', {'query':'success criteria', 'limit':2}),
        'knowledge.practice.result': ('knowledge_adapter', {'practices':[
            {'field':'success_criteria','question':'How is success checked?',
             'ref':REF,'revision_sha256':'c'*64}]}),
        'formation.model_question.request': ('formation', {
            'field':'success_criteria','prompt':'Ask one useful question?', 'practice_refs':[REF]}),
        'model.question.result': ('model_adapter', {'question':'What outcome would count as success?'}),
        'formation.question.suggestion': ('formation', {
            'field':'success_criteria','question':'How will you measure success?', 'practice_refs':[REF]}),
    }
    origin, payload = payloads[kind]
    return {'schema_id':'hwi.router.message.v1','version':1,'kind':kind,
            'message_id':'1'*32,'correlation_id':'2'*32,'causation_id':None,
            'origin':origin,'sensitivity':'confidential','trace_ref':None,'payload':payload}


class CMR04ShapeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Draft202012Validator.check_schema(SCHEMA)

    def deny(self, msg):
        self.assertFalse(VALIDATOR.is_valid(msg))

    def test_all_five_valid_kinds(self):
        for row in COMPAT['messages']:
            with self.subTest(kind=row['kind']):
                m=example(row['kind'])
                self.assertTrue(VALIDATOR.is_valid(m))
                self.assertEqual(m['origin'], row['producer'])
                self.assertEqual(row['authority'], 'advisory_only')
        self.assertEqual({r['kind'] for r in COMPAT['messages']},
                         {v['properties']['kind']['const'] for v in SCHEMA['oneOf']})

    def test_missing_fields(self):
        for field in example():
            m=example(); del m[field]
            with self.subTest(field=field): self.deny(m)
        m=example(); del m['payload']['query']; self.deny(m)

    def test_unknown_or_extra_fields(self):
        m=example(); m['kind']='governance.approve'; self.deny(m)
        m=example(); m['approved']=True; self.deny(m)
        m=example(); m['payload']['write']=True; self.deny(m)

    def test_invalid_versions_and_schema(self):
        for v in (2, True, '1', None, 0):
            m=example(); m['version']=v
            with self.subTest(version=v): self.deny(m)
        m=example(); m['schema_id']='hwi.router.message.v2'; self.deny(m)

    def test_mismatched_origin(self):
        m=example('model.question.result'); m['origin']='formation'; self.deny(m)

    def test_authority_claims_in_model_output(self):
        for key in ('approved','permission','effect','signature','source'):
            m=example('model.question.result'); m['payload'][key]='human'
            with self.subTest(key=key): self.deny(m)

    def test_limits_and_control_characters(self):
        for n in (0,4, True, False, 1.5,'3'):
            m=example(); m['payload']['limit']=n
            with self.subTest(limit=n): self.deny(m)
        for query in ('','x'*101, 'multi\nline', 'nul\x00'):
            m=example(); m['payload']['query']=query
            with self.subTest(query=query[:10]): self.deny(m)
        m=example('model.question.result'); m['payload']['question']='x'*301; self.deny(m)
        m=example('formation.question.suggestion'); m['payload']['field']='can_write'; self.deny(m)

    def test_pinned_evidence_shape(self):
        m=example('knowledge.practice.result'); m['payload']['practices'][0]['ref']='../file'; self.deny(m)
        m=example('knowledge.practice.result'); m['payload']['practices'][0]['revision_sha256']='dead'; self.deny(m)
        m=example('knowledge.practice.result'); m['payload']['practices']*=4; self.deny(m)
        m=example('formation.question.suggestion'); m['payload']['practice_refs']*=2; self.deny(m)
        m=example('knowledge.practice.result'); m['payload']['practices'][0]['approved']=True; self.deny(m)

    def test_meta_limits(self):
        m=example(); m['message_id']='BAD'; self.deny(m)
        m=example(); m['correlation_id']='g'*32; self.deny(m)
        m=example(); m['causation_id']=42; self.deny(m)
        m=example(); m['trace_ref']='../../private'; self.deny(m)
        m=example(); m['sensitivity']='public'; self.deny(m)

    def test_valid_empty_result(self):
        m=example('knowledge.practice.result'); m['payload']['practices']=[]
        self.assertTrue(VALIDATOR.is_valid(m))
        m=example(); m['causation_id']='3'*32
        self.assertTrue(VALIDATOR.is_valid(m))

    def test_shape_does_not_prove_origin(self):
        # A forged packet can have a valid *shape*; IG-01 must reject it later.
        self.assertTrue(VALIDATOR.is_valid(example('model.question.result')))

if __name__ == '__main__':
    unittest.main(verbosity=2)
