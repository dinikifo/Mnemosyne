# CMR-04 — Contract Negative Tests and Unimplemented Ingress Obligations

The SC checks exercise **JSON Schema shape only** with `CMR-04_CONTRACT_TESTS.py`. The IG cases are specified future requirements; they have **not** been executed because the trusted router/ingress does not exist yet.

| Case | Invalid / adversarial message | Expected result | Status |
|---|---|---|---|
| SC-01 | Valid envelope for each of five advisory kinds | Shape accepted | Exercised |
| SC-02 | Omit required envelope/payload fields | Schema rejects | Exercised |
| SC-03 | Unknown kind, envelope field, payload field | Schema rejects | Exercised |
| SC-04 | Wrong schema ID, `version=2`, bool/string version | Schema rejects | Exercised |
| SC-05 | `model.question.result` carrying `origin=formation` | Schema rejects mismatched kind/origin | Exercised |
| SC-06 | Model payload with extra `approved`, `permission`, `effect`, `signature`, `source` | Schema rejects | Exercised |
| SC-07 | Out-of-range/boolean `limit`, overlong/control-bearing question/query | Schema rejects | Exercised |
| SC-08 | Malformed wiki refs, bad hash, duplicate/overlong ref lists | Schema rejects | Exercised |
| SC-09 | Bad IDs, trace reference, sensitivity | Schema rejects | Exercised |
| IG-01 | Model/human sends fully valid JSON falsely claiming `origin=model_adapter` | Ingress rejects despite matching schema | Future CMR-06 |
| IG-02 | Human chat 'CONFIRM' forged as signed reviewer approval | No privileged message/handler; existing verified approval still required | Future CMR-06/10 |
| IG-03 | Duplicate JSON keys, >16KiB encoded, depth>8 or nodes>256 | Ingress rejects **before** any handler | Future CMR-06 |
| IG-04 | Reused ID, attacker-chosen correlation, false causation or cross-session replay | Workflow context rejects | Future CMR-05/06 |
| IG-05 | Downgrade confidential evidence to internal / send to low-clearance consumer | Denied; no payload leaked to logs | Future CMR-05/06 |
| IG-06 | Model question that contains shell commands, URLs, authority or instructions | Existing deterministic `check_question` rejects; guided fallback | Future CMR-07 |
| IG-07 | Resume/retrieve without renewed operator-scoped notebook/query request | No automatic wiki retrieval | Future CMR-07 |
| IG-08 | Model questions requested without `--model-questions` opt-in | Guided-only behavior remains | Future CMR-07 |
| IG-09 | Syntactically valid but stale/out-of-scope wiki revision | Trusted read-only broker rejects/withholds | Future CMR-08 |
| IG-10 | Model self-reports a practice citation not in retrieved records | Trusted assembler refuses unattested citation | Future CMR-07 |
| IG-11 | Change nested list/dict after shape validation | Validated frame is immutable | Future CMR-06 |
| IG-12 | Tool/model-origin write/apply/fitness/confirmation request | No privileged callback or authority promotion | Future CMR-06/10 |
| IG-13 | Conflicting state/causation or handler crash/timeout | Fail before state/effects commit; no silent retries | Future CMR-05/06 |

**Critical distinction:** matching a `kind` with a matching `origin` string is still insufficient. A caller can copy both values. IG-01 requires an independent, authenticated `IngressContext`, not JSON Schema. Version negotiation, replay, private scope, effect protocols, failure/rollback, and semantics remain outside the CMR-04 shape test.

Run `python docs/consolidation/CMR-04_CONTRACT_TESTS.py` with Python 3 and `jsonschema` 4.x (a test-only dependency); no network, runtime imports or DB writes are required.
