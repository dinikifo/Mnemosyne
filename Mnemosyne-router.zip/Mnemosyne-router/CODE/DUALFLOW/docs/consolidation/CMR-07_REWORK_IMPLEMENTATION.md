# CMR-07 — Substitutable Formation knowledge-port rework (technical candidate)

**Status:** Technically verified rework; **human usefulness/CMR-07 closure decision remains open**. 2026-11-14. No CMR-08 work, no production approval.

## Operator direction and objective

The operator replied **“accepted.continue”** to the independent engineering recommendation to *rework* the CMR-07 shadow candidate. This approves performing the rework, **not** retroactively accepting the unbuilt revised candidate, enabling production, or advancing to CMR-08. The accepted task is to demonstrate one real substitutable, read-only Formation knowledge boundary.

## Implemented interface and behavior

- `hwi_formation/knowledge_port.py` defines the small `PracticeReader` Protocol and `WikiPracticeReader`. The broker-backed implementation delegates to existing `good_practices.retrieve_practices()`, which still opens the trusted read-only repository and applies its typed practice parser. A deterministic in-memory `PracticeReader` can replace it at the trusted Python integration boundary without modifying dialogue or repository code.
- `hwi_formation/cli.py` no longer imports or calls `retrieve_practices()` directly. Its `_practice_options()` checks the operator's query, session state, notebook identity and current scope **before** choosing a reader. Default behavior goes directly through `WikiPracticeReader`; new `--router-practices` on `start`/`resume` opts in to delivered routed evidence. Existing `--router-shadow` remains available and the two flags are mutually exclusive. Neither option persists as session authority.
- `hwi_router/formation_bridge.py` centralizes the trusted, previously duplicated CMR-07 guard/handle bootstrap used by the shadow observer and routed adapter. It disables all model routes. Handles and guard state are assigned inside trusted Python; model output cannot declare its own origin.
- `hwi_router/formation_knowledge.py` dispatches T01 before invoking the trusted reader **exactly once** following a matching advisory `knowledge.practice.read` descriptor. It then issues T02 with the bounded evidence-card projection and T07 with a pinned advisory suggestion. **Only after** all required transitions pass is the original fully typed broker practice tuple delivered to Formation and later consumed by `review_draft` and optional consent-controlled model guidance.
- The existing guided dialogue, draft formation, signed review, fitness and wiki-write paths are unchanged. This work adds no model call, wiki write, execution callback, database handle, or approval authority.

## Failure and compatibility design

- No explicit query, unpinned notebook, wrong session state or forbidden mixed flags: no router-controlled read. Existing Formation returns its established errors or direct path where appropriate.
- A router bootstrap/T01 rejection **before** any read leaves the explicitly approved baseline reader available as a one-time direct fallback. It is the trusted Formation owner executing that fallback, not a router effect. This choice preserves the existing read-only path when optional routing is unavailable.
- If T02/T07 rejects, the handler interrupts, a message replays, the origin is forged, the workflow times out or an evidence card is invalid **after** the read: return no advisory cards and continue guided Formation; never retry the broker request or deliver the rejected result.
- Broker errors propagate to the Formation owner's existing failure boundary. External I/O is not made atomic with dispatch, and neither an in-process source handle nor a digest is proof of authenticated origin in a malicious Python process.
- The router projects the first advisory check per returned practice as defined by CMR-04. All other practice fields remain subject to the existing broker's `parse_wiki_practice` validation, not independent new router authentication. Replay history remains process-local and provider redirect/proxy hardening remains unaddressed.

## Measured decoupling and complexity

Reproduce source-only counts via `python -B docs/consolidation/CMR-07_REWORK_AUDIT.py` and see `CMR-07_REWORK_COUPLING_AUDIT.json`.

| Boundary metric | Before rework | After rework |
|---|---:|---:|
| `hwi_formation/cli.py` direct calls to `retrieve_practices()` | 1 | **0** |
| Formation CLI calls through `PracticeReader.read()` | 0 | **1** |
| `knowledge_port.py` delegation to existing `retrieve_practices()` | — | 1 |
| Formation direct `question()` model calls | 1 | 1 |
| Formation direct `propose()` model calls | 1 | 1 |

Three new modules contain 28 + 94 + 111 = **233** lines; this includes the extracted 94-line bridge rather than 95 completely new lines. One existing 179-line shadow observer loses the extracted guard logic. The new route adds meaningful adapter complexity and JSON/guard overhead; it is justified only if the interface's swappability and observable safety are useful to the operator. A reduction in total wiki reads, overall system complexity, or latency is **not** claimed. Static source counts are not dynamic performance measurements.

## Verification (Linux offline, current release-layout overlay)

- Legacy: **335 Dual-Flow + 16 Mac launcher contracts + 65 content + 112 governance + 108 Formation = 636 executed, 635 passed, 1 governance skip**. The combined script exceeded the environment limit, so suites were rerun separately in the frozen release-layout overlay.
- Experimental: **41 router core + 15 shadow + 21 new routed-port = 77 tests passed**; CMR-04 shape **11** and CMR-05 protocol **17** passed. The current final modified CLI and router also passed a focused **85-test** rerun (77 router + 8 repository integration tests).
- New port tests: actual `PracticeReader` stub substitution without monkeypatching Formation; a dozen predefined opening-answer A/B records and draft reviews; explicit `CONFIRM` purpose-contract parity; real read-only broker ref/hash parity and unchanged notebook bytes; one broker query per explicitly authorized invocation; forbidden flag mixes; missing query/scope; malformed/oversize evidence; bad source; duplicate message ID; deadline expiration; interrupted handler; failed read; direct fallback before the read; no second read after the read.
- No native macOS test, live Ollama test, independent semantic usefulness score, durable exactly-once guarantee, threat-resistant in-process provenance, or production acceptance is claimed.

## Remaining human exit gate

Reviewer must inspect the revised read-only port, coupling/cost measurements and changed operator behavior, then explicitly **ACCEPT / REWORK / REJECT** CMR-07. The earlier operator message approved **the rework direction only**. Until that review, **CMR-07 remains pending, 6/12 completed = 50.00%, and CMR-08 remains blocked**. No approved provider/wiki code changed.
