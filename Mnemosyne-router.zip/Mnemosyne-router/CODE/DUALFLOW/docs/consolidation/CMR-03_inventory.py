#!/usr/bin/env python3
"""CMR-03 static dependency inventory. AST-only: never imports target code.

Run from any directory with --repo <Git worktree> and optional separately
packaged approved code roots; results are discovery evidence, not a dynamic call
trace or a claim that any listed edges execute in an observed scenario.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter
import json
from pathlib import Path

REPO_SUBTREES = ("hwi_formation", "hwi_governance", "tools", "hwi_i02")


def group(module: str) -> str | None:
    prefix = module.split(".", 1)[0]
    if prefix == "hwi_formation": return "formation"
    if prefix == "hwi_governance": return "governance"
    if prefix == "tools": return "dualflow_tools"
    if prefix == "hwi_i02": return "i02_evaluation"
    if prefix == "autogpt_lite": return "approved_agent"
    if prefix in ("hwi", "personal_wiki_core"): return "approved_wiki"
    return None


def test_file(rel: Path) -> bool:
    return any(p.startswith("test_") or p == "tests" for p in rel.parts)


def iter_files(repo: Path, agent: Path | None, wiki: Path | None):
    for folder in REPO_SUBTREES:
        for path in (repo / folder).rglob("*.py"):
            rel = path.relative_to(repo)
            if not test_file(rel):
                yield ("candidate", str(rel), path, ".".join(rel.with_suffix("").parts))
    for origin, root in (("approved_agent", agent), ("approved_wiki", wiki)):
        if root is None: continue
        for prefix in (("autogpt_lite",) if origin == "approved_agent" else ("hwi", "personal_wiki_core")):
            for path in (root / prefix).rglob("*.py"):
                rel = path.relative_to(root)
                if not test_file(rel):
                    yield (origin, str(rel), path, ".".join(rel.with_suffix("").parts))


def extract(repo: Path, agent: Path | None, wiki: Path | None) -> dict:
    files = sorted(iter_files(repo, agent, wiki), key=lambda x: (x[0], x[1]))
    modules = {mod for _, _, _, mod in files}
    tools_names = {mod.rsplit(".", 1)[-1] for mod in modules if mod.startswith("tools.")}
    i02_names = {mod.rsplit(".", 1)[-1] for mod in modules if mod.startswith("hwi_i02.")}
    edges, sql, dynamic = [], [], []
    count = Counter()
    for origin, rel, path, module in files:
        count[group(module)] += 1
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            raw_imports = []
            if isinstance(node, ast.Import):
                raw_imports = [name.name for name in node.names]
            elif isinstance(node, ast.ImportFrom):
                if node.level:
                    # Relative import: use the importing module's package, and
                    # subtract one parent for each level beyond the first.
                    package = module.rsplit(".", 1)[0]
                    parts = package.split(".")
                    parts = parts[:max(0, len(parts) - node.level + 1)]
                    base = ".".join(parts + ([node.module] if node.module else []))
                else:
                    base = node.module or ""
                raw_imports = [base]
                if not node.module:
                    raw_imports += [(base + "." + name.name).strip(".") for name in node.names]
            for raw in raw_imports:
                dest = raw
                if dest.split(".", 1)[0] in tools_names and not group(dest):
                    dest = "tools." + dest
                elif dest.split(".", 1)[0] in i02_names and not group(dest):
                    dest = "hwi_i02." + dest
                target_group = group(dest)
                if target_group and target_group != group(module):
                    edges.append({"source": module, "target": dest,
                                  "source_group": group(module), "target_group": target_group,
                                  "file": rel, "origin": origin, "line": node.lineno,
                                  "scope": "module" if node in tree.body else "nested"})
            if isinstance(node, ast.Call):
                fn = node.func
                if isinstance(fn, ast.Attribute):
                    owner = fn.value
                    if ((isinstance(owner, ast.Name) and owner.id == "sqlite3" and fn.attr == "connect") or
                            (isinstance(owner, ast.Attribute) and owner.attr == "_db" and fn.attr == "conn")):
                        sql.append({"file": rel, "origin": origin, "line": node.lineno, "operation": fn.attr})
                if isinstance(fn, ast.Name) and fn.id in {"__import__"}:
                    dynamic.append({"file": rel, "origin": origin, "line": node.lineno,
                                    "kind": "__import__"})
                if isinstance(fn, ast.Attribute) and fn.attr == "import_module":
                    dynamic.append({"file": rel, "origin": origin, "line": node.lineno,
                                    "kind": "import_module"})
    edges = sorted({(e["origin"], e["file"], e["line"], e["target"]): e for e in edges}.values(),
                   key=lambda e: (e["origin"], e["file"], e["line"], e["target"]))
    pairs = Counter((e["source_group"], e["target_group"]) for e in edges)
    return {"schema": "hwi.consolidation.dependency_inventory.v1",
            "method": "Static AST import statements; tests and test directories excluded; includes function-local imports. Not runtime dependency tracing or a call graph.",
            "module_count_by_group": dict(sorted(count.items())),
            "cross_group_import_occurrences": len(edges),
            "cross_group_source_module_count": len({(e["origin"], e["file"]) for e in edges}),
            "unique_group_pair_count": len(pairs),
            "cross_group_pairs": [{"from": a, "to": b, "occurrences": v} for (a,b), v in sorted(pairs.items())],
            "edges": edges, "sqlite_connect_call_sites": sql,
            "dynamic_import_call_sites": dynamic,
            "approved_snapshots_included": bool(agent is not None and wiki is not None)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--approved-agent", type=Path)
    p.add_argument("--approved-wiki", type=Path)
    p.add_argument("--output", type=Path)
    args = p.parse_args()
    doc = extract(args.repo.resolve(), args.approved_agent, args.approved_wiki)
    result = json.dumps(doc, indent=2, sort_keys=True) + "\n"
    if args.output: args.output.write_text(result, encoding="utf-8")
    else: print(result, end="")

if __name__ == "__main__": main()
