"""CMR-10 reproducible, deliberately narrow CLI read-call audit.

Run from the candidate Git checkout. Counts only direct `emit(fn(...))`
call sites for queue-status and queue-review; this is NOT a total import-edge
count or a claim that any trusted ledger/read implementation was removed.
"""
from __future__ import annotations
import ast
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PATH = 'hwi_governance/cli.py'
BASELINE = '8bb702c03d0b2bd7b9af92bd1e741caaf4655655'


def calls_in_emit(code: str, function: str) -> int:
    tree = ast.parse(code)
    return sum(1 for node in ast.walk(tree) if isinstance(node, ast.Call)
               and isinstance(node.func, ast.Name) and node.func.id == 'emit'
               and node.args and isinstance(node.args[0], ast.Call)
               and isinstance(node.args[0].func, ast.Name)
               and node.args[0].func.id == function)


def run():
    old = subprocess.check_output(['git', 'show', f'{BASELINE}:{PATH}'], cwd=ROOT).decode()
    now = (ROOT/PATH).read_text('utf-8')
    original = {'status_projection': calls_in_emit(old, 'status_projection'),
                'review_entry': calls_in_emit(old, 'review_entry')}
    new = {'status_projection': calls_in_emit(now, 'status_projection'),
           'review_entry': calls_in_emit(now, 'review_entry')}
    assert original == {'status_projection': 1, 'review_entry': 1}, original
    assert new == {'status_projection': 0, 'review_entry': 0}, new
    assert 'gate=review_entry(ws,name,args.proposal_id)' in now
    assert 'entry,fitness=gated_submit(args,repo,spec)' in now
    assert 'result=apply_review(ws,name,args.proposal_id,args.signature_hex' in now
    return {'checkpoint': 'CMR-10', 'baseline_commit': BASELINE,
            'metric': 'direct emit(...) read-call sites in governance CLI',
            'before': original, 'after': new,
            'interpretation': 'Two direct CLI read invocations replaced by replaceable port calls; trusted review_queue and approved ledger/writer unchanged',
            'limits': 'Does not count all imports or demonstrate lower total source complexity'}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
