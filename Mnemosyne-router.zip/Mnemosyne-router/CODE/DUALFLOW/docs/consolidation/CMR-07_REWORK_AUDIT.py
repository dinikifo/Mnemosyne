"""Reproducible source-only CMR-07 rework comparison; no application execution."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

BEFORE = '4087fabbfe5affe2e0b2e73aaa5fda0e5f408748'


def count_calls(code, target):
    tree = ast.parse(code)
    return sum(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
               and n.func.id == target for n in ast.walk(tree))


def make_report(repo):
    old = subprocess.check_output(['git','show',BEFORE+':hwi_formation/cli.py'],cwd=repo,text=True)
    new = (repo/'hwi_formation/cli.py').read_text(encoding='utf-8')
    port = (repo/'hwi_formation/knowledge_port.py').read_text(encoding='utf-8')
    routed = (repo/'hwi_router/formation_knowledge.py').read_text(encoding='utf-8')
    return {
        'schema':'hwi.cmr07.rework_coupling.v1',
        'comparison_base':BEFORE,
        'scope':'Python AST import/call sites + static line counts; not dynamic coupling or authorization proof',
        'formation_cli_direct_retrieve_calls_before':count_calls(old,'retrieve_practices'),
        'formation_cli_direct_retrieve_calls_after':count_calls(new,'retrieve_practices'),
        'formation_cli_port_reader_calls_after':sum(isinstance(n,ast.Call) and
            isinstance(n.func,ast.Attribute) and n.func.attr=='read'
            for n in ast.walk(ast.parse(new))),
        'port_delegates_to_existing_broker_calls':count_calls(port,'retrieve_practices'),
        'route_has_read_once_invocation_count':count_calls(routed,'read_once'),
        'model_question_calls_before':count_calls(old,'question'),
        'model_question_calls_after':count_calls(new,'question'),
        'model_propose_calls_before':count_calls(old,'propose'),
        'model_propose_calls_after':count_calls(new,'propose'),
        'added_module_lines':{path:len((repo/path).read_text().splitlines()) for path in (
          'hwi_formation/knowledge_port.py','hwi_router/formation_bridge.py',
          'hwi_router/formation_knowledge.py')},
        'cli_sha256_before':hashlib.sha256(old.encode()).hexdigest(),
        'cli_sha256_after':hashlib.sha256(new.encode()).hexdigest(),
        'note':'A direct CLI knowledge call is replaced with a typed port; the broker retrieval remains in the approved reader. Actual read-once parity is established by integration tests.'
    }

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[2])
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    report=make_report(args.repo.resolve())
    rendered=json.dumps(report,indent=2,sort_keys=True)+'\n'
    if args.output: args.output.write_text(rendered,encoding='utf-8')
    else: print(rendered,end='')
