# CMR-07 — Independent engineering assessment for operator review

**Result:** **REWORK RECOMMENDED** (engineering recommendation only).
**Gate:** CMR-07 **NOT ACCEPTED**; human review and explicit CMR-08 decision remain open.
**Scope:** Read-only static source comparison and existing offline A/B evidence; no new agent execution, model evaluation, repository access, or production permission.

## Why this assessment was added

The earlier CMR-07 candidate proved that adding `--router-shadow` does not change Formation's persisted records or permitted read paths in the tested fixtures. The declared goal of this consolidation track is **reducing cross-component coupling**, not merely introducing an optional observer. This review measures whether the implementation has replaced a concrete dependency yet.

## Reproducible source comparison

Run from the repository root:

```sh
python -B docs/consolidation/CMR-07_coupling_audit.py \
  --repo .
python -B docs/consolidation/CMR-07_COUPLING_AUDIT_TESTS.py -v
```

The audit pins **CMR-06 `81839a39…`** against **CMR-07 `526a00a5…`**, reads both Git trees, and uses Python AST to count import and direct-call sites in `hwi_formation/cli.py`. It does not execute application code. Full machine-readable results: `CMR-07_COUPLING_AUDIT.json`.

| Property | CMR-06 | CMR-07 | Interpretation |
|---|---:|---:|---|
| `retrieve_practices(...)` direct CLI call sites | 1 | 1 | Concrete knowledge call remains |
| `question(...)` direct CLI call sites | 1 | 1 | Concrete model-question call remains |
| `propose(...)` direct CLI call sites | 1 | 1 | Concrete purpose-draft model call remains |
| `hwi_router` import occurrences in CLI | 0 | 2 | Two new optional, lazy dependencies |
| `observe_guided(...)` call sites | 0 | 1 | Observation only |
| `observe_practices(...)` call sites | 0 | 1 | Observation only |
| New shadow adapter lines | 0 | 179 | Additional coordination surface |

Scoped source-diff footprint for CMR-07: **32 added / 3 removed lines** in the Formation CLI, **179** lines of new shadow adapter, **250** lines of new shadow tests, and **16** new router README lines. Counting documentation and tests is useful for maintenance cost but should **not** be misrepresented as runtime complexity or measured operator effort.

### Assessment against the five required human review questions

1. **Interface value — not demonstrated yet.** Traceable typed advisory transitions exist, but neither the knowledge nor the model dependency has been substituted. The observed route never delivers its effect to a component.
2. **Cost — currently disproportionate to proven decoupling.** 179 adapter lines, 29 net new CLI lines, and the router's existing independent protocol machinery provide no current reduction in the direct knowledge/model call sites. This may improve after a real port is substituted.
3. **Operator usability — technically adequate, subject to review.** `--router-shadow` defaults off; diagnostics are bounded status labels, and question text is unchanged. No human operator usability score has been collected.
4. **Safety — tested preservation, not blanket assurance.** Existing offline tests establish A/B record/contract parity, a single explicitly authorized read, and unchanged wiki bytes. They do not cover malicious in-process Python, persistent replay protection, native macOS, or a hardened live Ollama transport.
5. **Future migration — recommend targeted CMR-07 rework first.** The next change should prove replacement or swappability of **one** read-only advisory dependency, with no new model or wiki access. Do not advance to CMR-08 solely on shadow parity.

## Minimal rework acceptance target

Demonstrate a *single substitutable read-only knowledge port* while keeping the approved repository and all Formation state ownership intact:

1. Define a narrowly typed `PracticeReader` interface at Formation's advisory boundary; the existing trusted wiki adapter remains the only implementation that contacts the repository. A deterministic in-memory stub must substitute through the same interface without monkeypatching unrelated Formation logic.
2. Make the opt-in routed path actually **consume** validated advisory data from that port, rather than compare it and discard it. Keep the existing direct path available as the default and retain the original guided fallback on advisory rejection.
3. Enforce operator-supplied query, notebook pin and once-only broker read **before** router delivery. Do not permit a model message, observer label or router effect descriptor to cause an extra broker read.
4. Re-run all 12 A/B cases, explicit `CONFIRM` equivalence, failure/timeout/replay negative tests and the established 636 offline legacy tests. Record the actual number of broker calls and any change in cross-module import/call boundaries. This should be compared with the additional LOC and concepts, not assumed to be an improvement.
5. Obtain explicit human **ACCEPT / REWORK / REJECT** feedback after reviewing the revised candidate. Only then update the checkpoint to 7/12 and consider CMR-08 authorized. Any future model-adapter integration remains blocked by the unresolved redirect/proxy boundary.

The rework target is **a proposed engineering path**, not an approved instruction to change the existing protection model. No runtime edits were made as part of this assessment.

## Evidence and limitations

* Existing CMR-07 evidence: `CMR-07_FORMATION_SHADOW.md`, `CMR-07_TEST_EVIDENCE.json`, and `hwi_router/test_formation_shadow.py`; 12 A/B opening-answer cases, matching purpose contracts, 636/636 frozen legacy offline tests as previously recorded.
* Newly rerun: seven deterministic audit test methods; see `CMR-07_COUPLING_AUDIT_TESTS.py`.
* This audit measures **lexical call/import sites only**, not dynamic runtime coupling, code comprehension, security guarantees, user usefulness, or adapter-switching cost.
* `CMR-07_USEFULNESS_REVIEW.md` is intentionally left without a checked human decision.

**Progress remains 6 / 12 = 50.00%; CMR-07 is an unaccepted technical candidate.**
