# CMR-05 — Transition Contracts and Effect Protocols (design v1)

**Status:** Design-stage contract for the first Formation advisory slice. No dispatcher, authorization adapter, runtime, or external effects are implemented by this checkpoint. **Dependency:** CMR-04 schema/compatibility (`78a7867`). **Scope:** 5 advisory message kinds; no privileged messages. **Date:** 2026-11-13.

## 1. Responsibility and state boundaries

- **Formation owns its durable session and dialogue state.** `hwi_formation/dialogue.py` derives `NEED_QUESTION`, `GUIDE_OPEN`, `MODEL_OPEN`, `ASKING_MODEL` and `DONE`; `step()` emits Formation-owned effects and `stage()` validates pending records before existing `cli._perform` persists them. CMR-05 does not replace this logic or promise that the existing multi-save sequence is one atomic database transaction.
- **Knowledge owns retrieval.** `good_practices.retrieve_practices()` uses the existing read-only repository and revision references, with explicit operator query and pinned notebook scope. No router SQLite connection.
- **The local-model adapter owns its call.** `--model-questions` is off by default; independent opt-in is required before sharing practice-derived guidance. The existing provider redirect/proxy transport weakness must be resolved before private content is put through the candidate route.
- **Governance owns all authorization and writes.** Signed approval, revision checks, proposal ledger, fitness quotas and their recovery stay in the approved services. Neither an authenticated human chat frame nor a model frame is a signed authorization.
- **Router owns only ephemeral advisory coordination.** Its phase names below are *not* Formation dialogue states, are not persisted as Formation's source of truth, and confer no capabilities. No universal task stack is proposed. A direct-call path remains available behind original consent checks during shadow migration.

The normative machine-readable contracts are [`CMR-05_TRANSITION_MATRIX.json`](CMR-05_TRANSITION_MATRIX.json) and [`CMR-05_EFFECT_POLICY.json`](CMR-05_EFFECT_POLICY.json). They are **design inputs**, not runnable policy enforcement.

## 2. Admission and atomic stage boundaries

For a candidate message the proposed order is:

1. **Trusted ingress** binds the real adapter/session principal, permission scope, notebook pin, and sensitivity independent of message JSON. Before decoding: enforce 16,384-byte cap. Reject duplicate JSON keys, malformed encoding, excessive depth (>8) or aggregate nodes (>256). Parse without coercion, verify v1 shape, and deep-copy/freeze data.
2. **Identity and causation checks** verify `origin` against trusted ingress; scope-bound `message_id` replay verdict; `correlation_id` of current flow; `causation_id` null only for a Formation root from `READY`, or matching the expected pending request/latest result (the canonical schema permits null, but the transition may not).
3. **Exact transition matching** on `(coordinator phase, v1 kind, verified origin)`. There must be exactly one match. No match, unknown version, two matches, failed source, guard, or parent check is an error **without handler invocation**. Free-text ELIZA matching remains at the human-input edge, not here.
4. **Prepare without mutation:** evaluate the deterministic input contract, run a pure handler if applicable, assemble candidate output envelopes and effect *intents*, validate **all outputs** and their downstream transition shapes, confirm the effects belong to the allowlist. This does not pop a shared stack or publish an intermediate phase.
5. **Adapter effect boundary:** the owning trusted adapter rechecks permissions, current scope, operator opt-ins and deadlines *at invocation time*. If an effect is external, an already sent request/read cannot be undone by reversing the coordinator phase. Do not describe this as distributed atomic commit.
6. **Commit coordination verdict:** only after successful validation/response does the coordinator publish the next phase and result to the intended Formation consumer. Keep output immutable, with scoped message identity and concise metadata-only audit. A failure records the error and leaves Formation's previous durable state authoritative.

For asynchronous or side-effectful operations the prepare/effect/finalize stages are **separate boundaries**. An interruption after send is an **unknown outcome**, even when no local state advanced. Future CMR-06 must use a bounded, in-process dispatcher and can retain only a scoped, volatile replay cache; process restart does not certify whether an external call occurred. CMR-07 must test parity with Formation's existing saved conversation semantics.

## 3. Deterministic transition matrix

`READY`, `WAIT_PRACTICE`, `HAVE_PRACTICE`, `WAIT_MODEL`, `HAVE_MODEL`, `SUGGESTED` are coordination-only phases. Each trusted `formation` root starts a new correlation in `READY`. There is no automatic cycle back to `READY` and no implicit practice reread on resume.

| Rule | Coordinator phase + message | Required verified origin | Next phase | Candidate effect intent |
|---|---|---|---|---|
| T01 | READY + `formation.practice.request` | formation | WAIT_PRACTICE | `knowledge.practice.read` |
| T02 | WAIT_PRACTICE + `knowledge.practice.result` | knowledge_adapter | HAVE_PRACTICE | none |
| T03 | READY + `formation.model_question.request` | formation | WAIT_MODEL | `model.question.generate` |
| T04 | HAVE_PRACTICE + `formation.model_question.request` | formation | WAIT_MODEL | `model.question.generate` |
| T05 | WAIT_MODEL + `model.question.result` | model_adapter | HAVE_MODEL | none |
| T06 | READY + `formation.question.suggestion` | formation | SUGGESTED | `formation.question.deliver` |
| T07 | HAVE_PRACTICE + `formation.question.suggestion` | formation | SUGGESTED | `formation.question.deliver` |
| T08 | HAVE_MODEL + `formation.question.suggestion` | formation | SUGGESTED | `formation.question.deliver` |

**T01:** explicit operator-selected query, available original notebook scope pin and session consent; not a blanket permission to browse wiki. **T02:** verify response from the *actual* knowledge adapter and pending request; verify broker reference and current revision, even if the v1 JSON looks valid. **T03/T04:** require local model questions opt-in, and separate guidance-sharing consent if practice refs are included; transport hardening before sensitive calls. **T05:** deterministic `check_question()` and exact pending request parent. **T06/T07/T08:** trusted Formation assembler builds the card/question with any refs, revalidates session and question field, then supplies an advisory suggestion; the model's text alone cannot assert provenance or drive a state transition. Completion returns to Formation's existing state machine.

**Parent rules:** T01/T03/T06 from READY have null `causation_id` and a trusted new correlation. T02/T05 require `causation_id = pending_request.message_id`. T04/T07/T08 require the latest accepted result's ID and same correlation. Results never start workflows. A response with the wrong parent, even if correctly shaped, must not advance a workflow.

**No-match rule:** an unsupported or malformed message is rejected, not forwarded to an LLM. The owning Formation code may explicitly choose its already existing guided question fallback; no router auto-dispatch to privileged handlers. Where CMR-04 allows an empty practice result, T02 still checks that it is a response to an authorized read.

## 4. Effect authorization matrix and consent

| Effect intent | Executor (not router) | Allowed consequence | Required guard | Retry |
|---|---|---|---|---|
| `knowledge.practice.read` | read-only knowledge adapter | bounded notebook read | explicit operator query + original pinned scope | no automatic retries |
| `model.question.generate` | local-model adapter | bounded external local-model request | model-questions opt-in; separately opt in to sharing practice-derived guidance; secure loopback transport | no automatic retries |
| `formation.question.deliver` | existing Formation dialogue adapter | advisory question presented to Formation | active session + trusted assembler + valid field/question | no automatic retries |

The entire registry is **default deny**; it explicitly denies `wiki.write`, `wiki.post.apply`, `governance.queue.apply`, `governance.queue.submit`, `governance.fitness.sign`, `formation.contract.confirm`, `formation.session.persist`, `agent.execute`, `filesystem.write` and arbitrary network calls. The router must not dynamically import handlers by untrusted strings, invoke governance CLIs, or treat an effect descriptor as permission. Formation's *existing* session file writes occur outside the router using its own validation/optimistic concurrency checks.

## 5. Time, depth, idempotency and provenance

**Proposed CMR-06 experimental limits (not currently enforced):** <=8 dispatch hops per correlated flow; <=1 in-flight effect; nested router invocations 0; no stack; <=135,000 ms overall deadline; knowledge/read 10,000 ms; local-model 120,000 ms; advisory deliver 1,000 ms; **0 automatic retries**. The stricter 16 KiB/8-depth/256-node CMR-04 ingress caps also apply. Exceeding any bound rejects before selecting another effect; deadlines do not guarantee cancellation of requests already sent.

`(trusted session scope, message_id)` is the replay key. For the same key and identical canonical envelope digest, return the *recorded verdict without executing an effect again*; for different digests, reject. Use SHA-256 only to compare content, **not** to authenticate source. Keep correlation and parent IDs consistent and ensure output IDs are freshly assigned by trusted code. A bounded volatile replay table can protect a single live process in CMR-06; it **cannot** guarantee exactly once over crashes/restarts. Where outcome is unknown, no blind replay or model retry; require a newly authorized owner request if repetition is needed.

Audit only IDs, verified source, kind, transition ID, phase, effect ID, verdict, sensitivity and digest by default. Do not log wiki evidence bodies, raw human text, model prompts or secrets by default. Trace references are opaque locators and must not become arbitrary file paths.

## 6. Failure and recovery protocol

| Failure class | Transition/phase outcome | Recovery owner |
|---|---|---|
| Invalid parse, schema, provenance, parent, consent, state, effect or bounds | reject without handler; coordinator phase unchanged | caller fixes input or explicit Formation guided fallback |
| Handler emits invalid output or forbidden effect | discard staged output; no state publish | caller, never partial router commit |
| External read/model timeout or interruption | abort *ephemeral* coordination; external outcome may be unknown | Formation uses existing guided fallback; do not automatically retry |
| Broker reference stale/incorrect | reject advisory evidence and abort route; never silently reuse cached card | explicit operator-controlled re-query only |
| Model question rejected by `check_question()` | abort advisory route; do not show model text | existing Formation guided fallback |
| Exact duplicate message ID+digest | return previous verdict without re-executing (live process only) | caller receives same verdict |
| Duplicate ID with different digest | hard reject, no effect | investigate identity collision/spoof |
| Crash/restart with in-flight external call | outcome unknown; no guarantee of deduplication after restart | resume existing Formation session through trusted store; seek fresh consent before re-request |

Failure classification appears in `CMR-05_EFFECT_POLICY.json`. Internal transition failures are typed *program-level error/verdict objects*, **not new v1 wire message kinds**; a future error envelope must be registered and reviewed in a new schema before inter-component dispatch. No error event can carry an approval token, unlock a write, or silently replace a model question.

## 7. Side-effect ordering, rollback and known non-atomicity

- Before the first effect: reject without observable handler effects, unchanged durable Formation session.
- After an external read or Ollama send: validation failure does not undo external observation. Abort route, mark uncertainty if necessary, and avoid automatic redelivery. Never assume exactly once from an in-memory cache or audit checksum.
- On a valid result: check schema, trusted producer, same correlation, exact causation parent, output semantic rules and consent *before* presenting it. If delivery/Formation storage fails, Formation's existing store recovery and resume behavior apply; coordinator cannot roll that back.
- Existing Formation `stage()` prepares successive validated record states; `cli._perform()` saves each separately. Router is **not** a transaction layer for these writes.
- Governance `gated_submit()` reserves quota in one SQLite DB and submits to the proposal ledger in another. Existing `SubmissionOutcomeUnknown` / `SubmittedWithoutGateRecord` and operator reconciliation remain **unchanged**; introducing a message must not pretend to make these operations atomic. This stage explicitly excludes queue application, signed writes and gate reconciliation.
- A failed candidate seam is disabled in shadow mode and the previous direct path is restored with all original consent checks. No production rollback is performed by this checkpoint.

## 8. Technical exit and acceptance limits

Design-stage acceptance requires: (a) complete transition matrix for all 5 CMR-04 kinds, (b) allowlisted and denied effect policy, (c) failure/retry and interruption behavior, (d) explicit ordering, state rollback and uncertain-outcome semantics, (e) bounded depth/hops/times and provenance/idempotency design, (f) reproducible static design tests, (g) no executable router, runtime changes or production approval. The accompanying [`CMR-05_PROTOCOL_TESTS.py`](CMR-05_PROTOCOL_TESTS.py) verifies document consistency and deliberately negative matrix cases; it does **not** exercise authentication, live effects, crash recovery or operator approvals.

**Open for CMR-06/07/08/10:** implement trusted ingress and immutable envelopes, exercise adversarial source/replay/consent cases, validate handler side effects and deadlines, test interrupted effects, preserve Formation parity, repair Ollama redirect/proxy leakage before private tests, and independently verify signed review and two-database recovery. **No extra authority is conferred by this document.**
