"""Repeatable CMR-08 CLI call-site and authority-boundary source audit."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess

BEFORE = '71f4ae0'


def count_plain_calls(source, names):
    return {name: sum(isinstance(node, ast.Call) and
                      isinstance(node.func, ast.Name) and node.func.id == name
                      for node in ast.walk(ast.parse(source))) for name in names}


def report(root: Path):
    old = subprocess.check_output(['git', 'show', BEFORE + ':hwi_formation/cli.py'],
                                  cwd=root, text=True)
    new = (root/'hwi_formation/cli.py').read_text()
    modules = ('hwi_formation/cli.py', 'hwi_formation/model.py',
               'hwi_formation/model_port.py', 'hwi_formation/local_transport.py',
               'hwi_router/formation_bridge.py', 'hwi_router/formation_model.py')
    no_wiki_db = ('hwi_formation/cli.py', 'hwi_formation/knowledge_port.py',
                  'hwi_router/formation_knowledge.py',
                  'hwi_router/formation_model.py')
    banned_db = ('sqlite3.connect', 'wiki._db.conn')
    return {
        'schema': 'hwi.cmr08.adapter_audit.v1', 'baseline_commit': BEFORE,
        'static_only': True,
        'cli_direct_calls_before': count_plain_calls(old, ('retrieve_practices', 'question', 'propose')),
        'cli_direct_calls_after': count_plain_calls(new, ('retrieve_practices', 'question', 'propose')),
        'new_ports': ('ModelQuestionReader', 'ModelDraftReader'),
        'legacy_practice_port_preserved':
            'retrieve_practices(' in (root/'hwi_formation/knowledge_port.py').read_text(),
        'no_direct_wiki_db_at_advisory_boundary': all(
            not any(needle in (root/path).read_text() for needle in banned_db)
            for path in no_wiki_db),
        'modified_source_sha256': {
            path: hashlib.sha256((root/path).read_bytes()).hexdigest() for path in modules
        }
    }


if __name__ == '__main__':
    base = Path(__file__).resolve().parents[2]
    print(json.dumps(report(base), indent=2, sort_keys=True))
