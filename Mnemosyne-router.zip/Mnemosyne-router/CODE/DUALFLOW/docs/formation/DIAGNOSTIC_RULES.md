# Formation diagnostics: readable rule chain

The advisory `review_draft()` checks are now expressed using `DiagnosticRule` in
`hwi_formation/good_practices.py`. Each rule names its condition, describes its
operator-facing question, and returns a finding through a simple callback.

The `DiagnosticEngine` walks the chain **even if a rule does not match** so
independent missing-field checks are all evaluated. It has a step limit and
rejects accidental cycles. Matching callbacks see a read-only snapshot of
flat diagnostic facts. No callbacks perform I/O, invoke models, or authorize
anything. Wiki practice questions are still appended by the existing trusted
review code, preserving their provenance and advisory status.

This is deliberately **not** a new router, policy engine, execution language,
or generalized decision table. The existing Formation state machine, router,
fitness and signed governance boundaries are unchanged. The graph is intended
to make existing diagnostic branching self-documenting, not to expand agent
authority.

To test from a repository checkout with approved core on `PYTHONPATH`:

```sh
python3 -m unittest -q hwi_formation.test_diagnostic_rules hwi_formation.test_good_practices
```
