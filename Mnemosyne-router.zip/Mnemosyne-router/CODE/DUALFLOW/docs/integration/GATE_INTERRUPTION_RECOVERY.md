# Recovering a gate binding after an interrupted proposal submission

**Status:** experimental, not an acceptance of new authority or cross-database atomicity. Based on corrected governance `061c9cc` and the integrated pre-QSECD Formation branch `ab51cd7`. No QSECD.

## Problem and actual guarantee

`queue-submit` performs three independently committed actions:

1. Gate SQLite: reserve one quota slot after verifying the signed task scope.
2. Approved HWI-07 SQLite: append a proposal and its ledger event.
3. Gate SQLite: bind that slot to the proposal ID.

A process crash or I/O failure between steps 2 and 3 can leave a committed proposal with an `UNVERIFIED` fitness gate and a consumed `RESERVED` slot. An exception during step 2 can also leave an uncertainty: the ledger may or may not have committed. **These steps are not atomic as a group.** SQLite's per-file atomicity is not a substitute for a distributed transaction.

## Experimental mitigation

New gated submissions save an exact, bounded `submission_intents` record **in the same SQLite transaction** as the initial quota slot. The intent contains the original operator-supplied submission spec and a SHA-256 integrity digest. It is protected by the same private `0700` directory and `0600` SQLite file as receipts. Intent data can include proposed wiki text; keep this workspace private.

A new **explicit operator-only** command checks pending intents against the immutable HWI-07 proposals by comparing the operation, exact reason, author-origin claim, expected target revision, evidence references including the fitness reference, requested payload, and physical notebook scope. It can bind a missing slot only when:

- A single ledger proposal exactly matches an intent.
- A single pending reservation matches that proposal.
- No other slot already binds that proposal.
- Both the approved ledger and gate store open and verify their existing notebook scopes.

The match is strict, but not brittle: the request is normalised exactly as the approved ledger normalises input (reason, source references and proposed title are trimmed; `normalize_proposal_request`, pinned by a contract test). Submissions are normalised before reservation, and requests saved untrimmed by `df6ec53` are normalised at match time. Matching original request data is *not* proof of the submitter's real-world identity or independent provenance. A same-OS-user process able to edit both databases remains outside the threat model.

## Operator commands

From the extracted consolidated release root:

```sh
bash RUN_GOVERNANCE.command queue-gate-recover \
  --workspace '/path/to/your/private/wiki-workspace' --notebook primary
```

This is a **read-only diagnostic**. It may report:

- `READY_TO_BIND`: one exact match, binding not yet recorded.
- `NO_EXACT_MATCH`: no matching committed proposal; slot is retained.
- `AMBIGUOUS`: multiple pending intents/proposals match; slot is retained.
- `LEGACY_NO_INTENT`: older reservation has no captured request; slot is retained.
- `ALREADY_BOUND_ELSEWHERE`: proposal already uses another slot; no repair.

After examining the proposal in the usual review queue, explicitly opt in to repairing only the ready entries:

```sh
bash RUN_GOVERNANCE.command queue-gate-recover \
  --workspace '/path/to/your/private/wiki-workspace' --notebook primary --apply
```

A recovered binding is recorded in the same transaction in an immutable `recovered_bindings` table, and its gate status permanently shows `binding: OPERATOR_RECOVERY` (normal ones show `GATE_SUBMISSION`), because an exactly matching record proves the request was signed for, not that the gate itself submitted it. This does **not** approve a proposal or change wiki content. The normal fitness gate is rechecked later by `queue-review` and `queue-apply`; the existing separate signed wiki reviewer is still required. Repeating `--apply` does not rebind an already bound slot.

## Compatibility and non-goals

The intent table is an **additive extension** of the existing HWI-GOV-v1 database. It is installed for old stores on the next explicit gated-submission write path (`GateStore(create=True)`); read-only operations do not migrate a database. Old RESERVED slots do not gain retroactive intent records and cannot be safely assigned by guessing. Existing verified BOUND slots and quota counts are left unchanged.

Unmatched reservations are **never automatically freed**, even when the ledger currently appears empty, because the original commit outcome may have been uncertain and another submitter may be in flight. This mitigation restores verifiable committed bindings where possible; it does **not** eliminate orphaned quota slots or make HWI-07 submission and the gate one atomic transaction. That would require a separately approved core change with a transaction coordinator and crash tests.

## Deterministic tests

`python3 -B -m unittest hwi_governance.test_gate_recovery -v` covers post-commit bind failure, lost response after the ledger committed, unknown precommit failure, duplicate matching intents, nonmatching payload, altered intent digests, immutable intents, definite rejection cleanup, legacy-store upgrade, and idempotence. Tests use a real temporary PERSONAL.WIKI notebook and the approved ledger; they do not require Ollama, a live user wiki, or QSECD.
