# Agent Formation + SQLite-backed governance — experimental integration

Status: **unaccepted** Python-only candidate built on governance commit
`061c9cc`; two development histories merged without rewriting either. No QSECD.

## Authority and data ownership

| Item | Authoritative location | Consumers |
|---|---|---|
| Wiki posts, catalog, verified revision history | Approved PERSONAL.WIKI SQLite stores | `Repository` read-only broker API |
| HWI-07 proposal ledger | Existing proposals SQLite store | `Repository` and `review_queue` |
| HWI-08 application receipts | Existing wiki history SQLite | `Repository.applied_proposal_ids()` (one contract-tested private core read) |
| Fitness gate receipts/quota | Governance SQLite (`GateStore`) | Existing `fitness_policy` and CLI |
| Formation transcript/purpose contract | Private, integrity-checked local files | Formation CLI only; **not authority** |

`hwi_formation/wiki_adapter.py` no longer opens `NotebookWorkspace` or imports
`hwi.knowledge_broker`. It calls `hwi_governance.repository.Repository` for
readiness and retrieval. The repository still uses the frozen HWI-05 broker for
revision-pinned, PVS-filtered, current-record reads. Every retrieval is
read-only, opt-in, bounded, and advisory. A formation session pins the physical
notebook scope; on resume, an explicit retrieval against a different instance
of `primary` is rejected even if the notebook *name* matches.

The Formation CLI uses `check_storage_environment()` from this same repository.
The model sees only the capability **status** and, with separate operator
consent, bounded advisory questions (not wiki content, SQL, filenames or paths).

## Read-only review status, not wiki approval

A current status projection can be queried directly:

```sh
bash RUN_GOVERNANCE.command queue-status \
  --workspace '/path/to/existing/workspace' --notebook primary
```

`queue-status` invokes `review_queue.status_projection()`, reads the *current*
proposal ledger, wiki application receipts and reverified fitness gate status,
and returns only IDs, status codes, operation names and counts. It omits all
untrusted before/after content and error details. It neither imports a wiki
post nor writes a receipt. It is suitable as the **data contract** for a future
read-only PERSONAL.WIKI review panel, but **is not such a panel today**.

The existing `queue-export` remains a manually imported inert snapshot, and
`queue-apply` remains the only supported, separately signed application route.
No status indicator, Formation `CONFIRM`, or advisory RAG record grants authority.

## Agent Formation

```sh
bash RUN_AGENT_FORMATION.command start --manual
bash RUN_AGENT_FORMATION.command start --model 'llama3.1:8b' \
  --wiki-workspace '/path/to/existing/workspace' --notebook primary \
  --practice-query 'numerical comparison'
```

The operator must explicitly consent to local transcript storage before any
Formation files are created, and must separately consent before practice
questions enter the local model prompt. An unavailable Ollama instance falls
back to manual questions. `CONFIRM` creates a contract with
`FORMED_NOT_COMMISSIONED`, `fitness_status=NOT_TESTED`, and false authorization
claims; it does **not** make a task-fitness contract or a verified receipt.

## Important remaining gaps

1. **No atomic operation across gate and proposal databases.** A quota slot
   reservation and HWI-07 ledger submission still use separate commits. Existing
   fail-closed semantics and explicit diagnostic states remain; no claim of
   transaction atomicity is made.
2. **Frozen-core HWI-08 API gap.** The repository still uses one tested private
   read of `wiki._db.conn`. A separately accepted core release could replace it
   with a public receipt query.
3. **No embedded live wiki UI.** The new read-only status projection is a CLI
   API, not a TiddlyWiki-compatible dynamic rendering feature.
4. **No end-to-end commissioning or useful-task benchmark.** A formed purpose
   has not been independently tested; real native Ollama usability remains open.
5. **No adversarial protection from a process owning the same OS account**;
   checksums/SQLite constraints provide consistency, not identity authentication.

## Regression and acceptance

Integration tests verify the shared interface, physically pinned resumption,
no direct Formation SQLite/wiki-core import, no wiki/catalog mutation, and
fresh status projection before and after an HWI-08 signed application. The
approved wiki/agent sources are byte-identical to the uploaded `061c9cc`
release. All human approvals remain separately required.
