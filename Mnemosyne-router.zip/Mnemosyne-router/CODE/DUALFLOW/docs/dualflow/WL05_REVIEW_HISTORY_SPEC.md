# WL-05 — Portable, revision-linked review history (offline candidate)

**Status: UNCOMMITTED REVIEW CANDIDATE.** Depends on WL-03 and WL-04, both of which remain unaccepted. This checkpoint does not constitute acceptance of either predecessor or of WL-05.

## Purpose

Persist bounded WL-04 **synthetic regression reports** and **non-authorizing review notes** in one deterministic, locally verifiable, ordered history. Preserve the exact candidate, base, patch, suite and report SHA-256 identities supplied by WL-03/04, plus explicit chronological relationships. No agent-driven acceptance, PERSONAL.WIKI admission, protected write, signing operation or tool dispatch is provided.

## Record contract

The local history file is UTF-8 JSON Lines. Each event is a closed object with:

- `schema`: `hwi.dualflow.history_entry.v0`
- `sequence`: strictly consecutive 1-based integer
- `previous_entry_sha256`: null for the first event, otherwise the exact preceding event digest
- `kind`: either `REGRESSION_REPORT` or `REVIEW_NOTE`
- `payload`: a complete WL-04 report or review note, respectively
- `entry_sha256`: SHA-256 of canonical JSON of all other event fields

The full content of each regression report is retained within the history, including revision identity pins, test identifiers, synthetic expected/observed comparisons and its preexisting `evidence_sha256`. A review note may only be appended when that **same report is already present**; the existing WL-04 `attach_review_note` validator must accept the note. Repeat report identities and duplicate `(report, note)` pairs are refused.

Only `READY_FOR_OWNER_REVIEW` or `REGRESSION_MISMATCH` synthetic reports with `PENDING_OWNER_REVIEW` and all authority/independence flags false may enter the history. Report counts, statuses, result identifiers and stored digests are checked for internal consistency. WL-05 **does not replay simulation tests during history verification**: WL-04 owns the replay step, and even replay cannot establish source truth or independent test expectations.

## Local storage guarantees and limitations

- The ledger is logically append-only. Writes are performed by **atomically replacing a complete validated JSONL snapshot**, not by filesystem-level WORM storage. Existing events must remain unchanged for a legitimate append.
- Cooperating Unix/macOS writers use a separate advisory `flock` file. A writer must supply an `--expected-head` SHA-256 (or `GENESIS` for a new ledger); a stale head is rejected before any new history file is written.
- Durable-save steps write to a same-directory temporary file, `fsync` its bytes, atomically replace the ledger and `fsync` the containing directory. Implementation assumes a cooperating local POSIX filesystem; not tested for network filesystems or crash power-loss guarantees.
- The history is bounded to **128 events, 300,000 bytes per event and 4,000,000 bytes total**. Inputs reject oversized files, malformed JSON, duplicate JSON object keys, nonstandard JSON numbers and broken or missing final newlines.
- Event hashes provide **local integrity and relative history consistency**, not signatures, validated authorship, independent custody or anti-rollback protection. A party able to rewrite the ledger and recompute its chain could forge it; an old valid prefix could also be substituted without an **independently retained** head digest. This implementation makes no security claim against such actors.
- The `.lock` file and temporary-write path are not trusted as a security perimeter. This tool is explicitly **not** an authoritative PVS log or a replacement for protected wiki/PVS admission.
- The tool accepts only report and note events, never `OWNER_ACCEPTANCE` or permissions. A review annotation's `RECOMMEND_FOR_OWNER_DECISION` remains advisory.

## CLI

```bash
python3 tools/review_dualflow.py \
  docs/dualflow/examples/evidence_review.json \
  docs/dualflow/examples/evidence_review.patch.json \
  docs/dualflow/examples/evidence_review.regression.json \
  > /tmp/example-wl04-report.json

python3 tools/history_dualflow.py append-report /tmp/example-history.jsonl \
  /tmp/example-wl04-report.json --expected-head GENESIS

# Use the returned head_sha256 as the next expected head.
python3 tools/history_dualflow.py append-note /tmp/example-history.jsonl \
  docs/dualflow/examples/evidence_review.review_note.json \
  --expected-head <previous-head-sha256>

python3 tools/history_dualflow.py verify /tmp/example-history.jsonl \
  --expected-head <independently-retained-final-head-sha256>
python3 tools/progress_dualflow.py
python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
```

The tool does **not** create a human acceptance record. These files are test evidence and history examples only.

## Roadmap progress reporting

`ROADMAP_PROGRESS.json` locks the **currently scoped 10-goal** denominator: WL-01, SF-01, WL-02, SF-02, WL-03, WL-04, WL-05, WL-06, HWI-I01 and HWI-I02. `progress_dualflow.py` computes two separately labeled metrics:

- **Accepted** = exact owner-accepted and locally committed goals, as maintained in the roadmap (4/10 as of this candidate).
- **Technically complete** = accepted goals plus bounded candidates that passed their stated tests (7/10 including this uncommitted WL-05 candidate).

The `ACCEPTED` label requires a recorded 40-character Git commit ID in the JSON. This is a *format check, not verification of owner authority*. Planned increments and in-progress work are not counted as technically complete. HWI's original C1–C14 milestones, Linux RC-05 condition, model evaluation and other project tracks are **not** folded into this denominator.

## Acceptance gates remaining

1. Owner reviews WL-03 and WL-04 before WL-05 acceptance; their exact source changes are prerequisite dependencies.
2. Tests and a fresh replay must pass, with a clear reproducible patch that contains only WL-05 files.
3. Owner reviews the security limitations, chooses whether to accept the history representation, and separately authorizes an exact Git commit.
4. Future work may integrate durable records with REAL wiki/PVS authorization, but that requires a separate security and compatibility review.
