# Dual-flow research roadmap — accepted local checkpoint

**Owner decision:** 2026-11-12 — explicitly accepted the full scoped dual-flow
workflow-language and local-model research codebase, with remaining fixes
deferred to production hardening. This record supersedes earlier review-candidate
progress summaries; those historical records remain in Git unchanged.

| Scope | Accepted / total | Percent |
|---|---:|---:|
| **Fixed dual-flow research workstream** | **10 / 10** | **100%** |
| Technically implemented in the accepted scope | 10 / 10 | 100% |
| Awaiting dual-flow roadmap acceptance | 0 / 10 | 0% |

Accepted goals: WL-01, SF-01, WL-02, SF-02, WL-03, WL-04, WL-05, WL-06,
HWI-I01 and HWI-I02. Each goal in `ROADMAP_PROGRESS.json` cites the exact
local implementation Git commit that establishes its accepted source lineage.

**Acceptance is of a bounded research implementation, not proof of general
model reliability or authorization to deploy.** A real Llama 3.1 8B trial
produced a structurally valid alternative in all 3 v1 patch trials, but 0/3
matched the synthetic reference, and a later cited-content v1 trial failed its
predeclared `platform_scope` label check (`UNRESOLVED` instead of
`NOT_CONFLICT`). The failed-trial human-review path is implemented, but that
patch has not yet been independently repeated on native macOS. Review remains
pending; source citations are not an independent attestation of truth.

Production follow-ups and boundaries are recorded in
`HWI_I02_ACCEPTANCE_2026-11-12.md` and `PRODUCTION_HARDENING_BACKLOG.md`.
The **separate original HWI C1–C14 roadmap** and Linux **RC-05 gate** are not
accepted or closed by this decision. No protected wiki writes, expanded PVS or
SEC-02 authority, remote push, or production rollout is implied.

To check the current maintained summary:

```sh
python3 tools/progress_dualflow.py
```
