# WL-01 — Workflow language contract (design v0)

## Intent

Express a bounded, **declarative** workflow as a versioned artifact representing changes to work and knowledge. The human-visible Markdown manual is documentation; the JSON specification is the typed design contract. Neither format is an instruction with independent execution authority.

## Document envelope

- `schema`: exact string `hwi.dualflow.design.v0`.
- `workflow_id`: bounded lowercase symbolic identifier (`[a-z][a-z0-9_.-]{0,63}`).
- `revision`: positive, exact integer; identifies the candidate within a workflow lineage, but does not attest to PVS acceptance.
- `mode`: exactly `simulation_only` in v0.
- `resources`: exact integer limits `max_steps` (1–100) and `max_artifacts` (1–256). These are modeling bounds, not a runtime watchdog.
- `stocks`: 2–32 distinct named containers; each is typed `work` or `knowledge`, with up to 16 initial artifact identifiers.
- `flows`: 1–32 transitions; each names a declared capability, input and output stock IDs, named preconditions and expected observations, and explicit `on_failure`/`on_unknown` destination stocks.
- `invariants`: required fixed invariants `no_protected_writes`, `no_unverified_success`, `preserve_provenance` (more may be documented but are not executed by the checker).
- `terminal_stocks`: nonempty set of declared **work** stocks marking the end of a simulation path.

Every object uses closed keys. Duplicate symbolic IDs, undeclared stock references, disallowed capabilities, unsupported versions, and noncanonical types are rejected.

## Transition semantics

A flow is a **candidate transition contract**, not an action instruction. `inputs` and `outputs` declare potential stock dependencies and effects; they do not authorize cloning an artifact, rewriting evidence, or committing a state. The capability identifier must resolve to an independently supplied implementation in a future, separately reviewed integration. The only v0 names are:

- `retrieve_readonly`: retrieve source material without writing protected records.
- `assess_evidence`: construct provisional, attributed assessments; it cannot certify factual truth.
- `render_report`: produce a reviewable explanation from available assessments.

`guards` and `observations` are symbolic obligations. In v0 they are checked for syntax only. The proposed runtime semantics are three-valued: `VERIFIED`, `VIOLATED`, or `UNKNOWN`. A missing binding or unresolved guard must not silently become true.

A transition may be considered for application only when its preconditions are verified by appropriate checks. On failure or unknown applicability, the transition must stop or move to an explicit failure/unknown destination. A future interpreter must implement atomicity, rollback/reconciliation, observation recording, bounded execution, and authorization checks independently; these **are not implemented** in this checkpoint.

## LLM and versioning boundary

An LLM may suggest a new document or a bounded diff against a pinned base revision. Each proposed change remains untrusted until checked and reviewed. A valid JSON shape, passing tests, wiki presence, or a claimed `approval` field grants no authority. Source records, test expectations, and a human acceptance record must not be inferred from the model's output. V0 does not parse patches or accept embedded code.

## Completion of WL-01

This design checkpoint is complete when the contract and example are inspectable, the offline checker passes valid examples and rejects representative malformed inputs, and the limitations are explicit. This does **not** count as an implemented workflow language or final acceptance of its runtime semantics.
