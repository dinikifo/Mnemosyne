# WL-03 — Versioned workflow proposals (uncommitted candidate)

**Status: SCOPED AUTHOR REVIEW; NOT APPROVED OR COMMITTED.**

## Purpose and trust boundary

The `tools/patch_dualflow.py` proposal tool accepts an exact WL-01 `hwi.dualflow.design.v0` base and a closed `hwi.dualflow.patch.v0` JSON patch. It constructs a fresh candidate on a deep copy and validates the complete resulting design using the unchanged WL-01 checker. All operations remain **simulation-only**. A successful result means **structurally valid candidate**, never authorized workflow, accepted revision, executed test, verified evidence, or permission to publish to PERSONAL.WIKI/PVS.

This is an offline, deterministic versioning aid. It does not write to disk, execute a workflow, run the tests listed by a patch, invoke a model, trust any claimed signature, accept approval, or modify governance/security code. The CLI emits a JSON preview on standard output and errors with exit code 2 on rejected input.

## Patch envelope

Exactly these keys:

- `schema`: `hwi.dualflow.patch.v0`.
- `workflow_id`: exact identifier of the base design.
- `base_revision`: exact integer matching the base design's positive revision.
- `base_sha256`: exact SHA-256 digest of canonical JSON of the base document, as defined by WL-02. **Identity pin only, not authorization**.
- `rationale`: 10–1000 printable characters explaining the change. **Untrusted text, not evidence**.
- `tests_to_run`: 1–16 unique, bounded symbolic test IDs. **Test declarations, not test execution or proof of coverage**.
- `operations`: 1–16 bounded changes, with no repeated edit target within one patch.

The tool rejects duplicate JSON object keys, nonstandard JSON numbers, unknown fields, invalid types, stale base identities, unknown operations and final designs that violate WL-01 constraints. A patch applied to its own candidate fails the stale-base check. No rebase or merge occurs automatically.

## Allowed operations

| Operation | Fields | Constraints |
|---|---|---|
| `replace_flow` | `id`, full `value` | Existing flow, same ID, non-identical new content; full design validated |
| `add_flow` | full `value` | New flow ID; bounded, permitted capability only |
| `remove_flow` | `id` | Existing flow; remaining design must still validate |
| `add_stock` | full `value` | New empty stock; namespaced `work.*` or `knowledge.*`; final connectivity checked |
| `remove_stock` | `id` | Existing stock with no initial artifacts; remaining graph must validate |
| `set_resource` | `name`, `value` | Only `max_steps` or `max_artifacts`; exact positive integer within WL-01 limits |
| `set_terminal_stocks` | `value` | Existing validated terminal work stocks; non-identical list |

Patch operations deliberately cannot change `schema`, `workflow_id`, `mode`, `invariants`, or initial artifacts, and cannot introduce new capabilities. The new revision is **exactly base revision + 1**. Revisions use finite positive exact integers, with a limit of 1,000,000. This is local proposal sequencing, not a claim about PVS or published-wiki revision numbers.

## Candidate output and review requirements

A successful result returns `UNREVIEWED_CANDIDATE_SHAPE_VALID_ONLY`, the pinned base identity, canonical patch and candidate digests, the exact candidate design, structured before/after operation changes, the rationale and proposed tests. It explicitly sets `owner_accepted`, `workflow_published`, `execution_authorized`, `knowledge_approved`, and `observations_independently_verified` to `false`.

The patch is reviewed as a single atomic proposal: no partial result is returned on failure. The original base and patch are not mutated. Regression evidence remains separate. Because a revision changes both `revision` and the design hash, old WL-02 scenarios are intentionally invalid until **explicitly** adapted, reviewed and re-run against the new candidate. Merely inserting a new digest and calling old assertions `VERIFIED` is not independent verification.

## Example reproduction

```sh
python3 tools/patch_dualflow.py \
  docs/dualflow/examples/evidence_review.json \
  docs/dualflow/examples/evidence_review.patch.json
python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
```

The example proposal extends `report_assessment` with an additional guard and observation to prompt contradiction reporting. It does **not** execute the new tests or prove those obligations hold in the real world.

## Deferred and separately governed

Semantic analysis of revisions; executable capability evaluation; concurrency/continuous stocks; automated regression orchestration; external evidence checking; real-LLM effectiveness; merged branches; PVS approval; user identity verification; wiki publication; protected writes; and any SEC-02 policy expansion are not part of this checkpoint.
