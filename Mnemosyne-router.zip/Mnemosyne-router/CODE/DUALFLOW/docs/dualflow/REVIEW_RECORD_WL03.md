# WL-03 — Versioned workflow proposal candidate

**Disposition: PRE-COMMIT TECHNICAL REVIEW; OWNER ACCEPTANCE NOT YET GIVEN.**

## Exact baseline

- Parent: WL-02/SF-02 accepted commit `9ccb79f5b0f946c3d354ceb3dedd8bf7d4dc4b2a`.
- Approved CR03 runtime source and SEC-02/PVS policy remain unchanged.
- This branch adds an offline patch proposal tool, a test module, a sample patch and the two documents in this review.

## Acceptance criteria

1. Exact-base pinned revisions reject stale base and invalid identities.
2. Every patch operation is bounded, typed, and restricted to the declared design surface.
3. The entire resulting design is revalidated before any preview is returned.
4. Input objects are unchanged, revisions increment exactly once, and attempts to patch the wrong base fail.
5. Before/after differences and proposed tests are explicit, without false assertions of test execution or approval.
6. A new revision invalidates scenarios pinned to the previous design, even when the only new requirement is a guard or observation.
7. Existing WL-01 and WL-02 tests still pass; adversarial new cases pass; independent replay of the exact patch produces byte-identical payloads.
8. No new execution capabilities, protected writes, or authorization paths are introduced.

## Known limitations

- This implementation is **structural**: it cannot detect a dishonest rationale, insufficient tests, invalid scientific claims, or semantically unsafe combinations that pass the existing shape checker.
- A caller can put synthetic `VERIFIED` assertions into a re-pinned simulation. That does **not** amount to factual verification.
- The before/after diff is operation-based, not a complete semantic/graph-impact diff. A human must review consequences across the full workflow.
- `tests_to_run` lists obligations; no tests are executed as part of proposal generation.
- There is no protected publication, signatures, independent human validation, source selection, external review or live model run.
- The design model is still discrete, acyclic, single active work token in simulation, and lacks real resource accounting and scheduling.

## Scope discipline

The candidate must remain uncommitted until separately reviewed and accepted by the owner. Subsequent changes, including a real wiki integration, require their own scope and approval.
