# HWI-I01 — Exact-revision, read-only PERSONAL.WIKI workflow bridge

**Disposition: uncommitted technical candidate; no owner acceptance.**

## Boundary and purpose

The first HWI integration connects an *explicitly selected* current PERSONAL.WIKI
record to the existing dual-flow **offline** validator and simulator. It does not
implement wiki search, instruction following, workflow publication, PVS approval,
LLM invocation, or any executable workflow capability.

The application is required to supply a previously constructed instance of the
actual `hwi.knowledge_broker.ReadOnlyKnowledgeBroker` (HWI-05), using a trusted
`NotebookWorkspace` and notebook name. The integration does **not** accept
paths, file names, commands or note titles from the model. The caller must
independently establish that the user explicitly requested this workflow;
this adapter does not establish human intent or authenticate an approval.

## Input contract

`select_pinned_workflow` requires:

- `broker`: exact HWI-05 read-only broker class, not a stub/subclass.
- `reference`: exact `hwi05://<local_namespace>/<post_id>@<event_id>` **current** revision reference.
- `expected_source_revision_sha256`: broker catalog's current SHA-256 revision identity.
- `expected_design_sha256`: canonical JSON SHA-256 of the workflow definition.
- `expected_workflow_id` and positive integer `expected_revision`.

Both SHA digests must be independently supplied by the caller; they may be
pinned during an untrusted search/discovery step, but a match is **not** proof
of approval. The exact record is read using the broker's `read()` method only;
`revision()` is never used to bypass stale-revision rejection. Catalog and
historical PVS restrictions remain enforced by the HWI-05 broker.

The record must be complete and untruncated and retain HWI-05's
`untrusted_wiki_data` and false authority labels. The adapter never forwards
arbitrary wiki titles, fields or metadata into its selection result. It parses
bounded JSON with duplicate-key and non-standard-constant rejection, checks the
strict `hwi.dualflow.design.v0` schema and permitted simulation capabilities,
and matches exact document identity, revision and canonical digest.

HWI-05 currently caps text returned by `read()` at 4096 characters; this
checkpoint rejects longer workflow documents. Supporting larger workflows
would require a separately reviewed contract rather than silent truncation.

## Result and simulation

`hwi.dualflow.wiki_selection.v0` contains the selected **untrusted** design, its
local wiki revision and selection digests, and explicit `false` approval flags.
The source digest is local revision provenance, not a portable signed PVS
receipt. `rehearse_pinned_workflow` re-reads the current revision, then passes
caller-supplied synthetic observations to WL-02. Its result
`hwi.dualflow.wiki_rehearsal.v0` remains `SYNTHETIC_REHEARSAL_ONLY`; no measured
real-world evidence or authorization is inferred.

This selection does **not** satisfy WL-06's per-application owner review, and
does not upgrade a draft workflow to an accepted one. Workflow acceptance and
wiki/PVS admission must be independently designed and reviewed.

## Dependency and reproducibility

The governance-history worktree does not contain the approved PERSONAL.WIKI
runtime source; it resides in the separately retained CR03 reference ZIP.
The HWI-05 broker used for real integration tests is byte-identical to
`source/wiki/hwi/knowledge_broker.py` in that reference.

To run real broker tests in isolation, extract the bundled `personal-wiki-core`
wheel (from `source/evidence/wheel_c14_r1/`) into a temporary directory and
set `PYTHONPATH` to that directory. The test fixtures create **temporary**
notebooks, initialize a catalog, use `ReadOnlyKnowledgeBroker`, and verify the
on-disk notebook inventory remains unchanged by the bridge. The test suite
skips these real-broker cases when the approved wheel is absent, so a passing
**stdlib-only** suite is not sufficient evidence for HWI-I01 completion.

```sh
PYTHONPATH=/path/to/extracted/approved_wheel \
  python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
python3 tools/progress_dualflow.py
```

## Non-goals and open limitations

- No new source-level changes to PERSONAL.WIKI, HWI-05, HWI-12, PVS or SEC-02.
- No search or automatic workflow selection from relevant retrieved passages.
- No broker call based solely on wiki prose or an LLM instruction.
- No change to protected-record access, key custody, or executable permissions.
- No external trusted custody or cryptographic proof of human acceptance.
- No actual agent integration, real-model behavior or end-to-end user approval.
- Exact class checks and read-only SQLite do not constitute a complete OS/process
  isolation boundary.
