# HWI-I02 — Local-model trial review gate (uncommitted candidate)

**Purpose:** turn `run_dualflow_local.py` JSON trial reports into a complete, reviewable
worksheet and a reproducible accounting summary. This is an **offline reader**;
it does not call Ollama, execute workflows, accept proposals, publish wiki
content, verify factual truth, or authenticate a human reviewer.

## Flow

1. On a computer with local Ollama and approved dependencies, run the already
   packaged `RUN_LOCAL_OLLAMA.sh` (or `run_dualflow_local.py`) and preserve the
   private JSON trial report. Capture actual machine/model metadata separately.
2. Audit the report and generate a pinned worksheet:

   ```sh
   python3 tools/assess_dualflow_trials.py local-trial.json
   python3 tools/assess_dualflow_trials.py local-trial.json --make-review-template > review.json
   ```

3. Independently inspect each trial's actual proposal, its task context,
   provenance, synthetic test limitations and evidence. In `review.json`, set
   a verdict of `SUPPORTED`, `INCORRECT` or `UNCERTAIN`, with a specific note
   (at least 10 characters). Leave `PENDING` if not reviewed. All trials must
   remain present; do not omit failures or inconvenient cases.
4. Produce a reproducible, digest-pinned summary:

   ```sh
   python3 tools/assess_dualflow_trials.py local-trial.json --review review.json > assessment.json
   ```

## Invariants

The auditor verifies outer and per-trial SHA-256 digests and internally
consistent counts, identities, trial indices, reported percentages, and false
authorization flags. Recomputing a digest is trivial and does **not** establish
independently signed custody or that the provider was a real LLM.

The assessment uses a full-denominator support percentage, and separately
reports pending and uncertain outcomes; it does not silently exclude failures.
Review notes are **untrusted local annotations**, not owner acceptance or
independent truth verification. Evidence notes are required for non-pending
judgments, but the tool cannot judge their quality.

The sample report in `docs/dualflow/examples/synthetic_http_fixture.local_trial.json`
comes from a **deterministic loopback HTTP fixture**. Its `LOCAL_LOOPBACK_OLLAMA_PROTOCOL`
field describes the transport interface only and must not be mistaken for
LLM provenance. The sample worksheet is entirely `PENDING`.

## Remaining acceptance conditions

A genuine local model must be run on the target machine. Independently reviewed
results should cover meaningful positive, negative and uncertain scenarios,
including a non-reference case, and should be compared with a simple Markdown
baseline. The trial gate **never** marks HWI-I02 accepted, regardless of scores.
Explicit owner acceptance of the exact HWI-I02 candidate and commit remains
separate. Scoped roadmap stays **9/10 accepted (90%) and 9/10 technically
complete (90%)**, with HWI-I02 still in progress.

## Security and privacy

Trial reports contain candidate workflows, notes and model metadata. Keep them
private; do not upload them publicly without review. SHA-256 can detect accidental
changes to archived reports, but an attacker able to rewrite a report can also
rewrite its digests. The auditor neither accesses network endpoints nor writes
protected knowledge. Use an external, independently controlled record if
reviewer identity and authorization must be established.
