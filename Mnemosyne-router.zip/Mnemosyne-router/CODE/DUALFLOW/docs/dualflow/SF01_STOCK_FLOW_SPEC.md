# SF-01 — Stock-and-flow semantics (design v0)

## Scope

The model describes **flow of work** and **flow of knowledge** in a coordinated discrete process. Authorization state is a separate external boundary. A state graph is useful for discrete procedural changes; quantitative stock-flow equations remain a separate extension for rate-based or continuous models.

## Stocks and identities

A stock is a named container for references to typed artifacts. `kind=work` holds task, operation, or report references; `kind=knowledge` holds source, evidence, claim, or assessment references. The v0 example uses token-like artifact IDs, not claims about truth. A knowledge artifact must retain provenance and cannot become independently trusted merely by entering a `knowledge` stock.

For a discrete transition at step `t`, the intended conservation/accountability relation is:

`Stock[t+1] = Stock[t] - moved_out + moved_in + newly_observed`

All removed artifacts must exist; no artifacts may silently vanish or duplicate identities. New artifacts require distinct IDs and links to origin observations (or an explicit reason that no source exists). These equations are *design obligations*; the v0 shape checker **does not simulate balances, allocate artifacts, or establish conservation**.

## Flows and timing

A flow is a transition between declared stocks and can produce work outcomes as well as provisional knowledge assessments. A future executable model must define discrete step ordering, concurrency policy, resource consumption, guards, unknown results, error transition atomicity, and stop behavior. V0 specifies only bounded resource declarations and transition structure.

Examples of interaction:

1. `retrieve_readonly` moves a work request toward evidence collection, making source references available as knowledge artifacts.
2. `assess_evidence` produces **provisional** claim assessments with cited origins, not PVS-approved memory.
3. `render_report` produces a report representing actual observed evidence and unresolved conditions.

## Three irreducible distinctions

1. A successful *work* operation is not proof that its output is factually true.
2. A supported *knowledge* claim is not permission to change the wiki or run a tool.
3. An accepted *workflow definition* is not blanket authorization for each invocation or its consequences.

Pre-application testing determines applicability under current conditions. Post-application checks compare actual observations with expected outcomes. Failed and unknown outcomes remain observable and must not be represented as success.

## Versioning

Keep workflow definitions immutable by revision. Keep each application history separate from definition history. Keep proposed knowledge changes distinct from governed knowledge revisions. A candidate's diff must be anchored to an exact base identity and accompanied by rationale, tests, and review evidence before publication. No implicit promotion is permitted.

## Deferred questions

- Continuous versus discrete flows and units; whether conservation is required for any given stock.
- Full typed artifact schemas and provenance links for each stock.
- Runtime scheduling, concurrency, liveness checks and bounded retries.
- Structural versus semantic workflow diff and protected revision protocol.
- How source references cross the PERSONAL.WIKI and PVS boundary without authority escalation.

These are specification/implementation tasks for later checkpoints, not present capabilities.
