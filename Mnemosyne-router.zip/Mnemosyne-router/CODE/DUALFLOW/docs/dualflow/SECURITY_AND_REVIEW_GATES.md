# Security and review gates — dual-flow design

## Non-negotiable boundaries

- The approved CR03 source and its governance checkpoint are immutable baselines. No old approval is transferred to new code or new workflow revisions.
- All model text, retrieved documents, Markdown comments, workflow specifications, and symbolic assessments are **untrusted inputs**.
- Only exact, independently verified approved workflow revisions may be considered for user-requested application; semantic retrieval may discover candidates but cannot establish approval.
- Deterministic checks cannot assert semantic truth just because an LLM generated an expected result.
- A workflow's `mode`, `guards`, or self-declared status cannot grant protected writes, executable dispatch, PVS admission, or human-review authority.
- SEC-02 remains deny-only. Existing credential custody, signing bytes, approval-digest binding, PVS write policy and recovery boundaries must not be changed by this design checkpoint.
- Unknown, failed, stale, partially written, or unauthorized states must remain observable and cannot be silently retried or reclassified as complete.

## Waterfall checkpoints

1. **Specify:** user and agent agree on desired changes, available resources, risks and expected results.
2. **Model:** propose separate work and knowledge stocks, transitions, guards, failure paths and provenance obligations.
3. **Validate:** run static checks and controlled simulation; independent expected observations are retained as evidence.
4. **Review:** compare the versioned diff, tests, residual uncertainty, and scope with the user.
5. **Accept:** a real authorization mechanism separately authorizes the exact intended publication or action.
6. **Apply:** before each application, revalidate task-specific assumptions and new test cases, and discuss results with the user; any consequential operation remains gated independently.
7. **Verify and revise:** compare actual effects with declared expected outcomes. If defects appear, create a new candidate revision rather than quietly modifying an accepted one.

A positive design-check report does not permit skipping any gate. No automatic workflow publication or invocation is part of this checkpoint.
