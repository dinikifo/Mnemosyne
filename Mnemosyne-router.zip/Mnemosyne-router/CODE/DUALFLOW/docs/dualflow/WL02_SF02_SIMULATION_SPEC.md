# WL-02 / SF-02 — Offline deterministic simulation candidate

**Status: UNCOMMITTED REVIEW CANDIDATE.** This document describes a bounded prototype on top of the unchanged WL-01 / SF-01 design contract. It does not grant model, tool, wiki, or PVS authority.

## Scope and model

`tools/simulate_dualflow.py` accepts (1) an immutable WL-01 `hwi.dualflow.design.v0` document and (2) a scenario conforming to `hwi.dualflow.simulation.v0`. It first calls the unchanged WL-01 shape checker. The scenario references the exact workflow ID, exact integer revision, and the canonical JSON SHA-256 of the design. This is a *local identity pin*, **not** an authorization fingerprint or provenance attestation.

A scenario consists of 1..`resources.max_steps` externally supplied step records, each with:

- `flow`: a declared flow ID;
- `work_artifact`: an existing work token in the flow's declared input work stock;
- `guards`: exactly the declared guard IDs, each marked `VERIFIED`, `VIOLATED`, or `UNKNOWN`;
- `observations`: exactly the declared observation IDs with the same three values **only if guards are all VERIFIED**; otherwise an empty object;
- `knowledge_produced`: for success only, a bounded array of fresh, named knowledge tokens, with the declared destination stock and at least one existing provenance-parent token.

**All supplied guard results, observations, and artifact descriptions are simulated assertions.** The program does not evaluate predicates against reality, retrieve documents, invoke a model, or independently verify evidence. In particular, `VERIFIED` is an input label to the simulator, not a verified external finding. A subsequent real integration must bind those labels to independently evaluated, typed evidence.

## Deterministic discrete semantics

- The v0 simulation profile requires **exactly one initial work artifact** and an acyclic work-state graph. WL-01's shape contract permits more than one; that broader case is deliberately rejected by this simulator.
- There is one work-token move per step. On success it moves from the declared work input stock to the declared work output stock; otherwise it moves to the declared terminal failure/unknown stock. It never duplicates or silently discards work tokens.
- A `VIOLATED` guard/observation produces `FAILURE`; otherwise an `UNKNOWN` result produces `UNKNOWN`; otherwise `SUCCESS`. A violated guard skips observations entirely. `VIOLATED` wins over `UNKNOWN` when both are present.
- Knowledge-input stocks are **read dependencies, not consumed resources**. Successful knowledge-producing steps create fresh globally unique token IDs in their declared knowledge output stocks. Parents must already exist; when a knowledge input is declared, at least one parent must belong to one of those declared input stocks. For source retrieval without knowledge inputs, its new token must cite the triggering work token as parent. All provenance is **claimed scenario lineage**, not a cryptographic proof of source truth or identity.
- Each successful step with a declared knowledge output stock must produce at least one token for that stock. A failed/unknown step must produce no knowledge. Step validation completes before local state mutation. The simulator maintains `total tokens = initial tokens + newly created tokens`, bounded by `max_artifacts`.
- Initial work tokens retain identity when moved. No retry, concurrency, real-time scheduling, quantitative rates, dynamic code evaluation, automatic repair or external effect exists in this version.
- A scenario ending in a declared terminal work stock reports `SIMULATED_TERMINAL` (including an error terminal). A shorter scenario ends with `SIMULATION_INCOMPLETE`, which must not be reported as successful completion. Extra steps after terminal are invalid.

## Failure and authority boundary

The simulator rejects undeclared flows, missing dependencies, stale design digests, invalid results, unexpected outputs, missing provenance parents, artifact-ID reuse, budget overruns and conflicting step states. The CLI returns exit code 2 for rejected scenarios. Its error text escapes terminal control characters.

A deterministic trace includes work-token movement, provisional knowledge lineage, terminal state, and its SHA-256 digest. These identities support repeatable replay; they **do not** attest to truthful evidence, correct reasoning, independent test expectations, operator consent, or human approval. `execution_authorized`, `knowledge_approved`, and `observations_independently_verified` are always false.

## Reproduce

From the candidate worktree root:

```sh
python3 tools/check_dualflow_design.py docs/dualflow/examples/evidence_review.json
python3 tools/simulate_dualflow.py docs/dualflow/examples/evidence_review.json docs/dualflow/examples/evidence_review.simulation.json
python3 -m unittest discover -s tools -p 'test_dualflow*.py' -v
```

## Next decisions, not included in candidate

An externally bound guard/observation evaluator; typed claim/source schemas; realistic user-defined quantity stocks and conservation laws; event scheduling and concurrency; independent review of semantic correctness; versioned patch application; actual HWI/PERSONAL.WIKI integration; owner acceptance; and any changes to SEC-02 or PVS authority all require subsequent, separate reviews.
