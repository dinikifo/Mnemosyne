# HWI-I02 consolidated implementation scope

Integration source accepted for the scoped dual-flow workstream:

- Local-loopback Ollama provider adapter, bounded prompting, strict typed
  patch checking, revision-pinned candidate generation, deterministic trial
  reports and separately recorded human review (`tools/`).
- Explicit per-operation prompt schema (`model_prompt.v1`) and native Mac path
  correction for temporary realpaths (`tools/test_dualflow_wiki.py`).
- Separate evidence-based content evaluator (`hwi_i02/CONTENT_EVAL/`) with
  exact quotation checks, predeclared synthetic labels, v1 deterministic
  classification summary, re-audit and pending review workflow.
- Mac launcher and tests (`hwi_i02/MAC_TOOLS/`); real local Ollama evidence has
  been seen, but is not an owner-attested semantic or deployment verification.

This acceptance does not revise the existing approved CR03 agent, PERSONAL.WIKI
source or PVS/SEC-02 authorization boundaries. It does not close the separate
Linux RC-05 or original HWI C1–C14 acceptance plan.
