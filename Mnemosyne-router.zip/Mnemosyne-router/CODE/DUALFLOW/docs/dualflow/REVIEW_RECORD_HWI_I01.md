# HWI-I01 review submission — uncommitted

**Review status:** scoped technical candidate, owner acceptance pending.
**Parent:** approved WL-02/SF-02 commit `9ccb79f5b0f946c3d354ceb3dedd8bf7d4dc4b2a`.
**Unaccepted dependencies:** original WL-03, WL-04, WL-05 and WL-06 candidate
patches are retained unmodified and are NOT retroactively approved.

## Scope for review

Add the exact-revision HWI-05 bridge, real-broker integration tests, this contract,
review record, and roadmap progress update. Nothing is committed, pushed,
published, authorized or written into a user's PERSONAL.WIKI.

## Test claims and their limits

- Existing offline design, simulation, patch, regression, history and
  per-application tests must continue passing.
- Real tests use the approved HWI-05 broker through a separately extracted
  CR03 wheel and temporary notebooks. They exercise source identity, exact
  reference binding, stale/cross-notebook failures, protected-PVS refusal,
  fake approval fields, malformed JSON, dangerous capabilities, bounded
  reads, reproducible synthetic rehearsal and no-write byte inventories.
- **No independent verification** of LLM observations, provenance custody,
  actual workflow acceptance or execution capability is claimed.

## Pending review decisions

1. Is strict current-revision selection (no historical fallback) sufficient
   for the initial read-only integration?
2. Accept the 4096-character HWI-05 text ceiling as an intentional v0 bound?
3. Keep selection independent of permission and publication, with the user
   intent check owned by the future application layer?

**Owner acceptance and Git commit require separate explicit authorization.**

## Recorded verification (2026-11-12)

- Full candidate suite with exact approved HWI-05 wheel: **253 passed** (232
  existing + 21 new bridge tests; no skips in the wheel-enabled run).
- Independent replay: **253 passed**, starting from accepted Git commit
  `9ccb79f5b0f946c3d354ceb3dedd8bf7d4dc4b2a`, applying the unchanged
  WL-03, WL-04, WL-05 and WL-06 patches, then this HWI-I01 incremental patch.
- All seven new/changed HWI-I01 files matched byte-for-byte in the replay.
- HWI-05 broker wheel `hwi/knowledge_broker.py` matched the source copy from the
  original CR03 reference archive byte-for-byte.
- Roadmap: **4/10 accepted (40%); 9/10 technical (90%)**. All five pending
  increments still require separate acceptance.

The passed tests are a **bounded local technical check**, not independently
signed software supply-chain evidence or owner acceptance. A clean replay also
cannot by itself establish physical separation or authorization custody.
