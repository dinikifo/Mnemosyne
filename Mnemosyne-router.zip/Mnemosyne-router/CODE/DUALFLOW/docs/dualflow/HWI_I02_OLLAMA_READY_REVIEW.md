# HWI-I02 — Ollama-ready integration candidate (human review)

**Status:** TESTABLE OFFLINE / AWAITING GENUINE MODEL TRIAL / NOT ACCEPTED FOR HWI-I02.

## Accepted dependency baseline

WL-01, SF-01, WL-02, SF-02, WL-03, WL-04, WL-05, WL-06 and HWI-I01
are recorded as owner accepted and committed to a local Git history.
The scoped roadmap is **9/10 accepted and committed (90%)** and
**9/10 technically complete (90%)**; HWI-I02 remains in progress.

## Functionality added to the prior HWI-I02 candidate

1. `evaluate_dualflow_model.py` now supplies the **exact deterministic base SHA-256** to the model in its input, alongside the base workflow and change request. A small local model must copy this digest rather than compute it. Model responses remain bounded strict WL-03 JSON patches.
2. `run_dualflow_local.py` uses the archived approved CR03 `OllamaProvider` with loopback-only HTTP access, no environment proxy routing and no cross-origin redirects. It discovers installed models, optionally requires exact installed model digest pins, supports 1–8 named local models, 1–12 trials per model, and runs pinned synthetic benchmark cases.
3. The runner records report digests, statuses, proposed patches, token counts, elapsed time, model tags, pinned task and workflow identities, and **separate validity and exact-reference agreement rates**. It never approves proposals, executes workflows, modifies PERSONAL.WIKI or pulls models.
4. `test_dualflow_local.py` tests the actual approved Ollama HTTP provider against a deterministic local loopback responder. This validates HTTP payloads, pinned inputs, model discovery, JSON-mode behavior and error handling. **The responder is a fixture, not a real LLM.**

## What a passing test means

Structural validity and matching a synthetic reference are **not evidence of semantic correctness, model cognition, source truth, or independent model attestation**. An exact reference match means agreement with the predeclared WL-03 patch and supplied WL-04/WL-06 expectations only. Local Ollama `/api/tags` identifies installed model names and locally reported digests; this is not independent verification of the model weights or operator identity.

## What remains open

- A genuine Ollama process and locally installed model must be available on the test computer.
- A human must inspect sampled model outputs and independently adjudicate factual/semantic quality.
- Test at least one valid non-reference scenario and a meaningful failure scenario before HWI-I02 acceptance.
- Capture real model version/digest, hardware, test corpus, latencies, token counts, reject rate, validated-patch rate and reference-match rate; compare against the simpler Markdown reference baseline.
- HWI-I02 requires separate owner acceptance and commit. Current source is a review candidate.

## Runtime instructions

From the consolidated testing archive on a machine with Python 3.11+, `requests`, and local Ollama started with a model already installed:

```sh
./RUN_TESTS.sh
./RUN_LOCAL_OLLAMA.sh --list-models
./RUN_LOCAL_OLLAMA.sh --model YOUR_INSTALLED_MODEL_NAME --repeats 3 --output ./my-local-test.json
```

Model names must match those returned by `/api/tags`. To compare models, supply another `--model NAME`. To pin a model digest, use `--pin-model 'NAME=64_LOWERCASE_HEX_DIGEST'`. `--output` uses an exclusive mode-0600 file; it must not already exist. The wrapper passes the example workflow, task, and reviewed synthetic comparison cases. It does not install, pull or launch Ollama.

For a different workflow or task, call `python3 CODE/DUALFLOW/tools/run_dualflow_local.py` with explicit `--design`, `--task-file`, and optional `--reference-patch`, `--regression`, and `--application` flags; all three benchmark inputs must be provided together. When no reference is supplied, even a structurally valid output remains `VALID_CANDIDATE_UNTESTED`.

## Security boundaries

- HTTP is restricted to literal loopback addresses; no arbitrary network endpoints, shell commands, tool execution or key access.
- Model output is parsed as untrusted JSON data only, validated against the exact starting revision and protected flow capabilities.
- No changes to CR03 agent source, PVS, SEC-02, protected wiki records or execution governance.
- No signed external model identity, human owner approval, factual truth, or permission is inferred from a report.
