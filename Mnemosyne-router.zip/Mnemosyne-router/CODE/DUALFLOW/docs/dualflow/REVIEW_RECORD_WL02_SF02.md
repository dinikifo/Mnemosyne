# WL-02 / SF-02 — Pre-commit review candidate

**Status: REQUEST OWNER REVIEW; NOT COMMITTED.**

**Parent design checkpoint:** `6335f92ccfbcaab038d2de044c7b07cd4a978ec5` (`design/wl01-sf01`).

## Change inventory

- New `tools/simulate_dualflow.py`: stdlib-only deterministic replay of a declared simulation scenario.
- New `tools/test_dualflow_simulation.py`: positive/negative tests, including unknown/failure cases and authority confusion.
- New `docs/dualflow/examples/evidence_review.simulation.json`: a fully synthetic scenario pinned to the existing design hash.
- New `docs/dualflow/WL02_SF02_SIMULATION_SPEC.md`: semantics, error handling and explicit limitations.
- This review record.

No approved CR03 source modules, original WL-01 design files, HWI/PVS security modules or SEC-02 policies were modified.

## Checks to complete before proposing commit

- Inspect exact patch and confirm all content is additive and simulation-only.
- Reproduce all predecessor WL-01 tests alongside new simulator tests.
- Reproduce successful and negative scenario CLI behavior.
- Verify a clean manifest and portable review package.
- Record residual risks, followed by an explicit user acceptance decision for the exact candidate.

## Known limitations to discuss

1. The simulator reads **asserted** guard and observation values; it cannot independently establish that they hold. Passing simulations are not runtime evidence.
2. There is only one active initial work token and a discrete, acyclic state graph; no concurrency, scheduling, quantitative flow rates, or general resource calculus.
3. Knowledge artifact provenance is a checked *reference linkage* within a synthetic trace, not verified source provenance or semantic truth.
4. The simulator does not enforce human approval or use the real HWI runtime, wiki, PVS, real model, or tools.
5. The proposed code is an uncommitted implementation candidate; owner approval and exact-patch commit are separate actions.

## Candidate author verification (2026-11-12)

- Parent is the exact committed WL-01/SF-01 design: `6335f92ccfbcaab038d2de044c7b07cd4a978ec5`.
- Original source ZIP SHA-256 remains `ebdbeae0a7ab8b78aa5dbd9e9ce3a30ae54e7ec1f50824a0d03b691773563773`.
- Original 17 WL-01 checker tests remain passing; 39 new simulation tests pass (56/56 total).
- Success scenario reaches `work.reported` with two claimed, linked knowledge artifacts; guard-unknown scenario reaches `work.stopped` with no new knowledge.
- The output always states `execution_authorized=false`, `knowledge_approved=false`, and `observations_independently_verified=false`.
- Staged patch check reports no whitespace/conflict errors; a separate fresh-patch replay and SHA-256 handoff manifest are required for the final review package.

**Author verdict:** SCOPED TECHNICAL PASS FOR OFFLINE SIMULATION ONLY; **AWAITING INDEPENDENT REVIEW AND OWNER DECISION BEFORE COMMIT**.
