# HWI dual-flow design checkpoint — WL-01 / SF-01

**Status:** design checkpoint, not a runtime implementation or an acceptance of HWI C1–C14.
**Baseline:** approved CR03 governance checkpoint `eeb08b688e702736d91f8bcb8b08304344457c20` and the separately retained approved source ZIP (SHA-256 `ebdbeae0a7ab8b78aa5dbd9e9ce3a30ae54e7ec1f50824a0d03b691773563773`).

This checkpoint specifies a bounded workflow language and stock-and-flow model that distinguish **work**, **knowledge**, and **authority**. Work and knowledge changes are modeled together; authority remains outside the model's power to grant.

## Deliverables

- [`WL01_LANGUAGE_SPEC.md`](WL01_LANGUAGE_SPEC.md): proposed JSON-based workflow-language surface and validation semantics.
- [`SF01_STOCK_FLOW_SPEC.md`](SF01_STOCK_FLOW_SPEC.md): discrete stocks, flows, timing, and knowledge provenance.
- [`SECURITY_AND_REVIEW_GATES.md`](SECURITY_AND_REVIEW_GATES.md): immutable boundary conditions and staged validation/approval.
- [`examples/evidence_review.json`](examples/evidence_review.json): one **simulation-only** example spanning work and knowledge states.
- [`../../tools/check_dualflow_design.py`](../../tools/check_dualflow_design.py): offline design-shape checker (Python stdlib only).
- [`../../tools/test_dualflow_design.py`](../../tools/test_dualflow_design.py): negative and positive design-contract tests.
- [`REVIEW_RECORD.md`](REVIEW_RECORD.md): test evidence, open decisions, and scope.

## Non-goals for this commit

No general-purpose programming language, LLM interpreter, workflow executor, PERSONAL.WIKI writer, PVS admission, SEC-02 permission expansion, reviewer-key change, deployment or GitHub push. The schema is a **design-time format**. A passing shape check proves neither task correctness nor human authorization.

## Reproduce

From the repository root:

```sh
python3 tools/check_dualflow_design.py docs/dualflow/examples/evidence_review.json
python3 -m unittest discover -s tools -p 'test_dualflow_design.py' -v
```

The original approved CR03 runtime source is held in a separate source ZIP, not in this governance-history worktree. No approved source files were changed.
