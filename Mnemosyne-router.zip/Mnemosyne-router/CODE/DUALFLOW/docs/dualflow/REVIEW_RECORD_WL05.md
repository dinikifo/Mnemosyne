# WL-05 — Pre-commit review record

**Disposition: TECHNICAL REVIEW CANDIDATE; UNACCEPTED AND UNCOMMITTED.** WL-03 and WL-04 are also unaccepted and uncommitted.

## Intended change

- Add a bounded local JSONL review history for pinned WL-04 regression reports and their separate non-authorizing review notes.
- Provide a deterministic history verifier, stale-head rejection, local cooperating-writer serialization, and atomic snapshot replacement.
- Introduce a fixed-scope dual-flow roadmap with separate accepted/technical percentages and a validator to compute them.
- Preserve the accepted WL-01/SF-01 and WL-02/SF-02 source, plus the previously staged WL-03/WL-04 patches, byte-for-byte unchanged.
- Do not alter agent runtime, SEC-02 permissions, PVS custody, protected wiki writes, or install/deploy a background service.

## Required review questions

1. Is the use of a **local hash chain with no signature or external anchor** clearly labeled as an integrity aid, not an authoritative audit system?
2. Should the first persistent format be self-contained JSONL (as implemented), or should it eventually reference externally retained artifact blobs? The latter is not implemented.
3. Are the 128-event / 4 MB bounds sufficient for a research prototype? A future migration can be designed without expanding current limits prematurely.
4. Is a maintained 10-goal roadmap with **accepted** and **technical-pass** percentages an acceptable way to report this workstream without conflating it with original HWI milestones?
5. Can the owner review and accept WL-03 and WL-04 first, preserving the dependency order before any WL-05 commit?

## Proposed acceptance tests

- Demonstrate a report + note round trip with exact digest pins and chronological continuity.
- Reject stale history heads, missing report identities, repeated reports/notes, malformed records and impossible report counts/statuses.
- Reject reports or notes carrying asserted owner approval even if a caller recalculates their digest.
- Detect tampering, sequence breaks and truncated records; explicitly demonstrate that an external valid-prefix rollback is **not** intrinsically detectable.
- Reproduce the combined WL-01 through WL-05 suite in a fresh checkout from accepted WL-02 plus the unmodified WL-03 and WL-04 patches, followed by the WL-05 patch.
- Verify no executable capability, PVS permissions, model access, network operation or wiki write was introduced.

## Review evidence

The handoff archive is intended to contain the WL-05-only patch; cumulative WL-03/04/05 replay patch; Python test logs; synthetic example review history; and SHA-256 manifest. Owner acceptance and exact commit authorization remain outstanding.
