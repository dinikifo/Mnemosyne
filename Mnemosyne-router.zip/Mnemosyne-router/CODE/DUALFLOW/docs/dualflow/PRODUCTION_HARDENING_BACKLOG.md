# HWI dual-flow — deferred production-hardening backlog

The owner has accepted the **research implementation** despite these known
limitations. These are **open production work items**, not silently resolved
by changing the roadmap status. Priorities are recommendations, not production
approval or a deployment order.

| ID | Priority | Work item | Exit evidence required |
|---|---|---|---|
| PROD-01 | High | Separate unresolved obligations from contradictory evidence statements; v1 `platform_scope` classification was wrong | Held-out annotated examples, regression coverage, independently reviewed label definitions |
| PROD-02 | High | Independent source-grounded semantic correctness and contradiction disclosure (including omissions and false conclusions) | Human-checked report artifacts, negative cases, per-claim provenance; documented false-positive/negative rates |
| PROD-03 | High | Native macOS rerun of final failed-v1 review-path package; inspect skips and test warnings | Sealed package digest, complete Mac 416-test transcript and test environment metadata |
| PROD-04 | High | Keep original HWI C1–C14 and Linux RC-05 acceptance barriers independently enforced | Separate owner-gated clean-environment execution and evidence, not derived from this acceptance |
| PROD-05 | High | Authenticate review, model identity, evidence sources and human sign-off; preserve fail-closed review status | Attested review/audit scheme, tested tampering and replay handling |
| PROD-06 | High | Deployment authorization, least-privilege threat review and protected-write controls | Independent security review and an explicit new permission grant; none granted here |
| PROD-07 | Medium | More model prompts, models, varied temperatures and representative tasks | Repeatable metrics with pinned inputs/model versions and regressions |
| PROD-08 | Medium | Improve workflow/semantic test mapping for an assessment-stage versus final-report-stage contradiction guarantee | Pinned negative scenarios and reviewed invariants, no assumption simulation proves truth |
| PROD-09 | Medium | Production observability, rollback and recovery, resource budgets, dependency/version pinning | Production-specific runbooks, monitoring tests, rollback rehearsals |

The v1 model trial that returned `CONTENT_CHECK_FAILED` is **still a failed
trial**. The benchmark's researcher-predeclared labels are **not** independent
ground truth. Human review remains `PENDING`, not accepted/endorsed by this
roadmap-status decision. All production work requires its own appropriate
approval and test evidence.
