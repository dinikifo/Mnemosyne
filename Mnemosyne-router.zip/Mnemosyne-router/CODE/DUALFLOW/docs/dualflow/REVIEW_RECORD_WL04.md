# WL-04 — Proposed review record

**Disposition: UNCOMMITTED; AWAITING OWNER REVIEW.** The WL-03 predecessor is also not accepted. Neither document is an approval or commit authorization.

## Scope

- Add the strictly bounded `tools/review_dualflow.py` offline comparator and optional non-authorizing note binding.
- Add `tools/test_dualflow_review.py`, a pinned three-case sample suite, and an explicitly synthetic review note.
- Add this review record and `WL04_REGRESSION_REVIEW_SPEC.md`.
- No changes to WL-01, SF-01, WL-02, SF-02, WL-03, approved CR03 source, application runtime, PERSONAL.WIKI, PVS or SEC-02.

## Proposed acceptance criteria

1. Run exactly the tests declared in the WL-03 patch, with complete, unique case-ID coverage and exact base/patch/candidate identity binding.
2. The test suite must include a candidate-pinned simulation; a base-pinned stale scenario can only be used as an explicit expected-rejection case.
3. Record deterministic expected-versus-observed differences and trace identities, and mark mismatches as blocking further recommendation.
4. Handle invalid scenario cases without letting unrelated exceptions count as a successful negative test.
5. Preserve unknown/failure simulation results, avoid unintended knowledge generation, and reject stale, malformed, or over-broad test inputs.
6. Review annotations must bind to the exact report and candidate and never become verified identity, owner approval or executable permission.
7. Run all prior WL-01, WL-02 and WL-03 tests without changing the earlier files; reproduce the candidate from the accepted WL-02 commit plus the uncommitted WL-03 and WL-04 patches in a separate worktree.
8. Produce an auditable manifest and exact patch; do not commit until explicit owner acceptance.

## Constraints and known limitations

- This verifies replay against *synthetic*, caller-provided results, not real-world facts, independent test expectations, or semantic quality.
- A complete declared test-ID set does not prove adequate test coverage. Negative cases can be trivial or dishonest; human review remains necessary.
- Hashes are not evidence of author identity or approval, and a claimed review recommendation is not an authenticated user decision.
- In-memory deterministic outputs do not guarantee atomic persistence or durability; WL-04 does not write or publish artifacts.
- No WL-04 commit has been made; dependent WL-03 acceptance remains unresolved.

## Evidence to fill after reproducibility checks

The owner-review package should contain the precise incremental WL-04 patch, cumulative WL-03+WL-04 patch, test log, sample report, per-file SHA-256 manifest and independent replay results. This record itself contains no claims of final owner acceptance.
