# WL-06 — Per-application, task-specific simulation validation

**Disposition: UNCOMMITTED TECHNICAL CANDIDATE.** The underlying WL-03, WL-04 and WL-05 candidates remain unaccepted, uncommitted, and logically distinct. WL-06 must not be interpreted as accepting them or any workflow definition. This is a **read-only synthetic rehearsal** facility, not an application/authorization worker.

## Problem and intent

Previously, WL-03 proposed an exact-base workflow revision, WL-04 replayed revision-bound synthetic regressions, and WL-05 recorded the evidence locally. A passing revision regression does **not** establish suitability for a specific, different user request. WL-06 accepts a separate per-request suite, binds it to the exact selected revision and recomputed WL-04 baseline report, checks declared coverage and basic structural novelty, and replays case-specific scenarios in the existing WL-02 simulator.

This creates an explicit gate **before user review of the application plan**. It does not create a gate that authorizes actual application or substitutes for the user's discussion, approval, real observations or independent evidence evaluation.

## Application-suite schema `hwi.dualflow.application_suite.v0`

A strict, closed JSON object with:

- `schema`: exact identifier above.
- `application_id`: bounded symbolic identifier, unique only by caller convention. Not globally reserved.
- `task`: `goal` (bounded explanatory text) and `requirements` (1–12 typed `{id, description}` objects). The requirements are *provided assertions* about the task, not independently extracted from the user's actual request.
- `workflow`: exact `workflow_id`, integer `revision`, and lowercase 64-character `design_sha256` of the selected WL-03 candidate.
- `baseline_evidence_sha256`: digest of a **recomputed** WL-04 baseline regression report. The tool recomputes WL-03 and WL-04 reports from supplied base, patch and regression suite, refusing a baseline with mismatched regressions.
- `cases`: 2–16 cases, each with unique `case_id`, `requirement_ids`, bounded `rationale`, exact-selected-revision `scenario`, and WL-04-style `expected` simulation result. There must be a case covering every declared requirement, at least one successful non-failure terminal expectation and at least one failure/unknown terminal expectation.

All case IDs must be new relative to the provided baseline regression suite. The digest of each case's `scenario.steps` must differ from **every** baseline scenario's steps and from all other new cases. These checks establish only syntactic novelty relative to the **provided** baseline; new wording, token identifiers or scenario arrangements may describe the same semantic test. No claim of fresh reasoning or independent expectations is made.

All scenarios are synthetic: guard and observation outcomes are caller supplied, not retrieved, measured or validated against the real world. Work and knowledge transitions are simulated by WL-02, and provisional knowledge identifiers remain unapproved.

## Output `hwi.dualflow.application_report.v0`

The deterministic report contains task, application, selected revision, baseline evidence and application suite digest identities; per-case expected/observed results and trace digests; and total matched-case count. Its statuses are:

- `READY_FOR_HUMAN_APPLICATION_REVIEW`: all declared synthetic expectations matched. This means *reviewable*, **not applicable, approved or executable**.
- `APPLICATION_BLOCKED`: valid input suite, but at least one simulation did not match the supplied expectation, or simulation raised `DesignError`.

Malformed documents, stale pins, incomplete declared coverage, reused steps, invalid baseline regression or unauthorized document fields are **rejected**, not turned into a green report. The CLI exits 0 for reviewable, 1 for blocked and 2 for rejected input.

The report always sets these fields **false**: `workflow_owner_acceptance_verified`, `expectations_independently_verified`, `observations_independently_verified`, `human_application_review_completed`, `application_authorized`, `application_executed`, `knowledge_approved`, and `workflow_published`. Its SHA-256 is a local content identity, not a signature or authorization receipt.

## Example and reproduction

```bash
python3 tools/validate_dualflow_application.py \
  docs/dualflow/examples/evidence_review.json \
  docs/dualflow/examples/evidence_review.patch.json \
  docs/dualflow/examples/evidence_review.regression.json \
  docs/dualflow/examples/evidence_review.application.json
python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
python3 tools/progress_dualflow.py
```

The example models a historical architecture-assessment request. It includes a task-specific successful assessment, an `UNKNOWN` source guard that stops without producing knowledge, and a `VIOLATED` contradiction-review guard that stops without reporting success. No source retrieval or real LLM call occurs.

## Deliberate omissions and boundary conditions

- No verification that the selected workflow is **actually approved**. Version pins are not evidence of acceptance, and the WL-03 candidate is unaccepted. A later governed integration must independently establish approval and catalog eligibility.
- No guarantee that generated cases are substantively new, relevant, complete, independent, or derived from the real user request. All requirements and expectations are caller declarations.
- No automatic test generation, real-model judgment, live evidence verification, procedure publication, user approval receipt, execution worker, PVS write, security-policy change or promotion to PERSONAL.WIKI.
- No semantic equivalence testing; digest-based novelty cannot detect renamed duplicates or logical equivalence. The gate does not make the agent self-authorizing.
- No extension to continuous-time or quantitative stock-flow simulation; WL-02's bounded discrete work/artifact semantics remain unchanged.
- Local report and source-file identity are not independent custody or anti-rollback guarantees.

## Next acceptance dependency

Before WL-06 source can be committed in dependency order, explicitly review and accept WL-03, WL-04 and WL-05, then review the exact WL-06 patch and test evidence. Such source commits do not authorize publication or application of any workflow revision. The user must separately review each intended real application, its cases and findings; a future independent authorization gate must be implemented before any protected writes or executable operations.
