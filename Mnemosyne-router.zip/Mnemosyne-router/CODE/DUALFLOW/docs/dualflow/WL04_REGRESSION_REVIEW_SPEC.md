# WL-04 — Simulation regression evidence and bounded review annotations

**Status: UNCOMMITTED REVIEW CANDIDATE.** This checkpoint is built **on top of the unaccepted, uncommitted WL-03 proposal candidate**. Its behavior is not separately approved and it does not imply acceptance of WL-03.

## Motivation and boundary

WL-03 validates and previews a proposal against an exact base workflow. Its `tests_to_run` field contains *declarations* only. WL-04 links those declarations to bounded scenario inputs and explicit expected results, replays them using WL-02, and produces a deterministic, digest-identified comparison report.

**No runtime execution, LLM calls, verification of real evidence, provenance attestation, authenticated owner consent, protected wiki/PVS writes, or SEC-02 policy changes occur.** An expectation may come from the same LLM that proposed the patch, so a passing comparison cannot establish the expectation's correctness or independent review.

## Regression suite `hwi.dualflow.regression.v0`

A closed JSON object contains:

- `schema`: exact schema ID above.
- `workflow_id`: exact base workflow identifier.
- `base_sha256`, `patch_sha256`, `candidate_sha256`: lowercase 64-digit digests matching the WL-03 proposal generated in this call. These are **identity pins**, not signatures.
- `cases`: 1–16 bounded test cases, with exactly one case for every symbolic `tests_to_run` ID in the original patch; no omissions, duplicates, or extras. At least one case must expect a successful terminal simulation with every flow outcome `SUCCESS`.

Each case contains `test_id`, `scenario` and `expected`.

- `scenario` is an embedded WL-02 simulation input. For an expected simulation result, it **must pin the proposed candidate**. For an expected rejection, it must pin either the real base or the proposed candidate; arbitrary unrelated identities are rejected.
- An expected simulation is a closed object: `kind=simulate`, `status` (`SIMULATED_TERMINAL` or `SIMULATION_INCOMPLETE`), `terminal_stock` (an actual declared terminal work stock, or `null` for incomplete), `flow_statuses` (ordered `SUCCESS`/`FAILURE`/`UNKNOWN` results), and `knowledge_ids` (the exact set of newly created provisional knowledge tokens, represented as a deterministic sorted list).
- An expected rejection is `kind=reject` plus bounded `error_contains`. Only an actual *DesignError* thrown by WL-02 can satisfy this expectation. Arbitrary crashes or a successful simulation are not accepted as a rejection.

All structured inputs are size-bounded and use strict JSON loading (duplicate object keys and nonstandard JSON numbers rejected). CLI error statuses are distinct: `0` for all expected comparisons matching, `1` for a valid suite containing a mismatch, `2` for an invalid document, stale pin, or rejected processing.

## Report `hwi.dualflow.regression_report.v0`

The report includes the exact base/patch/candidate/suite digests; each case's expected and observed comparison; a SHA-256 identity for the scenario and any generated trace; a total count of matches; and its digest `evidence_sha256` (computed over the report excluding the digest field). All comparison results are deterministic on the same supplied inputs and implementation. A digest preserves local report identity, **not authenticity**.

- `READY_FOR_OWNER_REVIEW`: all the *declared* synthetic expectations matched.
- `REGRESSION_MISMATCH`: at least one validly declared expectation did not match. The report is preserved rather than treated as a successful gate.

Both states leave `review_outcome=PENDING_OWNER_REVIEW` and the flags `owner_accepted`, `workflow_published`, `execution_authorized`, `knowledge_approved`, `reviewer_identity_verified`, `observations_independently_verified`, and `expected_results_independently_verified` false.

The suite proves neither regression-test independence nor adequate coverage; review must inspect whether the scenarios actually challenge the intended change. A passing simulation does not mean a real capability was invoked or a fact was proven.

## Review note `hwi.dualflow.review_note.v0`

An optional **unauthenticated, non-authorizing** annotation is bound to the exact `candidate_sha256` and `evidence_sha256`. It contains `disposition` (`REQUEST_REVISION`, `DEFER`, or `RECOMMEND_FOR_OWNER_DECISION`), bounded `reason`, and a subset of `reviewed_test_ids`. The recommendation disposition is unavailable if any regression mismatched or not all cases are listed as reviewed.

The annotation's output explicitly says `REVIEW_ANNOTATION_ONLY_NOT_AUTHORIZATION`, reports `reviewer_identity_verified=false`, and keeps all approval/publication/authorization booleans false. A reviewer name or claimed signature is **not** accepted. Even a recommendation is not an owner acceptance record. Actual identity, authority and protected persistence require a separately designed and approved HWI/PVS protocol.

CLI output with a note is an envelope with `evidence_report` and `review_annotation` to preserve the report hash unmodified.

## Example

```sh
python3 tools/review_dualflow.py \
  docs/dualflow/examples/evidence_review.json \
  docs/dualflow/examples/evidence_review.patch.json \
  docs/dualflow/examples/evidence_review.regression.json \
  --review-note docs/dualflow/examples/evidence_review.review_note.json
python3 -m unittest discover -s tools -p 'test_dualflow*.py' -q
```

The sample includes (a) successful proposed-revision simulation, (b) an `UNKNOWN` guard causing a safe stop, and (c) rejection of a simulation still pinned to the old revision. Its note is a *synthetic DEFER example*, not a record of a real user's judgment.

## Deferred to later gates

Independent expectation generation/review, semantic test coverage, externally evaluated guards and observed evidence, verified reviewer identity and custody, persistent evidence storage, wiki/PVS integration, live-model assessment, protected publication and real execution remain outside WL-04. Existing WL-01/02/03 code, the CR03 source and all SEC-02 deny-only behavior are unchanged.
