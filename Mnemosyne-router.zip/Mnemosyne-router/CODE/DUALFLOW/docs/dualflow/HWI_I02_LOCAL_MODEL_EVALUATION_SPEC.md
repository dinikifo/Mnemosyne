# HWI-I02 — Local model proposals and end-to-end read-only evaluation

**Disposition: IN PROGRESS, UNCOMMITTED REVIEW CANDIDATE.** Real local-model performance was **not** demonstrated in the build environment on 12 November 2026: `ollama` was not installed and the localhost `127.0.0.1:11434` endpoint refused connections. Fixture tests and an unreachable-server preflight are not substitutes for a genuine model trial. The roadmap is now **9/10 technically complete (90%)**, **9/10 accepted and committed (90%)** following the later owner acceptance checkpoint. See `ACCEPTANCE_CHECKPOINT_2026-11-12.md` and `HWI_I02_OLLAMA_READY_REVIEW.md` for current details.

## Goal and source boundaries

This increment connects the previously defined dual-flow workflow specification and HWI-05 exact-revision read-only broker to the **existing** `autogpt_lite.llm.provider.LLMProvider.chat` interface. The optional live CLI uses the approved `autogpt_lite.llm.ollama.OllamaProvider` implementation with a fixed `http://127.0.0.1:11434` endpoint; it does not add a new HTTP client, download weights, or modify the approved CR03 source.

The application task and the exact wiki record are selected by a trusted caller outside the model; untrusted wiki text is only used as a version-pinned, strict workflow definition. The model receives one bounded request to return a `hwi.dualflow.patch.v0` JSON object. The model receives neither the reference patch nor the secret of what the external benchmark expects. Its response must pass WL-03's strict patch checks before it can be represented as a proposal. Any unknown fields, unauthorized capabilities, executable instructions, malformed JSON, stale pins or response-model mismatch lead to rejection.

The agent can suggest a proposal, **not approve it, publish knowledge, execute a workflow, or certify evidence**. All simulated observations remain supplied test assertions. Successful matches to reference candidates do not imply objective factual correctness or permission to apply the workflow. The injected provider is not a security sandbox or proof of model identity; untrusted retrieved source content is never executable authority.

## Components and contract

`tools/evaluate_dualflow_model.py` supplies:

1. `evaluate_model_proposal` — provider-based proposal generation for a caller-pinned base workflow and task. Uses fixed temperature 0, JSON mode and a bounded response; output is a reviewable status/digest/diff, not an executed tool action.
2. `evaluate_pinned_wiki_model` — obtains the exact current HWI-05 read-only record using HWI-I01 and only then invokes the model. Stale wiki references fail **before** the model is called. This is an API for the trusted caller, not automatic RAG discovery.
3. `evaluate_model_batch` — repeats a predeclared task/reference comparison 1–12 times with status counts and exact-match rate, preserving the distinction between fixture metadata and real-world competence.
4. A **live opt-in CLI** that imports the existing approved Ollama provider. A failed local provider availability check exits with `MODEL_UNAVAILABLE` status 3 and produces no success report.

The benchmark suite is supplied **before** the model is called: exact base/patch WL-04 regression and WL-06 per-application cases. `MODEL_PATCH_MATCHES_PINNED_REFERENCE` means the candidate exactly reproduces the selected WL-03 reference and the WL-04/WL-06 synthetic expectation checks passed again. A structurally valid but different candidate remains untested or alternative, even if it produces the same structural design; it does not inherit the passing result from another patch. The benchmark can only measure agreement with its expected candidate, not full semantic equivalence.

`hwi.dualflow.model_trial.v0` includes exact base/design and task hashes, claimed provider name, request and response identities, bounded reported token usage, candidate proposal/diff or bounded failure class, and explicit false authorization/verification flags. The report hashes are local integrity identifiers, **not** evidence of independently authenticated model identity or approved custody.

## Deterministic test and live trial distinction

Unit and broker integration tests use a `FakeProvider` that reproduces a known WL-03 JSON patch or deliberately malformed/adversarial responses. Passing these tests demonstrates parser, state-binding, benchmark and fail-closed integration correctness. It cannot demonstrate how Ollama, an 8B-class model or a particular model version performs.

For a future **genuine** local-model run, an independent reviewer must record the actual Ollama model name and digest (as reported by the local installation), host/runtime environment, test corpus, input pins, raw CLI result, failure rate, target-reference match rate, token/time costs, unexpected output, and the precise limitations of the benchmark. The `provider_kind` string in a report is caller declared and must never by itself count as model-attestation evidence. User review and authorization remain separate.

### Local live CLI (explicit opt-in; does not execute workflows)

Install and start Ollama **outside** this review checkpoint, provision a model, and make the approved CR03 agent source importable on `PYTHONPATH`. Then run from the dual-flow worktree:

```sh
PYTHONPATH=/path/to/approved/agent/source:$PYTHONPATH \
python3 tools/evaluate_dualflow_model.py \
  --design docs/dualflow/examples/evidence_review.json \
  --task-file docs/dualflow/examples/evidence_review.model_task.txt \
  --model YOUR_LOCAL_MODEL_NAME \
  --reference-patch docs/dualflow/examples/evidence_review.patch.json \
  --regression docs/dualflow/examples/evidence_review.regression.json \
  --application docs/dualflow/examples/evidence_review.application.json \
  --repeats 3
```

The `--repeats` option requires all three predeclared benchmark files and does not imply model evaluation was conducted here. The sample task is a controlled prompt designed to test known-reference revision reproduction, **not** an independently representative distribution of agent tasks.

## Scoped remaining work for HWI-I02 completion

- Perform genuine, non-fixture local Ollama trials through the unchanged provider on the target environment, retaining raw inputs, outputs and version identifiers.
- Independently assess a representative set of success, failure and uncertain cases against human-reviewed expectations; compare with a simple Markdown-guided baseline.
- Review whether measured benefit and error handling justify the complexity; document a release/stop decision and human acceptance of the exact candidate before a commit.
- Keep WL-03, WL-04, WL-05 and WL-06 unaccepted and uncommitted until their separately reviewed owner decisions. HWI-I01 has owner acceptance recorded in the handoff, but is not committed because of unresolved dependencies.

## Security non-goals

No protected wiki/PVS mutation; no tool dispatch or code execution; no independent source truth/custody checks; no model-driven workflow discovery; no automatic workflow acceptance; no networking except a **user-invoked**, fixed-loopback Ollama call; no remote push or Git commit.

## Follow-up local model harness

The bounded runner `tools/run_dualflow_local.py`, the revised prompt contract, and HTTP protocol tests supersede the earlier CLI-only handoff for Ollama experiments. See `HWI_I02_OLLAMA_READY_REVIEW.md`. The original I02 fixture tests remain part of the regression suite, and real-model effectiveness is still unverified.
