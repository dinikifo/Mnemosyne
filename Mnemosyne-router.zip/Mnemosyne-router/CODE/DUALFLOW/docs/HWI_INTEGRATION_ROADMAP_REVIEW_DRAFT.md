# HWI — Human–Wiki–Agent Integration

**Status:** PROPOSED — REVIEW REQUIRED; NOT APPROVED FOR IMPLEMENTATION OR COMMIT  
**Version:** Proposal v0.1 · 2026-11-09  
**Inputs reviewed:** AutoGPT Lite/PVS M8 recovery-inspection source checkpoint (`989ae0f`), PERSONAL.WIKI T06 CC0 upload, M8 field-trial kit (declared later source commit `12f068d6` not included in that kit).  
**Purpose:** Incrementally consolidate interfaces and verified capabilities while preserving independently controlled evidence, memory and execution boundaries.

## 1. Vision and success criteria

An enduring human–agent workspace in which replaceable LLMs consult and revise a versioned PERSONAL.WIKI, deterministic checks verify explicit facts and constraints, PVS governs the promotion of selected revisions into authoritative memory, and SEC-02 independently governs consequential execution. The user retains authority over goals, significant notebook changes, and actions requiring authorization. No auto-accept or indefinite execution is introduced.

The integration must demonstrate measurable improvement against the current file-based baseline, especially in decision continuity, contradictory-evidence handling, procedural reuse, and cross-model handoff. It should not rely on the premise that SQLite or symbolic inference automatically increases reasoning capability.

### Non-negotiable invariants

1. Source journal is historical evidence; not editable by normal agent notebook operations.
2. PERSONAL.WIKI holds revisable interpretations, decisions and procedures; revision history and explicit reasons are preserved.
3. Model-authored inference is not evidence of an independent human instruction, review, or authorization.
4. Provisional notebook content is treated as untrusted data (including prompt-injection resistance), never elevated into policy or tool authority by retrieval.
5. PVS-governed memory is the only source of governed prompt memory in the protected execution profile, unless a separately reviewed policy explicitly changes that rule.
6. SEC-02 continues to forbid implicit auto-accept and unreviewed prompt providers/components; the agent cannot approve its own consequential actions.
7. Signed approval must bind exact content/revision, reviewer scope, credential validity, and applicable external pins. A valid hash/signature is not proof of factual truth or real human identity.
8. The system detects and reports uncertain cross-store outcomes, without automatic re-issue of operations whose completion is unknown.
9. User data remains portable, independently readable, recoverable, and accessible if the model is replaced or retired.
10. Fix defects without deleting the evidence of their occurrence; create a regression test before promoting the correction.

## 2. Ownership map and consolidation strategy

| Component | Retains ownership of | Planned integration |
|---|---|---|
| AutoGPT Lite | Agent lifecycle, current task, episodic journal, model/provider abstraction | New knowledge-broker interface and experimental harness; runtime changes delayed |
| PERSONAL.WIKI | SQLite content/history pair, field contracts, wiki revisions, human-readable project notes | Reusable Qt-free core; optional agent-facing adapter; no direct model SQL |
| PVS memory research | Evidence pins, reviewer decisions, credential registry, governed promotion, authorized selection | Exact-revision export/promotion pathway, using existing governance rather than cloning it |
| SEC-02 | Supervised execution, operator decision gates, approved runtime components | No changes until explicit security review of protected prompt integration |
| New HWI bridge | Type contracts, stable ID projection, proposals, read-side orchestration, receipts | Small package developed beside existing repos; no wholesale copy-paste consolidation |

**Code-consolidation policy:** first stabilize interface contracts and package imports, then consolidate duplicate *interfaces* and shared tests, then selectively consolidate workflow implementation when ownership and evidence semantics agree. Do not merge the agent journal, wiki history and PVS store into one database. Preserve independent original repos and portable snapshots until behavioral evidence justifies any physical repo consolidation.

**Known integration constraints:** `WikiCore` lives in `app/wiki_core.py`, depends on flat sibling imports and owns SQLite connections (do not share instances across threads). Read APIs include `search`, `get_tiddler`, `post_history`, `verify_history`; write APIs include `save_tiddler`, `update_tiddler`, `write_batch`. Existing wiki content relationships often use mutable titles while historical posts have stable IDs; a stable identifier projection is needed. Full-text search does not automatically index every structured reasoning field. AutoGPT Lite protects its SEC-02 kernel with an exact allowed-component list. Its `AgentStore` currently accepts traversal-style `agent_id` strings: fix before writable integration.

## 3. Milestone ledger

**Initial ledger:** `0 / 14 complete = 0%` (all proposed, no implementation approved). Exactly one milestone counts as complete when its acceptance evidence and user review are accepted. The planning proposal itself is **not** counted as an implemented milestone.

### Phase A — Foundations and code consolidation (0/3 = 0%)

| ID | Checkpoint | Deliverable | Acceptance evidence / mandatory gate |
|---|---|---|---|
| HWI-01 | Baseline freeze and authority contract | Exact source hashes, test ledger, dependency/license inventory; ratified `KnowledgeRecord`, `EvidenceRef`, `Intent`, `Decision`, `Authorization`, `Proposal`, `Procedure`, `Receipt` contracts and threat model | Both originals reproduce focused tests; source provenance reconciled; contract examples cover inferred intent, invalid authority, revocation, contradictions and injection |
| HWI-02 | Consolidate importable wiki core | Packaging/adapter boundary so Qt-free `WikiCore` can be imported as a normal dependency while GUI and original wiki still work | Clean install/import from outside wiki working directory; no GUI dependency; pre-existing wiki regressions pass |
| HWI-03 | Secure persistence and isolate workspaces | Fix `AgentStore` path traversal and unsafe deletes; sandbox notebook paths; isolated test databases and explicit backup/restore fixtures | Negative tests for traversal, symlinks, cross-root deletion, state-id mismatches, untrusted paths; SEC-02 and PVS tests remain unchanged |

### Phase B — Knowledge representation and read-only integration (0/3 = 0%)

| ID | Checkpoint | Deliverable | Acceptance evidence / mandatory gate |
|---|---|---|---|
| HWI-04 | Stable identity and provenance | Stable knowledge IDs mapped to wiki records/revisions, source-origin types, derivation edges and title-independent cross-references | Rename, delete/restore, split/merge proposal, stale revision, same-title collision and history lineage tests; no older notebook loss |
| HWI-05 | Read-only knowledge broker | `search`, `read`, `revision`, `trace`, `query_by_contract`, `get_context` adapter using `WikiCore` without raw SQL bypass | Read-only SQLite invocation; deterministic bounds; attribution and trust labels preserved; zero writes on retrieval |
| HWI-06 | Retrieval evaluation and sandbox model study | Frozen file-vs-wiki fixtures with comparable budgets; isolated answer-only model harness, outside SEC-02 protected pilot | Report recall, source tracing, stale recall, latency, token costs and injection outcomes; no model write access, direct governed-prompt path, or SEC-02 registration |

### Phase C — Living notebook, consent and recovery (0/4 = 0%)

| ID | Checkpoint | Deliverable | Acceptance evidence / mandatory gate |
|---|---|---|---|
| HWI-07 | Agent proposal ledger | Separately stored, attributable create/revise/link/retire proposals; human-visible diffs; model proposals cannot mutate wiki | Rejected, duplicated, malformed and stale proposals do not alter wiki or PVS; every proposal binds source refs and expected revision |
| HWI-08 | Reviewed wiki changes | Approval-gated commit operation with revision compare-and-swap, change reason, diff, author/origin fields and rollback-as-new-revision | Exact revision + explicit human approval required for protected changes; interrupted write and concurrent edit tests; no auto-accept |
| HWI-09 | Cross-store receipt/reconciliation | Durable prepare/commit/receipt states between proposal queue, wiki content+history, journal and PVS handoff; read-only inspector | Fault injection at every boundary; classify complete/incomplete/uncertain; never auto-repeat ambiguous side effects or infer approval from structural completeness |
| HWI-10 | Governed memory integration | Explicit path from an approved wiki revision to PVS evidence and signed review; protected prompt consumes *only* selector-verified results | Revoked/stale/missing approvals fail closed; old evidence epoch does not transfer approval; SEC-02 component allowlist changes require separate review; M8 status unchanged unless its own external gates pass |

### Phase D — Symbolic competence and empirical validation (0/4 = 0%)

| ID | Checkpoint | Deliverable | Acceptance evidence / mandatory gate |
|---|---|---|---|
| HWI-11 | Symbolic inference v1 | Limited typed rules for prerequisite, contradiction, dependency and temporal applicability; outputs `VERIFIED`, `VIOLATED`, `UNKNOWN` with evidence links | Conflicting and absent premises remain UNKNOWN where appropriate; no tool/action authority is derived from logical output |
| HWI-12 | Procedural and negative knowledge | Versioned procedures with preconditions, steps, postconditions, failures, expiration/revisit triggers, validated reuse examples | New model can retrieve procedures; unsafe/inapplicable conditions halt rather than repeat; previous mistakes remain traceable |
| HWI-13 | Defect-to-regression/data pipeline | Capture observed defect → causal analysis → corrected rule/knowledge/code → test → optionally human-curated training example | Independent labels, provenance, privacy/licensing checks, de-duplication and strict training/evaluation split; rejected cases stay visible |
| HWI-14 | Longitudinal comparison and release decision | Model A→B swap, file vs wiki vs living wiki vs hybrid comparison; backup/recovery and human-factor checks; integration packaging decision | Evidence of actual behavior, no authority regressions, quantified cost; user approves whether to proceed to broader testing or production-oriented hardening |

### Progress calculation and reporting

- Per-phase progress = `accepted phase milestones / phase total × 100` (A and B have 3 each; C and D have 4 each).
- Overall HWI progress = `accepted HWI milestones / 14 × 100`.
- Report at every checkpoint: `ID`, `status` (`PROPOSED`, `IN_PROGRESS`, `SUBMITTED_FOR_REVIEW`, `CHANGES_REQUESTED`, `ACCEPTED`, `COMMITTED`), exact source hashes, changed files, test results, unverified claims, new and carried findings, and `completed/total/%`.
- **Counting rule:** `ACCEPTED` is the moment of milestone completion; `COMMITTED` records subsequent source-control publication. Never count a partly implemented or synthetically demonstrated behavior as empirically validated.
- Existing PVS milestone `7/8 = 87.5%` and SEC-02 `25/30 = 83.33%` remain independent ledgers.

## 4. Example integration contracts (conceptual, not implemented)

```python
@dataclass(frozen=True)
class KnowledgeRef:
    knowledge_id: str
    wiki_revision: str
    source_refs: tuple[str, ...]
    provenance_status: str  # sourced / inferred / disputed / unknown
    authority_status: str   # provisional / authorized / revoked

@dataclass(frozen=True)
class WikiProposal:
    proposal_id: str
    operation: str           # create / revise / link / retire
    target_id: str | None
    expected_revision: str | None
    reason: str
    evidence_refs: tuple[str, ...]
    proposed_payload: dict

class KnowledgeBroker(Protocol):
    def search(self, query: str, *, scope: str, limit: int): ...
    def read(self, knowledge_id: str, *, revision: str | None = None): ...
    def propose(self, proposal: WikiProposal): ...
    def validate(self, proposal_id: str): ...
    def commit_authorized(self, proposal_id: str, authorization_ref: str): ...
```

The contract is illustrative and must be reviewed in HWI-02. An authorization reference must bind the action's exact target and revision; possession of arbitrary text resembling an approval is not sufficient.

## 5. Code layout and consolidation waves

**Wave 1 — Read-only packaging (HWI-01–06):**

```text
integration/  (separate experimental package, not registered in SEC-02)
  hwi/
    contracts.py
    ids.py
    wiki_adapter.py
    provenance.py
  tests/
    test_contracts.py
    test_wiki_readonly.py
```

Keep `app/wiki_core.py` as the single wiki persistence facade. Normalize package imports upstream instead of copying history/database code into the agent. Keep `autogpt_lite/persistence` responsible for run state and episodic evidence.

**Wave 2 — Controlled writes (HWI-07–09):** Add `proposals.py`, `reviews.py`, `receipts.py`, `reconcile.py`; write through the facade with explicit revision checks, rollback-as-new-revision, and independent recovery. No direct PVS writes from the wiki package.

**Wave 3 — Approved memory (HWI-10):** Add `pvs_promotion.py` as a separate authorized workflow; the agent's existing governed-memory selector remains the policy-enforcing prompt boundary. Explicitly review any SEC-02 kernel changes. Preserve the exact M8 approval semantics.

**Wave 4 — Research features (HWI-11–14):** Add `rules.py`, `procedures.py`, `defects.py`, and evaluation tools only when benchmark evidence motivates them. Merge repositories only if it materially reduces maintenance without erasing separations of responsibility.

## 6. Review-before-commit protocol (mandatory for every milestone)

1. **Design proposal:** State rationale, interfaces, changed trust boundaries, alternatives and tests; do not commit.
2. **Implementation for inspection:** Produce an uncommitted patch in a disposable checkout; include changed-file inventory and exact diff. Never modify the original uploaded archives.
3. **Verification:** Run focused and adjacent tests; include execution output, environmental limitations, and a failing-before/fixed-after reproduction for defects.
4. **Safety review:** Verify no stealth auto-accept, authority escalation, lost history, silent schema migration, hidden model-to-tool calls, or unsupported claim of human review.
5. **Submission:** Deliver the patch, test results, open findings, and milestone progress as `SUBMITTED_FOR_REVIEW`. **Do not commit.**
6. **Human decision:** Wait for explicit acceptance or change requests. Approval should cover the exact patch/diff rather than a generic direction.
7. **Commit and checkpoint evidence:** Only after approval, commit the agreed files, retain exact Git and artifact hashes, and update the HWI ledger. If the patch changes after approval, submit the changed diff for review again.

**Review summary template**

```text
HWI-XX: <milestone>
Base revision(s): <hashes>
Changed files: <paths>
Behavioral changes: <what changed>
Authorization impact: NONE / EXPLICITLY REVIEWED
Tests executed: <commands, passed/failed/skipped>
Known limitations: <list>
Open defects: <list>
HWI progress: N/14 = PERCENT
Review state: SUBMITTED_FOR_REVIEW
Approval: PENDING
Commit: NOT CREATED
```

## 7. Decisions requested before the first code change

1. **Repository organization:** Prefer a thin `hwi` integration package while keeping AutoGPT Lite and PERSONAL.WIKI independently runnable. A monorepo or migration can be reconsidered after HWI-06.
2. **Initial authority policy:** Let agent-generated *proposals* be autonomous, but require explicit human approval before committing high-impact wiki revisions; provisional scratch writes may be allowed only in a segregated, bounded workspace.
3. **Acceptance rule:** Use the 14 milestone gates above; no completion credited for drafting alone; include metrics and open findings in every checkpoint.
4. **Current source baseline:** Validate the exact current GitHub revision for each project before HWI-01 acceptance, especially because the last lightweight field-trial kit references a later AutoGPT commit absent from the most recent supplied source archive.

## 8. Exclusions from this integration track

- Completion of PVS M8 external-human and genuine-model validation is **not** implied by HWI acceptance.
- No claim of legal liability allocation or human identity attestation can be established by notebook logs alone.
- No autonomous schema rewriting, unbounded browsing/tool execution, self-authorized policy changes, or automatic fine-tuning in the first HWI cycle.
- No replacement of the episodic journal, no blanket migration of project files into SQLite, and no assumption that wiki revision checks are equivalent to independently pinned PVS governance.

---

**Submission:** This is a design-review proposal. No user repository was edited, no Git commit was created, and no milestone was marked complete. Approval, rejection, or revisions are explicitly invited before implementation.
