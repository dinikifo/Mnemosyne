# RC-01 technical completion report — 2026-11-10

**Scope:** source-grounded R0 architecture and invariants only. No runtime behavior changes or owner acceptance.

## Deliverables (5/5 technical goals)

1. `RC01_INVENTORY.md` — component ownership and refactoring seams (agent, Qt, wiki, workspace, HWI, PVS, SEC-02, offline studies).
2. `RC01_DEPENDENCIES.md` — observed call/import map, proposed allowed/forbidden dependencies, explicit non-OS-security limitations.
3. `RC01_AUTHORITY.md` — actors, signatures, writes and executable-dispatch authority matrix.
4. `RC01_CONTRACTS_RECOVERY.md` — signed bytes, versioned contracts, C14-R1 snapshot invariants, uncertainty/restart classifications.
5. `RC01_BASELINE.md` — exact 693-file frozen source lock, 93 independently rerun focused checks, and original packaging setup failure.

## Verified

- Source/static anchors: `verify_rc01_inventory.py` matched **693/693** file hashes and **25/25** AST anchors; source lock contains five required documents.
- Behavioral focused checks: **30** C13/C14 `unittest` and **63** agent/SEC-02 `pytest` passed. See logs in `refactor/rc01_test_logs/`.
- Checkpoint verifier negative controls: **10/10** passed, including path traversal, modified source hash, missing anchor and skipped dependency cases.
- Existing HWI ledger and evidence index checks passed. Historical carry-forward ledgers remain explicitly unverified.
- All 693 runtime/reference/offline files are unchanged from the prior C14-R2 RC-00 archive.

## Two design observations to carry forward

- **Terminal coupling:** `AgentRuntime._display()` and `_authorize()` use terminal I/O directly; `UserInteractionComponent._ask_user()` also uses `input()`. RC-03 will address these interfaces while preserving refusal behavior.
- **Answer-only distinction:** `sec02.answer_only` is already implemented as a constrained, non-executable recorded event in the SEC-02 pilot. This refines the older review statement that there was no answer-only path. There is still no independently demonstrated useful genuine-model session.

## Acceptance boundaries

This is an independently reproducible **technical map**, not owner sign-off, PVS key custody, cross-process isolation, or a genuine-model evaluation. RC-00/RC-01 owner acceptance remains pending. HWI integration remains **0/14 accepted**; SEC-02 dispatch is closed. The next checkpoint is **RC-02: typed evidence/data contracts**, with exact signed-byte compatibility.
