# RC-04 — Application and workflow boundaries: technical review

**Status: 5/5 goals technically complete; owner acceptance PENDING.**

## Implemented

1. Typed command/query handling through `ApplicationBoundary` with read-only status and pending-proposal queries and a `RunSupervisedCycle` delegate; unknown requests rejected.
2. Immutable, detached presentation snapshots; no signed record or credential passed as a view.
3. Pure transition rules on existing `pending_phase`, preserving stored strings, authorized-uncertain crash semantics and normal record clearing.
4. Explicit startup failure for cyclic, missing or duplicate component registrations before component attachment. Valid topological ordering preserved.
5. Negative/compatibility test matrix across SEC-02, agent crash recovery, HWI C4/C5 lineage and PVS startup.

## Verification evidence

- `rc04_test_logs/application_security.log`: 222 passed, 0 skipped.
- `rc04_test_logs/recovery_security.log`: 166 passed, 9 subtests passed, 0 skipped.
- `rc04_test_logs/pvs_c4_c13_c14.log`: 47 passed, 15 subtests passed, 0 skipped.
- `rc04_test_logs/pvs_c5.log`: 33 passed, 7 subtests passed, 0 skipped.
- `rc04_test_logs/pvs_c6_c7.log`: 13 passed, 10 subtests passed, 0 skipped.

**481 distinct tests passed, 41 additional subtests passed** across these disjoint file selections. Separately, the checkpoint-tool suite passed **19 tests and 11 subtests**, including a reconstructed RC-01 to RC-04 source lineage check for 699 current source files and 25 frozen code anchors. The previous combined PVS run exceeded the execution limit; it was not credited. The complete optional-dependency suite was not rerun. A newly rebuilt agent wheel was checked byte-for-byte against the four RC-04 runtime modules. The first checkpoint-tool run identified obsolete RC-01-only expectations; those failures were retained and the tests changed to verify the immutable RC-01 lock through the documented RC-02/03/04 patch lineage, not by rewriting that lock.

The scope is deliberately limited to 5 files (two modified, three new). PVS source, signed C4/C5 and C14 paths, SEC-02 dispatch and governing policy remain identical to RC-03. Invalid dependency graphs now fail explicitly rather than only warning: this is the intended fail-closed difference.

## Constraints and next gate

No external reviewer/key-custody or model trial was conducted. In-process module boundaries are **not security isolation**. The Git review commit is not HWI milestone acceptance. Next: RC-05 clean rebuild, before/after comparison and the diminishing-returns stop/go gate, then separate human acceptance decisions.
