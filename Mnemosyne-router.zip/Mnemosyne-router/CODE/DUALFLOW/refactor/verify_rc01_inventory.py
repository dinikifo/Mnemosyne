#!/usr/bin/env python3
"""RC-01 frozen source inventory check (documentation baseline, not approval)."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
AREAS = ('wiki', 'agent', 'reference', 'offline_testing')
EXCLUDES = {'__pycache__', '.pytest_cache', '.git'}


def actual_files(root: Path) -> set[str]:
    return {p.relative_to(root).as_posix() for area in AREAS
            for p in (root/area).rglob('*') if p.is_file()
            and not EXCLUDES.intersection(p.relative_to(root).parts)}


def check(lock: dict, root: Path):
    failures = []
    declared = lock.get('files', {})
    if lock.get('schema') != 'hwi.refactor.rc01-source-lock.v1':
        failures.append('UNKNOWN_SCHEMA')
    if lock.get('baseline_zip_sha256') != 'c1920eac230445d11cff9a00932a794b1d75ad125721bcaa0ec38219e6f2d9fc':
        failures.append('BASELINE_ID_MISMATCH')
    observed = actual_files(root)
    if set(declared) != observed:
        failures.append(f'FILE_SET_CHANGED missing={len(set(declared)-observed)} added={len(observed-set(declared))}')
    for name, expected in declared.items():
        if (not isinstance(name, str) or not name.startswith(tuple(a+'/' for a in AREAS))
                or '..' in Path(name).parts or Path(name).is_absolute()):
            failures.append(f'INVALID_PATH {name}'); continue
        path = root/name
        if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            failures.append(f'SOURCE_CHANGED {name}')
    for item in lock.get('anchors', []):
        rel, symbol = item['path'], item['symbol']
        path = root/rel
        if not path.is_file():
            failures.append(f'ANCHOR_FILE_MISSING {rel}'); continue
        try:
            tree = ast.parse(path.read_text(encoding='utf-8'))
            top = {n.name for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))}
            if symbol not in top:
                failures.append(f'ANCHOR_MISSING {rel}:{symbol}')
        except (SyntaxError, UnicodeError) as exc:
            failures.append(f'ANCHOR_UNREADABLE {rel}: {exc}')
    for rel in lock.get('required_documents', []):
        if not (root/rel).is_file(): failures.append(f'DOCUMENT_MISSING {rel}')
    return failures, {'files':len(declared), 'anchors':len(lock.get('anchors', [])),
                      'documents':len(lock.get('required_documents', []))}


if __name__ == '__main__':
    lock=json.loads((ROOT/'refactor/RC01_SOURCE_LOCK.json').read_text())
    errors, stats=check(lock, ROOT)
    if errors:
        print('RC01_SOURCE_INVENTORY_FAILED', '\n'.join(errors[:20]), sep='\n')
        sys.exit(1)
    print('RC01_SOURCE_INVENTORY_VALID',json.dumps(stats,sort_keys=True))
