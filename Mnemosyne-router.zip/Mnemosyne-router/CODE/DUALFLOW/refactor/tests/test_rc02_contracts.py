"""RC-02 deterministic contract gates; no PVS writes or real signer keys."""
import copy
import hashlib
import json
from pathlib import Path
import unittest

from hwi.pvs_admission import admission_operator_message, AdmissionError
from hwi.pvs_contracts import (AdmissionPlanIdentity, AdmissionReceiptIdentity,
    PvsSourceBinding, ContractError, inspect_admission_plan,
    inspect_admission_receipt, canonical_snapshot)
from hwi.pvs_review_gate import PvsReviewGateError, _check_admission

FIXTURE = json.loads((Path(__file__).resolve().parents[1] / 'RC02_GOLDEN_VECTOR.json').read_text())


class RC02ContractTests(unittest.TestCase):
    def setUp(self):
        self.plan=copy.deepcopy(FIXTURE['plan'])
        self.receipt=copy.deepcopy(FIXTURE['receipt'])

    def test_original_signed_bytes_unchanged(self):
        msg=admission_operator_message(self.plan,expected_plan_sha256=self.plan['plan_sha256'])
        self.assertEqual(msg.hex(),FIXTURE['expected_plan_message_hex'])
        self.assertEqual(hashlib.sha256(msg).hexdigest(),FIXTURE['expected_plan_message_sha256'])
        self.assertEqual(msg,inspect_admission_plan(self.plan,self.plan['plan_sha256']).signing_message)

    def test_internal_views_are_immutable_and_do_not_claim_authority(self):
        p=inspect_admission_plan(self.plan,self.plan['plan_sha256'])
        r=inspect_admission_receipt(self.receipt,self.receipt['receipt_sha256'])
        self.assertIsInstance(p,AdmissionPlanIdentity)
        self.assertIsInstance(r,AdmissionReceiptIdentity)
        with self.assertRaises((AttributeError, TypeError)):
            p.draft_sha256='0'*64
        with self.assertRaises((AttributeError, TypeError)):
            r.proposal_count=5
        self.assertFalse(self.plan['write_authorized'])
        self.assertFalse(self.receipt['pvs_approved'])

    def test_original_receipt_digest_and_fields_unchanged(self):
        r=inspect_admission_receipt(self.receipt,self.receipt['receipt_sha256'])
        self.assertEqual(r.receipt_sha256,self.receipt['receipt_sha256'])
        self.assertEqual(r.plan_sha256,self.plan['plan_sha256'])
        self.assertEqual(r.draft_sha256,self.plan['draft_sha256'])

    def test_plan_wrong_digest_schema_authority_and_count_rejected(self):
        cases=[{'schema':'hwi.pvs.admission.plan.v2'},
               {'write_authorized':True},{'plan_sha256':'0'*64},
               {'pvs_proposal_count_before':True},{'unexpected':'field'},
               {'witness_sha256':'A'*64}]
        for change in cases:
            with self.subTest(change=change):
                plan=dict(self.plan,**change)
                with self.assertRaises(AdmissionError):
                    admission_operator_message(plan,expected_plan_sha256=self.plan['plan_sha256'])

    def test_plan_subclass_and_nonprimitive_sha_denied(self):
        class FakeDict(dict): pass
        class FakeStr(str): pass
        with self.assertRaises(ContractError):
            inspect_admission_plan(FakeDict(self.plan),self.plan['plan_sha256'])
        with self.assertRaises(AdmissionError):
            admission_operator_message(self.plan,expected_plan_sha256=FakeStr(self.plan['plan_sha256']))

    def test_receipt_wrong_digest_schema_authority_and_extra_field_denied(self):
        for change in ({'schema':'hwi.pvs.admission.receipt.v1'},
                       {'execution_authorized':True},
                       {'receipt_sha256':'0'*64},
                       {'external_custody_established':True},
                       {'unexpected':'field'}):
            with self.subTest(change=change):
                receipt=dict(self.receipt,**change)
                with self.assertRaises(ContractError):
                    inspect_admission_receipt(receipt,self.receipt['receipt_sha256'])

    def test_digest_is_not_signature_or_authority(self):
        # A forged *internally consistent* receipt passes this checksum-only
        # layer. C5 must still check the independent signing key, source and PVS.
        receipt=dict(self.receipt,pvs_proposal_count=99)
        from hwi.proposals import _canon
        body={k:v for k,v in receipt.items() if k != 'receipt_sha256'}
        receipt['receipt_sha256']=hashlib.sha256(_canon(body).encode()).hexdigest()
        view=inspect_admission_receipt(receipt,receipt['receipt_sha256'])
        self.assertEqual(view.proposal_count,99)
        # Full gate has additional requirements and rejects this incomplete input.
        with self.assertRaises(PvsReviewGateError):
            _check_admission(receipt=receipt,expected_receipt_sha256=receipt['receipt_sha256'],
                plan=self.plan,operator_public_key=b'0'*32,
                expected_operator_key_sha256='3'*64,draft={},source_kwargs={},
                packet={},pvs_context={},externally_pinned_origins={})

    def test_pvs_instance_checks_do_not_use_equality(self):
        class EqualObjects:
            def __eq__(self,other):return True
        workspace,journal=EqualObjects(),EqualObjects()
        context=dict(workspace=workspace,journal=journal,actor='x',versioner_id='v',
            source_target_id='s',source_project_id='p',proposal_target_id='q',
            proposal_project_id='qp',expected_source_head='head',expected_versioner_pin={},
            expected_source_target_pin={},expected_proposal_target_pin={})
        source=dict(pvs_workspace=workspace,journal=journal,source_actor='x',
            source_versioner_id='v',source_target_id='s',source_project_id='p',
            expected_source_head='head',expected_source_versioner_pin={},
            expected_source_target_pin={})
        binding=PvsSourceBinding.from_context(context)
        self.assertTrue(binding.matches_source(source))
        self.assertFalse(binding.matches_source(dict(source,pvs_workspace=EqualObjects())))
        self.assertFalse(binding.matches_source(dict(source,journal=EqualObjects())))

    def test_canonical_snapshot_breaks_json_aliases(self):
        source={'nested':[{'v':1}]}
        frozen=canonical_snapshot(source)
        source['nested'][0]['v']=2
        self.assertEqual(frozen['nested'][0]['v'],1)
        with self.assertRaises((TypeError, ValueError)):
            canonical_snapshot({'not-json':object()})


if __name__=='__main__':unittest.main()
