"""RC-01 inventory negative controls; does not import or execute application code."""
import copy
import importlib.util
import json
import sys
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('rc01_inventory', ROOT/'refactor/verify_rc01_inventory.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
sys.path.insert(0, str(ROOT/'refactor'))
from verify_source_lineage import check as check_lineage

class RC01SourceLockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.lock=json.loads((ROOT/'refactor/RC01_SOURCE_LOCK.json').read_text())
        cls.diffs=[json.loads((ROOT/f'refactor/RC0{i}_SOURCE_DIFF.json').read_text()) for i in (2,3,4)]

    def test_frozen_baseline(self):
        issues, meta=check_lineage(ROOT, self.lock, self.diffs)
        self.assertEqual(issues, [])
        self.assertEqual(meta['files'],699)
        self.assertGreaterEqual(meta['anchors'],15)

    def test_modified_hash_fails(self):
        data=copy.deepcopy(self.lock)
        example=next(iter(data['files']))
        data['files'][example]='0'*64
        self.assertTrue(any('SOURCE_CHANGED' in x for x in check_lineage(ROOT,data,self.diffs)[0]))

    def test_missing_anchor_fails(self):
        data=copy.deepcopy(self.lock)
        data['anchors'][0]['symbol']='DefinitelyNoSuchFunctionRC01'
        self.assertTrue(any('ANCHOR_MISSING' in x for x in check_lineage(ROOT,data,self.diffs)[0]))

    def test_path_traversal_fails(self):
        data=copy.deepcopy(self.lock)
        data['files']['wiki/../unauthorized']='0'*64
        self.assertTrue(any('INVALID_PATH' in x for x in check_lineage(ROOT,data,self.diffs)[0]))

    def test_missing_doc_fails(self):
        data=copy.deepcopy(self.lock)
        data['required_documents'].append('refactor/NEVER_EXISTS.md')
        self.assertTrue(any('DOCUMENT_MISSING' in x for x in check_lineage(ROOT,data,self.diffs)[0]))

if __name__=='__main__':unittest.main()
