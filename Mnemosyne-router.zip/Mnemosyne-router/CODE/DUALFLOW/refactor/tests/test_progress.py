import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('verify_refactor_checkpoints',ROOT/'tools/verify_refactor_checkpoints.py')
checker=importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)

class ProgressTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=json.loads((ROOT/'refactor/GOALS.json').read_text())

    def test_baseline_valid(self):
        errors,out=checker.validate(self.data,ROOT)
        self.assertEqual(errors, [])
        self.assertEqual((out['complete'],out['total']), (sum(g['status']=='complete' for cp in self.data['checkpoints'] for g in cp['goals']),27))
        self.assertEqual((out['implementation_complete'],out['implementation_total']), (out['complete']-3,24))

    def test_cannot_complete_without_evidence(self):
        data=copy.deepcopy(self.data)
        g=data['checkpoints'][1]['goals'][0]
        g['status']='complete'
        g['evidence']=[]
        self.assertTrue(checker.validate(data,ROOT)[0])

    def test_cannot_skip_dependency(self):
        data=copy.deepcopy(self.data)
        g=data['checkpoints'][2]['goals'][0]
        g['status']='pending'
        g['evidence']=[]
        self.assertTrue(any('prior checkpoint' in e for e in checker.validate(data,ROOT)[0]))

    def test_rejects_traversal_evidence(self):
        data=copy.deepcopy(self.data)
        data['checkpoints'][0]['goals'][0]['evidence']=['../outside']
        self.assertTrue(checker.validate(data,ROOT)[0])

    def test_rejects_changed_denominator(self):
        data=copy.deepcopy(self.data)
        data['checkpoints'][-1]['goals'].append({'id':'RC-05.extra','title':'extra','status':'pending','evidence':[]})
        self.assertTrue(checker.validate(data,ROOT)[0])

if __name__=='__main__':unittest.main()
