# RC-04 — Reproduction instructions

Use the extracted RC-04 archive and Python 3.11+ with installed pytest, cryptography and the optional dependencies required by previous checkpoints. Do not count skipped tests as passes.

```sh
ROOT=/path/to/HWI_C14_R2_REFACTOR_RC04_CONSOLIDATED
export PYTHONPATH="$ROOT/agent:$ROOT/wiki:$ROOT/reference/pvs01_src:$ROOT/offline_testing:/path/to/installed-personal_wiki_core"
export PVS01_SOURCE_ROOT="$ROOT/reference/pvs01_src"
python -m pytest -q "$ROOT/agent/tests/test_rc04_application_workflow.py" "$ROOT/agent/tests/test_rc03_interaction_port.py" "$ROOT/agent/tests/test_sec02_supervised_mode.py" "$ROOT/agent/tests/test_sec02_r4_closed_pilot.py" "$ROOT/agent/tests/test_sec02_r5_bypass_resistance.py" "$ROOT/agent/tests/test_sec02_r8_answer_only.py" "$ROOT/agent/tests/test_hwi_c6_runtime_guard.py" "$ROOT/agent/tests/test_hwi03_agent_store_boundary.py"
python -m pytest -q "$ROOT/agent/tests/test_am03_crash_recovery.py" "$ROOT/agent/tests/test_sec02_r4_recovery_lab.py" "$ROOT/agent/tests/test_sec02_r6_outcome.py" "$ROOT/agent/tests/test_sec02_r7_consolidation.py" "$ROOT/agent/tests/test_sec02_r8_independent.py" "$ROOT/agent/tests/test_im07_coverage_and_agent_runtime.py"
python -m pytest -q "$ROOT/wiki/tests/test_hwi_c4_pvs_admission.py" "$ROOT/wiki/tests/test_hwi_c13_provenance_gate.py" "$ROOT/wiki/tests/test_hwi_c14_lineage_custody.py"
python -m pytest -q "$ROOT/wiki/tests/test_hwi_c5_independent_pvs_review.py"
python -m pytest -q "$ROOT/wiki/tests/test_hwi_c6_real_pvs_runtime.py" "$ROOT/wiki/tests/test_hwi_c7_operator_startup.py"
python -m pytest -q "$ROOT/refactor/tests"
python "$ROOT/refactor/verify_source_lineage.py"
python "$ROOT/tools/verify_refactor_checkpoints.py" --markdown
python "$ROOT/tools/verify_ledgers.py"
python "$ROOT/tools/verify_manifest.py"
```

The earlier combined PVS batch hit the execution limit and is retained in `refactor/rc04_test_logs/pvs_compatibility.log`. Completed split tests are recorded separately. The source patch `refactor/RC04_CANDIDATE.patch` applies to **RC-03 only**, with `patch -p1` from the extracted root. Check every changed source SHA-256 in `RC04_SOURCE_DIFF.json`; patch application is not an authorization grant.
