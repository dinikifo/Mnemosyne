# RC-02.3–RC-02.5 — Pure validation and compatibility evidence

## Deterministic baseline vector

`RC02_GOLDEN_VECTOR.json` was generated using **unchanged RC-01 C4 code**. It contains an exact synthetic plan dictionary, its original canonical operator-message bytes (hex), message digest, and a synthetic receipt body/digest. Its all-zero dummy signatures are NOT valid signatures and cannot establish authority; this fixture tests the *shape and byte serialization* only.

- Plan digest: `ab484fe63acd1443735fa32b9d36408ba206768c0f4b4a493781143016a0cc3a`
- Signed-message digest: `cc2346d1a022586773f9df7965f37ab0b3c64516e6897e2a6b0549e9b52b4d69`
- Synthetic receipt digest: `2bfab34e6f41f8fe3c4e5598cf2b8a63b54eda1f4beb4b5fbfd7fc8b84201764`

The RC-02 code generates precisely the same signed-message **bytes** and validates the same receipt body digest. `canonical_snapshot` uses the original JSON canonicalization and unmarshal; it does not change the written candidate. The valid-signature tests in C4/C5/C13/C14 cover the true cryptographic path.

## Executed tests

| Test group | Result | Evidence |
|---|---|---|
| C4 admission | 17/17 | `refactor/rc02_test_logs/c4_final.log` |
| C5 review | 33/33 (includes 17 imported C4 tests) | `refactor/rc02_test_logs/c5_final.log` |
| C13/C14 lineage and receipt custody | 30/30 | `refactor/rc02_test_logs/c13_c14_final.log` |
| New RC-02 golden-vector, schema, negative and identity checks | 9/9 | `refactor/rc02_test_logs/contract_focused_final.log` |
| Agent/SEC-02 unchanged-boundary tests | 63/63 | `refactor/rc02_test_logs/agent_boundary.log` |
| **Distinct focused tests** | **135**, with overlap subtracted | Five successful groups above |

The first combined attempt did not finish within the tool's execution window (`/mnt/data/rc02_compat_initial.log`; outside bundle). An intermediate C5/C13-C14 run failed due to an accidental variable replacement (`admission_admission_receipt`); logs retained in `c5.log` and `c13_c14.log`. The typo was corrected; final runs passed. No failure is recast as a pass.

`refactor/RC02_CANDIDATE.patch` replays exactly against RC-01 for all three affected HWI module files. `RC02_SOURCE_DIFF.json` records base/result SHA-256 for both modifications and the new helper. A **fresh wheel** was built from a clean copy of the refactored source, installed to an isolated directory, and its three HWI module members matched the source byte-for-byte. This does not imply that all optional PVS/NLTK/Qt extras have been exercised in a clean environment.

## Boundary limitations

The tests use synthetic keys, not independently witnessed human reviewers; external custody is still not demonstrated. The C14-R2 runtime and RC-02 changes are review candidates. No real-model trial, OS-user separation, HWI acceptance, production approval, SEC-02 tool authorization, or cross-store atomic transaction is claimed. RC-03 may address UI coupling but must not convert any of these software-only checks into supposed isolation.
