# RC-02.1 and RC-02.2 — C4/C5 contract map and typed internal evidence

**Scope:** Refactor the *internal representation* at the C4 admission / C5 read-only review boundary. This is NOT a new signing protocol, new PVS gate, change of reviewer enrollment, or source of authority. The C14-R2 source remains an unaccepted implementation candidate.

## Operations and boundaries

| Entry point | Inputs (existing public interface) | Existing result | Side effects / authority | New internal view |
|---|---|---|---|---|
| `prepare_admission_plan` (C4) | Witnessed source kwargs, expected witness/packet SHA, semantic packet+decision+signature+key, exact PVS context, draft | `hwi.pvs.admission.plan.v1` dict, `VERIFIED_PREFLIGHT_NOT_AUTHORIZED` | Read-only; NOT a write authorization | `PvsSourceBinding` compares exact Python workspace and journal identity against source refs |
| `admission_operator_message` (C4) | Exact plan dict + separately supplied plan hash | Domain-separated canonical bytes | None; a message to sign, not a signature | `AdmissionPlanIdentity` and pure `inspect_admission_plan` enforce keys, typed hash/count and false authority flags |
| `submit_signed_unreviewed_admission` (C4) | Operator signed plan, C13 lineage and origins, PVS draft/context, source witness/semantic review | `hwi.pvs.admission.receipt.v2` dict, storage-only | Calls original PVS proposal writer only after verification; uncertain commit requires manual reconciliation | `canonical_snapshot` deep-detaches the same six JSON document inputs before validation and PVS write |
| `_check_admission` (C5) | Independent receipt pin, plan, operator key, candidate, source and current PVS context, origin pins | Verified state used by read-only review/selection | No PVS write and no grant of execution authority | `AdmissionReceiptIdentity` checks exact receipt shape, canonical digest and false authority flags; original cryptographic verification and store reads remain in C5 |
| `prepare_independent_pvs_review` (C5) | Verified C4 + current PVS review context and separate reviewer key | `hwi.pvs.review.handoff.v1` dict with `AWAITING_INDEPENDENT_PVS_REVIEW` | Read-only PVS M4 request preparation | Existing API; no changes to output |
| `inspect_independent_pvs_selection` (C5) | Verified C4 + independently provisioned credential-enforced selector and current PVS review evidence | `hwi.pvs.review.selection.v1` dict | Read-only; selects only under original PVS/M8 checks, never authorizes tools | Existing API; no changes to output |

## New internal components

`wiki/hwi/pvs_contracts.py` adds frozen slotted views `AdmissionPlanIdentity`, `AdmissionReceiptIdentity` and `PvsSourceBinding`, plus deterministic helpers `inspect_admission_plan`, `inspect_admission_receipt` and `canonical_snapshot`. It centralizes the exact plan/receipt/PVS context key sets. Views contain verified *fields*, not the signed documents themselves. No one signs or serializes a dataclass instance, and the C4/C5 public functions still accept and return original dictionaries.

`PvsSourceBinding` holds original workspace/journal object references. Its `matches_source` method checks them with `is`, not `==`. It does not establish process separation or tamper resistance; the objects remain in the same trust domain.

## Unchanged external formats

- C4 plan schema and exact `_canon` encoding (`sort_keys=True`, compact separators, ASCII encoding, no NaN).
- Signed C4 operator message `HWI-C4-STORE-UNREVIEWED-PVS-DRAFT-V1\n` plus canonical original plan.
- C13 operator lineage signature and pinned origin map.
- C14-R1 receipt v2 keys, canonical digest and frozen signed input snapshots.
- C5 independent reviewer cryptography, pinned PVS store checks, credential revocation, source/project identity, current revision, denial and uncertainty semantics.

A checksum-valid synthetic receipt is **not** approved evidence: C5 still verifies the operator signature and independently supplied keys and reads the actual PVS state. No original PVS-01 backend, journal, SEC-02 dispatcher or Qt source was modified.
