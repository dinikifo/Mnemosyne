# Reproduce approved CR-01 Batch A-R6 patch

1. Verify the original frozen source archive SHA-256: `bddd6b8981c7c8aca2af102c202374eec4e8dd11d7ef1b6f4d71ed8827ecae42`; validate its 987-file internal manifest.
2. Extract the archive to an empty directory.
3. In that directory, run `git apply --check /path/to/refactor/CR01_BATCH_A_APPROVED.patch` and then `git apply /path/to/refactor/CR01_BATCH_A_APPROVED.patch`.
4. Compare the three modified files and seven new tests to `refactor/CR01_R6_REVIEW_SOURCE_DELTA.json` using the `r6_sha256` values. Only those 10 paths may differ from the frozen archive.
5. Run `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=agent:wiki:reference/pvs01_src python -m pytest -q -p no:cacheprovider agent/tests/test_refactor_batch_a_r6_review_boundaries.py agent/tests/test_refactor_batch_a_r5_journal_preflight.py agent/tests/test_am03_crash_recovery.py` (56 tests independently passed). Follow with agent store and RC04/BATCH-A regressions.
6. Preserve historical lineage artifacts as immutable evidence. The original RC01–RC04 verifier is expected to reject the intentional post-RC04 changes; use the recorded per-file source delta and newly signed acceptance instead of modifying old locks.

These locally available tests do not substitute for the clean environment with exact pinned dependency wheels. No real model, independent OS custody or external execution is implied.
