# RC-00: immutable input baseline

- Source: `HWI_C14_R2_CONSOLIDATED_CODEBASE_UNCOMMITTED.zip`
- SHA-256: `c1920eac230445d11cff9a00932a794b1d75ad125721bcaa0ec38219e6f2d9fc`
- Status: consolidated **unaccepted** implementation candidate.
- No PVS authority, SEC-02 tool execution, real-model run or HWI acceptance is implied.
- Original C0 Git history is carried in `governance/C0_ACCEPTED_PLANNING_HISTORY.bundle`.
- New refactor planning commits are carried in `governance/REFACTOR_CP00_PLANNING_HISTORY.bundle` (Git, not implementation acceptance).
- Refactor checkpoint progress is **independent of** the HWI-01..14, PVS memory, SEC-02, and IF00 ledgers.

This checksum identifies the historical input ZIP, not the new output ZIP, and must never be overwritten in place.
