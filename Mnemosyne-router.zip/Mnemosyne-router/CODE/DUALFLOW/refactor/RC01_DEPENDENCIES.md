# RC-01.2 — Dependency directions and boundaries

**Legend:** `observed` means traceable to imports/calls in the current source. `target` is a proposed refactoring rule, not an existing enforcement mechanism. This is a logical module map; **no process or OS-user isolation is established by it**.

## Observed relationships

```mermaid
flowchart TD
    CLI[Agent CLI / bootstrap] --> AR[AgentRuntime]
    AR --> K[ComponentKernel]
    AR --> SP[SEC-02 deny-only gate]
    AR --> ST[AgentStore / journal]
    AR --> TTY[Terminal I/O]
    K --> MC[GovernedMemoryComponent]
    MC --> S[M5 selector]
    MC --> G[C6 HWI guard]
    G --> C5[C5 PVS review gate]
    C5 --> PVS[PVS store / original backend]
    C5 --> C4[C4 admission receipt]
    C4 --> SRC[Wiki + journal + provenance]
    QT[Qt TiddlyViewer] --> WC[WikiCore]
    WC --> DB[SQLite content/history]
    KB[Read-only knowledge broker] --> WC
    RW[Signed wiki-write service] --> WC
    RW --> PL[Proposal ledger]
```

Anchors: `agent/autogpt_lite/main.py:160`, `agent/autogpt_lite/agent.py:299,576,596,633`, `agent/research_memory/pvs_memory_selector.py:174`, `wiki/hwi/runtime_guard.py:62`, `wiki/hwi/pvs_review_gate.py:232`, `wiki/hwi/pvs_admission.py:197`, `wiki/app/ui_window.py:65`, `wiki/hwi/reviewed_writes.py:114`.

## Refactoring dependency policy (proposed)

| Caller | Permitted direction | Forbidden or constrained direction | Reason |
|---|---|---|---|
| Human UI adapters | Application commands, queries and read-only presentation results | Direct signing, privileged PVS writer, or policy overrides | Display must not create authority |
| Agent reasoning | Typed proposal and retrieval ports | Direct trusted signature creation, unchecked SQL/PVS writes, terminal policy decisions | Agent is a requester, not an authority |
| Application orchestration | Explicit domain services, policy/gate before effects | Treat a UI `yes` or model response as independent signed authority | Exact-operation approval and provenance |
| Verification and governance | Independently provisioned pins/keys and fixed domain records | Source authority from model-provided text, saved config or wiki prose | Prevent circular trust |
| Knowledge broker | Read-only scoped wiki data | Private writable `WikiCore`/DB handles to agent | Retrieval is data, not permission |
| PVS writer | Verified signed operator admission, exact current PVS identities | Automatic approval/prompt inclusion from a write receipt | C4 unreviewed ≠ C5 reviewed |
| Persistent journal | Append/replay source observations | Silent retroactive reinterpretation | Maintain evidence lineage |
| SEC-02 closed dispatcher | Canonical diagnosis and refusal | Command execution, including aliases | Pilot is closed |

## Existing mismatches / deferred changes

1. `AgentRuntime._display()` and `_authorize()` directly couple runtime to terminal I/O. `UserInteractionComponent._ask_user()` also uses `input()`; extracting the display port alone is insufficient.
2. `ComponentKernel._resolve_order()` logs a cycle and returns rather than failing startup (`agent/autogpt_lite/kernel.py:72-106`). Preserve current behavior in R0; design an explicit failure in RC-04 under a separate compatibility gate.
3. `HwiProtectedSelectionGuard` relies on **exact in-process Python object identity** (`wiki/hwi/runtime_guard.py:31-44`). Moving it across processes would require a protocol redesign; not part of this refactoring track.
4. `wiki/app/ui_window.py` directly coordinates `WikiCore` operations; the next step is a typed application seam, not immediate full Qt decomposition.
5. C4 PVS writes and M5 governed reads coexist inside the same privilege domain in research paths. An import boundary is **not** a hostile-code boundary. Independent keys, second-user ownership and external custody remain unresolved deployment assumptions.

**Non-goal:** no new interprocess RPC, multi-service framework, permission bypass or refactoring of the original PVS-01 backend.
