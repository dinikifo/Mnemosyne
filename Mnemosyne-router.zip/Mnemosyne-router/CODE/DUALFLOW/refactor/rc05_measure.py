#!/usr/bin/env python3
"""Compare frozen RC-01 source against RC-05 candidate without mutating either.

Static proxies are descriptive, not a maintainability or security proof.
Usage: python refactor/rc05_measure.py --baseline /path/to/C14-R2 --current .
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def python_metrics(root):
    packages = [root/'agent/autogpt_lite', root/'wiki/hwi', root/'wiki/app']
    files = sorted(p for d in packages for p in d.rglob('*.py') if p.is_file())
    parsed = [(p,ast.parse(p.read_text('utf-8'))) for p in files]
    return {
       'python_modules': len(files),
       'python_physical_lines': sum(len(p.read_text('utf-8').splitlines()) for p in files),
       'python_nonblank_lines': sum(sum(bool(line.strip()) for line in p.read_text('utf-8').splitlines()) for p in files),
       'classes': sum(isinstance(n,ast.ClassDef) for _,tree in parsed for n in ast.walk(tree)),
       'functions_methods': sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) for _,tree in parsed for n in ast.walk(tree)),
    }


def terminal_in_runtime(root):
    rels=['agent/autogpt_lite/agent.py','agent/autogpt_lite/components/user_interaction.py']
    out={}
    for rel in rels:
        p=root/rel; tree=ast.parse(p.read_text())
        direct_calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('input','print')]
        tty_literals=[n for n in ast.walk(tree) if isinstance(n,ast.Constant) and n.value=='/dev/tty']
        out[rel]={'print_input_calls':len(direct_calls),'dev_tty_literals':len(tty_literals)}
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,required=True);ap.add_argument('--current',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path)
    a=ap.parse_args();b=a.baseline.resolve();c=a.current.resolve()
    lock=json.loads((c/'refactor/RC01_SOURCE_LOCK.json').read_text()); seen=lock['files'];assert len(seen)==693
    bad=[x for x,digest in seen.items() if not (b/x).is_file() or sha(b/x)!=digest]
    if bad:raise SystemExit(f'BASELINE_LOCK_MISMATCH: {bad[:5]} total={len(bad)}')
    changed=[x for x in sorted(seen) if not (c/x).is_file() or sha(c/x)!=seen[x]]
    areas=tuple(lock['areas']); source=lambda r:{str(p.relative_to(r)) for a in areas for p in (r/a).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts}
    new=sorted(source(c)-set(seen)); removed=sorted(set(seen)-source(c))
    result={'schema':'hwi.refactor.rc05.measure.v1','method':'AST physical/nonblank lines; trusted baseline hashes; source diff; direct runtime I/O calls. Counts are proxies not causal outcomes.',
            'baseline_zip_sha256':lock['baseline_zip_sha256'],'baseline_lock_files':len(seen),'baseline_lock_mismatches':len(bad),
            'changed_frozen_files':changed,'changed_frozen_count':len(changed),'new_source_files':new,'new_source_count':len(new),'removed_source_files':removed,
            'baseline_python':python_metrics(b),'current_python':python_metrics(c),
            'baseline_terminal_calls':terminal_in_runtime(b),'current_terminal_calls':terminal_in_runtime(c),
            'new_refactor_test_modules':sorted(str(p.relative_to(c)) for p in (c/'agent/tests').glob('test_rc0[34]*.py'))+sorted(str(p.relative_to(c)) for p in (c/'wiki/tests').glob('test_rc02*.py'))}
    blob=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if a.output:a.output.write_text(blob)
    print(blob)

if __name__=='__main__':main()
