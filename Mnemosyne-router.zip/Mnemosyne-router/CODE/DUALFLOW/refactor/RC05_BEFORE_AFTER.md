# RC-05.2 — Before/after compatibility comparison

The baseline is the **C14-R2 consolidated, uncommitted** source (referenced by SHA-256 `c1920eac230445d11cff9a00932a794b1d75ad125721bcaa0ec38219e6f2d9fc`), independently checked against the frozen RC-01 lock of 693 files (0 mismatches). The current candidate is RC-04 plus **RC-05 documentation and verification only**; runtime source has not changed from RC-04.

| Identical test selection | C14-R2 baseline | RC-04/RC-05 current | Scope |
|---|---|---|---|
| Wiki C13 provenance + C14 lineage | 30 passed + 8 subtests | 30 passed + 8 subtests | Signed lineage and custody under test fixtures |
| Agent SEC-02 R8 answer-only + R4 closed pilot + HWI-03 store | 63 passed | 63 passed | Deny-only pilot, non-executable answer event, path safety |

Thus **93 selected regression tests passed on each** version (186 executions). This is a shared-test comparison, **not** a proof of universal behavioral equivalence. Tests were run under the current ambient Python installation, not fully isolated pinned dependencies. See `refactor/rc05_test_logs/{baseline,current}_c13_c14.log` and `{baseline,current}_agent_boundary.log`.

Additional current-only tests: 49 agent RC-03/RC-04 interaction/workflow tests and 19 refactor contract/progress/inventory tests (11 additional subtests) passed. The old C14-R2 baseline has no corresponding new test modules. **Current-run total in RC-05: 161 distinct passing tests**, excluding subtests; previous RC-04 481-test results remain checkpoint history rather than newly reproduced here. An initial attempt to run RC-02 contracts from the wrong directory returned `file or directory not found`; it was corrected by executing the actual `refactor/tests/test_rc02_contracts.py` within the successful 19-test group. That failed selection is retained.

The original PVS backend (`reference/pvs01_src`), SEC-02 dispatch module, SEC-02 authorization module, and signed wiki-write service remain byte-identical to C14-R2. Five frozen source files changed and six new source files were added through RC-02–RC-04, with no removals. The deliberate non-equivalent change is that RC-04 rejects invalid component dependency graphs at startup; the prior kernel could log and continue. The typed internal C4/C5 representations are covered by the C13/C14 regression samples and the checkpoint contract golden-vector tests, but we do not claim an exhaustive formal proof of signed-byte equivalence.

**Limits:** no live model, real external human key custody, OS-user separation, production execution, or exhaustive suite verification; the PVS governed-memory and recovery matrix was not newly rerun in RC-05 beyond the focused tests above.
