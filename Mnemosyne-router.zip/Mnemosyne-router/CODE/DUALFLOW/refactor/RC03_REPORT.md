# RC-03 — Agent / UI separation checkpoint

**Checkpoint status: 5/5 technical goals fulfilled, owner acceptance pending.**

### Delivered

1. Typed, immutable `InteractionEvent` and `OperatorDecision` and `InteractionPort` contract.
2. Default terminal adapter retaining `/dev/tty` explicit `yes/no/quit` and optional denial feedback.
3. Deterministic, non-authoritative test adapter with captured events, one-use queued decisions and no implicit approval.
4. `AgentRuntime` no longer prints, reads input or opens a terminal. `UserInteractionComponent` forwards questions through the interaction port.
5. Focused negative and compatibility tests (unknown choices, missing TTY, EOF, interruption, malformed port output, SEC-02 no execution or authorization prompt, HWI C6 failures) passed.

### Verification

- 197 distinct passed tests in `rc03_test_logs/final_agent_boundary.log`.
- 106 **different** tests passed and 9 subtests passed in `rc03_test_logs/additional_security.log`.
- Total **303 distinct tests**, 9 subtests passed in those final two groups, zero skipped there. Early 47-test pass and 107-test rerun overlap; do not add their totals.
- First extended attempt recorded 11 PVS setup errors because `PVS01_SOURCE_ROOT` was not supplied. Setting it to bundled `reference/pvs01_src` resolved the setup issue; final runs passed. Not counted as software defects or passing results.
- Fresh agent wheel built from current source; all three modified/new runtime modules byte-identical to wheel contents.
- Signed C4/C5 sources, original PVS and SEC-02 dispatch byte-identical to RC-02.

**Limit:** The independent human approval, OS-user separation, real-model usefulness, clean full optional dependency suite and production acceptance are not evidenced. The Git review commit contains a source patch and evidence, not a production release.
