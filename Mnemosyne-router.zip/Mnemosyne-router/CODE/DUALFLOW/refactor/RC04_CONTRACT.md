# RC-04 — Application and workflow boundaries

This is a **behavior-preserving, unaccepted refactoring candidate** against RC-03. It is not process isolation, approval verification or an independent security principal.

## Application boundary

`autogpt_lite.application.ApplicationBoundary` separates **queries** (`GetRuntimeStatus`, `GetPendingProposal`) from the **command** (`RunSupervisedCycle`). Queries yield immutable `RuntimeStatusView` or `ProposalView` snapshots; they do not pass `AgentState`, mutable proposal dictionaries, signing objects or private credentials to the interface. A presentation model cannot grant approval. A view may contain model-generated or untrusted text; UI clients must escape it and must never interpret it as instructions or authority.

`RunSupervisedCycle` delegates exactly once to the **existing** `AgentRuntime.run()` code path, retaining the current SEC-02/guard/preflight/one-invocation restrictions. Runtime exceptions, evidence failures and recovery requirements are not converted into success. The typed application boundary is a library API, not a network endpoint or privilege boundary; callers with arbitrary Python access already have direct access to `AgentRuntime`.

## Existing workflow marker

`autogpt_lite.workflow.next_pending_phase` is a **pure transition check** over the already-persisted `AgentState.pending_phase` field (unchanged strings and JSON schema). `PROPOSED` is not approval. `AUTHORIZED_UNCERTAIN` is a crash-sensitive intent marker **not proof that a tool completed**. `RECORD` clears a normally recorded episode; legacy direct error/answer recording from `None` is preserved. No new workflow or approval datastore was introduced. Previously persisted unknown phases are rejected by transition checks, not silently repaired. The original startup/recovery gates remain responsible for reconciliation.

## Dependency startup

`ComponentKernel` retains its deterministic topological ordering, but now refuses a missing `run_after` target, duplicate registered component type, or cycle via `ComponentDependencyError` **before attaching components or executing pipelines**. Previously a cycle was logged and ordering continued; this was an unsafe ambiguity. Startup preflight remains inside the runtime's existing initialization path, not a second authority mechanism.

## Preserved invariants

- No change to PVS original source, C4/C5 signed bytes, C14 lineage receipts, or SEC-02 dispatch.
- No new UI-provided authorization; `TestInteraction` remains an untrusted in-process stub.
- `AUTHENTICATED_UNCERTAIN` is **not** a valid state; the actual persisted spelling is `AUTHORIZED_UNCERTAIN`.
- No automatic retry on interrupted/uncertain actions and no promotion of wiki notes to governed memory.
- No independent OS-user/key custody; owner review/acceptance remains pending.

## Deliberate compatibility tradeoff

Rejecting invalid component graphs is intentionally stricter startup behavior; it improves fail-closed handling for an invalid configuration but is **not byte-for-byte behavioral equivalence** for invalid graphs. Tests cover this difference. The normal registered component order and allowed execution path remain unchanged.
