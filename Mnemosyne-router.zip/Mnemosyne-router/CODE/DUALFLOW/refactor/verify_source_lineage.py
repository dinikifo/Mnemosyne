#!/usr/bin/env python3
"""Check the frozen RC-01 source hashes plus explicitly recorded RC-02..04 overlays.

Does not mutate the RC-01 baseline, authorize changes, or execute any source code.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

from verify_rc01_inventory import check as check_inventory

ROOT = Path(__file__).resolve().parents[1]
CHECKPOINTS = ('RC-02', 'RC-03', 'RC-04')


def check(root: Path, lock: dict, diffs: list[dict]) -> tuple[list[str], dict]:
    failures = []
    expected = copy.deepcopy(lock.get('files', {}))
    if len(diffs) != len(CHECKPOINTS):
        return ['DIFF_CHAIN_LENGTH'], {}
    for i, (checkpoint, record) in enumerate(zip(CHECKPOINTS, diffs)):
        # RC-02 predates the shared diff schema; normalize only its documented
        # preimage/postimage records, without changing the frozen manifest.
        if checkpoint == 'RC-02' and record.get('schema') == 'hwi.refactor.rc02.source-diff.v1':
            import hashlib
            patch = root / record.get('patch', '')
            if not patch.is_file() or hashlib.sha256(patch.read_bytes()).hexdigest() != record.get('patch_sha256'):
                failures.append('RC02_PATCH_DIGEST_MISMATCH')
            record = {
                'schema': 'hwi.refactor.source.diff.v1',
                'new_checkpoint': 'RC-02',
                'baseline_checkpoint': 'RC-01',
                'signed_or_dispatch_sources_changed': False,
                'files': {row['path']: {'before': row['baseline_sha256'], 'after': row['rc02_sha256']}
                          for row in record.get('changes', [])},
            }
        if record.get('schema') != 'hwi.refactor.source.diff.v1' or record.get('new_checkpoint') != checkpoint:
            failures.append(f'BAD_DIFF_ID {checkpoint}')
            continue
        parent = 'RC-01' if i == 0 else CHECKPOINTS[i - 1]
        if record.get('baseline_checkpoint') != parent:
            failures.append(f'BAD_PARENT {checkpoint}')
        if record.get('signed_or_dispatch_sources_changed') is not False:
            failures.append(f'SIGNED_BOUNDARY_NOT_PRESERVED {checkpoint}')
        for path, change in record.get('files', {}).items():
            # A path can be a changed tracked source or newly introduced one.
            if not isinstance(path, str) or not path.startswith(('agent/', 'wiki/', 'reference/', 'offline_testing/')) or Path(path).is_absolute() or '..' in Path(path).parts:
                failures.append(f'INVALID_PATH {path}')
                continue
            before = expected.get(path)
            if before != change.get('before'):
                failures.append(f'CHAIN_PREIMAGE_MISMATCH {checkpoint} {path}')
            after = change.get('after')
            if not isinstance(after, str) or len(after) != 64 or any(c not in '0123456789abcdef' for c in after):
                failures.append(f'INVALID_POSTIMAGE {checkpoint} {path}')
            else:
                expected[path] = after
    # Keep the RC-01 original identity, anchors and documentation requirements.
    inspection = copy.deepcopy(lock)
    inspection['files'] = expected
    issues, info = check_inventory(inspection, root)
    return failures + issues, {'files': info['files'], 'anchors': info['anchors'], 'steps': len(diffs)}


def main() -> None:
    lock = json.loads((ROOT / 'refactor/RC01_SOURCE_LOCK.json').read_text())
    diffs = [json.loads((ROOT / f'refactor/{cp.replace("-", "")}_SOURCE_DIFF.json').read_text()) for cp in CHECKPOINTS]
    issues, stats = check(ROOT, lock, diffs)
    if issues:
        print('SOURCE_LINEAGE_FAILED', '\n'.join(issues[:20]), sep='\n')
        raise SystemExit(1)
    print('SOURCE_LINEAGE_VALID', json.dumps(stats, sort_keys=True))


if __name__ == '__main__':
    main()
