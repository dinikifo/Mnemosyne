# RC-01.5 — Before-refactor behavior and regression baseline

## Frozen scope and identity

- Source under inspection: RC-00 packaged **C14-R2 uncommitted** candidate. Historical original ZIP SHA-256: `c1920eac230445d11cff9a00932a794b1d75ad125721bcaa0ec38219e6f2d9fc` (from RC-00 `BASELINE.md`). This is not the new output archive hash.
- `refactor/RC01_SOURCE_LOCK.json` records the exact hashes of **693 runtime/reference/offline files** under `wiki/`, `agent/`, `reference/` and `offline_testing/`. The frozen lock is a review baseline; RC-02/RC-03 may intentionally diverge and must compare their changes explicitly rather than silently regenerate this record.
- All 693 of those files are byte-identical to their RC-00 inputs. **RC-01 makes no runtime, PVS, SEC-02, wiki, original test, or signed-byte changes.**
- The source lock is local integrity evidence, *not* external custody, independent approval, a production signing key, or a model evaluation.

## Independently rerun in this checkpoint

| Scope and command shape | Outcome | Evidence | Limitations |
|---|---|---|---|
| `cd wiki; python3 -m unittest tests.test_hwi_c13_provenance_gate tests.test_hwi_c14_lineage_custody -v` with explicit source paths and packaged wheel dependencies | **30 passed**, 0 skipped, process exit 0 | `refactor/rc01_test_logs/c13_c14_unittest_installed.log` | Synthetic Ed25519 fixtures, PVS reference source; not independent human custody |
| `cd agent; python3 -m pytest -q tests/test_sec02_r8_answer_only.py tests/test_sec02_r4_closed_pilot.py tests/test_hwi03_agent_store_boundary.py` with explicit source paths and packaged wheel dependencies | **63 passed**, 0 skipped, exit 0 | `refactor/rc01_test_logs/sec02_agent_boundary.log` | Checks answer-only, deny-only pilot and persistence; no genuine model run |
| Initial C13/C14 source-only setup, before wheel dependency | **Failed: missing `personal_wiki_core`** | `refactor/rc01_test_logs/c13_c14_unittest.log` | Test setup failure; not counted as a passing run |
| `pip install --no-index --no-deps --target <scratch> <bundled wheel>` | Installation succeeded | `refactor/rc01_test_logs/wheel_install.log` | Uses shipped wheel rather than rebuilding it; RC-05 clean-environment reproducibility remains open |

**Current focused total: 93 passing tests**, from two distinct successful groups. This is not the full combined suite. Existing C14-R2 wider claims remain historical supplied evidence, not independently repeated here.

### Reproduction notes

Python in this run: 3.13; pytest 9.0.2. The `personal_wiki_core` wheel was installed to a scratch location *outside* the archive with `pip --no-index --no-deps`, then used only to satisfy the `personal_wiki_core` package mapping. The checked-out `wiki/hwi` and `agent/` source paths were first in `PYTHONPATH`. Original PVS reference came from `reference/pvs01_src/`.

```sh
R="$PWD"
python3 -m pip install --no-index --no-deps --target /tmp/rc01-wheel \
  "$R/evidence/wheel_c14_r1/personal_wiki_core-0.0.0+hwi02-py3-none-any.whl"
(cd "$R/wiki" && PYTHONPATH="$R/wiki:$R/agent:$R/reference/pvs01_src:/tmp/rc01-wheel" \
  python3 -m unittest tests.test_hwi_c13_provenance_gate tests.test_hwi_c14_lineage_custody -v)
(cd "$R/agent" && PYTHONPATH="$R/agent:$R/wiki:$R/reference/pvs01_src:/tmp/rc01-wheel" \
  python3 -m pytest -q tests/test_sec02_r8_answer_only.py \
     tests/test_sec02_r4_closed_pilot.py tests/test_hwi03_agent_store_boundary.py)
```

## Compatibility contract for later checkpoints

Preserve deny-only SEC-02 dispatch, the non-executable answer-only event, terminal refusal on missing interactive authorization, C14-R1 signed snapshot behavior, v2 receipt verification, manual recovery on uncertain commits, and no self-promotion of wiki or proposal text. New typed boundaries or adapters must demonstrate equivalence on these specific cases before claiming improvement.

## Not demonstrated

The tests do not prove OS/process isolation, human identity, key custody, full provenance completeness, cross-store atomicity, end-to-end genuine-model usefulness, deployment permission or owner acceptance. HWI remains **0/14 accepted**; RC-01 remains **PENDING_OWNER_REVIEW** even after technical completion.
