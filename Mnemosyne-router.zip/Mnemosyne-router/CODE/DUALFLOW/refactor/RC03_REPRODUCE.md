# RC-03 reproduction

Requires Python 3.11+, pytest and the optional cryptography dependency for HWI C6 tests. Run using paths from the extracted RC-03 archive. Do not count skipped tests as passing.

```sh
ROOT=/path/to/HWI_C14_R2_REFACTOR_RC03_CONSOLIDATED
export PVS01_SOURCE_ROOT="$ROOT/reference/pvs01_src"
export PYTHONPATH="$ROOT/agent:$ROOT/wiki:$ROOT/reference/pvs01_src:$ROOT/offline_testing:/path/to/installed-personal_wiki_core"
python -m pytest -q "$ROOT/agent/tests/test_rc03_interaction_port.py" \
  "$ROOT/agent/tests/test_sec02_supervised_mode.py" \
  "$ROOT/agent/tests/test_sec02_r4_closed_pilot.py" \
  "$ROOT/agent/tests/test_sec02_r5_bypass_resistance.py" \
  "$ROOT/agent/tests/test_sec02_r8_answer_only.py" \
  "$ROOT/agent/tests/test_hwi_c6_runtime_guard.py" \
  "$ROOT/agent/tests/test_hwi03_agent_store_boundary.py"
python -m pytest -q "$ROOT/agent/tests/test_sec02_r6_outcome.py" \
  "$ROOT/agent/tests/test_sec02_r7_consolidation.py" \
  "$ROOT/agent/tests/test_sec02_r8_independent.py" \
  "$ROOT/agent/tests/test_im07_coverage_and_agent_runtime.py"
python "$ROOT/tools/verify_refactor_checkpoints.py" --markdown
python "$ROOT/tools/verify_ledgers.py"
python "$ROOT/tools/verify_evidence_index.py"
python "$ROOT/tools/verify_manifest.py"
```

For the wheel, `pip wheel --no-deps --no-build-isolation "$ROOT/agent"` and compare the archive's `autogpt_lite/agent.py`, `interaction.py`, and `components/user_interaction.py` against the source. The retained evidence logs show the first attempt missing the external PVS source path, followed by a passing rerun.

`RC03_CANDIDATE.patch` applies to RC-02, not C14-R2 or C14-R1 directly. Applying it does not authorize agent execution.
