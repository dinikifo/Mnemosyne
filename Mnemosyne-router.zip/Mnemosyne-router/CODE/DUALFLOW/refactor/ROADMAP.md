# HWI refactoring checkpoints — RC-00 through RC-05

**Purpose:** consolidate architecture for human and LLM maintainers **before** adding capabilities. This is a separate, finite refactoring track, not a replacement for HWI implementation acceptance or the original roadmap.

## Rules

- Preserve C14-R2 as immutable reference and keep its HWI 0/14 implementation acceptance intact.
- No agent self-authorization; UI responses are not signatures; PVS signed content, ancestry and credential logic are not silently migrated.
- Keep SEC-02 executable dispatch closed; no model or worker permissions change in these checkpoints.
- Logical interface separation comes before process isolation. A module boundary must not be described as an OS security boundary.
- Complete goals only with source evidence and passing applicable tests. Mark failures, skips and unknowns explicitly; a commit does not mean acceptance.
- One checkpoint at a time in dependency order; a successful checkpoint produces an inspectable Git commit and a review package.
- Stop after RC-05, or earlier if two successive proposed changes fall below an indicative value/effort ratio of 1.5, or a planned change threatens authority/signature compatibility without approved migration. The ratios are planning estimates, not measurements.

## Checkpoints and gates

| Checkpoint | Original phase | Completion gate |
|---|---|---|
| RC-00 | Setup | Baseline identified; bounded goal matrix; verified progress checker; **planning-only commit** |
| RC-01 | R0 | Source-grounded component and trust maps, signed/recovery invariant matrix, regression baseline |
| RC-02 | R1 | Internal typed contracts and pure verification with byte-for-byte external compatibility |
| RC-03 | R2 | UI-free agent interaction boundary; terminal and test adapters; negative authorization tests |
| RC-04 | R3 | Commands/queries, view models, explicit transitions and startup checks; no new execution authority |
| RC-05 | R4 | Clean reproducibility, before/after comparison, maintenance value, documented stop/go decision |

Each goal is identified and tracked in `refactor/GOALS.json`, not by a prose percentage. The two public progress metrics are: **whole track: completed/27**, and **implementation-only: completed/24**, excluding the three RC-00 setup goals. Per-checkpoint counts are also reported.

## Commit and acceptance protocol

1. Work in a local branch from the retained C0 planning Git history; do not rewrite or imply acceptance of C1–C14.
2. For RC-00, commit only the planning roadmap and progress validator. The full C14-R2 runtime remains a separate, unaccepted archive.
3. For future code checkpoints: collect tests and diff, update goal statuses and evidence, run verifiers, commit locally, record commit SHA in the review handoff; obtain explicit owner acceptance separately.
4. Never auto-increment another track in `LEDGERS.json` because a refactor goal was completed. Do not push to GitHub without an explicit separate request.

Run `python3 tools/verify_refactor_checkpoints.py --markdown` and `python3 tools/verify_ledgers.py`.
