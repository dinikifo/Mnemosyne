# Batch C — RC02-F01 exact immutable typed-scalar contract correction

## Findings fixed (technical candidate, NOT ACCEPTED)

- `AdmissionPlanIdentity.proposal_target_id` could hold a caller-owned mutable list
  when the plan dictionary had a self-consistent SHA-256. Immutable dataclass
  slots alone cannot freeze objects referenced by its fields.
- `AdmissionReceiptIdentity.proposal_count` could hold the boolean `True` as
  an apparent integer; the receipt target ID could also be a mutable list.
- Receipt projected digest fields had no exact SHA-256 type checks.

## Correction

`wiki/hwi/pvs_contracts.py` now requires exact nonempty built-in `str`
for proposal target identity, exact nonnegative built-in `int` for proposal
counts (never `bool`), exact lowercase built-in `str` for projected SHA-256
values, and exact built-in `bytes` for signing messages. It checks the
frozen slotted dataclass constructors as well as both `inspect_*` boundaries.
All rejection is through `ContractError`, with the original public C4 error
mapping retained.

The signed plan/receipt dictionaries, canonical JSON encoder, signing domain,
cryptographic verification, original golden-vector bytes, PVS source, SEC-02
and execution policy have not changed. A checksum valid receipt still does NOT
establish operator signature validity or PVS admission authority.

## Verified evidence

- Baseline: 3 independent checksum-valid malformed vectors were ACCEPTED before
  this patch (see `logs/baseline_negative_probe.log`).
- Focused RC02 + Batch C: **19 tests and 69 subtests passed**.
- C4/C5/lineage RC02 + Batch C: **99 tests and 91 subtests passed**.
- Replayed source Batch B interaction + RC02 + Batch C: **164 tests and
  69 subtests passed**.
- SEC-02 deny-only: **358 tests and 9 subtests passed**.
- Wiki/PVS integration: **4 tests passed**.
- **606 unique tests passed** across these groups (the 19 RC02/Batch C tests
  were run in both the C4/C5 and replayed interaction groups). The 69 focused
  subtests overlap the 91 C4/C5 subtests; total distinct reported subtests:
  **100** (91 C4/C5 + 9 SEC-02).
- Approved baseline SHA-256 verified **1,021/1,021** files; candidate source
  verified **1,022/1,022** files; **1,020/1,020 untouched** files match.
- Full patch replay from extracted approved B-R6 produced **1,022/1,022
  byte-identical** candidate files, with no implementation edits outside
  `wiki/hwi/pvs_contracts.py`.

## Open limitations

Tests use a locally installed bundled PERSONAL.WIKI wheel plus available Python
packages, not the exact pinned clean environment. No live human-terminal,
independent operator custody, or real model execution is certified. Original
source-lock manifests are historical: the candidate carries its own manifest
because a controlled correction necessarily changes one historical file.

## Acceptance ledger (not approval)

Batch A 3/3 accepted; Batch B 3/3 accepted; Batch C 0/1 pending.
Total formally accepted **6/7**. Refactoring original 26/27 technically
complete; original HWI milestones 0/14 accepted.
No new Git commit, remote push, PVS write, or SEC-02 policy expansion.
