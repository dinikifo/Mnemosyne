# RC-02 reproduction (local, source-first)

From the extracted consolidated archive root (requires Python >=3.11, `pytest`, `cryptography`, plus the original reference PVS source already in the archive):

```sh
R="$PWD"
# Use an isolated installation of the newly built refactored wheel. Do not
# mistake the historical wheel at evidence/wheel_c14_r1 for this checkpoint.
python3 -m venv /tmp/hwi_rc02_env
/tmp/hwi_rc02_env/bin/python -m pip install --no-index --no-deps refactor/artifacts/*.whl
# Additional dependencies (including cryptography and pytest) must be
# installed/provisioned separately in the target environment.
PYTHONPATH="$R/wiki:$R/agent:$R/reference/pvs01_src" python3 -m unittest discover \
    -s refactor/tests -p 'test_rc02_contracts.py' -v
(cd wiki && PYTHONPATH="$R/wiki:$R/agent:$R/reference/pvs01_src" \
    python3 -m unittest tests.test_hwi_c4_pvs_admission \
    tests.test_hwi_c5_independent_pvs_review \
    tests.test_hwi_c13_provenance_gate tests.test_hwi_c14_lineage_custody -v)
(cd agent && PYTHONPATH="$R/agent:$R/wiki:$R/reference/pvs01_src" \
    python3 -m pytest -q tests/test_sec02_r8_answer_only.py \
    tests/test_sec02_r4_closed_pilot.py tests/test_hwi03_agent_store_boundary.py)
python3 tools/verify_refactor_checkpoints.py --markdown
python3 tools/verify_ledgers.py
python3 tools/verify_evidence_index.py
```

These are command shapes, not an assertion that every clean-machine optional dependency is included in the archive. See `refactor/RC02_COMPATIBILITY.md` for actual completed runs, environment notes and limitations. `refactor/RC02_CANDIDATE.patch` is replayable against the RC-01 C14-R2 frozen source; it is **not** an authorization to write to PVS.
