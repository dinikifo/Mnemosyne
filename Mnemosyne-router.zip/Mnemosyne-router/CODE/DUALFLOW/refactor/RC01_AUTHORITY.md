# RC-01.3 — Actor, capability and authority matrix

The rows distinguish **ability to call code** from **legitimate authority**. In the current research bundle agent-side and signer-side Python may be in one OS-user domain; these roles are conceptual, not cryptographically isolated from hostile same-process code.

| Actor | Can propose/observe | Can independently approve | Can write durable state | Can dispatch executable SEC-02 commands | Basis / caveat |
|---|---|---|---|---|---|
| LLM/agent reasoning | Yes: answer, plan, candidate, draft | **No** | Only through exposed workflow; no general HWI authority | **No** in closed pilot | `agent/autogpt_lite/agent.py:299,547,633` |
| Terminal or Qt UI | Display and collect input | A terminal `yes` is not a C4/C5 signed attestation | UI can use WikiCore operations in its human context | **No** in closed pilot | `agent/autogpt_lite/agent.py:596`; `wiki/app/ui_window.py` |
| Human operator, independently acting | Inspect original source and request | Can sign/enroll outside agent control *if external custody is real* | May direct bounded writes and retain external pins | Not while SEC-02 policy remains closed | `wiki/hwi/pvs_admission.py:162,197` |
| HWI-07 ledger | Stores bounded proposed change | **No** | Append proposal/event records | No | `wiki/hwi/proposals.py` |
| HWI-08 reviewed-write service | Verify signature and expected local revision | Does not decide who is a human | Applies one authorized wiki mutation; creates local receipt | No | `wiki/hwi/reviewed_writes.py:114,246` |
| C4 admission operator writer | Verify C2/C3/C13/C4 material | Requires external operator signature; cannot confer PVS review | Writes **unreviewed** PVS draft | No | `wiki/hwi/pvs_admission.py:197-320` |
| C5 independent review gate | Check admission, fresh review context and selected result | Does not issue signature or make review independent | Read-only verification | No | `wiki/hwi/pvs_review_gate.py:183,232` |
| M5 selector + C6 runtime guard | Eligible memory only after signed PVS review, current pins and credentials | **No** | Read-only for prompt selection | No | `agent/research_memory/pvs_memory_selector.py:70,174`; `wiki/hwi/runtime_guard.py` |
| Recovery inspectors | Investigate uncertain or partial observable state | **No** | No repair or automatic retry | No | `wiki/hwi/recovery_inspection.py:205`, `wiki/hwi/operator_handoff.py:52` |
| SEC-02 dispatch gate | Describe a refused command request | **No** | Refusal may be recorded by runtime | **Never** in current pilot | `agent/autogpt_lite/sec02_dispatch.py:29,47` |

## State-dependent guarantees and limitations

- A valid Ed25519 signature verifies bytes under a key, **not** a person's identity, intent or independence. Enrollment and key custody require independent operator evidence.
- A signed wiki revision is **not** an M5 approved memory. A C4 admission receipt proves only an attempted/observed **unreviewed** PVS write under tested assumptions.
- A reviewed memory selection is **not** permission to execute a tool. `sec02.answer_only` is a recorded non-executable event, not installed tool dispatch.
- `NO_APPROVED_MEMORY` and missing/bad credentials are not equivalent states: valid absence may return no memory, while invalid pins/credentials raise and may block a required provider before model invocation.
- A source-history hash validates integrity within the checked model, **not** truth or immunity to a malicious process with write access. Real independent custody/privilege separation is unverified.

## Questions reserved for a future authorized redesign

Who signs and keeps keys? Which OS principals own data? How are review approvals authenticated across a process boundary? What availability and latency should a protected session guarantee? These are **not** answered by RC-01 documentation.
