# CR03 Batch C approved correction — offline reproduction

1. Verify the SHA-256 sums of the approved B-R6 ZIP and exact `CR03_BATCH_C_APPROVED.patch` against `CR03_BATCH_C_ACCEPTANCE.md`.
2. Verify all 1021 payloads in B-R6 against its `SHA256_MANIFEST.json`, then extract into a clean directory.
3. `git -C <B_R6_EXTRACT> apply --check /absolute/path/CR03_BATCH_C_APPROVED.patch` and apply that same patch.
4. Compare the extracted tree to the original reviewed Batch C candidate ZIP: all 1022 reviewed payloads must match, and its original manifest is copied unchanged for the comparison.
5. Install the bundled PERSONAL.WIKI wheel to an isolated target with `pip install --no-index --no-deps --target <DEPS_DIR> <BUNDLE>/refactor/artifacts/personal_wiki_core-0.0.0+hwi02-py3-none-any.whl`.
6. Set `PYTHONPATH=<source>/wiki:<source>/agent:<source>/reference/pvs01_src:<DEPS_DIR>`, `PYTHONDONTWRITEBYTECODE=1`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`.
7. `python -m pytest -q -p no:cacheprovider refactor/tests/test_rc02_contracts.py refactor/tests/test_cr03_batch_c_immutable_scalar_contracts.py` should report 19 passed and 69 subtests (under the locally installed dependency set).
8. See the independent review for the broader 787-test, 177-subtest matrix and limitations.

Review Git stores only patch/governance; the separate consolidated ZIP stores approved runtime source. No deployment, remote push, widened SEC-02 dispatch, or pinned clean-environment validation is implied.
