# RC-05-R1 — Offline dependency handoff (verification-only)

**Status: BLOCKED / goal RC-05.clean still PENDING.** There is no new runtime capability, change to SEC-02 dispatch, or owner acceptance. This follow-up does not change the 26/27 (96.3%) refactor count.

## What was independently checked

* The RC-05 source and requirements pins are retained. No pinned version was silently relaxed.
* The existing archive provides two application wheels, **not** a complete third-party wheelhouse. Against `refactor/artifacts`, the preflight returned `BLOCKED_MISSING_DIRECT_WHEELS` for all seven exact test requirements. This is expected, not a successful test installation. See `refactor/rc05_r1_test_logs/wheelhouse_preflight.json`.
* The new offline preflight has eight passing unit tests, including malformed requirements, corrupt and mismatched wheels, absent exact pins, and a **synthetic** positive resolver fixture. A synthetic fixture does not validate the project's real pinned dependencies.
* Direct package-index access failed in the previous attempt. No full clean-environment runner has been reproduced here. The historical RC-05 focused passes remain valid **within their stated, non-pinned environment**, not equivalent to the missing clean-run evidence.

## Reproduction handoff

On a connected, trusted machine with the **same target Python and OS/architecture** as the testing host:

```sh
# Use a fresh Python >=3.11 installation for this preparation step.
python3 -m venv /tmp/hwi-wheel-download
/tmp/hwi-wheel-download/bin/python -m pip download \
  --only-binary=:all: --dest /path/to/hwi-wheelhouse \
  -r requirements-test.txt

# Independently retain the wheel-file checksums outside the agent's control.
sha256sum /path/to/hwi-wheelhouse/*.whl > /separately-retained/hwi-wheelhouse.sha256

# On the offline verification host, with the reviewed candidate extracted:
python tools/verify_test_wheelhouse.py \
  --wheelhouse /path/to/hwi-wheelhouse \
  --output /tmp/hwi-wheelhouse-preflight.json
# Only READY_FOR_ISOLATED_INSTALL_NOT_TESTED (exit 0) permits the next step.

HWI_WHEELHOUSE=/path/to/hwi-wheelhouse \
HWI_TEST_LOG_DIR=/path/to/preserved-test-results \
HWI_KEEP_WORK=1 \
./run_c14_r1_tests.sh
```

After the run, review the full bounded-group outputs, the `pip_freeze.txt`, `identity_check.log`, `wheel_build.log`, `RESULT.txt`, exit status, and skipped-test counts. Confirm that the rebuilt wheel corresponds to the reviewed source and compare test output to the checkpoint's frozen expectations. Store the external checksum record independently. A preflight `READY` result **does not** establish installation, full-test success, trustworthy supplier custody, or RC-05 acceptance.

## Notes and limitations

* Wheelhouse preflight runs entirely without an index (`--no-index`) and checks that pip can *plan* all required dependencies from local wheels. It records local hashes, which detect later alteration if separately pinned; they do not authenticate the supplier on their own.
* The preflight's direct-pin parser only accepts exact `name==version` lines, matching the current requirements file; it intentionally rejects range pins and extras instead of interpreting them loosely.
* A wheelhouse collected for a different OS/CPU/Python version may contain exact versions but lack compatible binary distributions. The resolver phase must detect that.
* If any requirement truly cannot be downloaded for the target platform, treat it as a new **dependency decision**, not an excuse to invent equivalent version evidence. Changing the pins requires an explicit follow-up and re-baselined regression evidence.
* Until the above real clean run completes and is reviewed, RC-05.clean stays pending, and SEC-02 remains closed.
