# Reproducing the RC-05 evidence

Use the matching, separately supplied C14-R2 consolidated baseline source and this candidate extracted into different directories. The baseline is verified against `refactor/RC01_SOURCE_LOCK.json` by `rc05_measure.py`. All operations are read-only except temporary test output.

```sh
python refactor/rc05_measure.py --baseline /path/to/C14-R2 --current . --output /tmp/rc05_metrics.json
python refactor/verify_source_lineage.py
python tools/verify_refactor_checkpoints.py --markdown
python tools/verify_ledgers.py
python tools/verify_evidence_index.py
python tools/verify_manifest.py .
```

For test comparison, use the same interpreter and dependencies for both directories (run from each respective directory). The test environment in this review was **not** a pinned clean venv; see `RC05_ENVIRONMENT.md`:

```sh
(cd wiki && PYTHONPATH="$PWD/wiki:$PWD/agent:$PWD/reference/pvs01_src:<independently-installed-wiki-package>" PVS01_SOURCE_ROOT="$PWD/reference/pvs01_src" python -m pytest -q -p no:cacheprovider tests/test_hwi_c13_provenance_gate.py tests/test_hwi_c14_lineage_custody.py)
(cd agent && PYTHONPATH="$PWD/agent:$PWD/wiki:$PWD/reference/pvs01_src:<independently-installed-wiki-package>" PVS01_SOURCE_ROOT="$PWD/reference/pvs01_src" python -m pytest -q -p no:cacheprovider tests/test_sec02_r8_answer_only.py tests/test_sec02_r4_closed_pilot.py tests/test_hwi03_agent_store_boundary.py)
```

The placeholder is an actual independently installed package-directory location; do not copy it literally into a command. Use `run_c14_r1_tests.sh` and a complete verified local wheelhouse for the outstanding pinned clean-run gate. Its attempted failure is saved in `refactor/rc05_test_logs/clean_dependencies_failed.log`; installation of the two application wheels with `--no-deps` is not a substitute.

**RC-05-R1:** Before trying the full offline runner, use `python tools/verify_test_wheelhouse.py --wheelhouse /path/to/verified/wheels --output /tmp/hwi-wheelhouse-preflight.json`. See `RC05_R1_OFFLINE_DEPENDENCIES.md` for the custody and collection procedure. A preflight pass does not complete the clean-run goal.
