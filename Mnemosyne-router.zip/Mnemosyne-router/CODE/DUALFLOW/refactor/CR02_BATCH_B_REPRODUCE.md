# CR-02 Batch B-R6 approved patch — offline reproduction

1. Verify SHA-256 of the approved Batch A source ZIP and this exact reviewed patch against `CR02_BATCH_B_ACCEPTANCE.md`.
2. Verify all 1001 files listed in the approved A source `SHA256_MANIFEST.json`; extract the ZIP to a clean directory.
3. Apply `patch --batch --forward -p1 -i /absolute/path/CR02_BATCH_B_APPROVED.patch` in that directory.
4. Replace the historical A manifest with `SHA256_MANIFEST.json` from the original reviewed B-R6 candidate ZIP, then verify all 1011 payload SHA-256 entries and the exact 1012-file byte identity.
5. Offline-install the bundled PERSONAL.WIKI wheel into an isolated dependency directory (`python -m pip install --no-deps --no-index --target ... <source>/refactor/artifacts/personal_wiki_core-0.0.0+hwi02-py3-none-any.whl`).
6. Set `PYTHONDONTWRITEBYTECODE=1`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, and `PYTHONPATH=<deps>:<source>/agent:<source>/wiki:<source>/reference/pvs01_src`. Run:
   `python -m pytest -q -p no:cacheprovider <source>/agent/tests/test_cr02_batch_b_r6_reviewer_acceptance.py <source>/agent/tests/test_cr02_batch_b_r6_task_metadata_contract.py`.
7. See the original R6 review package for the wider partitioned regression evidence, the R5→R6 patch path, and documented combined-run timeouts.

This Git repository is only a review/governance repository; the patch is applied to the separately provided consolidated source.
