# RC-03 — Agent interaction boundary (R2)

## Responsibility and contract

- `InteractionPort.emit(InteractionEvent)`: presentation only. Frozen event carries text, optional kind, output terminator and flush flag.
- `InteractionPort.authorize_action()`: returns `OperatorDecision(APPROVE | DENY | STOP)`. The type is immutable and invalid approval/stop payloads are rejected. **This is a UI decision, not an identity proof, signature, or policy admission.**
- `InteractionPort.ask_question(prompt)`: optional text reply for legacy `ask_user` and resume questions; `None` indicates interrupted/unavailable input. No authorization through this route.
- `TerminalInteraction`: defaults to the pre-existing controlling-terminal flow (`/dev/tty`, exact `yes`; piped stdin cannot authorize). CLI boot and list-agent presentation remain in `main.py`, which is an entry adapter.
- `TestInteraction`: records typed events and consumes explicit queued decisions and replies. Missing authorization decisions deny, never approve. It is for tests and **cannot establish human authority**.
- `AgentRuntime`: delegates all display to `InteractionPort.emit`, authorization to the port and resume prompts to the port. Does not import Qt; no terminal printing, input or `/dev/tty` access remains in `agent.py` or `components/user_interaction.py`.

## Authority and recovery compatibility

SEC-02 dispatch remains deny-only; `sec02.answer_only` is recorded before display. The pilot checks happen before `_authorize` and `_execute`. The legacy non-pilot runtime retains its pre-existing supervised flow, but a pluggable in-process UI is **not** a trustworthy OS or cryptographic authorization boundary. Execution isolation remains a separate unaccepted redesign.

An absent, malformed or broken decision adapter fails closed. An explicit STOP is distinct from a denial. Terminal EOF, no TTY, unknown responses, and terminal interrupts preserve the legacy refusal behavior. No PVS, HWI C4/C5, signed record, hash, credential, journal or SEC-02 dispatcher has been changed.

## Compatibility risks deferred

- `main.py` CLI startup still prints directly; it is not the agent runtime and will be addressed only if a concrete new interface needs it.
- Text output remains formatted inside the runtime; converting strings into independent presentation models belongs in RC-04.
- An in-process test adapter could inject APPROVE for legacy non-pilot mode; this is why the adapter must **not** be used as a production permission boundary. SEC-02 pilot forbids executable dispatch regardless of this response.
- No genuine model runs, real human custody, or separate-OS-user boundary were established by RC-03.
