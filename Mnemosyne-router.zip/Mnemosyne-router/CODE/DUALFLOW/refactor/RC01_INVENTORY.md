# RC-01.1 — Source-grounded component and responsibility inventory

**Baseline:** HWI C14-R2 / RC-00; documentation-only analysis, not implementation acceptance. File references are repository-relative, line numbers are for this frozen baseline. A source module may be present without being enabled by the default CLI.

| Component and source anchors | Observed responsibility | Not an authority for |
|---|---|---|
| CLI and construction — `agent/autogpt_lite/main.py:37,160,205` | Parse config, instantiate runtime and components | Operator cryptographic enrollment; granting tool privileges from model text |
| Agent lifecycle — `agent/autogpt_lite/agent.py:39,175,299,364,547,576,596,633` | Plan, display, ask for authorization (legacy path), save state, execute if permitted, record outcomes; closed-pilot answer-only event | Independent signer identity or PVS memory approval |
| Component coordination — `agent/autogpt_lite/kernel.py:45,72,116,127,143` | Register providers, order by dependencies, collect prompts and commands | Security isolation; current cycle detection logs and returns, rather than rejecting |
| Terminal command interface — `agent/autogpt_lite/components/user_interaction.py:13,29` | `ask_user` command backed by `print`/`input` | Authenticated human approval |
| SEC-02 dispatch — `agent/autogpt_lite/sec02_dispatch.py:17,29,47` | Resolve and *deny* every executable command in closed pilot | Authorizing a command, even if its proposal was displayed |
| Agent state — `agent/autogpt_lite/persistence/store.py:55,69,107,158,224` | Agent-ID validation, descriptor-anchored save/load/delete | Independent evidence custody |
| Source journal — `agent/autogpt_lite/persistence/episode_journal.py:83,119,157` | Append and replay hash-linked observed episodes | Truth of content; PVS approval; full application crash recovery |
| Wiki API — `wiki/app/wiki_core.py:60,108,214,227,338,451` | Qt-free notebook CRUD, history and search through two SQLite stores | Independent authorization for managed agent-generated knowledge |
| Wiki UI — `wiki/app/ui_window.py:65,566,736,997` | Qt window, event handlers and direct calls into `WikiCore` | Defining the meaning of signed authorization |
| Workspace — `wiki/app/workspace.py:22,44,65` | Scope notebook names and private path resolution | Separate OS-user isolation or race-free storage against same-user malicious code |
| Wiki revision DB — `wiki/app/history_db.py:201,242,433,650` | Record/replay before–after history and local ownership checks | External tamper-resistance or semantic truth |
| Stable identity — `wiki/app/knowledge_identity.py:88,136,201,260` | ID/revision catalog and typed relationships | Cross-machine custody identity |
| Knowledge retrieval — `wiki/hwi/knowledge_broker.py:64` | Bounded read-only, locally scoped retrieval; verified history/catalog | PVS approval or model instructions |
| Proposal ledger — `wiki/hwi/proposals.py:73,142,370` | Canonical immutable HWI-07 proposal records and states | Approving own proposal |
| Signed wiki writes — `wiki/hwi/reviewed_writes.py:37,60,114,246` | Verify exact HWI-08 signed proposal, one-use revision-checked local application | PVS or SEC-02 authorization |
| Local recovery — `wiki/hwi/recovery_inspection.py:205` | Read-only inspection of partial wiki application/receipt | Automatic reconciliation or retry |
| PVS candidate export — `wiki/hwi/pvs_handoff.py:44` | Read-only HWI-10 candidate preparation from signed wiki evidence | Writing/approving in PVS |
| Grounding and review — `wiki/hwi/journal_grounding.py:108`, `wiki/hwi/semantic_review.py:61,270` | Bind a candidate to journal/wiki evidence; independently signed semantic-review packets | Truth of review or signer identity |
| PVS write admission — `wiki/hwi/pvs_admission.py:109,162,197` | C4 signed operator instruction to write *unreviewed* draft; C13 lineage; C14-R1 snapshots | Approved memory or agent tool permission |
| Independent PVS review — `wiki/hwi/pvs_review_gate.py:183,232` | C5 reinspection of admission lineage and reviewed-selection match | Granting tool execution rights |
| Prompt guard — `wiki/hwi/runtime_guard.py:31,62`, `wiki/hwi/operator_startup.py:31` | C6 and C7 exact-selector/evidence checks before protected prompt use | Cross-process security isolation |
| PVS M5 selection — `agent/research_memory/pvs_memory_selector.py:26,70,145,174` | Credential-enforced reviewed memory selection and prompt-data insertion | Authorizing executable actions |
| Original PVS backend — `reference/pvs01_src/` | Bundled original reference for offline C4/C5/C6 integration tests | An independently controlled production service |
| Offline verification — `offline_testing/`, `agent/research_sec02/` | Synthetic, symbolic and contained research test fixtures | Real-model empirical evidence or deployment permission |

## Priority seams for the next checkpoints

- **RC-02:** C4/C5 signatures and authority fields remain dictionaries with runtime validation; internal typed value objects must preserve exactly serialized signed bytes and existing external schemas.
- **RC-03:** terminal `print`, `/dev/tty` and `input()` are embedded in agent runtime and a command component. Extract these via a narrowly scoped interaction port; keep the deny-only pilot intact.
- **RC-04:** Qt window calls application services directly and the component dependency cycle is only logged; clarify orchestration and startup failures after the preceding interfaces stabilize.

**Status:** inventory is an observation of this source tree, not proof of the security properties it describes. The default CLI does not automatically activate all HWI/PVS research components.
