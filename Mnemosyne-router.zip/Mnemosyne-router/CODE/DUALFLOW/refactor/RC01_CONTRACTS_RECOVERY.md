# RC-01.4 — Signed contracts, revisions and recovery invariants

This is an inventory of **current external formats and failure semantics to preserve**. No existing source is rewritten; exact bytes must be checked when RC-02 introduces internal types.

| Boundary | Existing contract / canonical bytes | Required invariant | Source anchors |
|---|---|---|---|
| HWI-07 proposal | `_canon`: ASCII JSON, sorted keys, compact separators, `allow_nan=False`; digest `HWI07-proposal-v1\x00` plus canonical record; events use separate `HWI07-event-v1\x00` | Proposal content, identity, revision and event lineage remain bound; drafts grant no authority | `wiki/hwi/proposals.py:73,142,313-370` |
| HWI-08 signed write | `hwi.review.v1` canonical JSON `review_message(entry)`; external Ed25519 signature | One proposal, scope, current revision and enrolled reviewer key; signature not PVS approval | `wiki/hwi/reviewed_writes.py:37,47,78,114,246` |
| C2 journal grounding | Journal `entry_sha256`, current head, selected event references, exact wiki revision | Candidate must relate to pinned source, not arbitrary model assertions | `agent/autogpt_lite/persistence/episode_journal.py:28,119,157`; `wiki/hwi/journal_grounding.py:108,183` |
| C3 semantic review | `hwi.semantic.review.packet.v1`, `hwi.semantic.review.decision.v1` and `hwi.semantic.review.signature.v1` | Review bytes checked with separately provided key, not self-promotion | `wiki/hwi/semantic_review.py:19-20,256-296` |
| C4 PVS admission | `hwi.pvs.admission.plan.v1`; signing bytes `b'HWI-C4-STORE-UNREVIEWED-PVS-DRAFT-V1\n' + _canon(plan).encode('utf-8')` | Signed intent authorizes storage only; no memory approval | `wiki/hwi/pvs_admission.py:23-24,162-194` |
| C13 lineage | `hwi.provenance.lineage.v1`; signature domain `HWI-C13-OPERATOR-LINEAGE-ATTESTATION-V1` + canonical manifest | Bind a declared ancestry graph and separately provided external origin pins; not exhaustive semantic truth | `wiki/hwi/provenance_gate.py:16-17,50,65,222` |
| C14-R1 receipt | `hwi.pvs.admission.receipt.v2` (not v1). Pre-write deep canonical snapshots of plan/packet/decision/draft/manifest/origins | Returned receipt and PVS write refer to the *same* signed lineage inputs; downstream C5 rechecks lineage. Legacy v1 cannot silently migrate | `wiki/hwi/pvs_admission.py:224-229,298-319`, `wiki/hwi/pvs_review_gate.py:77-167` |
| PVS M4 review | `pvs-memory-review-request-v1`, `pvs-memory-signed-review-v1`; `canonical_bytes` and Ed25519 signature | Approved current revision matches candidate and PVS source/proposal/review pins | `agent/research_memory/pvs_memory_review.py:26-42,292,311` |
| Reviewer revocation | `pvs-memory-review-credentials-envelope-v1`, signed registry | Enrollment/revocation must be checked for protected M5/C6; optional research selector must not be mistaken for a protected run | `agent/research_memory/pvs_memory_credentials.py:26,94-120`; `wiki/hwi/runtime_guard.py:34` |
| Local wiki recovery | `hwi.recovery.inspection.v1` with status and flags for no automatic retry/repair | Inspect observable cross-store footprint; do not turn `APPLIED_LOCALLY_LEDGER_OPEN` into broad authorization | `wiki/hwi/recovery_inspection.py:205,260-300` |
| HWI restart | `hwi.operator.handoff.v1` plus externally pinned saved-state and journal heads | Saved config cannot restore independent trust; provision fresh C7 guard | `wiki/hwi/operator_handoff.py:44,52` |
| SEC-02 review identity | `sec02.dispatch-review.v1` canonical hash; `pilot_preflight` & `pilot_dispatch_check` | Identity is diagnostic, **never** an authenticating authorization | `agent/autogpt_lite/sec02_dispatch.py:17,29,47` |

## Recovery and failure semantics to preserve

1. C4 `AdmissionCommitUncertain`: after an attempted PVS write, an exception is **COMMIT_UNCERTAIN**; inspect exact target history and do not automatically retry (`pvs_admission.py:312-320`). Similar review uncertainty exists in `pvs_memory_review.py:357`.
2. HWI-08 stores local receipts across two SQLite databases, **not** one atomic transaction; HWI-09 performs read-only inspection and requires manual reconciliation (`recovery_inspection.py:205-325`).
3. `AgentRuntime` checkpoints `PROPOSED` before human authorization and `AUTHORIZED_UNCERTAIN` before any allowed dispatch; restart cannot infer successful execution (`agent.py:323-348`).
4. C5/C6 use *exact Python object identities* plus fresh pinned source/PVS checks. Do not turn identity checks into hashes by moving a class into another process without an explicit, separately accepted protocol migration (`runtime_guard.py:11-44,62`).
5. SEC-02 closed pilot denies executable requests even if displayed or supplied with a user `yes`; `sec02.answer_only` is a distinct non-executable recorded text event (`agent.py:308-315,547-573`; `sec02_dispatch.py:29-48`).

## RC-02 compatibility gate

Compare external serialized bytes, hashes, signature verification outcomes, exception classifications and status flags against the frozen baseline. Where no comparable source evidence exists, label behavior **not established**, not passed. Never change externally signed bytes as an incidental dataclass cleanup.
