# RC-05.3 — Architecture value and maintenance-cost measurement

Method: `refactor/rc05_measure.py`, comparing the frozen 693-file RC-01 source lock with the RC-04 implementation in this candidate. Physical/nonblank Python line counts, AST classes/functions, and calls to `print()`/`input()` plus the literal `/dev/tty` are descriptive **static proxies**, not objective measures of future maintenance effort.

| Observed measure | C14-R2 | RC-04/05 | Change |
|---|---:|---:|---:|
| Python modules across agent core + wiki HWI/core | 70 | 74 | +4 |
| Physical Python lines in those packages | 16,929 | 17,321 | +392 (+2.3%) |
| Nonblank Python lines | 14,954 | 15,268 | +314 (+2.1%) |
| Classes | 109 | 128 | +19 |
| Functions/methods | 734 | 756 | +22 |
| Direct `print()`/`input()` in agent runtime + user input component | 43 | 0 | -43 |
| Literal `/dev/tty` in same core files | 1 | 0 | -1 |
| Frozen source files modified | — | 5 | +5 intentional changes |
| New files in frozen source areas | — | 6 | 4 app/core + 2 new agent test modules |

**What became easier to reason about:** (a) terminal interactions are isolated in an adapter; runtime and UI no longer share direct input calls; (b) status queries and command requests use typed application contracts and detached views; (c) PVS C4/C5 internal evidence gets typed snapshots while external signed records remain unchanged; (d) startup invalid graphs fail explicitly; (e) deterministic tests can drive the interface without a terminal.

**Cost/trade-off:** the implementation is larger by 392 physical lines in the measured package area and includes 19 more class definitions. The line count does not establish lower complexity; there is a real ongoing burden to maintain typed interfaces and adapters. We have not measured onboarding time, LLM correctness, or real feature development cost. A further wholesale Qt rewrite, general message bus, or interprocess rewrite lacks enough demonstrated incremental benefit at this stage.

**Diminishing-returns interpretation:** the boundary refactors have observable coupling and testability benefits despite increased size. Further generic abstractions are unlikely to pass the provisional value/effort cutoff of 1.5 without a specific failure or task demonstrating a need. This ratio remains a decision heuristic, not an empirically estimated statistic.
