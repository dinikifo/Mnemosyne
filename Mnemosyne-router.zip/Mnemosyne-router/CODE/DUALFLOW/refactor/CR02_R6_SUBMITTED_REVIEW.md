# CR02 Batch B-R6 — Saved Task Boundary Correction (Uncommitted)

**Disposition: REQUEST_REVIEW (not an owner acceptance or Git commit).**

## Scope
- IR-BR5-01: `AgentStore.list_agents()` advertises `task_valid` only for an explicitly present exact-string task. It preserves malformed JSON for read-only inspection.
- Both CLI listing modes render malformed tasks with a short, escaped `INVALID:` diagnostic rather than slicing/list-length errors.
- `AgentStore.load()` refuses missing/non-string task fields with `StateRecoveryError` before any provider construction. The CLI retains a defensive exact-type check before `OllamaProvider` construction.
- Existing explicitly stored empty-string tasks remain valid; absent task fields are rejected on resume and visibly marked invalid during listing. No missing task is silently replaced with a runnable default.
- SEC-02 deny-only dispatch, action fingerprint, request-bound authorization, journal recovery and signed PVS records remain unchanged.

## Evidence
- Original unmodified R5 reviewer tests plus previously submitted R5 cycle-counter contracts: **28 passed**.
- R6 copied reviewer tests (verbatim) and new saved-task contract tests: **27 passed**.
- Core compatibility tests in bounded partitions: **238 + 97 = 335 passed**.
- SEC-02: **358 passed + 9 subtests**.
- Wiki/PVS runtime integration: **4 passed**.
- **Total 697 distinct compatibility tests passed + 9 subtests.** Focused tests overlap this total.
- The first combined 335-test core run timed out with no final summary. Both bounded partitions completed and passed; the timeout is explicitly retained in the evidence.
- Fresh full-patch replay acceptance tests in bounded groups: **27 R6 + 17 retained R5 = 44 passed**. The initially combined fresh replay timed out without a final summary. Both partition runs completed.
- Full approved A-R6 to R6 patch and incremental B-R5 to R6 patch both reproduce the 1011-payload source archive **byte for byte, including SHA256_MANIFEST.json**.

## Conditions and limits
No Batch B Git commit, remote push, model deployment, permission widening or owner approval. Independent human review required. Exact clean pinned-dependency environment and actual operator terminal behavior remain unverified.
