# RC-05 test and reproducibility results

- **Before/after shared wiki tests:** C14-R2 30 passed + 8 subtests; RC-04 candidate 30 passed + 8 subtests.
- **Before/after shared agent tests:** C14-R2 63 passed; RC-04 candidate 63 passed.
- **Current-only tests:** RC-03 and RC-04 49 passed; refactor-tool tests 19 passed + 11 subtests. Total **161 distinct completed current tests**, plus 19 reported subtests. All these groups used the available interpreter, not a complete isolated pinned environment.
- **Clean-venv attempt:** pinned requirements installation FAILED due to unavailable package-index DNS and no complete local wheelhouse. Bundled application wheels installed with `--no-deps`; isolated package imports partly passed, but `hwi` cannot import without cryptography.
- **Wheel/source:** 53 packaged `.py` modules checked, 0 differing.
- **Lineage:** 699 files and 25 code anchors verified; unchanged baseline lock of 693 items.
- **Uncredited:** failed initially mislocated `tests/test_rc02_contracts.py` test selection; full clean C14-R2 runner and genuine-model tests not completed.

Detailed logs and limitations: `refactor/rc05_test_logs/`, `refactor/RC05_ENVIRONMENT.md`, `refactor/RC05_BEFORE_AFTER.md`.
