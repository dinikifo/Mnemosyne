"""Crash-window and operator-only cross-SQLite binding recovery tests."""
from __future__ import annotations

from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
import json
import sqlite3
import unittest

from . import test_governance as tg
from .cli import main
from .gate_store import GateStore
from .gate_recovery import recover_bindings
from .repository import Repository
from .review_queue import list_entries
from .task_fitness import FitnessError


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        # Use the real approved wiki/broker/ledger and signed fitness fixture;
        # do not replace the seam with a mock ledger that cannot commit.
        self.fix = tg.ReviewQueueTests('test_submit_does_not_change_wiki')
        self.fix.setUp()
        self.repo = Repository(self.fix.ws, 'primary')

    def tearDown(self):
        self.fix.tearDown()

    def command(self, *tail):
        out, err = StringIO(), StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = main(['queue-gate-recover', '--workspace', str(self.fix.ws.root),
                         '--notebook', 'primary', *tail])
        return code, json.loads(out.getvalue()) if code == 0 else err.getvalue()

    def stranded(self, *, spec=None):
        """Simulate an HWI-07 commit followed by a lost gate bind."""
        original = GateStore.bind
        try:
            def fail_bind(_self, _sha, _slot, _pid):
                raise OSError('simulated failure after ledger commit')
            GateStore.bind = fail_bind
            spec = spec or self.fix.agent_spec()
            args, assessment = self.fix.gate_args(spec)
            code, reason = self.fix.run_cli(args)
            self.assertEqual(code, 3, reason)
        finally:
            GateStore.bind = original
        return spec, assessment

    def extra_reservation(self, spec, assessment):
        sha = assessment['assessment_sha256']
        with GateStore(self.repo.root, 'primary', self.repo.scope(), writable=True) as store:
            receipt = json.loads(store.receipt(sha))
            verified = {'assessment_sha256':sha,
                        'reviewer_key_sha256':receipt['reviewer_key_sha256']}
            return store.reserve(receipt['assessment'],receipt['owner_decision'],verified,
                                 bytes.fromhex(receipt['owner_public_key_hex']),10,
                                 intent_spec=spec)

    def test_post_commit_recovery_replays_no_proposal_and_no_wiki_write(self):
        spec, assessment = self.stranded()
        entry = self.repo.list_proposals()[0]
        self.assertEqual(len(self.repo.list_proposals()), 1)
        self.assertEqual(list_entries(self.repo, 'primary')[0]['fitness_gate']['status'], 'UNVERIFIED')
        code, result = self.command()
        self.assertEqual(code, 0)
        self.assertEqual(result['reservations'][0]['status'], 'READY_TO_BIND')
        self.assertEqual(result['recovered'], 0)
        self.assertEqual(list_entries(self.repo, 'primary')[0]['fitness_gate']['status'], 'UNVERIFIED')
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['recovered'], 1)
        self.assertEqual(result['reservations'][0]['proposal_id'],entry['proposal_id'])
        self.assertEqual(len(self.repo.list_proposals()), 1)
        self.assertEqual(list_entries(self.repo, 'primary')[0]['fitness_gate']['status'], 'VERIFIED')
        with self.fix.ws.open_notebook('primary', readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'], 'Original claim')
        # An operator replay is idempotent and does not release quota.
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['recovered'], 0)
        with GateStore(self.repo.root,'primary',self.repo.scope()) as store:
            self.assertEqual(store.usage(assessment['assessment_sha256']), {'reserved':0,'bound':1})

    def test_exact_mismatch_never_recovers_or_releases_quota(self):
        spec, assessment = self.stranded()
        # Damage the *recovery intent* in a different way to test semantic mismatch:
        # add another reservation with a completely different proposed text.
        wrong = dict(spec, proposed=dict(spec['proposed'], text='not the proposal'))
        self.extra_reservation(wrong, assessment)
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['recovered'], 1)
        states = [r['status'] for r in result['reservations']]
        self.assertEqual(states, ['BOUND_BY_OPERATOR_RECOVERY', 'NO_EXACT_MATCH'])
        with GateStore(self.repo.root,'primary',self.repo.scope()) as store:
            self.assertEqual(store.usage(assessment['assessment_sha256']), {'reserved':1,'bound':1})

    def test_ambiguous_intents_do_not_bind(self):
        spec, assessment = self.stranded()
        self.extra_reservation(spec, assessment)
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['recovered'], 0)
        self.assertEqual([r['status'] for r in result['reservations']],
                         ['AMBIGUOUS','AMBIGUOUS'])
        self.assertEqual(list_entries(self.repo,'primary')[0]['fitness_gate']['status'],'UNVERIFIED')

    def test_legacy_reservation_is_not_guessed(self):
        spec, assessment = self.stranded()
        with GateStore(self.repo.root, 'primary', self.repo.scope(), writable=True) as store:
            store._conn.execute('DROP TRIGGER submission_intents_delete_only_with_slot')
            store._conn.execute('DELETE FROM submission_intents')  # simulate pre-extension store
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['reservations'][0]['status'], 'LEGACY_NO_INTENT')
        self.assertEqual(result['recovered'], 0)

    def test_intent_is_immutable_during_reserved_slot(self):
        self.stranded()
        with GateStore(self.repo.root,'primary',self.repo.scope(), writable=True) as store:
            with self.assertRaises(sqlite3.DatabaseError):
                store._conn.execute('DELETE FROM submission_intents')
            with self.assertRaises(sqlite3.DatabaseError):
                store._conn.execute("UPDATE submission_intents SET intent_json='{}'")

    def test_corrupt_intent_is_hard_failure(self):
        self.stranded()
        with GateStore(self.repo.root, 'primary', self.repo.scope(), writable=True) as store:
            store._conn.execute('DROP TRIGGER submission_intents_immutable_u')
            store._conn.execute("UPDATE submission_intents SET intent_json='{}'")
        code, error = self.command('--apply')
        self.assertEqual(code, 2)
        self.assertIn('digest mismatch', error)
        self.assertEqual(self.repo.list_proposals()[0]['state'], 'SUBMITTED')

    def test_existing_store_additive_upgrade_and_read_only_diagnostic(self):
        scope = self.repo.scope()
        with GateStore(self.repo.root,'primary',scope,create=True) as store:
            store._conn.execute('DROP TRIGGER submission_intents_immutable_u')
            store._conn.execute('DROP TRIGGER submission_intents_delete_only_with_slot')
            store._conn.execute('DROP TABLE submission_intents')  # simulate legacy schema
            store.reserve({'x':1},{'y':2},
                          {'assessment_sha256':'c'*64,'reviewer_key_sha256':'d'*64},
                          b'\x01'*32,1)  # legacy slot (no snapshot)
        with GateStore(self.repo.root,'primary',scope,create=False) as store:
            self.assertEqual(store.reservations()[0]['intent_spec'],None)
            table_before = store._conn.execute("SELECT 1 FROM sqlite_master WHERE name='submission_intents'").fetchone()
            self.assertIsNone(table_before)
        with GateStore(self.repo.root,'primary',scope,create=True) as store:
            self.assertEqual(store.reservations()[0]['intent_spec'],None)
            self.assertTrue(store._conn.execute("SELECT 1 FROM sqlite_master WHERE name='submission_intents'").fetchone())

    def test_unknown_failure_without_ledger_commit_keeps_quota(self):
        from unittest.mock import patch
        spec = self.fix.agent_spec()
        args, assessment = self.fix.gate_args(spec)
        with patch('hwi_governance.cli.submit_proposal',side_effect=OSError('uncertain I/O')):
            code, error = self.fix.run_cli(args)
        self.assertEqual(code, 3)
        self.assertIn('SUBMISSION_OUTCOME_UNKNOWN',error)
        self.assertEqual(len(self.repo.list_proposals()), 0)
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['reservations'][0]['status'],'NO_EXACT_MATCH')
        with GateStore(self.repo.root,'primary',self.repo.scope()) as store:
            self.assertEqual(store.usage(assessment['assessment_sha256']), {'reserved':1,'bound':0})

    def test_commit_then_unknown_failure_can_recover(self):
        from unittest.mock import patch
        from .review_queue import submit_proposal
        spec = self.fix.agent_spec()
        args, _ = self.fix.gate_args(spec)
        def commit_then_raise(repo, notebook, spec):
            submit_proposal(repo,notebook,spec)
            raise OSError('lost success response')
        with patch('hwi_governance.cli.submit_proposal',side_effect=commit_then_raise):
            code, reason = self.fix.run_cli(args)
        self.assertEqual(code, 3)
        self.assertIn('SUBMISSION_OUTCOME_UNKNOWN',reason)
        self.assertEqual(len(self.repo.list_proposals()), 1)
        code, result = self.command('--apply')
        self.assertEqual(code, 0)
        self.assertEqual(result['recovered'], 1)
        self.assertEqual(list_entries(self.repo,'primary')[0]['fitness_gate']['status'], 'VERIFIED')

    def test_definite_rejection_releases_intent_and_slot(self):
        bad = self.fix.agent_spec(expected_revision_sha256='f'*64)
        args, assessment = self.fix.gate_args(bad)
        code, error = self.fix.run_cli(args)
        self.assertEqual(code, 2)
        with GateStore(self.repo.root,'primary',self.repo.scope()) as store:
            self.assertEqual(store.reservations(),[])
            self.assertEqual(store.usage(assessment['assessment_sha256']), {'reserved':0,'bound':0})
            self.assertEqual(store._conn.execute('SELECT count(*) FROM submission_intents').fetchone()[0],0)


    # ---- review fixes: normalisation and visible recovered bindings ----------
    def padded_spec(self):
        spec = self.fix.agent_spec(reason='  padded reason  ')
        spec['source_refs'] = ['  external:testcase  ']
        spec['proposed'] = dict(spec['proposed'], title='  Evidence  ')
        return spec

    def test_padded_inputs_recover(self):
        self.stranded(spec=self.padded_spec())
        code, diag = self.command()
        self.assertEqual([r['status'] for r in diag['reservations']], ['READY_TO_BIND'])
        code, applied = self.command('--apply')
        self.assertEqual(applied['recovered'], 1)
        gate = list_entries(self.fix.ws, 'primary')[0]['fitness_gate']
        self.assertEqual((gate['status'], gate['binding']), ('VERIFIED', 'OPERATOR_RECOVERY'))

    def test_untrimmed_legacy_intent_still_matches(self):
        """Intents saved by df6ec53 before submit-time normalisation hold raw values."""
        from .review_queue import submit_proposal
        from .task_fitness import fitness_ref
        raw = self.padded_spec()
        args, assessment = self.fix.gate_args(self.fix.agent_spec(reason='seed', proposed=dict(
            self.fix.agent_spec()['proposed'], text='seed text')))
        self.assertEqual(self.fix.run_cli(args)[0], 0)  # creates receipt + store
        self.extra_reservation(raw, assessment)  # raw, untrimmed intent
        committed = dict(raw, source_refs=raw['source_refs'] + [fitness_ref(assessment['assessment_sha256'])])
        submit_proposal(self.fix.ws, 'primary', committed)  # ledger trims on commit
        code, diag = self.command()
        self.assertIn('READY_TO_BIND', [r['status'] for r in diag['reservations']])

    def test_normal_submission_is_marked_gate_submission(self):
        args, _ = self.fix.gate_args(self.fix.agent_spec())
        self.assertEqual(self.fix.run_cli(args)[0], 0)
        gate = list_entries(self.fix.ws, 'primary')[0]['fitness_gate']
        self.assertEqual((gate['status'], gate['binding']), ('VERIFIED', 'GATE_SUBMISSION'))

    def test_recovered_marker_visible_in_status_and_immutable(self):
        from .review_queue import status_projection
        self.stranded()
        self.command('--apply')
        rows = status_projection(self.fix.ws, 'primary')['proposals']
        self.assertEqual([(r['fitness_gate_status'], r['fitness_binding']) for r in rows],
                         [('VERIFIED', 'OPERATOR_RECOVERY')])
        with GateStore(self.repo.root, 'primary', self.repo.scope()) as store:
            path = store.path
        conn = sqlite3.connect(str(path), isolation_level=None)
        for sql in ("UPDATE recovered_bindings SET proposal_id='proposal:x'", 'DELETE FROM recovered_bindings'):
            with self.subTest(sql=sql), self.assertRaises(sqlite3.DatabaseError):
                conn.execute(sql)
        conn.close()

    def test_padded_fitness_reference_cannot_slip_past_spec_check(self):
        from .task_fitness import fitness_ref
        spec = self.fix.agent_spec(source_refs=['external:testcase', ' ' + fitness_ref('a' * 64)])
        args, _ = self.fix.gate_args(spec)
        code, err = self.fix.run_cli(args)
        self.assertEqual(code, 2)
        self.assertIn('added by the gate', err)
        self.assertEqual(list_entries(self.fix.ws, 'primary'), [])

if __name__ == '__main__':
    unittest.main()
