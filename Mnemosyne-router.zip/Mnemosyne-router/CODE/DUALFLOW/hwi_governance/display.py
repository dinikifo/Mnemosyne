"""Reviewer-facing JSON: readable text, visible tricks.

``json.dumps(ensure_ascii=True)`` keeps output safe but turns every non-ASCII
letter (e.g. Greek) into ``\\uXXXX``, which makes review of real content
impractical. This encoder starts from the ASCII-safe form and restores only
printable characters. Anything a reviewer could not see or that could reorder
what they see stays escaped: control and format characters (bidi overrides,
zero-width joiners/spaces, soft hyphen), line/paragraph separators,
private-use, unassigned and surrogate code points, and non-ASCII spaces.
Characters outside the Basic Multilingual Plane also stay escaped.

The result is valid JSON that parses to exactly the same value.
Homoglyphs (e.g. Cyrillic 'а' vs Latin 'a') are not detected.
"""
from __future__ import annotations

import json
import re
import unicodedata

_UNSAFE_CATEGORIES = frozenset(('Cc', 'Cf', 'Cs', 'Co', 'Cn', 'Zl', 'Zp', 'Zs'))
# Escape sequences preceded by an even number of backslashes are real \u escapes.
_ESCAPE = re.compile(r'(?<!\\)((?:\\\\)*)\\u([0-9a-f]{4})')


def _visible(code: int) -> bool:
    ch = chr(code)
    return code >= 0xA0 and unicodedata.category(ch) not in _UNSAFE_CATEGORIES


def readable_json(value, *, indent=2) -> str:
    text = json.dumps(value, ensure_ascii=True, sort_keys=True, indent=indent, allow_nan=False)
    def restore(match):
        code = int(match.group(2), 16)
        return match.group(1) + (chr(code) if _visible(code) else match.group(0)[len(match.group(1)):])
    return _ESCAPE.sub(restore, text)


def visible_text(text, *, keep_newlines: bool = False) -> str:
    """Plain-text counterpart of ``readable_json`` for one-line terminal output.

    Printable characters (Greek included) stay as written; control, format
    (bidi overrides, zero-width), separator, private-use and unassigned
    characters are shown as visible ``\\uXXXX`` escapes; tabs and newlines too.
    """
    out = []
    for ch in str(text):
        code = ord(ch)
        if ((code >= 0xA0 and unicodedata.category(ch) not in _UNSAFE_CATEGORIES) or 0x20 <= code < 0x7F
                or (keep_newlines and ch == '\n')):
            out.append(ch)
        else:
            out.append(f'\\u{code:04x}' if code <= 0xFFFF else f'\\U{code:08x}')
    return ''.join(out)
