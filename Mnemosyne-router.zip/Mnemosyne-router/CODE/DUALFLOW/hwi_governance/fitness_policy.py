"""Operator-provisioned fitness key pin and gate verification.

Policy pins stay as operator-written files (this module has NO pin-writing API):

    <workspace>/fitness_policy/<notebook>.json      (dir 0700, file 0600)

They bind the physical notebook scope to one fitness key fingerprint, which must
differ from the notebook's HWI-08 wiki reviewer key.

Gate records (receipts and quota slots) live in the per-installation SQLite
store (``gate_store``). ``gate_status`` re-verifies a ledger entry's
``external:hwi-fitness/<sha>`` reference against that store and the pin: the
owner signature must verify, the operation must be in scope, and the gate's own
BOUND slot must name this exact proposal. A copied reference therefore shows
UNVERIFIED, and a process that can write the workspace remains outside the
threat model.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
from pathlib import Path
import sqlite3
import stat

from .gate_store import GateStore, RECEIPT_SCHEMA
from .task_fitness import FITNESS_REF_PREFIX, FitnessError, SHA, verify_owner_decision

POLICY_SCHEMA = 'hwi.task_fitness.policy.v1'


def _private_dir(path: Path, label: str):
    if path.is_symlink() or not path.is_dir():
        raise FitnessError(f'{label} directory missing or unsafe')
    if os.name == 'posix' and path.stat().st_mode & 0o077:
        raise FitnessError(f'{label} directory must be private (0700)')


def _private_file(path: Path, label: str, max_size: int):
    if path.is_symlink() or not path.is_file():
        raise FitnessError(f'{label} is missing')
    st = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
        raise FitnessError(f'{label} must be a single-link regular file')
    if os.name == 'posix' and st.st_mode & 0o077:
        raise FitnessError(f'{label} must have mode 0600')
    if st.st_size > max_size:
        raise FitnessError(f'Oversized {label}')


def _strict_json(text):
    def pairs(items):
        data = {}
        for key, value in items:
            if key in data:
                raise FitnessError('Duplicate JSON key')
            data[key] = value
        return data
    return json.loads(text, object_pairs_hook=pairs)


def policy_path(root, notebook) -> Path:
    return Path(root) / 'fitness_policy' / (notebook + '.json')


def _wiki_reviewer_pin(root, notebook):
    path = Path(root) / 'review_policy' / (notebook + '.json')
    if path.is_symlink() or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text('utf-8'))
    except (OSError, ValueError, UnicodeError):
        return None
    return data.get('reviewer_key_sha256') if type(data) is dict else None


def load_fitness_pin(root, notebook, scope) -> str:
    """Operator-pinned fitness key fingerprint for this exact notebook scope."""
    path = policy_path(root, notebook)
    _private_dir(path.parent, 'Operator fitness policy')
    _private_file(path, 'Operator fitness policy', 2048)
    try:
        policy = _strict_json(path.read_text('utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise FitnessError('Invalid operator fitness policy') from exc
    if type(policy) is not dict or set(policy) != {'schema','notebook_scope','fitness_key_sha256'}:
        raise FitnessError('Unexpected operator fitness policy fields')
    if policy['schema'] != POLICY_SCHEMA or policy['notebook_scope'] != scope:
        raise FitnessError('Fitness policy does not match this notebook scope')
    pin = policy['fitness_key_sha256']
    if type(pin) is not str or not SHA.fullmatch(pin):
        raise FitnessError('Invalid fitness key fingerprint in policy')
    if pin == _wiki_reviewer_pin(root, notebook):
        raise FitnessError('Fitness key must differ from the HWI-08 wiki reviewer key')
    return pin


def proposal_fitness_refs(entry):
    return [r for r in entry['record'].get('source_refs', []) if r.startswith(FITNESS_REF_PREFIX)]


def gate_status(root, notebook, scope, entry) -> dict:
    """Re-verify the fitness gate recorded on a ledger entry. Never raises for display use."""
    refs = proposal_fitness_refs(entry)
    if not refs:
        return {'status':'UNGATED','detail':'No task-fitness reference (restore helper, library or legacy HWI-07 API)'}
    if len(refs) != 1:
        return {'status':'INVALID','detail':'Multiple fitness references'}
    sha = refs[0][len(FITNESS_REF_PREFIX):]
    try:
        if not SHA.fullmatch(sha):
            raise FitnessError('Malformed fitness reference')
        pin = load_fitness_pin(root, notebook, scope)
        with GateStore(root, notebook, scope) as store:
            raw = store.receipt(sha)
            if raw is None:
                raise FitnessError('No gate receipt for this reference')
            bound = store.is_bound(sha, entry['proposal_id'])
            recovered = bound and store.is_recovered(sha, entry['proposal_id'])
        receipt = _strict_json(raw)
        if (type(receipt) is not dict or receipt.get('schema') != RECEIPT_SCHEMA or
                set(receipt) != {'schema','assessment','owner_decision','reviewer_key_sha256',
                                 'owner_public_key_hex'}):
            raise FitnessError('Malformed fitness receipt')
        assessment = receipt['assessment']
        if type(assessment) is not dict or assessment.get('assessment_sha256') != sha:
            raise FitnessError('Receipt does not match the referenced assessment')
        if receipt['reviewer_key_sha256'] != pin:
            raise FitnessError('Receipt signed under a key that is no longer pinned')
        # Expiry limits new submissions; it does not retroactively invalidate a gate.
        as_of = _dt.date.fromisoformat(assessment['valid_until'])
        key = receipt['owner_public_key_hex']
        if type(key) is not str or len(key) != 64:
            raise FitnessError('Malformed receipt public key')
        verified = verify_owner_decision(assessment, receipt['owner_decision'],
                                         bytes.fromhex(key), pin, today=as_of)
        if entry['record']['operation'] not in verified['allowed_operations']:
            raise FitnessError('Proposal operation outside signed scope')
        if assessment['notebook'] != notebook:
            raise FitnessError('Receipt names a different notebook')
        if not bound:
            raise FitnessError('No gate usage record for this proposal (reference not written by the gate)')
        return {'status':'VERIFIED',
                'binding':'OPERATOR_RECOVERY' if recovered else 'GATE_SUBMISSION',
                'detail':('Owner-signed task scope re-verified against workspace pin; bound by explicit '
                          'operator recovery to an exactly matching ledger record, which the gate '
                          'itself may not have submitted' if recovered else
                          'Owner-signed task scope re-verified against workspace pin'),
                'task_id':assessment['task_id'],'assessment_sha256':sha,
                'valid_until':assessment['valid_until'],'max_proposals':assessment['max_proposals']}
    except (FitnessError, ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        return {'status':'UNVERIFIED','detail':f'{type(exc).__name__}: {exc}'}
