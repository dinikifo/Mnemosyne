"""CMR-10: substitutable operator-only governance *read* ports.

The router conveys opaque identities and SHA-256 metadata, never ledger bodies,
owner signatures, review signatures, or privileged effect executors. A successful
route is NOT approval, fitness verification, submission, or permission to write.
All real reads remain delegated to the existing governance services.
"""
from __future__ import annotations

from hashlib import sha256
from typing import Protocol
import json

import re


class GovernanceReadPort(Protocol):
    def status(self, repo: object) -> dict: ...
    def review(self, repo: object, proposal_id: str) -> dict: ...


class DirectGovernanceReadPort:
    """The legacy, authoritative on-demand read behavior."""

    def status(self, repo: object) -> dict:
        from .review_queue import status_projection
        return status_projection(repo, repo.notebook)

    def review(self, repo: object, proposal_id: str) -> dict:
        from .review_queue import review_entry
        return review_entry(repo, repo.notebook, proposal_id)


_MAX_RESULT_BYTES = 4_000_000
_GATE_STATES = frozenset({'VERIFIED', 'UNVERIFIED', 'UNGATED', 'INVALID'})
_ROW_KEYS = frozenset({'proposal_id', 'ledger_state', 'operation',
                       'wiki_receipt_present', 'fitness_gate_status', 'fitness_binding'})
_STATUS_KEYS = frozenset({'schema', 'status', 'notebook', 'total', 'pending', 'applied',
                          'proposals', 'wiki_modified', 'approval_authorized',
                          'execution_authorized', 'note'})
_REVIEW_KEYS = frozenset({'proposal_id', 'state', 'operation', 'target_ref',
                          'expected_revision_sha256', 'source_refs', 'reason', 'diff',
                          'before', 'after', 'note', 'may_mutate_wiki',
                          'human_authorized', 'fitness_gate'})


def _canonical_digest(result: object) -> str:
    try:
        encoded = json.dumps(result, sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise ValueError('CMR-10 invalid read projection') from exc
    if len(encoded) > _MAX_RESULT_BYTES:
        raise ValueError('CMR-10 read projection exceeds opt-in size limit')
    return sha256(encoded).hexdigest()


def _valid_status(result: object, notebook: str) -> bool:
    if (type(result) is not dict or set(result) != _STATUS_KEYS or
            result['schema'] != 'hwi.governance.review_status.v0' or
            result['status'] != 'LIVE_QUERY_READ_ONLY' or
            result['notebook'] != notebook or
            any(result[k] is not False for k in (
                'wiki_modified', 'approval_authorized', 'execution_authorized')) or
            type(result['note']) is not str or
            type(result['proposals']) is not list):
        return False
    rows = result['proposals']
    if (any(type(result[k]) is not int or result[k] < 0 for k in (
            'total', 'pending', 'applied')) or result['total'] != len(rows)):
        return False
    for row in rows:
        if (type(row) is not dict or set(row) != _ROW_KEYS or
                type(row['proposal_id']) is not str or
                re.fullmatch(r'proposal:[0-9a-f]{32}', row['proposal_id']) is None or
                type(row['ledger_state']) is not str or
                type(row['operation']) is not str or
                type(row['wiki_receipt_present']) is not bool or
                type(row['fitness_gate_status']) is not str or
                row['fitness_gate_status'] not in _GATE_STATES or
                row['fitness_binding'] not in (None, 'GATE_SUBMISSION', 'OPERATOR_RECOVERY') or
                (row['fitness_binding'] is not None and
                 row['fitness_gate_status'] != 'VERIFIED')):
            return False
    return (result['pending'] == sum(r['ledger_state'] == 'SUBMITTED' and
                                     not r['wiki_receipt_present'] for r in rows) and
            result['applied'] == sum(r['wiki_receipt_present'] for r in rows))


def _valid_review(result: object, proposal_id: str) -> bool:
    if (type(result) is not dict or set(result) != _REVIEW_KEYS or
            result['proposal_id'] != proposal_id or
            result['human_authorized'] is not False or
            result['may_mutate_wiki'] is not False or
            type(result['fitness_gate']) is not dict or
            type(result['fitness_gate'].get('status')) is not str or
            result['fitness_gate']['status'] not in _GATE_STATES or
            any(type(result[k]) is not str for k in (
                'state', 'operation', 'target_ref', 'expected_revision_sha256',
                'reason', 'diff', 'note')) or
            type(result['source_refs']) is not list or
            type(result['before']) is not dict or type(result['after']) is not dict):
        return False
    return True


def _router(context: dict[str, object]):
    """Fresh in-process flow with a local, reviewed, default-deny profile."""
    from hwi_router.read_protocol import open_read_profile
    def guard(key, msg, _snapshot):
        payload = msg.payload
        if payload.get('notebook') != context['notebook'] or payload.get('scope_sha256') != context['scope_sha256']:
            return False
        if key == 'operator_status_scope_pinned':
            return msg.origin == 'governance_operator'
        if key == 'operator_review_scope_pinned':
            return (msg.origin == 'governance_operator' and
                    payload.get('proposal_id') == context['proposal_id'])
        if key == 'projection_status_pinned':
            return (msg.origin == 'governance_projection' and
                    payload.get('result_sha256') == context.get('result_sha256') and
                    payload.get('total') == context.get('total') and
                    payload.get('pending') == context.get('pending') and
                    payload.get('applied') == context.get('applied'))
        if key == 'projection_review_pinned':
            return (msg.origin == 'governance_projection' and
                    payload.get('proposal_id') == context.get('proposal_id') and
                    payload.get('result_sha256') == context.get('result_sha256') and
                    payload.get('gate_status') == context.get('gate_status'))
        return False

    return open_read_profile('CMR-10', guard)


def _route(router, flow, source, kind, payload, *, parent=None, expected_transition, effect=None):
    from hwi_router.read_protocol import dispatch_read_message
    return dispatch_read_message(router, flow, source, kind, payload,
                                 parent=parent, transition=expected_transition,
                                 effect=effect)


class RoutedGovernanceReadPort:
    """Opt-in status/review read only; never submits proposals or applies reviews.

    A failed/uncertain read does not retry and does not auto-fallback to the
    direct service. The operator may repeat an explicitly requested read.
    """

    def __init__(self, delegate: GovernanceReadPort | None = None):
        self.delegate = delegate if delegate is not None else DirectGovernanceReadPort()

    def _context(self, repo: object) -> dict[str, object]:
        # Scope is derived inside the trusted governance repository, not from
        # a message/source tag or caller-provided payload.
        return {'notebook': repo.notebook,
                'scope_sha256': sha256(repo.scope().encode('utf-8')).hexdigest()}

    def status(self, repo: object) -> dict:
        context = self._context(repo)
        router, flow, src = _router(context)
        request = _route(router, flow, src['governance_operator'],
                         'governance.status.request', dict(context),
                         expected_transition='G01', effect='governance.status.read')
        result = self.delegate.status(repo)  # exactly once, after validated request
        if not _valid_status(result, repo.notebook):
            raise ValueError('CMR-10 unverified status projection')
        context.update(result_sha256=_canonical_digest(result),
                       total=result['total'], pending=result['pending'], applied=result['applied'])
        _route(router, flow, src['governance_projection'], 'governance.status.result',
               {k: context[k] for k in ('notebook', 'scope_sha256', 'result_sha256',
                                          'total', 'pending', 'applied')},
               parent=request, expected_transition='G02')
        return result

    def review(self, repo: object, proposal_id: str) -> dict:
        context = self._context(repo)
        context['proposal_id'] = proposal_id
        router, flow, src = _router(context)
        request = _route(router, flow, src['governance_operator'],
                         'governance.review.request', dict(context),
                         expected_transition='G03', effect='governance.proposal.review_read')
        result = self.delegate.review(repo, proposal_id)  # one real read, no retry
        if not _valid_review(result, proposal_id):
            raise ValueError('CMR-10 unverified proposal review view')
        context.update(result_sha256=_canonical_digest(result),
                       gate_status=result['fitness_gate']['status'])
        _route(router, flow, src['governance_projection'], 'governance.review.result',
               {k: context[k] for k in ('notebook', 'scope_sha256', 'proposal_id',
                                         'result_sha256', 'gate_status')},
               parent=request, expected_transition='G04')
        return result
