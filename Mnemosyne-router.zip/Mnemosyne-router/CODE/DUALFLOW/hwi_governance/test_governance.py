"""Offline tests for task fitness and reviewed wiki queue. Scratch notebooks only."""
from __future__ import annotations
import copy
import datetime
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from .task_fitness import (FitnessError, assess, digest, signing_message,
                           validate_contract, verify_owner_decision, fitness_ref)
from .review_queue import (list_entries, render_review_section, submit_proposal,
                           restore_as_proposal, signing_payload, apply_review, history_view,
                           review_entry, EXPORT_LIMIT)
from .cli import read_json, write_once, public_key_bytes, main
from personal_wiki_core import NotebookWorkspace
from hwi.knowledge_broker import ReadOnlyKnowledgeBroker
from hwi.proposals import KnowledgeProposalLedger
from hwi.reviewed_writes import AlreadyApplied, StaleReview, ReviewWriteError

H = '0'*64
TODAY = datetime.datetime.now(datetime.timezone.utc).date()

def in_days(n):
    return (TODAY + datetime.timedelta(days=n)).isoformat()

def example(**overrides):
    contract = {
      'schema':'hwi.task_fitness.contract.v2','valid_until':in_days(30),'max_proposals':10,'task_id':'historical_research',
      'domain':'history','objective':'Identify source contradictions without claiming general reliability',
      'configuration':{'model':'llama3.1:8b','model_sha256':'1'*64,'prompt_sha256':'2'*64,
                       'workflow_sha256':'3'*64,'tools_sha256':'4'*64,'evidence_scope_sha256':'5'*64},
      'notebook':'primary','allowed_operations':['revise'],
      'cases':[{'case_id':f'case{i}','purpose':f'Example evidence check {i}',
                'critical': i == 1,'evidence_sha256':str(i)*64} for i in range(1,4)],
      'acceptance':{'min_pass_percent':66,'max_unknown':0,'require_all_critical_pass':True}}
    contract.update(overrides)
    results = {'schema':'hwi.task_fitness.results.v2',
               'contract_sha256':digest(contract),
               'configuration_sha256':digest(contract['configuration']),
               'results':[{'case_id':f'case{i}','status':'PASS',
                            'evidence_sha256':str(i)*64, 'evaluator_note':'Reviewed synthetic expectation'}
                           for i in range(1,4)]}
    return contract, results

def key_pair():
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    return priv, pub

class TaskFitnessTests(unittest.TestCase):
    def setUp(self):
        self.contract,self.results=example()
        self.assessment=assess(self.contract,self.results)
        self.sk,self.pub=key_pair()
        self.pin=hashlib.sha256(self.pub).hexdigest()
        self.decision={'schema':'hwi.task_fitness.owner_decision.v2',
                       'assessment_sha256':self.assessment['assessment_sha256'],
                       'decision':'APPROVE_FOR_DECLARED_TASK',
                       'signature_hex':self.sk.sign(signing_message(self.assessment)).hex()}
    def test_eligible_not_automatically_fit(self):
        self.assertEqual(self.assessment['status'],'ELIGIBLE_FOR_HUMAN_TASK_APPROVAL')
        self.assertFalse(self.assessment['execution_authorized'])
        self.assertFalse(self.assessment['independently_verified'])
    def test_signing_requires_key_pin(self):
        record=verify_owner_decision(self.assessment,self.decision,self.pub,self.pin)
        self.assertEqual(record['status'],'OWNER_SIGNED_TASK_SCOPE_ONLY')
        self.assertFalse(record['wiki_write_authorized'])
        self.assertFalse(record['general_competence_claimed'])
    def test_wrong_key_rejected(self):
        _, other = key_pair()
        with self.assertRaises(FitnessError):
            verify_owner_decision(self.assessment,self.decision,other,self.pin)
    def test_wrong_signature_rejected(self):
        tampered=copy.deepcopy(self.decision)
        tampered['signature_hex']='0'*128
        with self.assertRaises(FitnessError):
            verify_owner_decision(self.assessment,tampered,self.pub,self.pin)
    def test_tampered_assessment_rejected(self):
        value=copy.deepcopy(self.assessment)
        value['pass_percent']=0
        with self.assertRaises(FitnessError):
            signing_message(value)
    def test_failed_critical_never_eligible(self):
        trial=copy.deepcopy(self.results)
        trial['results'][0]['status']='FAIL'
        check=assess(self.contract,trial)
        self.assertEqual(check['status'],'NOT_ELIGIBLE')
        with self.assertRaises(FitnessError):
            signing_message(check)
    def test_below_threshold_not_eligible(self):
        trial=copy.deepcopy(self.results)
        trial['results'][1]['status']='FAIL';trial['results'][2]['status']='FAIL'
        check=assess(self.contract,trial)
        self.assertEqual(check['status'],'NOT_ELIGIBLE')
    def test_unknown_is_not_pass(self):
        trial=copy.deepcopy(self.results); trial['results'][2]['status']='UNKNOWN'
        self.assertEqual(assess(self.contract,trial)['status'],'NOT_ELIGIBLE')
    def test_config_pin_mismatch(self):
        trial=copy.deepcopy(self.results); trial['configuration_sha256']='f'*64
        with self.assertRaises(FitnessError):
            assess(self.contract,trial)
    def test_contract_pin_mismatch(self):
        trial=copy.deepcopy(self.results);trial['contract_sha256']='f'*64
        with self.assertRaises(FitnessError):
            assess(self.contract,trial)
    def test_missing_duplicate_and_extra_results_rejected(self):
        for mutation in ('missing','duplicate','extra'):
            trial=copy.deepcopy(self.results)
            if mutation == 'missing': trial['results'].pop()
            elif mutation=='duplicate': trial['results'][2]['case_id']='case1'
            else: trial['results'].append(copy.deepcopy(trial['results'][2]))
            with self.subTest(mutation=mutation),self.assertRaises(FitnessError):
                assess(self.contract,trial)
    def test_critical_cannot_be_disabled(self):
        bad=copy.deepcopy(self.contract)
        bad['acceptance']['require_all_critical_pass']=False
        with self.assertRaises(FitnessError): validate_contract(bad)
    def test_no_fake_general_task_permissions(self):
        bad=copy.deepcopy(self.contract);bad['allowed_operations'].append('shell_exec')
        with self.assertRaises(FitnessError): validate_contract(bad)
    def test_invalid_case_pin(self):
        bad=copy.deepcopy(self.contract);bad['cases'][0]['evidence_sha256']='wrong'
        with self.assertRaises(FitnessError): validate_contract(bad)

    def test_contract_requires_a_critical_case(self):
        bad=copy.deepcopy(self.contract)
        for case in bad['cases']: case['critical']=False
        with self.assertRaises(FitnessError): validate_contract(bad)
    def test_pass_floor_enforced(self):
        for value in (0,49):
            bad=copy.deepcopy(self.contract); bad['acceptance']['min_pass_percent']=value
            with self.subTest(value=value),self.assertRaises(FitnessError): validate_contract(bad)
    def test_all_fail_can_never_be_eligible(self):
        trial=copy.deepcopy(self.results)
        for row in trial['results']: row['status']='FAIL'
        self.assertEqual(assess(self.contract,trial)['status'],'NOT_ELIGIBLE')
    def test_expired_or_overlong_contract_rejected(self):
        for value in (in_days(-1),in_days(400),'2027-02-30','tomorrow'):
            bad=copy.deepcopy(self.contract); bad['valid_until']=value
            with self.subTest(value=value),self.assertRaises(FitnessError): validate_contract(bad)
    def test_signed_scope_expires(self):
        later=TODAY+datetime.timedelta(days=31)
        with self.assertRaises(FitnessError):
            verify_owner_decision(self.assessment,self.decision,self.pub,self.pin,today=later)
    def test_quota_bounds(self):
        for value in (0,1001,'5'):
            bad=copy.deepcopy(self.contract); bad['max_proposals']=value
            with self.subTest(value=value),self.assertRaises(FitnessError): validate_contract(bad)
    def test_v1_contract_refused(self):
        bad=copy.deepcopy(self.contract); bad['schema']='hwi.task_fitness.contract.v1'
        with self.assertRaises(FitnessError): validate_contract(bad)
    def test_signing_message_names_scope(self):
        message=json.loads(signing_message(self.assessment))
        self.assertEqual(message['allowed_operations'],['revise'])
        self.assertEqual(message['max_proposals'],10)
        self.assertEqual(message['valid_until'],in_days(30))

class ReviewQueueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name).resolve(strict=True)
        self.ws=NotebookWorkspace(self.root/'workspace',create=True)
        self.ws.create_notebook('primary')
        with self.ws.open_notebook('primary',readonly=False) as wiki:
            wiki.save_tiddler('Evidence','Original claim', ['research'],reason='test seed')
            wiki.knowledge_catalog().initialize()
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            self.original=broker.search('Evidence',mode='Title')[0]
        with KnowledgeProposalLedger(self.ws,'primary',create=True): pass
        self.sk,self.pub=key_pair()
        folder=self.ws.root/'review_policy'
        folder.mkdir(mode=0o700)
        policy={'schema':'hwi.review.policy.v1',
                'notebook_scope':self.namespace(),
                'reviewer_key_sha256':hashlib.sha256(self.pub).hexdigest()}
        path=folder/'primary.json';path.write_text(json.dumps(policy))
        path.chmod(0o600)
        # Separate, operator-provisioned fitness key pin inside the workspace.
        self.fsk,self.fpub=key_pair()
        self.provision_fitness_policy(self.fpub)
    def provision_fitness_policy(self,pub,scope=None):
        folder=self.ws.root/'fitness_policy'
        if not folder.exists(): folder.mkdir(mode=0o700)
        path=folder/'primary.json'
        if path.exists(): path.unlink()
        path.write_text(json.dumps({'schema':'hwi.task_fitness.policy.v1',
                                    'notebook_scope':scope or self.namespace(),
                                    'fitness_key_sha256':hashlib.sha256(pub).hexdigest()}))
        path.chmod(0o600)
    def tearDown(self): self.temp.cleanup()
    def namespace(self):
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            return broker.namespace
    def spec(self):
        return {'task_id':'historical_research','operation':'revise','reason':'Correct source finding',
                'source_refs':['external:testcase'], 'author_origin':'human',
                'target_ref':self.original['ref'],
                'expected_revision_sha256':self.original['revision_sha256'],
                'proposed':{'title':'Evidence','text':'Corrected claim','tags':['research'], 'fields':{}}}
    def submit(self): return submit_proposal(self.ws,'primary',self.spec())
    def signature(self,entry):return self.sk.sign(signing_payload(self.ws,'primary',entry['proposal_id'])).hex()
    def test_submit_does_not_change_wiki(self):
        entry=self.submit()
        self.assertEqual(entry['state'],'SUBMITTED')
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Original claim')
        self.assertFalse(list_entries(self.ws,'primary')[0]['wiki_applied'])
    def test_export_is_importable_and_inert_in_personal_wiki(self):
        spec=self.spec()
        spec['proposed']['text']=('Corrected [[Approve Now]] https://evil.example/x\n```\n'
                                  '<$list filter="[all[]]"/> <script>x</script> {{Inject}}')
        submit_proposal(self.ws,'primary',spec)
        records=render_review_section(list_entries(self.ws,'primary'))
        self.assertEqual(len(records),1)
        text=records[0]['text']
        self.assertEqual(text.count('```'),2)
        self.assertNotIn('<',text)
        self.ws.create_notebook('scratch')
        with self.ws.open_notebook('scratch',readonly=False) as wiki:
            self.assertEqual(wiki.import_records(records),1)
            html=wiki.render('For Human Review and Approval')
        self.assertNotIn('tw://',html)  # no wiki links and no executed <$list> filter
        self.assertNotIn('href="https://evil',html)
        self.assertNotIn('<script',html)
        self.assertIn('<pre><code',html)
        self.assertIn('Corrected',html)
    def test_export_states_truncation(self):
        self.submit()
        entry=list_entries(self.ws,'primary')[0]
        many=[dict(entry,proposal_id=f'proposal:{i:032x}') for i in range(EXPORT_LIMIT+5)]
        text=render_review_section(many)[0]['text']
        self.assertIn('WARNING: 5 older/closed proposals are NOT shown',text)
        self.assertIn(f'{EXPORT_LIMIT+5} proposals',text)
    def test_exact_signing_and_approved_edit_history(self):
        entry=self.submit()
        sig=self.signature(entry)
        receipt=apply_review(self.ws,'primary',entry['proposal_id'],sig,self.pub)
        self.assertEqual(receipt['operation'],'revise')
        self.assertFalse(receipt['execution_authorized'])
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Corrected claim')
            self.assertTrue(wiki.verify_history()['verified'])
            self.assertEqual(len(wiki.post_history(self.original['ref'].split('/')[-1].split('@')[0])),2)
        self.assertTrue(list_entries(self.ws,'primary')[0]['wiki_applied'])
        with self.assertRaises(AlreadyApplied):
            apply_review(self.ws,'primary',entry['proposal_id'],sig,self.pub)
    def test_invalid_signature_fails_without_edit(self):
        entry=self.submit()
        with self.assertRaises(ReviewWriteError):
            apply_review(self.ws,'primary',entry['proposal_id'],'0'*128,self.pub)
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Original claim')
    def test_stale_wiki_edit_fails_closed(self):
        entry=self.submit()
        with self.ws.open_notebook('primary',readonly=False) as wiki:
            wiki.update_tiddler('Evidence','Evidence','Changed concurrently',['research'],reason='concurrent fixture')
        with self.assertRaises(StaleReview):
            apply_review(self.ws,'primary',entry['proposal_id'],self.signature(entry),self.pub)
    def test_restore_is_new_signed_revision_not_rollback(self):
        first=self.submit()
        apply_review(self.ws,'primary',first['proposal_id'],self.signature(first),self.pub)
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            current=broker.search('Evidence',mode='Title')[0]
        second=restore_as_proposal(self.ws,'primary',current_ref=current['ref'],
                                   historical_ref=self.original['ref'],reason='Undo incorrect edit')
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Corrected claim')
        self.assertEqual(second['record']['after']['text'],'Original claim')
        apply_review(self.ws,'primary',second['proposal_id'],self.signature(second),self.pub)
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Original claim')
            self.assertTrue(wiki.verify_history()['verified'])
            self.assertEqual(len(wiki.post_history(current['ref'].split('/')[-1].split('@')[0])),3)
    def test_restore_rejects_foreign_history(self):
        with self.assertRaises(Exception):
            restore_as_proposal(self.ws,'primary',current_ref=self.original['ref'],
                                historical_ref='hwi05://invalid/abc@1',reason='wrong scope')
    def test_history_metadata_visible(self):
        post_id=self.original['ref'].split('/')[-1].split('@')[0]
        records=history_view(self.ws,'primary',post_id)
        self.assertEqual(len(records),1)
        self.assertIn('after_sha256',records[0])
    def test_private_output_does_not_overwrite(self):
        file=self.root/'export.json'
        write_once(file,'one')
        with self.assertRaises(FileExistsError): write_once(file,'two')
        self.assertEqual(file.read_text(),'one')
    # ---- CLI gate helpers
    def gate_args(self,spec,*,contract=None,results=None,signer=None,pub=None,tag='a'):
        if contract is None: contract,results=example()
        assessment=assess(contract,results)
        signer=signer or self.fsk
        decision={'schema':'hwi.task_fitness.owner_decision.v2',
                  'assessment_sha256':assessment['assessment_sha256'],
                  'decision':'APPROVE_FOR_DECLARED_TASK',
                  'signature_hex':signer.sign(signing_message(assessment)).hex()}
        spec_path=self.root/f'spec-{tag}.json'; spec_path.write_text(json.dumps(spec))
        args=['queue-submit','--workspace',str(self.ws.root),'--notebook','primary','--spec',str(spec_path)]
        for name,value in (('contract',contract),('results',results),('assessment',assessment),
                           ('owner_decision',decision)):
            f=self.root/f'{name}-{tag}.json'; f.write_text(json.dumps(value))
            args+=['--'+name.replace('_','-'),str(f)]
        key=self.root/f'pub-{tag}.bin'
        if key.exists(): key.unlink()
        key.write_bytes(pub or self.fpub); key.chmod(0o600)
        return args+['--owner-public-key',str(key)], assessment
    def run_cli(self,args):
        from contextlib import redirect_stdout,redirect_stderr
        from io import StringIO
        err=StringIO()
        with redirect_stdout(StringIO()),redirect_stderr(err):
            code=main(args)
        return code,err.getvalue()
    def agent_spec(self,**changes):
        spec=self.spec(); spec['author_origin']='agent'; spec.update(changes); return spec

    def test_agent_submission_requires_task_fitness_signature(self):
        spec=self.agent_spec()
        bare=['queue-submit','--workspace',str(self.ws.root),'--notebook','primary','--spec',
              str(self.root/'bare.json')]
        (self.root/'bare.json').write_text(json.dumps(spec))
        self.assertEqual(self.run_cli(bare)[0],2)
        self.assertEqual(list_entries(self.ws,'primary'),[])
        args,assessment=self.gate_args(spec)
        self.assertEqual(self.run_cli(args),(0,''))
        entries=list_entries(self.ws,'primary')
        self.assertEqual(len(entries),1)
        self.assertIn(fitness_ref(assessment['assessment_sha256']),entries[0]['record']['source_refs'])
        self.assertEqual(entries[0]['fitness_gate']['status'],'VERIFIED')
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Original claim')
        # A forged task id cannot borrow this signed decision.
        bad=self.agent_spec(task_id='another_domain')
        args,_=self.gate_args(bad,tag='b')
        self.assertEqual(self.run_cli(args)[0],2)
        self.assertEqual(len(list_entries(self.ws,'primary')),1)

    def test_self_minted_fitness_key_rejected(self):
        attacker,attacker_pub=key_pair()
        args,_=self.gate_args(self.agent_spec(),signer=attacker,pub=attacker_pub)
        code,err=self.run_cli(args)
        self.assertEqual(code,2); self.assertIn('workspace operator pin',err)
        self.assertEqual(list_entries(self.ws,'primary'),[])
    def test_operator_pin_argument_removed(self):
        args,_=self.gate_args(self.agent_spec())
        pin=self.root/'pin.txt'; pin.write_text(hashlib.sha256(self.fpub).hexdigest()); pin.chmod(0o600)
        from contextlib import redirect_stderr
        from io import StringIO
        with redirect_stderr(StringIO()),self.assertRaises(SystemExit):
            main(args+['--operator-pin',str(pin)])
    def test_missing_fitness_policy_fails_closed(self):
        (self.ws.root/'fitness_policy'/'primary.json').unlink()
        args,_=self.gate_args(self.agent_spec())
        self.assertEqual(self.run_cli(args)[0],2)
        self.assertEqual(list_entries(self.ws,'primary'),[])
    def test_fitness_policy_must_be_private_and_scoped(self):
        path=self.ws.root/'fitness_policy'/'primary.json'
        path.chmod(0o644)
        args,_=self.gate_args(self.agent_spec())
        self.assertEqual(self.run_cli(args)[0],2)
        self.provision_fitness_policy(self.fpub,scope='other-scope')
        self.assertEqual(self.run_cli(args)[0],2)
        self.assertEqual(list_entries(self.ws,'primary'),[])
    def test_fitness_key_must_differ_from_wiki_reviewer_key(self):
        self.provision_fitness_policy(self.pub)
        args,_=self.gate_args(self.agent_spec(),signer=self.sk,pub=self.pub)
        code,err=self.run_cli(args)
        self.assertEqual(code,2); self.assertIn('must differ',err)
    def test_signed_scope_quota_enforced(self):
        contract,results=example(max_proposals=2)
        for i in range(3):
            spec=self.agent_spec(); spec['proposed']=dict(spec['proposed'],text=f'Variant {i}')
            args,_=self.gate_args(spec,contract=contract,results=results,tag=f'q{i}')
            code,err=self.run_cli(args)
            self.assertEqual(code,0 if i<2 else 2,err)
        self.assertEqual(len(list_entries(self.ws,'primary')),2)
    def test_operation_outside_scope_rejected(self):
        spec=self.agent_spec(operation='create',target_ref=None,expected_revision_sha256=None)
        args,_=self.gate_args(spec)
        self.assertEqual(self.run_cli(args)[0],2)
    def test_spec_cannot_supply_fitness_ref(self):
        spec=self.agent_spec(source_refs=['external:hwi-fitness/'+'a'*64])
        args,_=self.gate_args(spec)
        self.assertEqual(self.run_cli(args)[0],2)
    def test_malformed_spec_is_rejected_not_crash(self):
        for missing in ('author_origin','task_id','operation'):
            spec=self.agent_spec(); spec.pop(missing)
            args,_=self.gate_args(spec,tag=missing)
            with self.subTest(missing=missing):
                self.assertEqual(self.run_cli(args)[0],2)
    def test_ungated_and_forged_gates_are_visible(self):
        self.submit()  # library API: no gate
        spec=self.spec(); spec['source_refs']=['external:hwi-fitness/'+'b'*64]
        spec['proposed']=dict(spec['proposed'],text='Forged gate')
        submit_proposal(self.ws,'primary',spec)
        status=[e['fitness_gate']['status'] for e in list_entries(self.ws,'primary')]
        self.assertEqual(status,['UNGATED','UNVERIFIED'])
        text=render_review_section(list_entries(self.ws,'primary'))[0]['text']
        self.assertIn('UNGATED',text); self.assertIn('UNVERIFIED',text)
    def test_review_entry_shows_gate(self):
        args,_=self.gate_args(self.agent_spec())
        self.assertEqual(self.run_cli(args)[0],0)
        pid=list_entries(self.ws,'primary')[0]['proposal_id']
        self.assertEqual(review_entry(self.ws,'primary',pid)['fitness_gate']['status'],'VERIFIED')
    def test_fitness_verify_cli_uses_workspace_pin(self):
        contract,results=example()
        assessment=assess(contract,results)
        files={}
        for signer,pub,tag,expected in ((self.fsk,self.fpub,'ok',0),(key_pair()[0],None,'bad',2)):
            if pub is None:
                attacker=signer; pub=attacker.public_key().public_bytes(
                    serialization.Encoding.Raw,serialization.PublicFormat.Raw)
            decision={'schema':'hwi.task_fitness.owner_decision.v2',
                      'assessment_sha256':assessment['assessment_sha256'],
                      'decision':'APPROVE_FOR_DECLARED_TASK',
                      'signature_hex':signer.sign(signing_message(assessment)).hex()}
            a=self.root/f'as-{tag}.json'; a.write_text(json.dumps(assessment))
            d=self.root/f'dec-{tag}.json'; d.write_text(json.dumps(decision))
            k=self.root/f'k-{tag}.bin'; k.write_bytes(pub); k.chmod(0o600)
            code,_=self.run_cli(['fitness-verify','--assessment',str(a),'--owner-decision',str(d),
                                 '--owner-public-key',str(k),'--workspace',str(self.ws.root),
                                 '--notebook','primary'])
            with self.subTest(tag=tag): self.assertEqual(code,expected)
    def test_restore_to_current_revision_rejected(self):
        with self.assertRaisesRegex(ValueError,'Historical revision is the current revision'):
            restore_as_proposal(self.ws,'primary',current_ref=self.original['ref'],
                                historical_ref=self.original['ref'],reason='no-op')
        self.assertEqual(list_entries(self.ws,'primary'),[])

    def test_human_origin_claim_does_not_bypass_task_gate(self):
        from contextlib import redirect_stderr
        from io import StringIO
        path=self.root/'human.json';path.write_text(json.dumps(self.spec()))
        with redirect_stderr(StringIO()):
            self.assertEqual(main(['queue-submit','--workspace',str(self.ws.root),
                                   '--notebook','primary','--spec',str(path)]),2)
        self.assertEqual(list_entries(self.ws,'primary'),[])

    def test_cli_export_is_only_an_unpublished_import_file(self):
        from contextlib import redirect_stdout
        from io import StringIO
        spec=self.spec(); spec['proposed']=dict(spec['proposed'],text='Ελληνικά [[Link]] \u202e')
        submit_proposal(self.ws,'primary',spec)
        out=self.root/'review.json'
        with redirect_stdout(StringIO()):
            self.assertEqual(main(['queue-export','--workspace',str(self.ws.root),
                                    '--notebook','primary','--output',str(out)]),0)
        self.assertEqual(json.loads(out.read_text())[0]['title'],'For Human Review and Approval')
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertIsNone(wiki.get_tiddler('For Human Review and Approval'))
        self.ws.create_notebook('scratch')
        with self.ws.open_notebook('scratch',readonly=False) as wiki:
            self.assertEqual(wiki.import_json(out),1)
            html=wiki.render('For Human Review and Approval')
        self.assertIn('Ελληνικά',html); self.assertIn('\\u202e',html)
        self.assertNotIn('\u202e',html); self.assertNotIn('tw://',html)

    def test_readable_text_but_visible_tricks(self):
        spec=self.spec(); spec['proposed']=dict(spec['proposed'],text='Διορθωμένο pay\u202eevil\u200b')
        entry=submit_proposal(self.ws,'primary',spec)
        text=render_review_section(list_entries(self.ws,'primary'))[0]['text']
        self.assertIn('Διορθωμένο',text)
        self.assertIn('\\u202e',text); self.assertIn('\\u200b',text)
        self.assertNotIn('\u202e',text); self.assertNotIn('\u200b',text)
        from contextlib import redirect_stdout
        from io import StringIO
        out=StringIO()
        with redirect_stdout(out):
            self.assertEqual(main(['queue-review','--workspace',str(self.ws.root),'--notebook','primary',
                                   '--proposal-id',entry['proposal_id']]),0)
        self.assertIn('Διορθωμένο',out.getvalue()); self.assertNotIn('\u202e',out.getvalue())
        self.assertEqual(json.loads(out.getvalue())['proposal_id'],entry['proposal_id'])
    def test_forged_reference_cannot_squat_quota_or_verify(self):
        contract,results=example(max_proposals=1)
        ref=fitness_ref(assess(contract,results)['assessment_sha256'])
        def forge(text):
            spec=self.spec(); spec['source_refs']=['external:testcase',ref]
            spec['proposed']=dict(spec['proposed'],text=text)
            submit_proposal(self.ws,'primary',spec)
        forge('squat before')
        args,_=self.gate_args(self.agent_spec(),contract=contract,results=results)
        self.assertEqual(self.run_cli(args),(0,''))
        forge('squat after')  # receipt now exists, but no gate usage record
        status={e['record']['after']['text']:e['fitness_gate']['status'] for e in list_entries(self.ws,'primary')}
        self.assertEqual(status,{'squat before':'UNVERIFIED','Corrected claim':'VERIFIED','squat after':'UNVERIFIED'})
    def test_rejected_submission_returns_quota_slot(self):
        contract,results=example(max_proposals=1)
        stale=self.agent_spec(expected_revision_sha256='f'*64)
        args,_=self.gate_args(stale,contract=contract,results=results,tag='stale')
        self.assertEqual(self.run_cli(args)[0],2)
        args,_=self.gate_args(self.agent_spec(),contract=contract,results=results,tag='ok')
        self.assertEqual(self.run_cli(args),(0,''))
        args,_=self.gate_args(self.agent_spec(reason='second'),contract=contract,results=results,tag='more')
        self.assertIn('exhausted',self.run_cli(args)[1])

    def test_gated_spec_still_needs_evidence_refs(self):
        args,_=self.gate_args(self.agent_spec(source_refs=[]))
        code,err=self.run_cli(args)
        self.assertEqual(code,2); self.assertIn('evidence source references',err)
        self.assertEqual(list_entries(self.ws,'primary'),[])
    def apply_args(self,entry):
        k=self.root/'reviewer.bin'
        if not k.exists(): k.write_bytes(self.pub); k.chmod(0o600)
        return ['queue-apply','--workspace',str(self.ws.root),'--notebook','primary',
                '--proposal-id',entry['proposal_id'],'--signature-hex',self.signature(entry),
                '--reviewer-public-key',str(k)]
    def test_apply_requires_acknowledging_unverified_gate(self):
        entry=self.submit()  # UNGATED
        code,err=self.run_cli(self.apply_args(entry))
        self.assertEqual(code,2); self.assertIn('--accept-unverified-gate',err)
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Original claim')
        self.assertEqual(self.run_cli(self.apply_args(entry)+['--accept-unverified-gate']),(0,''))
        with self.ws.open_notebook('primary',readonly=True) as wiki:
            self.assertEqual(wiki.get_tiddler('Evidence')['text'],'Corrected claim')
    def test_verified_gate_applies_without_acknowledgement(self):
        args,_=self.gate_args(self.agent_spec())
        self.assertEqual(self.run_cli(args),(0,''))
        entry=list_entries(self.ws,'primary')[0]
        self.assertEqual(self.run_cli(self.apply_args(entry)),(0,''))
    def test_post_commit_gate_record_failure_is_reported_honestly(self):
        from .gate_store import GateStore
        original=GateStore.bind
        def broken(self,sha,slot,proposal_id): raise OSError('disk full')
        GateStore.bind=broken
        try:
            args,_=self.gate_args(self.agent_spec())
            code,err=self.run_cli(args)
        finally:
            GateStore.bind=original
        self.assertEqual(code,3); self.assertIn('SUBMITTED_WITHOUT_GATE_RECORD',err)
        entries=list_entries(self.ws,'primary')
        self.assertEqual(len(entries),1)
        self.assertIn(entries[0]['proposal_id'],err)
        self.assertEqual(entries[0]['fitness_gate']['status'],'UNVERIFIED')

    def test_fitness_verify_rejects_other_notebook_assessment(self):
        contract,results=example(notebook='other')
        assessment=assess(contract,results)
        decision={'schema':'hwi.task_fitness.owner_decision.v2','assessment_sha256':assessment['assessment_sha256'],
                  'decision':'APPROVE_FOR_DECLARED_TASK','signature_hex':self.fsk.sign(signing_message(assessment)).hex()}
        a=self.root/'other-as.json'; a.write_text(json.dumps(assessment))
        d=self.root/'other-dec.json'; d.write_text(json.dumps(decision))
        k=self.root/'other-k.bin'; k.write_bytes(self.fpub); k.chmod(0o600)
        code,err=self.run_cli(['fitness-verify','--assessment',str(a),'--owner-decision',str(d),
                               '--owner-public-key',str(k),'--workspace',str(self.ws.root),'--notebook','primary'])
        self.assertEqual(code,2); self.assertIn('different notebook',err)
    def test_fitness_pins_matches_assessment_rules(self):
        from contextlib import redirect_stdout
        from io import StringIO
        contract,results=example()
        c=self.root/'pins-contract.json'; c.write_text(json.dumps(contract))
        out=StringIO()
        with redirect_stdout(out): self.assertEqual(main(['fitness-pins','--contract',str(c)]),0)
        pins=json.loads(out.getvalue())
        self.assertEqual((pins['contract_sha256'],pins['configuration_sha256']),
                         (results['contract_sha256'],results['configuration_sha256']))
        self.assertEqual(pins['case_ids'],['case1','case2','case3'])

    def test_duplicate_json_keys_rejected(self):
        file=self.root/'test.json'
        file.write_text('{"a":1,"a":2}')
        with self.assertRaises(ValueError): read_json(file)

class ShippedExampleTests(unittest.TestCase):
    def test_examples_are_consistent_and_eligible(self):
        folder=Path(__file__).resolve().parent/'examples'
        contract=read_json(folder/'TASK_FITNESS_CONTRACT.example.json')
        results=read_json(folder/'TASK_FITNESS_RESULTS.example.json')
        if datetime.date.fromisoformat(contract['valid_until']) < TODAY:
            self.skipTest('shipped example contract has expired; refresh valid_until and digests')
        self.assertEqual(assess(contract,results)['status'],'ELIGIBLE_FOR_HUMAN_TASK_APPROVAL')

if __name__ == '__main__': unittest.main()
