"""Operator-facing wiki review queue over approved HWI-07/08 and history APIs.

No agent-supplied text is used as a command. Export creates a PERSONAL.WIKI JSON
import artifact outside the protected wiki, never a live wiki edit. Signed
application is delegated exclusively to approved HWI-08, with the notebook's
separately provisioned reviewer-key pin and one-use receipt checks.
Restoration is an ordinary, exact revision-pinned *proposal*, not a bypass.

Export safety does not rely on the ``type`` field: PERSONAL.WIKI's renderer
ignores it and always renders wiki markup. All proposal-derived content is
therefore placed inside a single fenced code block (rendered HTML-escaped,
with no link/macro parsing), and backtick, ``<``, ``>`` and ``&`` characters in
that content are JSON-escaped so it can neither close the fence nor match the
raw ``<$list filter=...>`` scan performed by ``WikiCore.render``.
"""
from __future__ import annotations

from .display import readable_json
from .fitness_policy import gate_status
from .repository import Repository, RepositoryError

REVIEW_TITLE = 'For Human Review and Approval'
EXPORT_LIMIT = 100
SPEC_FIELDS = frozenset({'operation','reason','source_refs','author_origin','target_ref',
                         'expected_revision_sha256','proposed','task_id'})

class QueueError(ValueError):
    pass

def _repo(workspace, notebook) -> Repository:
    try:
        return workspace if isinstance(workspace, Repository) else Repository(workspace, notebook)
    except RepositoryError as exc:
        raise QueueError(str(exc)) from exc

def list_entries(workspace, notebook):
    """Every ledger proposal with HWI-08 application state and re-verified fitness gate."""
    repo = _repo(workspace, notebook)
    proposals = repo.list_proposals()
    applied = repo.applied_proposal_ids()
    scope = repo.scope()
    return [{**entry, 'wiki_applied':entry['proposal_id'] in applied,
             'fitness_gate':gate_status(repo.root, notebook, scope, entry)} for entry in proposals]

def review_entry(workspace, notebook, proposal_id):
    repo = _repo(workspace, notebook)
    view = repo.review_view(proposal_id)
    entry = repo.get_proposal(proposal_id)
    return {**view, 'fitness_gate':gate_status(repo.root, notebook, repo.scope(), entry)}


def status_projection(workspace, notebook):
    """Query current authoritative records for a read-only review status view.

    This is a *fresh on-demand projection*, not an imported wiki page, approval
    receipt, signed command, or transaction coordinator. It deliberately excludes
    all untrusted proposal prose and fitness error details. A future wiki UI
    may consume this API without reading governance SQL itself.
    """
    entries = list_entries(workspace, notebook)
    rows = []
    for entry in entries:
        gate = entry['fitness_gate']
        rows.append({'proposal_id': entry['proposal_id'],
                     'ledger_state': entry['state'],
                     'operation': entry['record']['operation'],
                     'wiki_receipt_present': entry['wiki_applied'],
                     'fitness_gate_status': gate['status'],
                     'fitness_binding': gate.get('binding')})
    return {'schema': 'hwi.governance.review_status.v0',
            'status': 'LIVE_QUERY_READ_ONLY',
            'notebook': notebook,
            'total': len(rows),
            'pending': sum(1 for row in rows if row['ledger_state'] == 'SUBMITTED'
                           and not row['wiki_receipt_present']),
            'applied': sum(1 for row in rows if row['wiki_receipt_present']),
            'proposals': rows,
            'wiki_modified': False,
            'approval_authorized': False,
            'execution_authorized': False,
            'note': 'Read-only on-demand projection, not a live PERSONAL.WIKI page or approval mechanism.'}

def _inert(value):
    text = readable_json(value)
    for ch, esc in (('`','\\u0060'),('<','\\u003c'),('>','\\u003e'),('&','\\u0026')):
        text = text.replace(ch, esc)
    return text

def render_review_section(entries):
    """PERSONAL.WIKI import array holding one inert review post.

    Pending (SUBMITTED, unapplied) proposals are listed first; at most
    EXPORT_LIMIT are shown and any omission is stated explicitly.
    """
    if type(entries) is not list:
        raise QueueError('List of ledger proposals required')
    for entry in entries:
        if type(entry) is not dict or entry.get('envelope_schema') != 'hwi.proposal.envelope.v1':
            raise QueueError('Invalid ledger proposal')
    ordered = sorted(entries, key=lambda e: (not (e['state'] == 'SUBMITTED' and not e['wiki_applied']),))
    shown, omitted = ordered[:EXPORT_LIMIT], len(ordered) - min(len(ordered), EXPORT_LIMIT)
    pending = sum(1 for e in entries if e['state'] == 'SUBMITTED' and not e['wiki_applied'])
    summary = [{'proposal_id':e['proposal_id'],'ledger_state':e['state'],
                'wiki_receipt_present':e['wiki_applied'],
                'fitness_gate':e['fitness_gate'],
                'operation':e['record']['operation'],
                'author_origin_claim_only':e['record']['author_origin'],
                'committed_proposal_digest':e['content_digest'],
                'expected_target_revision':e['record']['expected_revision_sha256'],
                'source_refs':e['record']['source_refs'],
                'untrusted_reason':e['record']['reason'],
                'untrusted_before':e['record']['before'],
                'untrusted_after':e['record']['after']} for e in shown]
    header = [f'Operator-generated read-only snapshot: {len(entries)} proposals, {pending} pending review.',
              'This page is NOT an approval mechanism and is not live. Re-export to refresh.',
              'Apply an exact proposal only with the separate signed CLI (queue-apply).',
              'Protected/PVS-managed records are never writable via this queue.',
              'Fitness gate VERIFIED = owner-signed task scope re-checked; UNGATED/UNVERIFIED need extra scrutiny.']
    if omitted:
        header.append(f'WARNING: {omitted} older/closed proposals are NOT shown (limit {EXPORT_LIMIT}). Use queue-list.')
    text = '\n'.join(header) + '\n\n```json\n' + _inert(summary) + '\n```\n'
    return [{'title':REVIEW_TITLE, 'tags':'HWIReview', 'type':'text/plain', 'text':text}]

def submit_proposal(workspace, notebook, spec):
    """Submit for review only, no wiki mutation. Fitness gating is in the CLI."""
    repo = _repo(workspace, notebook)
    if type(spec) is not dict or set(spec) != SPEC_FIELDS:
        raise QueueError('Submit specification fields must be exact: ' + ', '.join(sorted(SPEC_FIELDS)))
    return repo.submit_proposal(operation=spec['operation'], reason=spec['reason'],
                                source_refs=spec['source_refs'], author_origin=spec['author_origin'],
                                target_ref=spec['target_ref'],
                                expected_revision_sha256=spec['expected_revision_sha256'],
                                proposed=spec['proposed'])

def restore_as_proposal(workspace, notebook, *, current_ref, historical_ref, reason):
    """Make history restoration a *new reviewed revise proposal*.

    Historical content is read from the verified notebook after an HWI-05 broker
    check; it cannot be an arbitrary path or a PVS-managed historical record.
    Restoring a deleted post is intentionally outside this helper's scope.
    This helper is not fitness-gated; such proposals display as UNGATED.
    """
    repo = _repo(workspace, notebook)
    if type(reason) is not str or not reason.strip() or len(reason) > 2000:
        raise QueueError('Human-readable restoration rationale required')
    if type(current_ref) is not str or type(historical_ref) is not str:
        raise QueueError('Revision references required')
    try:
        snap = repo.restorable_snapshot(current_ref, historical_ref)
    except RepositoryError as exc:
        raise QueueError(str(exc)) from exc
    current, proposed = snap['current'], snap['proposed']
    if proposed == {k:current[k] for k in ('title','text','tags','fields')}:
        raise QueueError('Historical content equals current content; nothing to restore')
    return repo.submit_proposal(operation='revise', reason=f'Restore from {historical_ref}: {reason}',
                                source_refs=[historical_ref], author_origin='human',
                                target_ref=current_ref,
                                expected_revision_sha256=current['revision_sha256'],
                                proposed=proposed)

def history_view(workspace, notebook, post_id):
    repo = _repo(workspace, notebook)
    try:
        rows = repo.post_history(post_id)
    except RepositoryError as exc:
        raise QueueError(str(exc)) from exc
    # No unreviewed historical text is issued as agent instructions.
    return [{'event_id':x['event_id'],'changed_at':x['changed_at'],
             'change_type':x['change_type'],'reason':x['reason'],
             'title':x['title'],'before_sha256':x['before_sha256'],
             'after_sha256':x['after_sha256']} for x in rows]

def apply_review(workspace, notebook, proposal_id, signature_hex, reviewer_public_key):
    return _repo(workspace, notebook).apply_reviewed_change(
        proposal_id, signature_hex=signature_hex, reviewer_public_key=reviewer_public_key)

def signing_payload(workspace, notebook, proposal_id):
    return _repo(workspace, notebook).signing_payload(proposal_id)
