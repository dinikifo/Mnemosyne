"""Record this machine's HWI role once; rebuildable from the saved profile.

Called by ``INSTALL.sh``. It asks one question (the machine's role), checks the
prerequisites, creates an empty private workspace when this machine hosts the
wiki, and writes ``host_profile.json``. It NEVER creates notebooks, ledgers,
keys or policies: those remain operator acts, and it prints the next steps.

Installations are fixed: an existing, different profile is refused rather than
overwritten. ``--profile FILE`` reproduces a previous installation
non-interactively.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
from pathlib import Path
import platform
import re
import socket
import sys
import urllib.request

from .repository import RepositoryError, check_storage_environment, create_workspace, open_workspace

PROFILE_SCHEMA = 'hwi.host_profile.v1'
ROLES = {
    '1': 'wiki-and-model',
    '2': 'wiki-only',
    '3': 'model-only',
}
ENDPOINT = 'http://127.0.0.1:11434'
LABEL = re.compile(r'^[a-z0-9][a-z0-9-]{0,31}$')
MODEL_HOST = re.compile(r'^(?:[A-Za-z0-9._-]{1,32}@)?[A-Za-z0-9.-]{1,253}$')
SUPPORTED = ('Linux', 'Darwin')
LATER = ('FreeBSD', 'NetBSD', 'OpenBSD')
SD_CARD_MAJOR = 179  # Linux mmcblk block devices


class InstallError(ValueError):
    pass


def _default_label():
    host = re.sub(r'[^a-z0-9-]', '-', socket.gethostname().lower()).strip('-')[:32]
    return host if host and LABEL.fullmatch(host) else 'hwi-host'


def _ask(prompt, default=None):
    try:
        value = input(prompt + (f' [{default}]' if default else '') + ': ').strip()
    except EOFError:
        value = ''
    return value or (default or '')


def _check_ollama(endpoint):
    try:
        with urllib.request.urlopen(endpoint + '/api/tags', timeout=3) as resp:
            models = [m.get('name') for m in json.loads(resp.read().decode('utf-8')).get('models', [])]
        return {'reachable':True, 'models':models}
    except (OSError, ValueError):
        return {'reachable':False, 'models':[]}


def _on_sd_card(path: Path) -> bool:
    if platform.system() != 'Linux':
        return False
    probe = path
    while not probe.exists():
        probe = probe.parent
    return os.major(probe.stat().st_dev) == SD_CARD_MAJOR


def _profile_core(profile):
    return {k:profile[k] for k in ('schema','role','machine_label','workspace','model_endpoint','model_host')}


def build_profile(role, label, workspace, model_host):
    if role not in ROLES.values():
        raise InstallError(f'Unknown role {role!r}; expected one of {sorted(ROLES.values())}')
    if not LABEL.fullmatch(label or ''):
        raise InstallError('Machine label: lowercase letters, digits and hyphens, at most 32 characters')
    if role == 'model-only':
        if workspace:
            raise InstallError('A model-only host has no wiki workspace')
        workspace = None
    else:
        if not workspace:
            raise InstallError('This role hosts the wiki: a workspace path is required')
        workspace = str(Path(workspace).expanduser().absolute())
    if role == 'wiki-only':
        if not model_host or not MODEL_HOST.fullmatch(model_host):
            raise InstallError('wiki-only needs --model-host (the SSH target that runs Ollama)')
    else:
        model_host = None
    return {'schema':PROFILE_SCHEMA, 'role':role, 'machine_label':label, 'workspace':workspace,
            'model_endpoint':ENDPOINT, 'model_host':model_host,
            'platform':f'{platform.system().lower()}-{platform.machine().lower()}',
            'python':platform.python_version(),
            'created_at':_dt.datetime.now(_dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}


def _write_profile(config_dir: Path, profile) -> tuple[Path, str]:
    if config_dir.is_symlink():
        raise InstallError('Config directory must not be a symlink')
    config_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    if os.name == 'posix' and config_dir.stat().st_mode & 0o077:
        raise InstallError(f'{config_dir} must be private (0700)')
    path = config_dir / 'host_profile.json'
    if path.exists() or path.is_symlink():
        existing = json.loads(path.read_text('utf-8'))
        if _profile_core(existing) == _profile_core(profile):
            return path, 'ALREADY_INSTALLED'
        raise InstallError(f'{path} already records a different installation. Installations are fixed; '
                           'remove that profile deliberately to reinstall this machine.')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps(profile, indent=2, sort_keys=True) + '\n')
    return path, 'INSTALLED'


def next_steps(profile, ollama):
    steps = []
    label = profile['machine_label']
    if profile['role'] != 'model-only':
        steps += ['Create or restore a notebook in this workspace with PERSONAL.WIKI.',
                  'Run: bash RUN_GOVERNANCE.command queue-init --workspace '
                  f"{profile['workspace']} --notebook <name>  (prints notebook_scope)",
                  'Write review_policy/<name>.json and fitness_policy/<name>.json yourself '
                  '(USER_MANUAL Appendix A); use two different keys.']
    if profile['role'] == 'wiki-only':
        steps.append(f"Model access: ssh -N -L 11434:localhost:11434 {profile['model_host']}")
    if profile['role'] in ('wiki-and-model', 'model-only') and not ollama['reachable']:
        steps.append('Start Ollama on this machine and pull your model (e.g. ollama pull llama3.1:8b).')
    if profile['role'] == 'model-only':
        steps.append('On the wiki host, reach this machine with: ssh -N -L 11434:localhost:11434 <this host>')
    steps.append(f'Name fitness configurations <model>@{label} (e.g. llama3.1:8b@{label}).')
    return steps


def run(argv=None, *, out=sys.stdout):
    parser = argparse.ArgumentParser(prog='INSTALL.sh', description='Record this machine\'s HWI role (once).')
    parser.add_argument('--role', choices=sorted(ROLES.values()))
    parser.add_argument('--label', help='Machine label, e.g. pi5-cpu')
    parser.add_argument('--workspace', help='Private wiki workspace path (wiki roles)')
    parser.add_argument('--model-host', help='SSH target running Ollama (wiki-only role)')
    parser.add_argument('--profile', help='Rebuild non-interactively from a saved host_profile.json')
    parser.add_argument('--config-dir', help='Default: $XDG_CONFIG_HOME/hwi or ~/.config/hwi')
    parser.add_argument('--skip-ollama-check', action='store_true')
    args = parser.parse_args(argv)
    try:
        system = platform.system()
        if system not in SUPPORTED + LATER:
            raise InstallError(f'Unsupported platform {system}; supported: Linux, macOS')
        if sys.version_info < (3, 11):
            raise InstallError('Python 3.11 or newer is required')
        try:
            import cryptography  # noqa: F401
        except ImportError as exc:
            raise InstallError('Python package "cryptography" is required') from exc
        if args.profile:
            saved = json.loads(Path(args.profile).expanduser().read_text('utf-8'))
            if type(saved) is not dict or saved.get('schema') != PROFILE_SCHEMA:
                raise InstallError('Not an HWI host profile')
            role, label, workspace, model_host = (saved.get('role'), saved.get('machine_label'),
                                                  saved.get('workspace'), saved.get('model_host'))
        else:
            role, label, workspace, model_host = args.role, args.label, args.workspace, args.model_host
            interactive = sys.stdin.isatty()
            if role is None:
                if not interactive:
                    raise InstallError('Non-interactive install needs --role or --profile')
                print('What does this machine do?\n  1) hosts the wiki and runs the model\n'
                      '  2) hosts the wiki; the model runs on another machine\n'
                      '  3) runs the model only', file=out)
                role = ROLES.get(_ask('Choice'), None)
                if role is None:
                    raise InstallError('Please answer 1, 2 or 3')
            if label is None:
                label = _ask('Machine label', _default_label()) if interactive else _default_label()
            if role != 'model-only' and not workspace and interactive:
                workspace = _ask('Wiki workspace path', str(Path.home() / 'HWI-workspace'))
            if role == 'wiki-only' and not model_host and interactive:
                model_host = _ask('SSH target running Ollama (user@host)')
        profile = build_profile(role, label, workspace, model_host)
        warnings = []
        if system in LATER:
            warnings.append(f'{system} is planned but not yet tested.')
        try:
            check_storage_environment()
        except (RuntimeError, OSError, ValueError) as exc:
            raise InstallError(f'SQLite JSON/FTS5 support missing: {exc}') from exc
        ollama = {'reachable':None, 'models':[]} if args.skip_ollama_check else _check_ollama(ENDPOINT)
        if ollama['reachable'] is False:
            warnings.append('Ollama is not reachable on 127.0.0.1:11434 yet.')
        if profile['workspace']:
            ws = Path(profile['workspace'])
            if _on_sd_card(ws):
                warnings.append('Workspace is on an SD card; prefer an SSD for SQLite durability.')
            if ws.exists():
                open_workspace(ws)  # validates an existing private workspace
                created = False
            else:
                create_workspace(ws)
                created = True
        else:
            created = False
        config_dir = Path(args.config_dir).expanduser() if args.config_dir else \
            Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'hwi'
        path, status = _write_profile(config_dir, profile)
        result = {'status':status, 'profile':str(path), 'role':profile['role'],
                  'machine_label':profile['machine_label'], 'workspace':profile['workspace'],
                  'workspace_created':created, 'ollama':ollama, 'warnings':warnings,
                  'next_steps':next_steps(profile, ollama),
                  'keys_created':False, 'policies_created':False, 'notebooks_created':False}
        print(json.dumps(result, indent=2, ensure_ascii=False), file=out)
        return 0
    except (InstallError, RepositoryError, ValueError, OSError) as exc:
        print(f'INSTALL REFUSED: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(run())
