"""INSTALL.sh / install.py tests (no network: Ollama check skipped or unreachable)."""
from __future__ import annotations

from contextlib import redirect_stderr
from io import StringIO
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from .install import run

RELEASE = Path(__file__).resolve().parents[3]


class InstallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        os.chmod(self.root, 0o700)
        self.cfg = self.root / 'cfg'

    def tearDown(self):
        self.temp.cleanup()

    def install(self, *args):
        out, err = StringIO(), StringIO()
        with redirect_stderr(err):
            code = run(['--config-dir', str(self.cfg), '--skip-ollama-check', *args], out=out)
        return code, (json.loads(out.getvalue()) if code == 0 else None), err.getvalue()

    def test_wiki_and_model_creates_empty_private_workspace_and_profile(self):
        ws = self.root / 'ws'
        code, result, _ = self.install('--role', 'wiki-and-model', '--label', 'pc-cuda', '--workspace', str(ws))
        self.assertEqual(code, 0)
        self.assertEqual(result['status'], 'INSTALLED')
        self.assertTrue(result['workspace_created'])
        self.assertEqual(os.stat(ws).st_mode & 0o777, 0o700)
        # Only the approved empty layout: no notebook, ledger, governance store or policy.
        self.assertEqual(sorted(p.name for p in ws.iterdir()), ['backups', 'notebooks'])
        self.assertEqual(list((ws / 'notebooks').iterdir()), [])
        profile = self.cfg / 'host_profile.json'
        self.assertEqual(os.stat(profile).st_mode & 0o777, 0o600)
        self.assertEqual(os.stat(self.cfg).st_mode & 0o777, 0o700)
        saved = json.loads(profile.read_text())
        self.assertEqual((saved['role'], saved['machine_label'], saved['model_endpoint']),
                         ('wiki-and-model', 'pc-cuda', 'http://127.0.0.1:11434'))
        self.assertFalse(result['keys_created'] or result['policies_created'] or result['notebooks_created'])
        self.assertIn('llama3.1:8b@pc-cuda', ' '.join(result['next_steps']))

    def test_rerun_is_idempotent_but_a_different_install_is_refused(self):
        ws = str(self.root / 'ws')
        self.assertEqual(self.install('--role', 'wiki-and-model', '--label', 'pi5-cpu', '--workspace', ws)[0], 0)
        code, result, _ = self.install('--role', 'wiki-and-model', '--label', 'pi5-cpu', '--workspace', ws)
        self.assertEqual((code, result['status']), (0, 'ALREADY_INSTALLED'))
        code, _, err = self.install('--role', 'wiki-and-model', '--label', 'other', '--workspace', ws)
        self.assertEqual(code, 2)
        self.assertIn('Installations are fixed', err)

    def test_profile_rebuilds_on_a_clean_machine(self):
        ws = str(self.root / 'ws')
        self.install('--role', 'wiki-only', '--label', 'pi5-cpu', '--workspace', ws, '--model-host', 'me@gpu-pc')
        saved = self.root / 'saved.json'
        shutil.copy(self.cfg / 'host_profile.json', saved)
        shutil.rmtree(self.cfg)
        shutil.rmtree(ws)
        code, result, _ = self.install('--profile', str(saved))
        self.assertEqual((code, result['status'], result['role']), (0, 'INSTALLED', 'wiki-only'))
        self.assertIn('ssh -N -L 11434:localhost:11434 me@gpu-pc', ' '.join(result['next_steps']))

    def test_model_only_has_no_workspace(self):
        code, result, _ = self.install('--role', 'model-only', '--label', 'gpu-pc')
        self.assertEqual(code, 0)
        self.assertIsNone(result['workspace'])
        code, _, err = self.install('--role', 'model-only', '--label', 'gpu-pc', '--workspace', str(self.root / 'x'))
        self.assertEqual(code, 2)

    def test_invalid_inputs_refused(self):
        for args in (('--role', 'wiki-only', '--label', 'pi', '--workspace', str(self.root / 'w')),  # no model host
                     ('--role', 'wiki-and-model', '--label', 'Bad Label', '--workspace', str(self.root / 'w')),
                     ('--role', 'wiki-and-model', '--label', 'pc')):  # no workspace, non-interactive
            with self.subTest(args=args):
                self.assertEqual(self.install(*args)[0], 2)
        self.assertFalse((self.cfg / 'host_profile.json').exists())

    def test_existing_unsafe_workspace_refused(self):
        ws = self.root / 'loose'
        ws.mkdir(mode=0o755)
        os.chmod(ws, 0o755)
        code, _, _ = self.install('--role', 'wiki-and-model', '--label', 'pc', '--workspace', str(ws))
        self.assertEqual(code, 2)

    def test_install_sh_runs_under_posix_sh(self):
        sh = shutil.which('sh')
        if sh is None:
            self.skipTest('no sh')
        env = {k: v for k, v in os.environ.items() if k not in ('PYTHONPATH',)}
        env.update(HOME=str(self.root), XDG_CONFIG_HOME=str(self.root / 'xdg'))
        proc = subprocess.run([sh, str(RELEASE / 'INSTALL.sh'), '--role', 'model-only', '--label', 'gpu-pc',
                               '--skip-ollama-check'], env=env, capture_output=True, text=True,
                              stdin=subprocess.DEVNULL)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(json.loads(proc.stdout)['status'], 'INSTALLED')
        self.assertTrue((self.root / 'xdg' / 'hwi' / 'host_profile.json').exists())


if __name__ == '__main__':
    unittest.main()
