"""Boundary guard, SQLite gate store and decommission tests."""
from __future__ import annotations

import ast
import datetime
import json
import multiprocessing
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

from .decommission import DecommissionError, decommission
from .gate_store import GateStore, store_path
from .repository import Repository
from .task_fitness import FitnessError
from .test_wiki_contract import Fixture

PKG = Path(__file__).resolve().parent
SCOPE_A, SCOPE_B = 'a' * 64, 'b' * 64


class BoundaryTests(unittest.TestCase):
    """Only repository.py may reach the approved packages or their internals."""

    def modules(self):
        return [p for p in sorted(PKG.glob('*.py')) if not p.name.startswith('test_')]

    def test_only_repository_imports_approved_packages(self):
        offenders = []
        for path in self.modules():
            tree = ast.parse(path.read_text('utf-8'))
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0:
                    names = [node.module or '']
                for name in names:
                    if name.split('.')[0] in ('personal_wiki_core', 'hwi', 'autogpt_lite') \
                            and path.name != 'repository.py':
                        offenders.append(f'{path.name}: {name}')
        self.assertEqual(offenders, [])

    def test_only_repository_touches_private_db(self):
        offenders = [p.name for p in self.modules() for node in ast.walk(ast.parse(p.read_text('utf-8')))
                     if isinstance(node, ast.Attribute) and node.attr == '_db' and p.name != 'repository.py']
        self.assertEqual(offenders, [])

    def test_sqlite_connections_only_in_storage_modules(self):
        offenders = [p.name for p in self.modules()
                     if 'sqlite3.connect' in p.read_text('utf-8')
                     and p.name not in ('gate_store.py', 'repository.py')]
        self.assertEqual(offenders, [])

    def test_release_manifest_has_no_bytecode(self):
        """Compiled bytecode must never ship: it is version-specific and makes the
        approved trees differ from their approved source."""
        manifest = PKG.parents[2] / 'SHA256_MANIFEST.json'
        if not manifest.is_file():
            self.skipTest('not running from a packaged release')
        import json as _json
        names = _json.loads(manifest.read_text('utf-8'))['files']
        self.assertEqual([n for n in names if '__pycache__' in n or n.endswith('.pyc')], [])

    def test_no_platform_specific_locking(self):
        offenders = [p.name for p in self.modules() for node in ast.walk(ast.parse(p.read_text('utf-8')))
                     if (isinstance(node, ast.Import) and any(a.name in ('fcntl', 'msvcrt') for a in node.names))
                     or (isinstance(node, ast.ImportFrom) and node.module in ('fcntl', 'msvcrt'))]
        self.assertEqual(offenders, [])


def _verified(sha='c' * 64):
    return {'assessment_sha256':sha, 'reviewer_key_sha256':'d' * 64}


def _reserve_worker(args):
    root, scope, quota = args
    try:
        with GateStore(root, 'primary', scope, create=True) as store:
            return store.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, quota)
    except FitnessError:
        return None


class GateStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        os.chmod(self.root, 0o700)

    def tearDown(self):
        self.temp.cleanup()

    def store(self, scope=SCOPE_A, create=True, writable=None):
        return GateStore(self.root, 'primary', scope, create=create, writable=writable)

    def test_read_only_open_changes_nothing(self):
        import hashlib
        with self.store() as s:
            s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 5)
            path = s.path
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        with self.store(create=False) as s:
            self.assertEqual(len(s.reservations()), 1)
            with self.assertRaises(sqlite3.DatabaseError):
                s._conn.execute("INSERT INTO meta(key,value) VALUES('k','v')")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)
        self.assertEqual(sorted(p.name for p in path.parent.iterdir()), [path.name])

    def test_read_only_open_reports_but_keeps_unexpected_journal_mode(self):
        with self.store() as s:
            path = s.path
        conn = sqlite3.connect(str(path))
        self.assertEqual(conn.execute('PRAGMA journal_mode=WAL').fetchone()[0], 'wal')
        conn.close()
        with self.assertRaisesRegex(FitnessError, 'journal mode'):
            self.store(create=False).close()
        conn = sqlite3.connect(str(path))
        self.assertEqual(conn.execute('PRAGMA journal_mode').fetchone()[0], 'wal')
        conn.close()

    def test_create_requires_writable(self):
        with self.assertRaises(FitnessError):
            self.store(create=True, writable=False)

    def test_created_private(self):
        with self.store() as s:
            pass
        self.assertEqual(os.stat(self.root / 'governance').st_mode & 0o777, 0o700)
        self.assertEqual(os.stat(s.path).st_mode & 0o777, 0o600)

    def test_missing_store_not_created_on_read(self):
        with self.assertRaises(FitnessError):
            self.store(create=False)
        self.assertFalse(store_path(self.root, 'primary').exists())

    def test_other_scope_refused(self):
        self.store().close()
        with self.assertRaisesRegex(FitnessError, 'different physical notebook'):
            self.store(SCOPE_B, create=False)

    def test_quota_release_and_bind(self):
        with self.store() as s:
            self.assertEqual(s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 2), 1)
            self.assertEqual(s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 2), 2)
            with self.assertRaisesRegex(FitnessError, 'exhausted'):
                s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 2)
            s.release('c' * 64, 2)
            self.assertEqual(s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 2), 2)
            s.bind('c' * 64, 1, 'proposal:' + '0' * 32)
            self.assertTrue(s.is_bound('c' * 64, 'proposal:' + '0' * 32))
            self.assertEqual(s.usage('c' * 64), {'reserved':1, 'bound':1})

    def test_conflicting_receipt_refused(self):
        with self.store() as s:
            s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 5)
            with self.assertRaisesRegex(FitnessError, 'Conflicting'):
                s.reserve({'x':1}, {'y':3}, _verified(), b'\x01' * 32, 5)
            self.assertEqual(s.usage('c' * 64), {'reserved':1, 'bound':0})

    def test_triggers_make_records_immutable(self):
        with self.store() as s:
            s.reserve({'x':1}, {'y':2}, _verified(), b'\x01' * 32, 5)
            s.bind('c' * 64, 1, 'proposal:' + '1' * 32)
            path = s.path
        conn = sqlite3.connect(str(path), isolation_level=None)
        conn.execute('PRAGMA foreign_keys=ON')
        for sql in ("UPDATE receipts SET receipt_json='{}'",
                    'DELETE FROM receipts',
                    "UPDATE uses SET proposal_id='proposal:x'",
                    'DELETE FROM uses',
                    "UPDATE meta SET value='z'",
                    "INSERT INTO uses VALUES('e" + 'e' * 63 + "',1,'RESERVED',NULL,'t')"):
            with self.subTest(sql=sql), self.assertRaises(sqlite3.DatabaseError):
                conn.execute(sql)
        conn.close()
        with self.store(create=False, writable=True) as s:
            with self.assertRaises(FitnessError):
                s.release('c' * 64, 1)  # bound slots are never released
            with self.assertRaises(FitnessError):
                s.bind('c' * 64, 1, 'proposal:' + '2' * 32)  # bound once

    def test_concurrent_reservations_respect_quota(self):
        with self.store():
            pass
        ctx = multiprocessing.get_context('spawn')
        with ctx.Pool(8) as pool:
            slots = pool.map(_reserve_worker, [(str(self.root), SCOPE_A, 3)] * 8)
        self.assertEqual(sorted(s for s in slots if s is not None), [1, 2, 3])
        with self.store(create=False) as s:
            self.assertEqual(s.usage('c' * 64), {'reserved':3, 'bound':0})


class DecommissionTests(Fixture):
    NOW = datetime.datetime(2026, 11, 13, 6, 0, tzinfo=datetime.timezone.utc)

    def provision_governance(self):
        with GateStore(self.repo.root, 'primary', self.repo.scope(), create=True):
            pass
        folder = self.ws.root / 'fitness_policy'
        folder.mkdir(mode=0o700)
        (folder / 'primary.json').write_text('{}')
        (folder / 'primary.json').chmod(0o600)

    def notebook_bytes(self):
        path = self.ws.notebook_path('primary')
        return path.read_bytes(), path.with_name('primary.history.sqlite').read_bytes()

    def test_live_with_pending_refused(self):
        self.submit()
        with self.assertRaisesRegex(DecommissionError, '1 pending'):
            decommission(self.repo, now=self.NOW)
        self.assertTrue(self.repo.ledger_path().exists())

    def test_live_without_pending_archives_everything(self):
        self.provision_governance()
        entry = self.submit()
        self.repo.close_proposal(entry['proposal_id'], action='reject', actor_claim='op', reason='no')
        before = self.notebook_bytes()
        result = decommission(self.repo, now=self.NOW)
        self.assertEqual(result['instance_state'], 'LIVE')
        archive = Path(result['archive'])
        self.assertEqual(archive.name, 'primary-20261113T060000Z')
        self.assertEqual(os.stat(archive).st_mode & 0o777, 0o700)
        moved = {f['from'] for f in result['files']}
        self.assertEqual(moved, {'proposals/primary.proposals.sqlite', 'governance/primary.governance.sqlite',
                                 'review_policy/primary.json', 'fitness_policy/primary.json'})
        manifest = json.loads((archive / 'DECOMMISSION.json').read_text())
        self.assertFalse(manifest['notebook_touched'])
        for f in manifest['files']:
            import hashlib
            self.assertEqual(hashlib.sha256((archive / f['to']).read_bytes()).hexdigest(), f['sha256'])
        self.assertEqual(self.notebook_bytes(), before)
        self.assertFalse(self.repo.ledger_path().exists())
        with self.assertRaisesRegex(DecommissionError, 'Nothing'):
            decommission(self.repo, now=self.NOW)

    def test_reimported_instance_is_orphaned_and_archivable(self):
        self.submit()  # pending on the OLD instance: cannot travel, may be archived
        self.ws.export_backup('primary', 'b')
        # Hold the old inodes open so the restore cannot reuse them (see contract
        # test 9). With reuse, the restore keeps the old scope and decommission
        # refuses (pending proposal on a LIVE instance) - the safe outcome, and the
        # reason the manual says to decommission BEFORE deleting.
        path = self.ws.notebook_path('primary')
        held = [os.open(f, os.O_RDONLY) for f in (path, path.with_name(path.stem + '.history.sqlite'))]
        try:
            self.delete_notebook('primary')
            self.ws.restore_backup('b', 'primary')
        finally:
            for fd in held:
                os.close(fd)
        fresh = Repository(self.ws, 'primary')
        result = decommission(fresh, now=self.NOW)
        self.assertEqual(result['instance_state'], 'ORPHANED')
        self.assertNotEqual(result['current_scope'], result['archived_ledger_scope'])
        fresh.init_ledger()  # a clean ledger for the new instance
        self.assertEqual(fresh.list_proposals(), [])

    def test_existing_archive_destination_refused(self):
        self.provision_governance()
        decommission(self.repo, now=self.NOW)
        self.repo.init_ledger()
        with self.assertRaises(FileExistsError):
            decommission(self.repo, now=self.NOW)

    def test_cli_decommission(self):
        from contextlib import redirect_stdout, redirect_stderr
        from io import StringIO
        from .cli import main
        self.submit()
        err = StringIO()
        with redirect_stdout(StringIO()), redirect_stderr(err):
            self.assertEqual(main(['queue-decommission', '--workspace', str(self.ws.root),
                                   '--notebook', 'primary']), 2)
        self.assertIn('pending', err.getvalue())


if __name__ == '__main__':
    unittest.main()
