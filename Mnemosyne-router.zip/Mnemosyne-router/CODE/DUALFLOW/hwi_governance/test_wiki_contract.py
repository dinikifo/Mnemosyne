"""Contract tests: what HWI governance assumes about the frozen approved core.

Each test pins ONE behaviour of the unchanged APPROVED_WIKI_CORE that the
repository or the review export relies on. If a core release changes one of
them, exactly the matching test fails and its docstring says what to update.
These tests may import approved packages directly; production governance code
may not (see test_boundary).
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from personal_wiki_core import NotebookWorkspace
from personal_wiki_core.renderer import render_tiddler

from .repository import DEFINITE_REJECTIONS, Repository, normalize_proposal_request


class Fixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name).resolve(strict=True)
        os.chmod(root, 0o700)
        self.ws = NotebookWorkspace(root / 'workspace', create=True)
        self.ws.create_notebook('primary')
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            wiki.save_tiddler('Evidence', 'Original claim', ['research'], reason='seed')
            wiki.knowledge_catalog().initialize()
        self.repo = Repository(self.ws, 'primary')
        self.repo.init_ledger()
        self.sk = Ed25519PrivateKey.generate()
        self.pub = self.sk.public_key().public_bytes(serialization.Encoding.Raw,
                                                     serialization.PublicFormat.Raw)
        folder = self.ws.root / 'review_policy'
        folder.mkdir(mode=0o700)
        path = folder / 'primary.json'
        path.write_text(json.dumps({'schema':'hwi.review.policy.v1', 'notebook_scope':self.repo.scope(),
                                    'reviewer_key_sha256':hashlib.sha256(self.pub).hexdigest()}))
        path.chmod(0o600)

    def tearDown(self):
        self.temp.cleanup()

    def submit(self, text='Corrected claim'):
        current = self.repo.find_by_title('Evidence')[0]
        return self.repo.submit_proposal(operation='revise', reason='r', source_refs=['external:case'],
                                         author_origin='human', target_ref=current['ref'],
                                         expected_revision_sha256=current['revision_sha256'],
                                         proposed={'title':'Evidence','text':text,'tags':['research'],'fields':{}})

    def apply(self, entry):
        sig = self.sk.sign(self.repo.signing_payload(entry['proposal_id'])).hex()
        return self.repo.apply_reviewed_change(entry['proposal_id'], signature_hex=sig,
                                               reviewer_public_key=self.pub)

    def delete_notebook(self, name):
        path = self.ws.notebook_path(name)
        for f in (path, path.with_name(path.stem + '.history.sqlite')):
            f.unlink()


class WikiContractTests(Fixture):
    # 1
    def test_renderer_ignores_type(self):
        """PERSONAL.WIKI renders wiki markup even for type: text/plain.
        If this flips (core A2 release), the export may drop its fenced-code wrapping."""
        html = render_tiddler({'title':'T', 'text':'[[Evidence]]', 'type':'text/plain'})
        self.assertIn('tw://', html)

    # 2
    def test_fenced_code_is_inert(self):
        """Fenced code renders HTML-escaped with no link or macro parsing (export relies on it)."""
        html = render_tiddler({'title':'T', 'text':'```json\n[[Evidence]] <b>x</b>\n```'})
        self.assertNotIn('tw://', html)
        self.assertIn('&lt;b&gt;', html)

    # 3
    def test_list_filter_scanned_in_raw_text_even_inside_fence(self):
        """WikiCore.render scans <$list filter="..."> in RAW text, fences included.
        This is why the export JSON-escapes '<' inside its fenced block."""
        flt = '<$list filter="[tag[research]field:kind[x]sort[title]]"/>'
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            wiki.save_tiddler('Target', 'x', ['research'], fields={'kind':'x'}, reason='seed')
            wiki.save_tiddler('Fenced', '```\n' + flt + '\n```', [], reason='seed')
            html = wiki.render('Fenced')
        self.assertIn('tw://tiddler/Target', html)

    # 4
    def test_json_is_the_only_import_format(self):
        """Only import_json / import_records exist; the export ships a JSON array of records."""
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            self.assertEqual(sorted(m for m in dir(wiki) if m.startswith('import')),
                             ['import_json', 'import_records'])
            self.assertEqual(wiki.import_records([{'title':'R', 'tags':'HWIReview', 'type':'text/plain',
                                                    'text':'x'}]), 1)

    # 5
    def test_protected_import_cannot_be_overwritten(self):
        """A post imported as protected evidence refuses later overwrite (manual: answer No)."""
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            wiki.import_records([{'title':'R', 'text':'v1'}], protect_imported=True, reason='r')
            with self.assertRaises(PermissionError):
                wiki.import_records([{'title':'R', 'text':'v2'}], on_conflict='overwrite', reason='r')

    # 6
    def test_receipts_live_in_history_table_keyed_by_proposal_id(self):
        """HWI-08 receipts are rows of hist.hwi08_receipts(proposal_id,...) (raw read in repository)."""
        entry = self.submit()
        self.apply(entry)
        self.assertIn(entry['proposal_id'], self.repo.applied_proposal_ids())
        with self.ws.open_notebook('primary', readonly=True) as wiki:
            cols = [r[1] for r in wiki._db.conn.execute('PRAGMA hist.table_info(hwi08_receipts)')]
        self.assertIn('proposal_id', cols)

    # 7
    def test_restored_copy_gets_new_scope(self):
        """Scope = path + device + inode: a restored copy is a different instance."""
        self.ws.export_backup('primary', 'b1')
        self.ws.restore_backup('b1', 'copy')
        self.assertNotEqual(Repository(self.ws, 'copy').scope(), self.repo.scope())

    # 8
    def test_bundle_carries_history_catalog_receipts_not_ledger(self):
        """A .pwbundle carries posts, history, HWI catalog and HWI-08 receipts only."""
        entry = self.submit()
        self.apply(entry)
        self.ws.export_backup('primary', 'b2')
        self.ws.restore_backup('b2', 'copy')
        copy = Repository(self.ws, 'copy')
        self.assertIn(entry['proposal_id'], copy.applied_proposal_ids())
        self.assertEqual(copy.find_by_title('Evidence')[0]['title'], 'Evidence')  # catalog usable
        self.assertFalse(copy.ledger_path().exists())
        self.assertFalse((self.ws.root / 'governance' / 'copy.governance.sqlite').exists())

    # 9
    def test_ledger_refuses_reimported_instance(self):
        """After delete + restore under the same name the old ledger is refused; its meta
        still names the old scope (decommission reads it)."""
        old_scope = self.repo.scope()
        self.ws.export_backup('primary', 'b3')
        # Keep the deleted files' inodes allocated (open descriptors; the core
        # refuses extra hard links) so the restore cannot reuse them. Scope =
        # path + device + inode: if a filesystem reuses BOTH inode numbers, a
        # restore at the same path gets the old scope and is not detected as a
        # new instance. That is a known limitation of the approved core
        # (portable identity is an A2 item); the documented procedure is
        # queue-decommission BEFORE deleting or replacing a notebook.
        path = self.ws.notebook_path('primary')
        held = [os.open(f, os.O_RDONLY) for f in (path, path.with_name(path.stem + '.history.sqlite'))]
        try:
            self.delete_notebook('primary')
            self.ws.restore_backup('b3', 'primary')
        finally:
            for fd in held:
                os.close(fd)
        fresh = Repository(self.ws, 'primary')
        self.assertNotEqual(fresh.scope(), old_scope)
        self.assertEqual(fresh.ledger_scope_on_disk(), old_scope)
        with self.assertRaises(DEFINITE_REJECTIONS):
            fresh.list_proposals()

    # 10
    def test_ledger_rejections_happen_before_commit(self):
        """Stale or invalid submissions raise ProposalError/BrokerError and leave no row.
        The gate returns its quota slot on exactly these exceptions."""
        current = self.repo.find_by_title('Evidence')[0]
        cases = [dict(expected_revision_sha256='f' * 64),
                 dict(source_refs=[]),
                 dict(operation='explode')]
        for change in cases:
            kwargs = dict(operation='revise', reason='r', source_refs=['external:case'],
                          author_origin='agent', target_ref=current['ref'],
                          expected_revision_sha256=current['revision_sha256'],
                          proposed={'title':'Evidence','text':'x','tags':['research'],'fields':{}})
            kwargs.update(change)
            with self.subTest(change=change), self.assertRaises(DEFINITE_REJECTIONS):
                self.repo.submit_proposal(**kwargs)
        self.assertEqual(self.repo.list_proposals(), [])
        first = self.submit('dup')
        with self.assertRaises(DEFINITE_REJECTIONS):
            self.submit('dup')
        self.assertEqual([e['proposal_id'] for e in self.repo.list_proposals()], [first['proposal_id']])


    # 11
    def test_ledger_normalisation_matches_repository(self):
        """The ledger trims reason, source references and the proposed title only.
        The gate normalises with normalize_proposal_request before reserving, so its
        saved recovery intent equals the committed record."""
        current = self.repo.find_by_title('Evidence')[0]
        spec = {'operation':'revise', 'reason':'  padded reason \n', 'source_refs':['  external:case  '],
                'author_origin':'agent', 'target_ref':current['ref'],
                'expected_revision_sha256':current['revision_sha256'], 'task_id':'t',
                'proposed':{'title':'  Evidence  ', 'text':'  keep spaces  ', 'tags':['zeta', 'alpha'],
                            'fields':{'note':'  kept  '}}}
        entry = self.repo.submit_proposal(**{k:v for k, v in spec.items() if k != 'task_id'})
        record, norm = entry['record'], normalize_proposal_request(spec)
        self.assertEqual(record['reason'], norm['reason'])
        self.assertEqual(record['source_refs'], norm['source_refs'])
        self.assertEqual(record['after'], norm['proposed'])
        self.assertEqual(norm['proposed']['text'], '  keep spaces  ')  # not trimmed by the ledger

if __name__ == '__main__':
    unittest.main()
