# HWI Governance candidate (not yet separately accepted)

Adds task-specific fitness assessment + owner-signed approval evidence and a
wiki proposal review exporter/apply/restore operator CLI over the **unchanged**
approved HWI proposal, review and history APIs.

The `For Human Review and Approval` section is a PERSONAL.WIKI JSON
**manual import snapshot** with all proposal content inert inside a fenced code
block (PERSONAL.WIKI ignores `type`), not a live page. It never authenticates approvals.
The only wiki-editing command delegates to approved `hwi.reviewed_writes`,
requiring the operator-enrolled Ed25519 public key and exact proposal signature.
Restoration of active notes is a new HWI-07 revise proposal requiring identical
signed review; the code does not use the unrestricted wiki restore method.

`fitness-assess` reads externally supplied test evidence, not ground truth;
`fitness-verify` only validates a signed task-specific decision against the
operator-provisioned `fitness_policy/<notebook>.json` pin, and no
PVS, execution or wiki-edit permission is granted. The CLI requires this
signed scope for all `queue-submit` specifications, even a claimed human
origin, because the origin field is untrusted. Human recovery is a separate
explicit restore-proposal operation that still requires HWI-08 signing.

Modules: `repository.py` (only boundary to the approved packages),
`gate_store.py` (SQLite gate records), `fitness_policy.py` (operator pins and
gate verification), `task_fitness.py`, `review_queue.py`, `display.py`,
`decommission.py`, `install.py` (used by `INSTALL.sh`), `cli.py`.

See `USER_MANUAL.md` for end-to-end operator steps and limitations.

Offline tests:

```sh
PYTHONPATH="CODE/DUALFLOW:CODE/APPROVED_WIKI_CORE:CODE/APPROVED_AGENT_PROVIDER" \
  python3 -B -m unittest -q hwi_governance.test_governance hwi_governance.test_wiki_contract hwi_governance.test_repository_layer hwi_governance.test_install
```

The accepted 10/10 baseline remains unchanged; this is an additional
production-governance candidate, not retrospective acceptance.

## Interrupted gate submission recovery (experimental)

`queue-gate-recover` is a read-only operator diagnostic; `--apply` repairs only
a uniquely matched, committed proposal's stranded quota binding. It never
releases unmatched reservations or authorizes wiki edits. This mitigates one
crash window but **does not make the two SQLite commits atomic**. See
`docs/integration/GATE_INTERRUPTION_RECOVERY.md`.
