"""The shared boundary between HWI governance/Formation and approved wiki packages.

Principle: SQLite holds authoritative state; PERSONAL.WIKI presents knowledge and
reviewable views of it; HWI governance is the reasoning and workflow layer.

This is the ONLY governance module allowed to import ``personal_wiki_core`` or
``hwi`` or to touch a private ``_db`` attribute (enforced by ``test_boundary``).
Every assumption it makes about the frozen approved core is pinned by
``test_wiki_contract``; a core change therefore fails one named test instead of
causing a silent seam bug elsewhere.

The repository exposes behaviour, not table layouts. Where no public approved
API exists, the private access is confined here, documented, and contract-tested
(see ``applied_proposal_ids`` and ``ledger_scope_on_disk``).
"""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3

from hwi.knowledge_broker import BrokerError, ReadOnlyKnowledgeBroker
from hwi.proposals import KnowledgeProposalLedger, ProposalError
from hwi.reviewed_writes import apply_signed_review, review_message
from personal_wiki_core import NotebookWorkspace
from personal_wiki_core.db import custom_fields, parse_tags

# Exceptions after which the approved HWI-07 ledger has provably NOT committed a
# proposal: validation and staleness checks run before its BEGIN IMMEDIATE, and
# errors inside that transaction are rolled back (contract-tested).
DEFINITE_REJECTIONS = (ProposalError, BrokerError)

_LEDGER_PAGE = 100
_LEDGER_MAX_OFFSET = 10000


class RepositoryError(ValueError):
    pass


def normalize_proposal_request(spec: dict) -> dict:
    """Apply the approved HWI-07 ledger's own input normalisation to a request.

    The ledger trims the reason, every source reference and a proposed note's
    title (``_bounded``), and stores tags, text and fields unchanged. Applying the
    same trimming BEFORE validation and reservation means the gate checks, the
    saved recovery intent and the committed record all see identical values.
    Pinned by ``test_wiki_contract.test_ledger_normalisation_matches_repository``.
    Values of the wrong type are left untouched for the ledger to reject.
    """
    if type(spec) is not dict:
        return spec
    out = dict(spec)
    if type(out.get('reason')) is str:
        out['reason'] = out['reason'].strip()
    refs = out.get('source_refs')
    if type(refs) is list:
        out['source_refs'] = [r.strip() if type(r) is str else r for r in refs]
    proposed = out.get('proposed')
    if type(proposed) is dict and type(proposed.get('title')) is str:
        out['proposed'] = {**proposed, 'title': proposed['title'].strip()}
    return out


def open_workspace(path) -> NotebookWorkspace:
    """Open an existing private workspace by physical path (never creates one)."""
    try:
        return NotebookWorkspace(Path(path).resolve(strict=True))
    except (RuntimeError, OSError) as exc:  # approved WorkspaceError is not a ValueError
        raise RepositoryError(f'Workspace refused: {exc}') from exc


def create_workspace(path) -> Path:
    """Create a new private workspace through the approved constructor (install only).
    Creates no notebook, catalog, ledger, key or policy."""
    path = Path(path).expanduser()
    if path.exists() or path.is_symlink():
        raise RepositoryError('Workspace path already exists')
    try:
        return Path(NotebookWorkspace(path, create=True).root)
    except (RuntimeError, OSError) as exc:
        raise RepositoryError(f'Workspace creation refused: {exc}') from exc


def check_storage_environment() -> None:
    """Approved PERSONAL.WIKI check for SQLite JSON1/FTS5 support; raises if missing."""
    from personal_wiki_core import WikiCore
    WikiCore.check_storage_environment()


class Repository:
    """Behavioural access to one notebook, its proposal ledger and its history."""

    def __init__(self, workspace, notebook: str):
        if isinstance(workspace, (str, Path)):
            workspace = open_workspace(workspace)
        if not isinstance(workspace, NotebookWorkspace):
            raise RepositoryError('Trusted workspace required')
        workspace.notebook_path(notebook)  # validates the name
        self._ws = workspace
        self.notebook = notebook

    # ---- identity -------------------------------------------------------
    @property
    def root(self) -> Path:
        return Path(self._ws.root)

    def notebook_exists(self) -> bool:
        return self._ws.notebook_path(self.notebook).is_file()

    def scope(self) -> str:
        """Physical notebook identity (path + device + inode), per approved HWI-05."""
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            return broker.namespace

    def ledger_path(self) -> Path:
        return self.root / 'proposals' / (self.notebook + '.proposals.sqlite')

    def ledger_scope_on_disk(self):
        """Scope recorded inside an existing ledger file, read-only, or None.

        Used only to decide whether an old ledger belongs to a previous instance
        (decommission). Mirrors the approved HWI-07 ``meta`` table; contract-tested.
        """
        path = self.ledger_path()
        if path.is_symlink() or not path.is_file():
            return None
        conn = sqlite3.connect(f'file:{path}?mode=ro', uri=True)
        try:
            row = conn.execute("SELECT value FROM meta WHERE key='notebook_scope'").fetchone()
            return row[0] if row else None
        finally:
            conn.close()

    # ---- wiki reads -----------------------------------------------------
    def verify_history(self) -> bool:
        with self._ws.open_notebook(self.notebook, readonly=True) as wiki:
            return wiki.verify_history().get('verified') is True

    def applied_proposal_ids(self) -> set:
        """Proposal ids with an HWI-08 application receipt.

        No public approved API exists yet; this mirrors the approved HWI-07
        ``KnowledgeProposalLedger._has_wiki_receipt`` read of the same table and
        is pinned by ``test_wiki_contract``. To be replaced by a core query (A2).
        """
        with self._ws.open_notebook(self.notebook, readonly=True) as wiki:
            if wiki.verify_history().get('verified') is not True:
                raise RepositoryError('Wiki history verification failed')
            conn = wiki._db.conn
            if not conn.execute("SELECT 1 FROM hist.sqlite_master WHERE type='table' "
                                "AND name='hwi08_receipts'").fetchone():
                return set()
            return {r[0] for r in conn.execute('SELECT proposal_id FROM hist.hwi08_receipts')}

    def knowledge_catalog_ready(self) -> bool:
        """True only for a verified HWI-04 catalog in this existing notebook.

        This is a read-only preflight; a missing/uninitialized catalog returns
        False. A failed wiki-history verification is never hidden as readiness.
        """
        if not self.verify_history():
            raise RepositoryError('Wiki history verification failed')
        try:
            with ReadOnlyKnowledgeBroker(self._ws, self.notebook):
                return True
        except BrokerError:
            return False
        except sqlite3.Error as exc:
            raise RepositoryError('Wiki catalog query failed') from exc

    def search(self, query: str, *, mode: str = 'Text', limit: int = 10):
        """Bounded HWI-05 search; all returned records remain untrusted data."""
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            return broker.search(query, mode=mode, limit=limit)

    def find_by_title(self, title: str):
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            return broker.search(title, mode='Title')

    def read(self, reference: str, *, max_text_chars: int | None = None):
        """Read one revision-pinned, unrestricted current wiki record."""
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            if max_text_chars is None:
                return broker.read(reference)
            return broker.read(reference, max_text_chars=max_text_chars)

    def revision(self, reference: str):
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            return broker.revision(reference)

    def post_history(self, post_id: str) -> list:
        """History rows of one post; refuses if any revision is protected or PVS-managed."""
        with self._ws.open_notebook(self.notebook, readonly=True) as wiki:
            if wiki.verify_history().get('verified') is not True:
                raise RepositoryError('History verification failed')
            rows = wiki.post_history(post_id)
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            for event in rows:
                broker.revision(f'hwi05://{broker.namespace}/{post_id}@{event["event_id"]}')
        return rows

    def restorable_snapshot(self, current_ref: str, historical_ref: str) -> dict:
        """Current record plus the verified historical content to propose restoring."""
        with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
            current = broker.read(current_ref)
            historical = broker.revision(historical_ref)
            if (historical_ref.split('@')[0] != current_ref.split('@')[0] or
                    not historical_ref.startswith(f'hwi05://{broker.namespace}/{current["knowledge_id"]}@')):
                raise RepositoryError('Historical and current records must be same post')
            if historical['event_id'] == current['event_id']:
                raise RepositoryError('Historical revision is the current revision; nothing to restore')
        with self._ws.open_notebook(self.notebook, readonly=True) as wiki:
            if wiki.verify_history().get('verified') is not True:
                raise RepositoryError('History verification failed')
            events = wiki.post_history(current['knowledge_id'])
            event = next((e for e in events if e['event_id'] == historical['event_id']), None)
            if event is None:
                raise RepositoryError('Missing historical version')
            snapshot = json.loads(event['after_json'] or event['before_json'])
            if 'pvs' in parse_tags(snapshot.get('tags', [])) or wiki.is_protected(snapshot['title']):
                raise RepositoryError('Managed or protected historical record denied')
        proposed = {'title':snapshot['title'], 'text':snapshot.get('text', ''),
                    'tags':parse_tags(snapshot.get('tags', [])), 'fields':custom_fields(snapshot)}
        return {'current':current, 'proposed':proposed}

    # ---- proposal ledger --------------------------------------------------
    def init_ledger(self) -> str:
        with KnowledgeProposalLedger(self._ws, self.notebook, create=True) as ledger:
            return ledger.namespace

    def list_proposals(self) -> list:
        out, offset = [], 0
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            while True:
                if offset > _LEDGER_MAX_OFFSET:
                    raise RepositoryError('Proposal ledger exceeds listing bounds')
                page = ledger.list_proposals(limit=_LEDGER_PAGE, offset=offset)
                out += page
                if len(page) < _LEDGER_PAGE:
                    return out
                offset += _LEDGER_PAGE

    def get_proposal(self, proposal_id: str) -> dict:
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            return ledger.get(proposal_id)

    def review_view(self, proposal_id: str) -> dict:
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            return ledger.review_view(proposal_id)

    def submit_proposal(self, *, operation, reason, source_refs, author_origin,
                        target_ref, expected_revision_sha256, proposed) -> dict:
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            with ReadOnlyKnowledgeBroker(self._ws, self.notebook) as broker:
                return ledger.submit(broker, operation=operation, reason=reason,
                                     source_refs=source_refs, author_origin=author_origin,
                                     target_ref=target_ref,
                                     expected_revision_sha256=expected_revision_sha256,
                                     proposed=proposed)

    def close_proposal(self, proposal_id: str, *, action: str, actor_claim: str, reason: str) -> dict:
        if action not in ('reject', 'withdraw'):
            raise RepositoryError('Unknown proposal action')
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            fn = ledger.reject if action == 'reject' else ledger.withdraw
            return fn(proposal_id, actor_claim=actor_claim, reason=reason)

    # ---- signed application (approved HWI-08) ----------------------------
    def signing_payload(self, proposal_id: str) -> bytes:
        return review_message(self.get_proposal(proposal_id))

    def apply_reviewed_change(self, proposal_id: str, *, signature_hex: str,
                              reviewer_public_key: bytes) -> dict:
        """Delegate to HWI-08, which re-verifies the signature, the notebook's
        pinned reviewer key, the exact revision and replay receipts itself."""
        with KnowledgeProposalLedger(self._ws, self.notebook) as ledger:
            return apply_signed_review(self._ws, self.notebook, ledger, proposal_id,
                                       signature_hex=signature_hex,
                                       reviewer_public_key=reviewer_public_key)
