# HWI Dual-Flow — User Manual

**Consolidated release: accepted 10/10 research baseline + task-fitness and wiki-review integration candidate**  
**Edition:** 12 November 2026, revised 13 November 2026 (governance review fixes, repository interface and interrupted-submission recovery; see `GOVERNANCE_RELEASE_NOTES.md`)  
**Audience:** operators, human reviewers, research users, and maintainers  
**Status:** the earlier scoped 10/10 Dual-Flow research work remains accepted. The governance functions in this edition are newly implemented and offline-tested, **not separately approved for production deployment**.

## 1. Purpose and operating principle

HWI supports controlled reasoning about work and knowledge. It can retrieve selected PERSONAL.WIKI records read-only, generate proposed workflow revisions using local Ollama, interpret/simulate workflows, validate revision-pinned patches, and evaluate cited reports. It does **not** grant an LLM independent authority to execute workflows, edit protected content, certify facts, or approve its own conclusions.

This release adds two complementary features:

1. **Task Fitness Contract** — evaluate a specified agent configuration **for one named task, notebook and domain**, with pinned test evidence and a separately signed owner decision. A positive assessment is only *eligible for human task approval*. There is no general-purpose “reliable agent” label.
2. **For Human Review and Approval** — use the approved HWI proposal ledger as the authoritative queue; export an inert PERSONAL.WIKI import snapshot of the review section; examine exact before/after differences; apply a proposal only with the notebook's separately pinned Ed25519 reviewer signature; inspect append-only version history; and restore a previous **active** post revision by submitting a new signed proposal.

**Important:** The exported review section is a **manually imported snapshot**, not a live PERSONAL.WIKI panel. The signed proposal ledger, not wiki page text or an AI message, is the authoritative queue. Importing or editing that page does not approve a proposal.

## 2. At a glance: what is and is not supported

| Supported workflow | Boundary |
|---|---|
| Specify task, model/configuration fingerprints, permitted proposal operations, and test cases | Contract is task-specific, not universal competence |
| Assess exact result files against predeclared thresholds, including mandatory critical cases | Test outcomes are supplied evidence claims until independently inspected |
| Verify an offline owner signature against the operator-provisioned workspace key pin (`fitness_policy/`) | Not PVS approval or execution authorization |
| Queue create/revise/link/retire wiki proposals using HWI-07 | Submissions **do not edit** PERSONAL.WIKI |
| Export the review queue as a PERSONAL.WIKI JSON import file (`For Human Review and Approval`) | Import is operator-initiated; queue export never changes a notebook |
| Display the exact difference and obtain the precise signing payload | Humans must inspect before signing |
| Apply a one-use signed proposal using HWI-08, with strict revision checks | Only permitted, non-PVS, non-protected wiki content; policy must already be provisioned |
| View historical revision metadata and propose rollback | Restoration is a new signed edit; it does not erase history |
| Run Ollama patch trials and cited-content tests | Structural/mechanical success is not semantic truth or human approval |

## 3. Package structure

Extract the consolidated ZIP into a **new directory**. The release layout is:

- `CODE/DUALFLOW/` — versioned workflow language, simulator, model evaluators, and `hwi_governance/` canonical source. Inside it, `repository.py` is the only module that touches the approved packages, and `gate_store.py` holds the task-fitness gate records in SQLite.
- `CODE/APPROVED_WIKI_CORE/` — unchanged approved wiki, knowledge broker, proposals, signed-review writer, and history implementation.
- `CODE/APPROVED_AGENT_PROVIDER/` — unchanged approved local Ollama provider.
- `CONTENT_EVAL/` — cited-report/content evaluator and fixtures.
- `MAC_TOOLS/` — macOS launcher tests and diagnostics.
- `RUN_ON_MAC.command`, `RUN_CONTENT_EVAL.command` — previous research workflows.
- `INSTALL.sh` — records this machine's role once (§4).
- `RUN_GOVERNANCE.command` — new task fitness / operator review commands.
- `RUN_ALL_OFFLINE.command` — old test suites plus new governance tests.
- `USER_MANUAL.md`, `USER_MANUAL.pdf`, `USER_MANUAL.docx` — this manual.
- `VERIFY_ARCHIVE.py`, `SHA256_MANIFEST.json` — integrity verification; see `GOVERNANCE_RELEASE_NOTES.md`.
- `GIT/` — local portable Git bundle (accepted baseline + unaccepted governance candidate).

Never combine or overwrite notebooks with source archives. Keep workspace data outside the release folder.

## 4. Installation and verification

**Prerequisites:** macOS or Linux, Python 3.11+, `cryptography` for signature verification and existing approved agent dependencies for Ollama integration. The Mac launchers use `python3` unless `HWI_PYTHON` is explicitly set. The separate `MAC_SETUP.command` from the previous release can help with its optional environment.

From Terminal inside the extracted folder:

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_ALL_OFFLINE.command
```

Expected: checksum validation succeeds; the dual-flow, Mac-launcher, content-evaluator and governance test suites complete. Some environment-specific Ollama-negative tests may print that no service is present; the **overall unittest result** is the relevant outcome. Native macOS results must be recorded separately from Linux verification.

Inspect commands without changing anything:

```sh
bash RUN_GOVERNANCE.command --help
bash RUN_GOVERNANCE.command fitness-assess --help
bash RUN_GOVERNANCE.command queue-export --help
```

Running unit tests uses isolated temporary workspaces and synthetic source cases. It does **not** operate on your actual PERSONAL.WIKI notebooks.

### Native verification on each machine (Gate A)

Run this once on every machine you will use (macOS, the Linux PC, the Raspberry Pi), with a label for that machine:

```sh
bash RUN_GATE_A_NATIVE.command --label mac-m2
```

It verifies the archive first, then runs all offline suites, the manual walkthrough end to end through `RUN_GOVERNANCE.command`, eight concurrent gated submissions against a quota of three, and `INSTALL.sh` twice in a temporary home folder. It uses temporary folders and throwaway keys only, never your notebooks, keys, policies or `~/.config/hwi`. The result is `~/hwi-gate-a/<label>-<timestamp>/GATE_A_REPORT_<label>.json` (mode 0600) plus one log per step; the report also records platform facts (Python, SQLite and FTS5, `cryptography`, whether Ollama answers, whether the home folder is on an SD card). Gate A is met on that machine when the report says `"gate_a_passed_on_this_machine": true`.

### Record this machine's role (once)

Each machine is installed once and stays where it is. `INSTALL.sh` (POSIX `sh`, Linux and macOS) asks one question, what this machine does, and saves the answer to `~/.config/hwi/host_profile.json` (mode 0600):

| Role | Use when | What the script does |
|---|---|---|
| `wiki-and-model` | The wiki and Ollama run on this machine | Creates an empty private workspace if needed; checks Ollama on `127.0.0.1:11434` |
| `wiki-only` | The wiki runs here, the model on another machine | Creates the workspace; prints the `ssh -N -L 11434:localhost:11434 <host>` tunnel command |
| `model-only` | This machine only serves Ollama | No workspace; prints how the wiki host reaches it |

```sh
sh INSTALL.sh                                   # interactive
sh INSTALL.sh --role wiki-only --label pi5-cpu \
  --workspace /private/path/to/HWI-workspace --model-host me@gpu-pc
sh INSTALL.sh --profile saved-host_profile.json # rebuild a machine from its saved profile
```

It also checks Python 3.11+, `cryptography` and SQLite JSON/FTS5 support, and warns when the workspace sits on an SD card (prefer an SSD on a Raspberry Pi). The machine label names fitness configurations, for example `llama3.1:8b@pi5-cpu`, because the same model can answer differently on different hardware. Re-running with the same answers reports `ALREADY_INSTALLED`; a different answer is refused, because installations are fixed. The script never creates notebooks, ledgers, keys or policies: it prints those next steps instead.

## 5. Task Fitness Contract: define the scope

Start from the supplied **synthetic example** at `CODE/DUALFLOW/hwi_governance/examples/TASK_FITNESS_CONTRACT.example.json`. Prepare your own file containing:

- `task_id`, `domain`, and `objective`: the specific use case, not a universal agent specification.
- `notebook`: the named wiki notebook in scope.
- `configuration`: the model identifier plus SHA-256 pins for the model build, prompt, workflow, tool set and evidence scope. Do not reuse the placeholders from examples in real evaluations.
- `allowed_operations`: which proposal types this task may submit (`create`, `revise`, `link`, `retire`). These are **proposal** operations, not execution permissions.
- `cases`: at least three relevant scenarios, each with an ID, purpose, evidence digest, and `critical` indicator. **At least one case must be critical.** Include positive, negative, edge and failure cases appropriate for the domain.
- `acceptance`: `min_pass_percent` (an integer from **50** to 100), `max_unknown` and mandatory `require_all_critical_pass: true`.
- `valid_until`: the last UTC date (`YYYY-MM-DD`) on which the signed scope may gate new submissions; at most 366 days ahead. After it, a fresh contract, evaluation and signature are required.
- `max_proposals`: how many proposals (1–1000) this signed scope may gate in total, counted across every ledger state. One signature is therefore not a perpetual credential.
- `schema`: `hwi.task_fitness.contract.v2` (results files use `hwi.task_fitness.results.v2`). v1 files are refused.

For example, a historical-research task might require: identifying a genuine numerical discrepancy, distinguishing an open verification gate from conflicting claims, and refusing an unsupported citation. A software-review task would use entirely different cases. Fitness in one task makes **no claim** about another.

Define cases **before** testing. Keep expected outcomes and annotated evidence separately under human control. Avoid designing criteria after looking at model responses.

## 6. Assess pinned results

Make a result file with one row per declared case: `case_id`, `status` (`PASS`, `FAIL`, or `UNKNOWN`), exact `evidence_sha256`, and an evaluator note. The result's `contract_sha256` and `configuration_sha256` must match the complete contract/configuration using HWI's canonical JSON hashing rules; obtain them (and the declared case IDs) with:

```sh
bash RUN_GOVERNANCE.command fitness-pins --contract task-contract.json
```

Each case's `evidence_sha256` is the SHA-256 of that case's evidence file (for example `shasum -a 256 evidence.json` on macOS). The synthetic sample is supplied at `CODE/DUALFLOW/hwi_governance/examples/TASK_FITNESS_RESULTS.example.json`.

For sample-only demonstration:

```sh
bash RUN_GOVERNANCE.command fitness-assess \
  --contract CODE/DUALFLOW/hwi_governance/examples/TASK_FITNESS_CONTRACT.example.json \
  --results CODE/DUALFLOW/hwi_governance/examples/TASK_FITNESS_RESULTS.example.json \
  --output sample-assessment.json
```

An eligible result is named **`ELIGIBLE_FOR_HUMAN_TASK_APPROVAL`**, not “generally fit” or “permission granted.” A missing result, changed configuration pin, unknown critical case, invalid evidence digest, insufficient passing cases, a contract with no critical case, a pass threshold below 50, or an expired `valid_until` fails closed. Because at least one critical case must pass, an all-`FAIL` result set can never be eligible.

**Evidence limitation:** The evaluator enforces pins, set completeness and decision thresholds. It does not establish that a human actually ran each test or that the notes are true. Independent review of the case evidence remains required.

## 7. Operator signing and key enrollment

Task fitness and wiki editing are **different approval acts** and **must** use distinct offline Ed25519 keys; the CLI refuses a fitness key whose fingerprint equals the notebook's HWI-08 wiki reviewer pin. The application only verifies public keys and signatures. Do not store signing private keys under the agent's control, inside exported proposal files, or in the code release.

For fitness approval, generate the exact signing payload:

```sh
bash RUN_GOVERNANCE.command fitness-signing-payload \
  --assessment sample-assessment.json --output task-signing-message.json
```

The payload names the task, notebook, allowed operations, `valid_until` and `max_proposals`, so the owner signs the scope explicitly. The owner inspects the assessment and underlying evidence, then signs **these exact file bytes offline** with the enrolled fitness key. A decision JSON must have exactly:

```json
{
  "schema": "hwi.task_fitness.owner_decision.v2",
  "assessment_sha256": "<the exact assessment digest>",
  "decision": "APPROVE_FOR_DECLARED_TASK",
  "signature_hex": "<128 lowercase hexadecimal characters>"
}
```

The public key is supplied as a **32-byte raw Ed25519 public key** (or a 64-character hex representation) in a file with mode `0600`. Its fingerprint is **not** taken from the command line: it must match the operator-provisioned `fitness_policy/<notebook>.json` inside the private workspace (Appendix A), exactly as HWI-08 reads `review_policy/`. A key generated by whoever runs the CLI is therefore rejected unless the operator has enrolled it. Enrollment is an **operator action, outside the LLM or CLI**, and must be verified out of band. (`--operator-pin` was removed in this revision.)

Verify without editing any wiki (the assessment must name the same notebook as `--notebook`):

```sh
bash RUN_GOVERNANCE.command fitness-verify \
  --assessment sample-assessment.json \
  --owner-decision owner-decision.json \
  --owner-public-key /secure/operator-fitness-pub.bin \
  --workspace /private/path/to/HWI-workspace --notebook primary
```

The success status is `OWNER_SIGNED_TASK_SCOPE_ONLY`. It authorizes neither execution nor wiki writing. Do **not** sign the synthetic example as a real task assessment.

## 8. Prepare PERSONAL.WIKI for review

The wiki workspace and notebook must already exist, with history and its HWI knowledge catalog explicitly initialized via the approved PERSONAL.WIKI process. The workspace root must be private (`0700`) and use a **physical path** (macOS may expose `/var` through a `/private/var` symlink). Choose a notebook name such as `primary` and keep the workspace outside the release directory.

Initialize the separate proposal ledger (does not change notebook content):

```sh
bash RUN_GOVERNANCE.command queue-init \
  --workspace /private/path/to/HWI-workspace --notebook primary
```

Search permitted records read-only to obtain an exact `hwi05://...` revision reference and digest:

```sh
bash RUN_GOVERNANCE.command queue-search \
  --workspace /private/path/to/HWI-workspace \
  --notebook primary --query 'Example Topic'
```

If the notebook is missing, not history-verified, or the HWI knowledge catalog was never initialized, the command fails; it does not silently create or trust a substitute notebook.

## 9. Submit a proposed edit

An operator prepares a JSON submission specification with **exactly** these fields:

```json
{
  "task_id": "historical_research",
  "operation": "revise",
  "reason": "Correct the reported source discrepancy",
  "source_refs": ["external:reviewed-case-001"],
  "author_origin": "agent",
  "target_ref": "hwi05://<notebook-scope>/<post-id>@<event-id>",
  "expected_revision_sha256": "<current 64-hex revision SHA-256>",
  "proposed": {
    "title": "Example Topic",
    "text": "Proposed corrected content with source citations.",
    "tags": ["research"],
    "fields": {}
  }
}
```

`create` uses a null `target_ref`/`expected_revision_sha256`; `retire` uses null `proposed`; `link` has its own relation/target format. Source references must satisfy the approved HWI-07 ledger contract. An LLM-origin proposal cannot self-certify its fitness, and the new CLI requires a signed task decision **even if the input declares `author_origin: human`**, because that field is untrusted.

```sh
bash RUN_GOVERNANCE.command queue-submit \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --spec proposed-edit.json \
  --contract task-contract.json --results task-results.json \
  --assessment task-assessment.json --owner-decision owner-decision.json \
  --owner-public-key /secure/operator-fitness-pub.bin
```

The command first checks the specification shape (a malformed file is `REJECTED`, never a traceback), then rechecks the task evaluation, the signature against the workspace fitness pin, the expiry date and the `max_proposals` quota, and ensures notebook, task ID and proposal operation are in scope. It records the signed scope and reserves one quota slot in a single SQLite transaction in `governance/<notebook>.governance.sqlite` (created on first use, mode 0600, tied to this notebook instance like the ledger), submits, then binds that slot to the new proposal id, and appends the source reference `external:hwi-fitness/<assessment-sha256>` to the proposal, so every reviewer can see and re-verify which signed scope gated it. A specification may therefore carry at most 11 of its own source references and must contain 1–11 evidence references of its own and must not contain an `external:hwi-fitness/...` reference itself (the gate's reference does not count as evidence).

Quota is counted from the gate's own usage records, not from ledger references, so a caller that copies a real `external:hwi-fitness/...` reference into an ungated HWI-07 submission can neither use up the quota nor appear `VERIFIED`. A definite ledger rejection (invalid spec, stale revision, duplicate) returns the slot; any other failure keeps it consumed, because the submission may have been recorded. Before any check, the specification is normalised exactly as the ledger will store it (the reason, each source reference and a proposed title are trimmed), so the gate, the saved request and the committed record always agree.

If the submission is interrupted, the command exits with status 3 and one of two messages; in both cases **do not resubmit**:

- `SUBMITTED_WITHOUT_GATE_RECORD`: the proposal was committed (its id is shown) but the gate could not record it, so it shows as `UNVERIFIED`.
- `SUBMISSION_OUTCOME_UNKNOWN`: an error occurred while the ledger was writing, so the proposal may or may not exist.

### Recover an interrupted submission

Every gated submission saves the exact request in the same transaction as its quota slot. After an exit 3, first run the read-only diagnostic:

```sh
bash RUN_GOVERNANCE.command queue-gate-recover \
  --workspace /private/path/to/HWI-workspace --notebook primary
```

| Status | Meaning |
|---|---|
| `READY_TO_BIND` | Exactly one committed proposal matches exactly one saved request |
| `NO_EXACT_MATCH` | No matching proposal (for example the ledger never committed); the slot stays consumed |
| `AMBIGUOUS` | Several requests or proposals match; nothing is bound |
| `LEGACY_NO_INTENT` | The slot predates saved requests; nothing is guessed |
| `ALREADY_BOUND_ELSEWHERE` | That proposal already uses another slot |

After reviewing the proposal, repair only the `READY_TO_BIND` entries with `--apply`. A slot is never released by recovery. A recovered proposal shows `VERIFIED` with `binding: OPERATOR_RECOVERY` everywhere (`queue-review`, `queue-status`, the export), permanently: it matches a request you signed for, but the gate itself may not have submitted it. Normal submissions show `binding: GATE_SUBMISSION`. Details: `CODE/DUALFLOW/docs/integration/GATE_INTERRUPTION_RECOVERY.md`. It then calls the approved proposal ledger to record an **unapproved, immutable submission**. No wiki edit occurs. Direct use of older HWI-07/08 APIs remains governed by their prior contracts; this CLI does **not** retroactively impose its task gate on those APIs.

## 10. Work with “For Human Review and Approval”

Display proposals and their exact before/after difference. Each entry now carries a `fitness_gate` status:

- `VERIFIED` — the recorded owner signature, receipt and workspace pin were re-checked, the operation is in scope, and the gate's usage record names this exact proposal.
- `UNGATED` — no fitness reference (restore helper, library call or the older HWI-07 API). Review with extra care.
- `UNVERIFIED` / `INVALID` — a fitness reference is present but cannot be verified (missing or altered receipt, key no longer pinned, operation out of scope). Treat as untrusted.

A `VERIFIED` gate proves the owner signed that task scope and that the gate submitted this proposal; it is never a substitute for reviewing the diff.

Review output (`queue-list`, `queue-review`, the export) shows Greek and other printable text as written. Characters a reviewer could not see or that reorder text (bidi overrides, zero-width characters, control characters, non-ASCII spaces, private-use) stay visibly escaped, e.g. `\u202e`. Look-alike letters from different scripts (homoglyphs) are **not** detected. `queue-status` gives a compact read-only summary (counts, ledger state, gate status and binding) without any proposal text.

```sh
bash RUN_GOVERNANCE.command queue-list --workspace /private/path/to/HWI-workspace --notebook primary
bash RUN_GOVERNANCE.command queue-status --workspace /private/path/to/HWI-workspace --notebook primary
bash RUN_GOVERNANCE.command queue-review --workspace /private/path/to/HWI-workspace \
  --notebook primary --proposal-id 'proposal:<32-hex-ID>'
```

Create the section's importable PERSONAL.WIKI snapshot:

```sh
bash RUN_GOVERNANCE.command queue-export \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --output For_Human_Review_and_Approval.json
```

The file is a JSON array with one post, titled **For Human Review and Approval** and tagged `HWIReview`. Import it with PERSONAL.WIKI's *Import TiddlyWiki JSON* (`import_records`); PERSONAL.WIKI has no `.tid` importer. Its renderer ignores the `type` field, so safety does **not** rely on `text/plain`: all proposal-derived content is placed inside one fenced code block, which PERSONAL.WIKI shows HTML-escaped with no link, transclusion or macro parsing, and backtick, `<`, `>` and `&` characters are JSON-escaped so the content can neither close the fence nor trigger the `<$list filter=...>` scan. Pending proposals are listed first; at most 100 are shown and any omission is stated on the page (use `queue-list` for the full ledger). When importing, answer **No** to *Protect evidence*: a protected review post cannot be refreshed later. To refresh, import the new snapshot choosing **Yes** (replace conflicting records) and give a reason. Re-export creates a new snapshot file; existing files are never overwritten. The wiki view is a convenience display, **not a live authoritative queue**.

A non-signed administrative claim can close an unused proposal without editing wiki content:

```sh
bash RUN_GOVERNANCE.command queue-reject \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --proposal-id 'proposal:<32-hex-ID>' \
  --actor-claim operator --reason 'Evidence insufficient'
```

The `actor_claim` is not independently authenticated. A proposal already applied cannot be retroactively rejected or withdrawn.

## 11. Apply an exact reviewed edit

After inspecting the sources, the diff, target record, and task scope, the reviewer obtains the **exact message bytes** the approved HWI-08 writer expects:

```sh
bash RUN_GOVERNANCE.command queue-signing-payload \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --proposal-id 'proposal:<32-hex-ID>' \
  --output wiki-review-signing-message.json
```

The reviewer signs these exact bytes **offline**, then the operator applies the proposal using the approved wiki reviewer key. The notebook must already have an operator-provisioned `review_policy/primary.json` with mode `0600`, in a private `review_policy` directory (`0700`), matching the notebook's physical namespace and **the enrolled review public-key fingerprint**. This policy is not generated by the agent.

```sh
bash RUN_GOVERNANCE.command queue-apply \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --proposal-id 'proposal:<32-hex-ID>' \
  --signature-hex '<128-lowercase-hex-digits>' \
  --reviewer-public-key /secure/wiki-reviewer-pub.bin
```

`queue-apply` re-checks the proposal's fitness gate first. If it is not `VERIFIED` (for example `UNGATED` restore proposals, or `UNVERIFIED` references), the command refuses until the operator adds `--accept-unverified-gate` after reviewing the proposal on its own merits; the acceptance is recorded in the command output. The signed review, not the flag, remains the authority.

The HWI-08 writer rechecks the signed proposal, enrolled key pin, current revision and current before-image inside the SQLite writer transaction. It refuses PVS-managed or protected records, stale revisions, invalid signatures, and repeated application. A successful permitted edit records both a content/history event and an HWI-08 application receipt. **Neither this act nor a task-fitness decision confers PVS or SEC-02 permissions.**

For an uncertain outcome, inspect the receipt and wiki history before attempting anything else. **Never automatically retry** a possibly committed write.

## 12. View history and restore safely

Obtain the post ID from the active `hwi05://<scope>/<post_id>@<event_id>` reference. Show revision metadata:

```sh
bash RUN_GOVERNANCE.command queue-history \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --post-id '<post-id>'
```

To inspect a historical revision's permitted text:

```sh
bash RUN_GOVERNANCE.command queue-revision \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --reference 'hwi05://<scope>/<post-id>@<old-event-id>'
```

To restore an earlier **active** record, first obtain the latest current reference, then create a **new restoration proposal** (the source and target must be the *same* post):

```sh
bash RUN_GOVERNANCE.command queue-restore-proposal \
  --workspace /private/path/to/HWI-workspace --notebook primary \
  --current-ref 'hwi05://<scope>/<post-id>@<current-event-id>' \
  --historical-ref 'hwi05://<scope>/<post-id>@<old-event-id>' \
  --reason 'Undo reviewed but incorrect change'
```

The restore helper is an explicit human recovery tool and is **not** fitness-gated, so its proposals display as `UNGATED`. It refuses a historical reference equal to the current revision, or historical content identical to the current content. Review and sign the resulting proposal just as in §11, then apply it with `--accept-unverified-gate`. Only then does `queue-apply` restore the previous note content, recording **another history event**, not erasing the intervening changes. Original creation/modification timestamps may not be reproduced by a proposed revision; the old full snapshot remains in the immutable history. This helper intentionally does not restore **deleted** posts, bypass managed/protected records, or reconstruct notes beyond the approved HWI-07 proposal bounds. For full-notebook disaster recovery, use the separate approved `export_backup` / `restore_backup` procedures, restoring into a **new notebook** rather than overwriting the old one.

### Move or retire a notebook instance

A notebook's identity is its physical file: a restored copy is a **new instance**. A `.pwbundle` carries posts, full history, the HWI catalog and HWI-08 receipts. The proposal ledger, the governance database and both policy files stay behind, because they belong to the old instance.

To move to a clean setup on another machine:

1. Apply, reject or withdraw every pending proposal.
2. Export the notebook bundle, run `INSTALL.sh` on the new machine and restore the bundle there.
3. Run `queue-init` and note the new `notebook_scope`.
4. Write `review_policy/` and `fitness_policy/` again with that scope (Appendix A); public keys can be reused.
5. Re-run the task-fitness cases: the new machine is a new configuration.

To replace an instance with an older export on the same machine, first retire its governance files:

```sh
bash RUN_GOVERNANCE.command queue-decommission \
  --workspace /private/path/to/HWI-workspace --notebook primary
```

This **moves** (never deletes) the ledger, the governance database and both policy files into `archive/<notebook>-<UTC timestamp>/` with a `DECOMMISSION.json` manifest of their SHA-256 digests. It never touches the notebook or its history. While the ledger still belongs to the current instance, it refuses if any proposal is pending. After a delete and re-import, the old ledger belongs to an earlier instance; its pending proposals can no longer be applied anywhere, so it is archived as `ORPHANED`. Then restore, `queue-init` and re-provision the policies as above.

## 13. Local Ollama and report evaluation

These commands remain part of the accepted research baseline:

```sh
bash RUN_ON_MAC.command diagnose --model 'llama3.1:8b'
bash RUN_ON_MAC.command trial --model 'llama3.1:8b' --repeats 3
bash RUN_CONTENT_EVAL.command trial 'llama3.1:8b'
```

The local model communicates through loopback Ollama and generates candidate JSON; it cannot authorize itself or publish knowledge. A successful workflow patch is **structurally** valid, not necessarily adequate for the task. Content reports may contain wrong classifications, omissions or misleading free text. Use evidence review and task fitness controls to decide whether a configuration is suitable for each declared activity.

## 14. Troubleshooting and safe recovery

| Symptom | Meaning / response |
|---|---|
| `Symlinked workspace path is forbidden` | Use the **physical** `Path(...).resolve(strict=True)` workspace path; do not weaken the workspace guard |
| Notebook catalog missing | Operator must explicitly initialize the approved HWI knowledge catalog |
| Ledger missing | Run `queue-init` after the notebook is ready |
| `NOT_ELIGIBLE` fitness assessment | Fix task evidence or configuration; do not sign or waive failed critical cases |
| Signed fitness decision rejected | Recheck exact assessment bytes, Ed25519 public key, the workspace `fitness_policy/<notebook>.json` pin and signature |
| `Fitness key must differ from the HWI-08 wiki reviewer key` | Enroll a separate fitness key; never reuse the wiki reviewer key |
| `Task fitness contract has expired` / `Signed task scope has expired` | Re-run the evaluation under a new contract with a current `valid_until` and obtain a new signature |
| `Signed task scope exhausted` | `max_proposals` reached; a new evaluated and signed scope is required |
| `fitness_gate` shows `UNVERIFIED` | Do not rely on the gate; inspect the receipt and policy, and review the diff from first principles |
| `Fitness gate is UNGATED/UNVERIFIED ... --accept-unverified-gate` on apply | Review the proposal without relying on the gate; add the flag only if you still approve it |
| `SUBMITTED_WITHOUT_GATE_RECORD` or `SUBMISSION_OUTCOME_UNKNOWN` (exit 3) | Do not resubmit. Run `queue-gate-recover` (read-only), review, then `--apply` only for `READY_TO_BIND` (§9) |
| Recovery shows `NO_EXACT_MATCH` | The ledger most likely never committed; the slot stays consumed. Submit again only within the remaining quota |
| `Ledger belongs to a different physical notebook` or `Governance store belongs to a different physical notebook` | The notebook was restored or re-imported; run `queue-decommission`, then `queue-init` and re-provision both policies |
| `N pending proposal(s): apply, reject or withdraw them first` | `queue-decommission` refuses to retire a live instance with pending proposals |
| `INSTALL REFUSED: ... already records a different installation` | This machine is already installed; remove `~/.config/hwi/host_profile.json` deliberately only if you really are reinstalling it |
| Install warns about an SD card | Move the workspace to an SSD before real use |
| `unrecognized arguments: --operator-pin` | Removed in this revision; provision `fitness_policy/` instead (Appendix A) |
| Source or target revision stale | Fetch a fresh reference, re-propose, re-review and obtain **new** signature |
| Protected/PVS-managed record refused | Use the independent governed PVS process; this queue cannot authorize it |
| Proposal already applied | Inspect receipt and history; never replay an applied signature |
| Wiki import page is not updating | Export a **new** JSON snapshot and import it explicitly (overwrite with a reason) |
| `Protected historical record 'For Human Review and Approval'` on re-import | The page was imported as protected evidence; it cannot be overwritten. Import future snapshots without protection (rename or remove the old page through PERSONAL.WIKI's normal process) |
| `CONTENT_CHECK_FAILED` | Preserve failed report; human review is not a mechanical override |
| macOS `zsh: command not found: #` | Do not paste shell comments as commands; optionally use `setopt interactivecomments` |

Back up notebooks before production changes, exercise restoration in an isolated environment, protect private keys outside any agent-accessible directories, and retain signed approval evidence and history receipts.

## 15. Acceptance boundaries and production checklist

The prior **WL-01…HWI-I02 10/10 roadmap is accepted** as a scoped research implementation. This new task-fitness/wiki-review integration is an **unaccepted extension** until the owner reviews these changes and its native target environment tests.

Before a real deployment, independently establish: tested task-specific acceptance criteria and representative evidence; separate operator key enrollment/custody; native Mac/Linux qualification appropriate to deployment; explicit least-privilege security review; production backups and rollback rehearsal; monitoring/incident response; and the independent HWI C1–C14 and Linux RC-05 gates where applicable. Those gates are **not** satisfied by this release.

**The operating rule:** *The agent proposes. Deterministic checks expose structural failures. Independent reviewers judge task fitness. A separately pinned human signature authorizes an exact permitted wiki change. PERSONAL.WIKI preserves history. No step confers general AI correctness or protected execution authority.*

## Appendix A. Explicit offline reviewer-key procedure (operator only)

The following is a **manual operator example**, not an agent command and not a substitute for a security review. Use two distinct keys for fitness approval and wiki approval in production. Never expose a private key in a model prompt or store it in a directory that the agent can read. Ensure your `/secure/...` directory is private and outside the wiki/notebook/release trees.

To generate an offline Ed25519 key pair using locally installed Python `cryptography` (replace the example folder with a real operator-controlled location):

```python
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
import hashlib, os
folder = Path('/secure/independent-operator')  # must already exist, mode 0700
private = folder / 'wiki-reviewer-private.bin'
public = folder / 'wiki-reviewer-public.bin'
pin = folder / 'wiki-reviewer-public-pin.txt'
key = Ed25519PrivateKey.generate()
secret = key.private_bytes(serialization.Encoding.Raw,
                           serialization.PrivateFormat.Raw,
                           serialization.NoEncryption())
public_bytes = key.public_key().public_bytes(serialization.Encoding.Raw,
                                             serialization.PublicFormat.Raw)
for path, data in ((private, secret), (public, public_bytes),
                   (pin, hashlib.sha256(public_bytes).hexdigest().encode('ascii'))):
    with path.open('xb') as f:  # never overwrite an existing key
        os.chmod(path, 0o600)
        f.write(data)
```

After confirming the notebook's physical scope using the read-only HWI broker, a human operator provisions the wiki policy by writing this JSON under the private workspace's `review_policy/primary.json` (mode `0600`, parent mode `0700`). This is **not** a new application API:

```json
{
  "schema": "hwi.review.policy.v1",
  "notebook_scope": "<exact namespace returned by ReadOnlyKnowledgeBroker>",
  "reviewer_key_sha256": "<SHA-256 of the 32-byte raw public key>"
}
```

Provision the **fitness** policy the same way, with a **different** key, under `fitness_policy/primary.json` (mode `0600`, parent mode `0700`). The CLI has no API that writes it:

```json
{
  "schema": "hwi.task_fitness.policy.v1",
  "notebook_scope": "<exact namespace returned by queue-init or ReadOnlyKnowledgeBroker>",
  "fitness_key_sha256": "<SHA-256 of the 32-byte raw fitness public key>"
}
```

To sign a task-fitness or wiki-review signing payload **offline**, use the appropriate, separately enrolled private key:

```python
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
key = Ed25519PrivateKey.from_private_bytes(
    Path('/secure/independent-operator/wiki-reviewer-private.bin').read_bytes())
message = Path('wiki-review-signing-message.json').read_bytes()
print(key.sign(message).hex())
```

Record the output signature securely and provide it as `--signature-hex` to the signed wiki-apply command. For task fitness, sign the `task-signing-message.json` bytes with the **fitness reviewer key** and place the resulting lowercase hex signature in the owner-decision JSON. The exact message must not be edited between generation, signing and verification. Signatures and public keys are not passwords, but they bind to the reviewed content and should still be retained as part of the audit record.

A task-fitness signature does **not** satisfy the separate HWI-08 wiki-review signature requirement; the two payloads describe different decisions and cannot be substituted for each other.
