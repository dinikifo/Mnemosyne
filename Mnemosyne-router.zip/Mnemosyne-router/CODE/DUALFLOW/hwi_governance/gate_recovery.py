"""Operator-initiated recovery for interrupted, separately committed gate bindings.

This is not a distributed transaction or an automated slot reclamation system.
An immutable request snapshot is saved with each new reservation. After an
interrupted submit, an exact corresponding ledger record can be bound only when
there is a *single* matching proposal and a *single* matching reservation.

No wiki writes, permissions or fitness approvals are performed by this module.
No absence-of-proposal test is considered proof of a failed ledger commit;
stranded slots without matches continue to count against the signed quota.
"""
from __future__ import annotations

from .gate_store import GateStore
from .repository import normalize_proposal_request
from .task_fitness import fitness_ref
from .review_queue import SPEC_FIELDS


def _matches(entry: dict, request: dict, assessment_sha256: str, scope: str) -> bool:
    """Conservative match of requested input to immutable HWI-07 record.

    The request is first normalised exactly as the approved ledger normalises
    input (``normalize_proposal_request``, contract-tested); any remaining
    mismatch means operator investigation rather than guessing.
    """
    if type(request) is not dict or set(request) != SPEC_FIELDS or type(entry) is not dict:
        return False
    # Intents saved before submit-time normalisation may hold untrimmed values.
    request = normalize_proposal_request(request)
    r = entry.get('record')
    if type(r) is not dict or r.get('notebook_scope') != scope:
        return False
    for name in ('operation', 'reason', 'author_origin', 'target_ref',
                 'expected_revision_sha256'):
        if r.get(name) != request[name]:
            return False
    refs = request['source_refs']
    if type(refs) is not list or not all(type(x) is str for x in refs):
        return False
    if r.get('source_refs') != refs + [fitness_ref(assessment_sha256)]:
        return False
    op, after = r.get('operation'), r.get('after')
    desired = request['proposed']
    if op in ('create', 'revise', 'retire'):
        return after == desired
    if op == 'link':
        return type(after) is dict and type(desired) is dict and \
            after.get('relation') == desired.get('relation') and \
            after.get('to_ref') == desired.get('to_ref')
    return False


def recover_bindings(repo, *, apply: bool = False) -> dict:
    """Inspect unresolved slots, optionally bind unambiguous committed proposals.

    Never releases an unmatched reservation, even if the ledger currently has
    no matching proposal (its commit outcome may have been uncertain).
    Entries with old v1 reservations and no saved intent cannot be repaired.
    """
    scope = repo.scope()
    with GateStore(repo.root, repo.notebook, scope, writable=apply) as store:
        if apply:
            store.install_extensions()  # explicit write path only; diagnostics never migrate
        reservations = store.reservations()
        # A verified ledger must be opened using the approved Repository. A
        # missing/mismatched ledger is a failure, not a reason to free quota.
        entries = repo.list_proposals()
        matched: dict[tuple[str, int], list[dict]] = {}
        for item in reservations:
            key = (item['assessment_sha256'], item['slot'])
            matched[key] = [] if item['intent_spec'] is None else [
                e for e in entries if _matches(e, item['intent_spec'], key[0], scope)]
        counts: dict[str, int] = {}
        for options in matched.values():
            for entry in options:
                pid = entry['proposal_id']
                counts[pid] = counts.get(pid, 0) + 1
        rows = []
        for item in reservations:
            sha, slot = item['assessment_sha256'], item['slot']
            options = matched[(sha, slot)]
            status = 'LEGACY_NO_INTENT' if item['intent_spec'] is None else (
                'NO_EXACT_MATCH' if not options else
                'AMBIGUOUS' if len(options) != 1 or counts[options[0]['proposal_id']] != 1 else
                'ALREADY_BOUND_ELSEWHERE' if store.proposal_is_bound(options[0]['proposal_id']) else
                'READY_TO_BIND')
            pid = options[0]['proposal_id'] if status == 'READY_TO_BIND' else None
            if apply and status == 'READY_TO_BIND':
                # The gate DB itself checks that this exact slot remains
                # RESERVED and its proposal is not bound to another slot.
                store.bind(sha, slot, pid, recovered=True)
                status = 'BOUND_BY_OPERATOR_RECOVERY'
            rows.append({'assessment_sha256': sha, 'slot': slot, 'status': status,
                         'proposal_id': pid, 'matched_count': len(options)})
        return {'schema': 'hwi.governance.gate_recovery.v1',
                'mode': 'OPERATOR_RECOVERY' if apply else 'READ_ONLY_DIAGNOSTIC',
                'notebook': repo.notebook, 'reservations': rows,
                'recovered': sum(r['status'] == 'BOUND_BY_OPERATOR_RECOVERY' for r in rows),
                'wiki_modified': False, 'approval_authorized': False,
                'execution_authorized': False,
                'warning': 'No cross-file atomicity; unmatched or ambiguous slots remain consumed.'}
