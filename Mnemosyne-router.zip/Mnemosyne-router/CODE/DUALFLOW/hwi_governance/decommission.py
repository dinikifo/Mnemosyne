"""Retire one notebook instance's HWI governance files into a dated archive.

Moves, never deletes: the HWI-07 proposal ledger, the governance gate store and
both operator policy files go to ``archive/<notebook>-<UTC timestamp>/`` (0700)
together with a ``DECOMMISSION.json`` manifest of their SHA-256 digests. The
notebook and its history are never touched; keys live outside the workspace.

Two situations are supported:

* LIVE: the ledger belongs to the current notebook instance. Refused while any
  proposal is pending (SUBMITTED and not applied), because pending proposals
  cannot travel to another instance.
* ORPHANED: the notebook is gone, or the ledger belongs to an earlier instance
  (e.g. after deleting the notebook and restoring an older ``.pwbundle`` under
  the same name). Its pending proposals can no longer be applied anywhere, so
  archiving them is allowed and recorded.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
from pathlib import Path

from .repository import Repository, RepositoryError

DECOMMISSION_SCHEMA = 'hwi.decommission.v1'


class DecommissionError(ValueError):
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def _candidates(repo: Repository):
    root, nb = repo.root, repo.notebook
    files = [('proposals', root / 'proposals' / f'{nb}.proposals.sqlite'),
             ('proposals', root / 'proposals' / f'{nb}.proposals.sqlite-journal'),
             ('governance', root / 'governance' / f'{nb}.governance.sqlite'),
             ('governance', root / 'governance' / f'{nb}.governance.sqlite-journal'),
             ('review_policy', root / 'review_policy' / f'{nb}.json'),
             ('fitness_policy', root / 'fitness_policy' / f'{nb}.json')]
    found = []
    for category, path in files:
        if path.is_symlink():
            raise DecommissionError(f'Refusing symlinked governance file: {category}/{path.name}')
        if path.exists():
            if not path.is_file():
                raise DecommissionError(f'Unexpected non-file: {category}/{path.name}')
            found.append((category, path))
    return found


def _instance_state(repo: Repository):
    current = None
    if repo.notebook_exists():
        try:
            current = repo.scope()
        except (RepositoryError, ValueError, RuntimeError, OSError):
            current = None
    on_disk = repo.ledger_scope_on_disk()
    if on_disk is not None and current is not None and on_disk == current:
        return 'LIVE', current, on_disk
    return 'ORPHANED', current, on_disk


def decommission(repo: Repository, *, now=None) -> dict:
    found = _candidates(repo)
    if not found:
        raise DecommissionError('Nothing to decommission for this notebook')
    state, current, on_disk = _instance_state(repo)
    pending = []
    if state == 'LIVE':
        applied = repo.applied_proposal_ids()
        pending = [e['proposal_id'] for e in repo.list_proposals()
                   if e['state'] == 'SUBMITTED' and e['proposal_id'] not in applied]
        if pending:
            raise DecommissionError(f'{len(pending)} pending proposal(s): apply, reject or withdraw them first')
    stamp = (now or _dt.datetime.now(_dt.timezone.utc)).strftime('%Y%m%dT%H%M%SZ')
    archive = repo.root / 'archive'
    if not archive.exists():
        archive.mkdir(mode=0o700)
    if archive.is_symlink() or not archive.is_dir() or (os.name == 'posix' and archive.stat().st_mode & 0o077):
        raise DecommissionError('Archive folder must be a private directory (0700)')
    dest = archive / f'{repo.notebook}-{stamp}'
    dest.mkdir(mode=0o700)  # exclusive: an existing destination is an error
    moved = []
    for category, path in found:
        digest = _sha256(path)
        target = dest / f'{category}__{path.name}'
        os.rename(path, target)
        moved.append({'from':f'{category}/{path.name}', 'to':target.name, 'sha256':digest})
    manifest = {'schema':DECOMMISSION_SCHEMA, 'notebook':repo.notebook, 'instance_state':state,
                'current_scope':current, 'archived_ledger_scope':on_disk,
                'decommissioned_at':stamp, 'files':moved,
                'notebook_touched':False, 'deleted':False,
                'note':'Archived governance files of one notebook instance; restore by moving back manually.'}
    fd = os.open(dest / 'DECOMMISSION.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                 getattr(os, 'O_NOFOLLOW', 0), 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        handle.write(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    return {**manifest, 'archive':str(dest)}
