"""CMR-10 adversarial governance read-port tests; scratch workspace only."""
from __future__ import annotations

import contextlib
import copy
from hashlib import sha256
import io
import json
from pathlib import Path
import unittest

from .cli import main
from .read_ports import (DirectGovernanceReadPort, RoutedGovernanceReadPort,
                         _router, _valid_review, _valid_status)
from .repository import Repository


class GovernanceReadPortTests(unittest.TestCase):
    def setUp(self):
        # Use the pinned governance test fixture (private workspace, real wiki,
        # ledger and signed-review policy); never touch a production notebook.
        from .test_governance import ReviewQueueTests
        self.fixture = ReviewQueueTests('test_submit_does_not_change_wiki')
        self.fixture.setUp()
        self.repo = Repository(self.fixture.ws, 'primary')
        self.direct = DirectGovernanceReadPort()
        self.routed = RoutedGovernanceReadPort()

    def tearDown(self):
        self.fixture.tearDown()

    def files(self):
        root = Path(self.fixture.ws.root)
        return {str(p.relative_to(root)): sha256(p.read_bytes()).hexdigest()
                for p in root.rglob('*') if p.is_file()}

    def cli(self, command, *args):
        output, errors = io.StringIO(), io.StringIO()
        argv = [command, '--workspace', str(self.fixture.ws.root),
                '--notebook', 'primary', *args]
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
            rc = main(argv)
        return rc, output.getvalue(), errors.getvalue()

    def test_empty_status_matches_without_any_write(self):
        before = self.files()
        self.assertEqual(self.direct.status(self.repo), self.routed.status(self.repo))
        self.assertEqual(self.files(), before)

    def test_ungated_status_preserves_gate_and_receipt_state(self):
        entry = self.fixture.submit()  # older un-gated library path; read cannot upgrade it
        before = self.files()
        direct = self.direct.status(self.repo)
        routed = self.routed.status(self.repo)
        self.assertEqual(direct, routed)
        self.assertEqual(routed['total'], 1)
        self.assertEqual(routed['pending'], 1)
        self.assertEqual(routed['proposals'][0]['fitness_gate_status'], 'UNGATED')
        self.assertFalse(routed['proposals'][0]['wiki_receipt_present'])
        self.assertEqual(self.files(), before)
        self.assertEqual(entry['state'], 'SUBMITTED')

    def test_ungated_review_matches_and_remains_non_authorizing(self):
        proposal = self.fixture.submit()
        before = self.files()
        result = self.routed.review(self.repo, proposal['proposal_id'])
        self.assertEqual(self.direct.review(self.repo, proposal['proposal_id']), result)
        self.assertFalse(result['human_authorized'])
        self.assertFalse(result['may_mutate_wiki'])
        self.assertEqual(result['fitness_gate']['status'], 'UNGATED')
        self.assertEqual(self.files(), before)

    def test_verified_gate_preserved_without_becoming_approval(self):
        args, _ = self.fixture.gate_args(self.fixture.agent_spec(), tag='cmr10')
        self.assertEqual(self.fixture.run_cli(args)[0], 0)
        proposal_id = self.repo.list_proposals()[0]['proposal_id']
        before = self.files()
        direct = self.direct.review(self.repo, proposal_id)
        routed = self.routed.review(self.repo, proposal_id)
        self.assertEqual(direct, routed)
        self.assertEqual(routed['fitness_gate']['status'], 'VERIFIED')
        self.assertFalse(routed['human_authorized'])
        self.assertFalse(routed['may_mutate_wiki'])
        status = self.routed.status(self.repo)
        self.assertEqual(status['proposals'][0]['fitness_gate_status'], 'VERIFIED')
        self.assertFalse(status['approval_authorized'])
        self.assertEqual(self.files(), before)

    def test_unverified_gate_preserved_without_promotion(self):
        spec = self.fixture.spec()
        spec['source_refs'] = ['external:hwi-fitness/' + 'b'*64]
        self.fixture.submit()  # ungated
        from .review_queue import submit_proposal
        submit_proposal(self.fixture.ws, 'primary', spec)
        statuses = [r['fitness_gate_status'] for r in self.routed.status(self.repo)['proposals']]
        self.assertEqual(statuses, ['UNGATED', 'UNVERIFIED'])

    def test_cli_explicit_routed_status_and_review_parity(self):
        p = self.fixture.submit()
        for command, extra in [('queue-status', ()),
                               ('queue-review', ('--proposal-id', p['proposal_id']))]:
            direct = self.cli(command, *extra)
            routed = self.cli(command, *extra, '--routed-read')
            self.assertEqual(direct, routed)
            self.assertEqual(routed[0], 0)
            self.assertNotIn('approval_authorized": true', routed[1])

    def test_cli_opt_in_not_supported_on_write_or_gate_commands(self):
        for command in ('queue-submit', 'queue-apply', 'queue-restore-proposal',
                        'queue-gate-recover', 'queue-reject'):
            with self.subTest(command=command):
                with contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as ctx:
                        main([command, '--workspace', str(self.fixture.ws.root),
                              '--notebook', 'primary', '--routed-read'])
                self.assertEqual(ctx.exception.code, 2)

    def test_invalid_proposal_id_rejects_before_read(self):
        class Spy:
            count = 0
            def review(self, *args):
                self.count += 1
                return {}
        spy = Spy()
        with self.assertRaises(ValueError):
            RoutedGovernanceReadPort(spy).review(self.repo, 'invalid-or-injected;write')
        self.assertEqual(spy.count, 0)

    def test_missing_proposal_keeps_original_failure_and_no_retry(self):
        class Spy:
            count = 0
            def review(self, repo, proposal_id):
                self.count += 1
                return DirectGovernanceReadPort().review(repo, proposal_id)
        spy = Spy()
        with self.assertRaises(Exception):
            RoutedGovernanceReadPort(spy).review(self.repo, 'proposal:' + 'a'*32)
        self.assertEqual(spy.count, 1)

    def test_interrupted_status_fails_closed_without_retry(self):
        class Spy:
            count = 0
            def status(self, repo):
                self.count += 1
                raise OSError('read interrupted')
        spy = Spy()
        with self.assertRaises(OSError):
            RoutedGovernanceReadPort(spy).status(self.repo)
        self.assertEqual(spy.count, 1)

    def test_forged_status_authority_refused(self):
        class Forged:
            def status(self, repo):
                value = DirectGovernanceReadPort().status(repo)
                value['approval_authorized'] = True
                return value
        with self.assertRaisesRegex(ValueError, 'unverified status'):
            RoutedGovernanceReadPort(Forged()).status(self.repo)

    def test_forged_status_counts_refused(self):
        class Forged:
            def status(self, repo):
                value = DirectGovernanceReadPort().status(repo)
                value['pending'] += 1
                return value
        with self.assertRaisesRegex(ValueError, 'unverified status'):
            RoutedGovernanceReadPort(Forged()).status(self.repo)

    def test_forged_review_approval_refused(self):
        proposal_id = self.fixture.submit()['proposal_id']
        class Forged:
            def review(self, repo, proposal_id):
                value = DirectGovernanceReadPort().review(repo, proposal_id)
                value['human_authorized'] = True
                return value
        with self.assertRaisesRegex(ValueError, 'unverified proposal'):
            RoutedGovernanceReadPort(Forged()).review(self.repo, proposal_id)

    def test_forged_review_proposal_id_refused(self):
        proposal_id = self.fixture.submit()['proposal_id']
        class Forged:
            def review(self, repo, proposal_id):
                value = DirectGovernanceReadPort().review(repo, proposal_id)
                value['proposal_id'] = 'proposal:' + 'e'*32
                return value
        with self.assertRaisesRegex(ValueError, 'unverified proposal'):
            RoutedGovernanceReadPort(Forged()).review(self.repo, proposal_id)

    def test_forged_review_gate_status_refused(self):
        proposal_id = self.fixture.submit()['proposal_id']
        class Forged:
            def review(self, repo, proposal_id):
                value = DirectGovernanceReadPort().review(repo, proposal_id)
                value['fitness_gate']['status'] = 'APPROVED'
                return value
        with self.assertRaisesRegex(ValueError, 'unverified proposal'):
            RoutedGovernanceReadPort(Forged()).review(self.repo, proposal_id)

    def test_extra_status_authority_claim_refused(self):
        item = self.direct.status(self.repo)
        item['wiki_write_authorized'] = True
        self.assertFalse(_valid_status(item, 'primary'))

    def test_extra_review_authority_claim_refused(self):
        proposal_id = self.fixture.submit()['proposal_id']
        item = self.direct.review(self.repo, proposal_id)
        item['wiki_write_authorized'] = True
        self.assertFalse(_valid_review(item, proposal_id))

    def test_large_projection_refused_without_extra_read(self):
        class Spy:
            count = 0
            def status(self, repo):
                self.count += 1
                value = DirectGovernanceReadPort().status(repo)
                value['note'] = 'x' * 4_000_001
                return value
        spy = Spy()
        with self.assertRaisesRegex(ValueError, 'exceeds opt-in size'):
            RoutedGovernanceReadPort(spy).status(self.repo)
        self.assertEqual(spy.count, 1)

    def test_malformed_gate_status_type_refused(self):
        pid = self.fixture.submit()['proposal_id']
        class Spy:
            def review(self, repo, proposal_id):
                value = DirectGovernanceReadPort().review(repo, proposal_id)
                value['fitness_gate']['status'] = ['VERIFIED']
                return value
        with self.assertRaisesRegex(ValueError, 'unverified proposal'):
            RoutedGovernanceReadPort(Spy()).review(self.repo, pid)

    def test_read_port_exposes_no_submit_apply_or_sign(self):
        for name in ('submit', 'apply', 'approve', 'sign', 'recover'):
            self.assertFalse(hasattr(self.routed, name))
            self.assertFalse(hasattr(self.direct, name))


class GovernanceProfileTests(unittest.TestCase):
    def setUp(self):
        self.ctx = {'notebook':'primary','scope_sha256':'c'*64,
                    'proposal_id':'proposal:'+'d'*32}
        self.router,self.flow,self.sources = _router(self.ctx)

    def req(self):
        return self.router.issue_message(self.flow,self.sources['governance_operator'],
                  'governance.status.request',
                  {'notebook':'primary','scope_sha256':'c'*64})

    def test_request_result_and_cached_replay(self):
        req = self.req()
        outcome = self.router.dispatch(self.flow,self.sources['governance_operator'],req)
        self.assertTrue(outcome.accepted)
        self.assertEqual(outcome.transition_id, 'G01')
        self.assertEqual(tuple(e.kind for e in outcome.effects), ('governance.status.read',))
        self.assertTrue(self.router.dispatch(self.flow,self.sources['governance_operator'],req).replayed)
        self.ctx.update(result_sha256='f'*64,total=1,pending=1,applied=0)
        result = self.router.issue_message(self.flow,self.sources['governance_projection'],
             'governance.status.result',
             {'notebook':'primary','scope_sha256':'c'*64,'result_sha256':'f'*64,
              'total':1,'pending':1,'applied':0}, parent=req['message_id'])
        outcome=self.router.dispatch(self.flow,self.sources['governance_projection'],result)
        self.assertTrue(outcome.accepted)
        self.assertEqual(outcome.transition_id,'G02')
        self.assertFalse(outcome.effects)

    def test_model_tool_cannot_claim_operator_origin(self):
        from hwi_router.core import SourceHandle
        packet = self.req()
        self.assertEqual(self.router.dispatch(self.flow, SourceHandle('governance_operator'),packet).code, 'F02')
        packet['origin']='model_adapter'
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).code,'F01')

    def test_injected_approval_and_write_message_rejected(self):
        packet = self.req(); packet['payload']['signed_approval']=True
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).code,'F01')
        packet = self.req(); packet['kind']='governance.queue.apply'
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).code,'F01')
        packet = self.req(); packet['kind']='governance.queue.submit'
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).code,'F01')

    def test_wrong_scope_rejected_and_no_effect(self):
        packet = self.req();packet['payload']['scope_sha256']='0'*64
        outcome=self.router.dispatch(self.flow,self.sources['governance_operator'],packet)
        self.assertEqual(outcome.code, 'F04')
        self.assertFalse(outcome.effects)

    def test_correct_review_route_and_effect(self):
        request = self.router.issue_message(self.flow,self.sources['governance_operator'],
            'governance.review.request', dict(self.ctx))
        verdict = self.router.dispatch(self.flow,self.sources['governance_operator'],request)
        self.assertTrue(verdict.accepted)
        self.assertEqual(verdict.transition_id,'G03')
        self.assertEqual(tuple(e.kind for e in verdict.effects),
                         ('governance.proposal.review_read',))
        self.ctx.update(result_sha256='a'*64,gate_status='UNGATED')
        result = self.router.issue_message(self.flow,self.sources['governance_projection'],
            'governance.review.result',dict(self.ctx),parent=request['message_id'])
        verdict = self.router.dispatch(self.flow,self.sources['governance_projection'],result)
        self.assertTrue(verdict.accepted)
        self.assertEqual(verdict.transition_id,'G04')
        self.assertFalse(verdict.effects)

    def test_wrong_result_digest_does_not_cross_boundary(self):
        request = self.req()
        self.assertTrue(self.router.dispatch(self.flow,self.sources['governance_operator'],request).accepted)
        self.ctx.update(result_sha256='b'*64,total=0,pending=0,applied=0)
        result = self.router.issue_message(self.flow,self.sources['governance_projection'],
            'governance.status.result', {'notebook':'primary','scope_sha256':'c'*64,
                'result_sha256':'a'*64,'total':0,'pending':0,'applied':0},
            parent=request['message_id'])
        verdict=self.router.dispatch(self.flow,self.sources['governance_projection'],result)
        self.assertEqual(verdict.code,'F04')
        self.assertFalse(verdict.effects)
        self.assertEqual(self.router.snapshot(self.flow).phase,'WAIT_STATUS')

    def test_result_without_request_fails_closed(self):
        packet=self.router.issue_message(self.flow,self.sources['governance_projection'],
            'governance.status.result', {'notebook':'primary','scope_sha256':'c'*64,
            'result_sha256':'a'*64,'total':0,'pending':0,'applied':0},parent='e'*32)
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_projection'],packet).code,'F03')

    def test_result_wrong_parent_fails_closed(self):
        packet=self.req()
        self.assertTrue(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).accepted)
        result=self.router.issue_message(self.flow,self.sources['governance_projection'],
            'governance.status.result', {'notebook':'primary','scope_sha256':'c'*64,
            'result_sha256':'a'*64,'total':0,'pending':0,'applied':0}, parent='e'*32)
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_projection'],result).code,'F02')

    def test_same_id_changed_body_rejected(self):
        packet=self.req()
        self.assertTrue(self.router.dispatch(self.flow,self.sources['governance_operator'],packet).accepted)
        altered=copy.deepcopy(packet); altered['payload']['scope_sha256']='a'*64
        self.assertEqual(self.router.dispatch(self.flow,self.sources['governance_operator'],altered).code,'F10')

    def test_scope_limited_to_read_effects(self):
        self.assertEqual(set(self.router._effects),
                         {'governance.status.read', 'governance.proposal.review_read'})
        for effect in self.router._effects:
            self.assertEqual(self.router._effects[effect]['effect_class'], 'external_read')
        self.assertTrue({'governance.queue.submit','governance.queue.apply',
                         'wiki.write','agent.execute'}.isdisjoint(self.router._effects))

    def test_unregistered_model_and_tool_not_profiles(self):
        self.assertRaises(RuntimeError, self.router.register_source, 'model_adapter')
        self.assertRaises(RuntimeError, self.router.register_source, 'tool')


if __name__=='__main__':
    unittest.main()
