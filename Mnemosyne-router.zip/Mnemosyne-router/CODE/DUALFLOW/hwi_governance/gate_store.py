"""Per-installation SQLite store for task-fitness gate records.

Replaces the earlier JSON receipt/usage files and the ``fcntl`` lock:

    <workspace>/governance/<notebook>.governance.sqlite   (dir 0700, file 0600)

* ``receipts``: one row per owner-signed assessment (assessment + decision +
  public key), immutable once written.
* ``uses``: quota slots. A slot is RESERVED inside one ``BEGIN IMMEDIATE``
  transaction that also counts existing slots, so concurrent submitters are
  serialized by SQLite itself. After the ledger commits, the slot is BOUND to the
  proposal id (once). A RESERVED slot may only be released, never rebound.
* ``submission_intents``: an optional immutable request snapshot stored in the
  *same transaction as the quota reservation*. It permits exact-match,
  operator-initiated recovery of a lost RESERVED -> BOUND transition; older
  reservations lacking an intent remain unrecoverable automatically.
* ``meta`` records the notebook scope; a store from another physical notebook
  instance is refused, exactly like the approved HWI-07 ledger.

Like that ledger, the store uses rollback-journal mode, FULL sync and enforced
foreign keys. Triggers make receipts and bound slots immutable.

Known gap (by design, see plan): the approved ledger commits proposals on its
own private connection, so reservation and proposal are two transactions in two
files. A failure between them leaves a RESERVED slot (counted, fail-closed) and
an UNVERIFIED proposal. This module offers conservative, manual reconciliation,
not cross-database atomicity. Folding both into one transaction needs a ledger change.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import stat

from .task_fitness import FitnessError, SHA, canonical

STORE_VERSION = 'HWI-GOV-v1'
RECEIPT_SCHEMA = 'hwi.task_fitness.gate_receipt.v2'
INTENT_SCHEMA = 'hwi.governance.submission_intent.v1'
# Additive extension, intentionally keeps existing HWI-GOV-v1 receipts and slots.
_INTENTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS submission_intents (
    assessment_sha256 TEXT NOT NULL,
    slot INTEGER NOT NULL,
    intent_json TEXT NOT NULL,
    intent_sha256 TEXT NOT NULL CHECK(length(intent_sha256)=64),
    PRIMARY KEY (assessment_sha256, slot),
    FOREIGN KEY (assessment_sha256, slot) REFERENCES uses(assessment_sha256, slot)
      ON DELETE CASCADE
);
CREATE TRIGGER IF NOT EXISTS submission_intents_immutable_u
 BEFORE UPDATE ON submission_intents
 BEGIN SELECT RAISE(ABORT,'submission intent immutable'); END;
CREATE TRIGGER IF NOT EXISTS submission_intents_delete_only_with_slot
 BEFORE DELETE ON submission_intents
 WHEN EXISTS (SELECT 1 FROM uses WHERE uses.assessment_sha256=OLD.assessment_sha256
              AND uses.slot=OLD.slot)
 BEGIN SELECT RAISE(ABORT,'submission intent cannot be deleted while slot exists'); END;
"""

# Additive extension: bindings made by explicit operator recovery stay visible.
_RECOVERY_SCHEMA = """
CREATE TABLE IF NOT EXISTS recovered_bindings (
    assessment_sha256 TEXT NOT NULL,
    slot INTEGER NOT NULL,
    proposal_id TEXT NOT NULL UNIQUE,
    recovered_at TEXT NOT NULL,
    PRIMARY KEY (assessment_sha256, slot),
    FOREIGN KEY (assessment_sha256, slot) REFERENCES uses(assessment_sha256, slot)
);
CREATE TRIGGER IF NOT EXISTS recovered_bindings_immutable_u BEFORE UPDATE ON recovered_bindings
 BEGIN SELECT RAISE(ABORT,'recovered binding immutable'); END;
CREATE TRIGGER IF NOT EXISTS recovered_bindings_immutable_d BEFORE DELETE ON recovered_bindings
 BEGIN SELECT RAISE(ABORT,'recovered binding immutable'); END;
"""
_EXTENSIONS = _INTENTS_SCHEMA + _RECOVERY_SCHEMA

_SCHEMA = """
CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE receipts (
    assessment_sha256 TEXT PRIMARY KEY CHECK(length(assessment_sha256) = 64),
    receipt_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE uses (
    assessment_sha256 TEXT NOT NULL REFERENCES receipts(assessment_sha256),
    slot INTEGER NOT NULL CHECK(slot >= 1),
    state TEXT NOT NULL CHECK(state IN ('RESERVED','BOUND')),
    proposal_id TEXT UNIQUE,
    created_at TEXT NOT NULL,
    PRIMARY KEY (assessment_sha256, slot),
    CHECK ((state = 'RESERVED' AND proposal_id IS NULL) OR
           (state = 'BOUND' AND proposal_id IS NOT NULL))
);
CREATE TRIGGER receipts_immutable_u BEFORE UPDATE ON receipts
  BEGIN SELECT RAISE(ABORT,'receipts immutable'); END;
CREATE TRIGGER receipts_immutable_d BEFORE DELETE ON receipts
  BEGIN SELECT RAISE(ABORT,'receipts immutable'); END;
CREATE TRIGGER uses_bind_once BEFORE UPDATE ON uses
  WHEN OLD.state != 'RESERVED' OR NEW.state != 'BOUND' OR NEW.proposal_id IS NULL
       OR NEW.slot != OLD.slot OR NEW.assessment_sha256 != OLD.assessment_sha256
  BEGIN SELECT RAISE(ABORT,'only a reserved slot can be bound, once'); END;
CREATE TRIGGER uses_release_reserved_only BEFORE DELETE ON uses
  WHEN OLD.state != 'RESERVED'
  BEGIN SELECT RAISE(ABORT,'a bound slot cannot be released'); END;
CREATE TRIGGER meta_immutable_u BEFORE UPDATE ON meta
  BEGIN SELECT RAISE(ABORT,'meta immutable'); END;
CREATE TRIGGER meta_immutable_d BEFORE DELETE ON meta
  BEGIN SELECT RAISE(ABORT,'meta immutable'); END;
"""


def _now():
    return _dt.datetime.now(_dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def store_path(root, notebook) -> Path:
    return Path(root) / 'governance' / (notebook + '.governance.sqlite')


class GateStore:
    """Open the notebook's gate store; ``create`` only on the gated submit path.

    ``writable`` defaults to ``create``. A non-writable store is opened through
    SQLite's read-only mode and never changes the database, its configuration
    included: an unexpected journal mode is reported, not silently converted.
    """

    def __init__(self, root, notebook: str, scope: str, *, create: bool = False,
                 writable: bool | None = None):
        writable = create if writable is None else writable
        if create and not writable:
            raise FitnessError('A governance store can only be created writable')
        folder = Path(root) / 'governance'
        if create and not folder.exists():
            folder.mkdir(mode=0o700)
        if folder.is_symlink() or not folder.is_dir():
            raise FitnessError('Governance store folder missing')
        if os.name == 'posix' and folder.stat().st_mode & 0o077:
            raise FitnessError('Governance store folder must be private (0700)')
        path = store_path(root, notebook)
        created = False
        if not path.exists() and not path.is_symlink():
            if not create:
                raise FitnessError('Governance store missing')
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            os.close(fd)
            created = True
        st = path.stat(follow_symlinks=False)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1 or (os.name == 'posix' and st.st_mode & 0o077):
            raise FitnessError('Governance store must be a private single-link regular file')
        if writable:
            conn = sqlite3.connect(str(path), timeout=15, isolation_level=None)
        else:
            conn = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True,
                                   timeout=15, isolation_level=None)
        try:
            conn.execute('PRAGMA foreign_keys=ON')
            if writable:
                conn.execute('PRAGMA synchronous=FULL')
                conn.execute('PRAGMA journal_mode=DELETE')
            else:
                try:
                    mode = conn.execute('PRAGMA journal_mode').fetchone()[0]
                except sqlite3.Error as exc:
                    raise FitnessError(f'Governance store cannot be read without changes ({exc}); '
                                       'inspect it before running a write command') from exc
                if str(mode).lower() != 'delete':
                    raise FitnessError(f'Governance store journal mode is {mode!r}, expected delete; '
                                       'not changed by a read-only command')
            if created:
                if type(scope) is not str or not SHA.fullmatch(scope):
                    raise FitnessError('Invalid notebook scope')
                # One script = one transaction (executescript manages its own COMMIT).
                conn.executescript('BEGIN IMMEDIATE;' + _SCHEMA +
                                   f"INSERT INTO meta(key,value) VALUES('version','{STORE_VERSION}'),"
                                   f"('notebook_scope','{scope}');" + _EXTENSIONS + 'COMMIT;')
            meta = dict(conn.execute('SELECT key,value FROM meta'))
            if meta != {'version':STORE_VERSION, 'notebook_scope':scope}:
                raise FitnessError('Governance store belongs to a different physical notebook or version')
            # Intent support is an additive extension for pre-existing stores,
            # installed only on the explicit submission write path. A read-only
            # status query never migrates the store.
            if create and not created:
                conn.executescript('BEGIN IMMEDIATE;' + _EXTENSIONS + 'COMMIT;')
        except BaseException:
            conn.close()
            raise
        self._conn = conn
        self.path = path

    def close(self):
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ---- writes -----------------------------------------------------------
    def reserve(self, assessment, decision, verified, public_key: bytes, max_proposals: int,
                *, intent_spec: dict | None = None) -> int:
        """Store receipt, quota slot and optional exact submission intent atomically."""
        sha = verified['assessment_sha256']
        if not SHA.fullmatch(sha) or type(max_proposals) is not int or max_proposals < 1:
            raise FitnessError('Invalid reservation request')
        body = canonical({'schema':RECEIPT_SCHEMA, 'assessment':assessment, 'owner_decision':decision,
                          'reviewer_key_sha256':verified['reviewer_key_sha256'],
                          'owner_public_key_hex':public_key.hex()})
        intent_body = None
        if intent_spec is not None:
            if type(intent_spec) is not dict:
                raise FitnessError('Invalid submission intent')
            intent_body = canonical({'schema':INTENT_SCHEMA, 'spec':intent_spec})
            if len(intent_body.encode('utf-8')) > 32_000:
                raise FitnessError('Submission intent is too large')
        conn = self._conn
        conn.execute('BEGIN IMMEDIATE')
        try:
            row = conn.execute('SELECT receipt_json FROM receipts WHERE assessment_sha256=?', (sha,)).fetchone()
            if row is None:
                conn.execute('INSERT INTO receipts VALUES(?,?,?)', (sha, body, _now()))
            elif row[0] != body:
                raise FitnessError('Conflicting fitness receipt already stored')
            used, top = conn.execute('SELECT count(*), coalesce(max(slot),0) FROM uses '
                                     'WHERE assessment_sha256=?', (sha,)).fetchone()
            if used >= max_proposals:
                raise FitnessError(f'Signed task scope exhausted: {used}/{max_proposals} proposals used')
            slot = top + 1
            conn.execute("INSERT INTO uses VALUES(?,?,'RESERVED',NULL,?)", (sha, slot, _now()))
            if intent_body is not None:
                conn.execute('INSERT INTO submission_intents VALUES(?,?,?,?)',
                             (sha, slot, intent_body, hashlib.sha256(intent_body.encode('utf-8')).hexdigest()))
            conn.execute('COMMIT')
            return slot
        except BaseException:
            conn.execute('ROLLBACK')
            raise

    def release(self, sha: str, slot: int):
        """Return a slot after a definite pre-commit ledger rejection."""
        conn = self._conn
        conn.execute('BEGIN IMMEDIATE')
        try:
            cur = conn.execute("DELETE FROM uses WHERE assessment_sha256=? AND slot=? AND state='RESERVED'",
                               (sha, slot))
            if cur.rowcount != 1:
                raise FitnessError('Only an unbound reservation can be released')
            conn.execute('COMMIT')
        except BaseException:
            conn.execute('ROLLBACK')
            raise

    def install_extensions(self):
        """Add the additive tables to an older store (explicit write paths only)."""
        self._conn.executescript('BEGIN IMMEDIATE;' + _EXTENSIONS + 'COMMIT;')

    def bind(self, sha: str, slot: int, proposal_id: str, *, recovered: bool = False):
        """Bind a reserved slot; a recovered binding is recorded in the same transaction."""
        if type(proposal_id) is not str or not proposal_id.startswith('proposal:'):
            raise FitnessError('Ledger returned an unexpected proposal id')
        conn = self._conn
        conn.execute('BEGIN IMMEDIATE')
        try:
            cur = conn.execute("UPDATE uses SET state='BOUND', proposal_id=? "
                               "WHERE assessment_sha256=? AND slot=? AND state='RESERVED'",
                               (proposal_id, sha, slot))
            if cur.rowcount != 1:
                raise FitnessError('Reservation to bind not found')
            if recovered:
                conn.execute('INSERT INTO recovered_bindings VALUES(?,?,?,?)',
                             (sha, slot, proposal_id, _now()))
            conn.execute('COMMIT')
        except BaseException:
            conn.execute('ROLLBACK')
            raise

    # ---- reads ------------------------------------------------------------
    def receipt(self, sha: str):
        row = self._conn.execute('SELECT receipt_json FROM receipts WHERE assessment_sha256=?', (sha,)).fetchone()
        return None if row is None else row[0]

    def is_bound(self, sha: str, proposal_id: str) -> bool:
        return self._conn.execute("SELECT 1 FROM uses WHERE assessment_sha256=? AND proposal_id=? "
                                  "AND state='BOUND'", (sha, proposal_id)).fetchone() is not None

    def usage(self, sha: str) -> dict:
        rows = dict(self._conn.execute('SELECT state, count(*) FROM uses WHERE assessment_sha256=? '
                                       'GROUP BY state', (sha,)).fetchall())
        return {'reserved':rows.get('RESERVED', 0), 'bound':rows.get('BOUND', 0)}

    def reservations(self) -> list[dict]:
        """Read all RESERVED slots, retaining legacy ones without intent data.

        Does not mutate a store on read. Corrupt intent data is a hard failure,
        never silently accepted as an operator-authorized request.
        """
        conn = self._conn
        present = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                               "AND name='submission_intents'").fetchone()
        if present:
            rows = conn.execute("SELECT u.assessment_sha256,u.slot,i.intent_json,i.intent_sha256 "
                                "FROM uses u LEFT JOIN submission_intents i "
                                "ON u.assessment_sha256=i.assessment_sha256 AND u.slot=i.slot "
                                "WHERE u.state='RESERVED' ORDER BY u.assessment_sha256,u.slot").fetchall()
        else:
            rows = [(a, s, None, None) for a, s in conn.execute(
                "SELECT assessment_sha256,slot FROM uses WHERE state='RESERVED' "
                "ORDER BY assessment_sha256,slot")]
        out = []
        for sha, slot, body, expected in rows:
            spec = None
            if body is not None:
                if hashlib.sha256(body.encode('utf-8')).hexdigest() != expected:
                    raise FitnessError('Submission intent digest mismatch')
                try:
                    parsed = json.loads(body)
                except (TypeError, ValueError) as exc:
                    raise FitnessError('Submission intent unreadable') from exc
                if type(parsed) is not dict or set(parsed) != {'schema','spec'} or \
                        parsed['schema'] != INTENT_SCHEMA or type(parsed['spec']) is not dict or \
                        canonical(parsed) != body:
                    raise FitnessError('Malformed submission intent')
                spec = parsed['spec']
            out.append({'assessment_sha256':sha, 'slot':slot, 'intent_spec':spec})
        return out

    def is_recovered(self, sha: str, proposal_id: str) -> bool:
        """True when this binding was made by explicit operator recovery."""
        if not self._conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                                  "AND name='recovered_bindings'").fetchone():
            return False
        return self._conn.execute('SELECT 1 FROM recovered_bindings WHERE assessment_sha256=? '
                                  'AND proposal_id=?', (sha, proposal_id)).fetchone() is not None

    def proposal_is_bound(self, proposal_id: str) -> bool:
        return self._conn.execute("SELECT 1 FROM uses WHERE state='BOUND' AND proposal_id=?",
                                  (proposal_id,)).fetchone() is not None
