"""Deterministic task-scoped fitness checks and independently signed owner decision.

A model's self-reported test result never establishes independent evidence. The
assessment merely tells an operator whether the supplied, hashed test records
meet a task's predeclared thresholds; owner signing is a separate offline act.
No execution token, wiki authority or general capability is issued here.

v2 (governance review fixes):
- at least one critical case and a non-trivial pass floor are mandatory, so an
  all-FAIL result set can never become eligible;
- the signed scope is bounded in time (``valid_until``) and in use
  (``max_proposals``), so one owner signature is not a perpetual bearer token;
- the owner key pin is read from an operator-provisioned workspace policy
  (see ``fitness_policy``), never from a caller-supplied file.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import re
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

SHA = re.compile(r'^[0-9a-f]{64}$')
NAME = re.compile(r'^[a-zA-Z][a-zA-Z0-9_.-]{0,79}$')
DATE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
OPERATIONS = frozenset(('create','revise','link','retire'))
CONTRACT_SCHEMA = 'hwi.task_fitness.contract.v2'
RESULTS_SCHEMA = 'hwi.task_fitness.results.v2'
ASSESSMENT_SCHEMA = 'hwi.task_fitness.assessment.v2'
DECISION_SCHEMA = 'hwi.task_fitness.owner_decision.v2'
MIN_PASS_FLOOR = 50          # percent; contracts may demand more, never less
MAX_VALIDITY_DAYS = 366      # a signed task scope must be re-reviewed at least yearly
MAX_PROPOSALS = 1000
FITNESS_REF_PREFIX = 'external:hwi-fitness/'

class FitnessError(ValueError):
    pass

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)

def digest(value):
    return hashlib.sha256(canonical(value).encode('ascii')).hexdigest()

def _nonempty(x, max_len=512):
    return type(x) is str and 1 <= len(x.strip()) <= max_len and '\x00' not in x

def _keys(x, expected, label):
    if type(x) is not dict or set(x) != set(expected):
        raise FitnessError(f'{label}: exact fields required: {sorted(expected)}')

def _sha(s):
    return type(s) is str and SHA.fullmatch(s) is not None

def _today():
    return _dt.datetime.now(_dt.timezone.utc).date()

def _parse_date(value, label):
    if type(value) is not str or not DATE.fullmatch(value):
        raise FitnessError(f'{label} must be a YYYY-MM-DD UTC date')
    try:
        return _dt.date.fromisoformat(value)
    except ValueError as exc:
        raise FitnessError(f'{label} is not a real date') from exc

def fitness_ref(assessment_sha256):
    """Named HWI-07 source reference recording which signed scope gated a proposal."""
    if not _sha(assessment_sha256):
        raise FitnessError('Assessment digest required')
    return FITNESS_REF_PREFIX + assessment_sha256

def validate_contract(data, *, today=None):
    _keys(data, ('schema','task_id','domain','objective','configuration','notebook',
                 'allowed_operations','cases','acceptance','valid_until','max_proposals'), 'contract')
    if data['schema'] != CONTRACT_SCHEMA:
        raise FitnessError('Unsupported contract schema (v2 required)')
    for name in ('task_id','domain'):
        if type(data[name]) is not str or not NAME.fullmatch(data[name]):
            raise FitnessError(f'Invalid {name}')
    if not _nonempty(data['objective'], 2000):
        raise FitnessError('Nonempty bounded objective required')
    if type(data['notebook']) is not str or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}', data['notebook']):
        raise FitnessError('Named notebook required')
    _keys(data['configuration'], ('model','model_sha256','prompt_sha256','workflow_sha256',
                                   'tools_sha256','evidence_scope_sha256'), 'configuration')
    if not _nonempty(data['configuration']['model'], 120):
        raise FitnessError('Pinned local model name required')
    if any(not _sha(data['configuration'][k]) for k in data['configuration'] if k != 'model'):
        raise FitnessError('Pinned configuration SHA-256 values required')
    ops = data['allowed_operations']
    if type(ops) is not list or not 1 <= len(ops) <= 4 or any(type(o) is not str or o not in OPERATIONS for o in ops) or len(set(ops)) != len(ops):
        raise FitnessError('Invalid permitted proposal operation set')
    cases = data['cases']
    if type(cases) is not list or not 3 <= len(cases) <= 100:
        raise FitnessError('At least three representative cases required')
    seen = set()
    for case in cases:
        _keys(case, ('case_id','purpose','critical','evidence_sha256'), 'case')
        if type(case['case_id']) is not str or not NAME.fullmatch(case['case_id']) or case['case_id'] in seen:
            raise FitnessError('Duplicate or invalid case id')
        seen.add(case['case_id'])
        if not _nonempty(case['purpose'], 1000) or type(case['critical']) is not bool or not _sha(case['evidence_sha256']):
            raise FitnessError('Invalid case purpose, severity or evidence pin')
    if not any(case['critical'] for case in cases):
        raise FitnessError('At least one critical case is mandatory')
    _keys(data['acceptance'], ('min_pass_percent','max_unknown','require_all_critical_pass'), 'acceptance')
    policy = data['acceptance']
    if type(policy['min_pass_percent']) is not int or not MIN_PASS_FLOOR <= policy['min_pass_percent'] <= 100:
        raise FitnessError(f'Pass threshold must be an integer from {MIN_PASS_FLOOR} to 100')
    if type(policy['max_unknown']) is not int or not 0 <= policy['max_unknown'] <= len(cases):
        raise FitnessError('Invalid unknown threshold')
    if policy['require_all_critical_pass'] is not True:
        raise FitnessError('Critical-case pass requirement cannot be disabled')
    valid_until = _parse_date(data['valid_until'], 'valid_until')
    today = today or _today()
    if valid_until < today:
        raise FitnessError('Task fitness contract has expired')
    if (valid_until - today).days > MAX_VALIDITY_DAYS:
        raise FitnessError(f'valid_until may be at most {MAX_VALIDITY_DAYS} days ahead')
    if type(data['max_proposals']) is not int or not 1 <= data['max_proposals'] <= MAX_PROPOSALS:
        raise FitnessError(f'max_proposals must be an integer from 1 to {MAX_PROPOSALS}')
    return data

def assess(contract, results, *, today=None):
    validate_contract(contract, today=today)
    _keys(results, ('schema','contract_sha256','configuration_sha256','results'), 'results')
    expected_contract = digest(contract)
    expected_config = digest(contract['configuration'])
    if results['schema'] != RESULTS_SCHEMA or results['contract_sha256'] != expected_contract or results['configuration_sha256'] != expected_config:
        raise FitnessError('Result set belongs to different contract or configuration')
    rows = results['results']
    expected = {x['case_id']: x for x in contract['cases']}
    if type(rows) is not list or len(rows) != len(expected):
        raise FitnessError('Exactly one result per declared case required')
    tally = {'PASS':0,'FAIL':0,'UNKNOWN':0}
    mapped = {}
    for row in rows:
        _keys(row, ('case_id','status','evidence_sha256','evaluator_note'), 'result')
        key = row['case_id']
        if type(key) is not str or key not in expected or key in mapped:
            raise FitnessError('Unexpected/duplicate case result')
        if type(row['status']) is not str or row['status'] not in tally:
            raise FitnessError('Invalid result status')
        if row['evidence_sha256'] != expected[key]['evidence_sha256'] or not _nonempty(row['evaluator_note'], 1500):
            raise FitnessError('Incorrect result evidence pin or missing review note')
        mapped[key] = row
        tally[row['status']] += 1
    n = len(rows)
    pass_percent = 100 * tally['PASS'] / n
    critical = [case['case_id'] for case in contract['cases'] if case['critical']]
    failed_critical = [cid for cid in critical if mapped[cid]['status'] != 'PASS']
    eligible = (bool(critical) and
                pass_percent >= contract['acceptance']['min_pass_percent'] and
                tally['UNKNOWN'] <= contract['acceptance']['max_unknown'] and not failed_critical)
    payload = {'schema':ASSESSMENT_SCHEMA,
               'task_id':contract['task_id'],'domain':contract['domain'],
               'notebook':contract['notebook'],
               'allowed_operations':sorted(contract['allowed_operations']),
               'valid_until':contract['valid_until'],
               'max_proposals':contract['max_proposals'],
               'contract_sha256':expected_contract, 'configuration_sha256':expected_config,
               'results_sha256':digest(results), 'case_count':n,
               'critical_case_count':len(critical),
               'counts':tally,'pass_percent':round(pass_percent, 4),
               'min_pass_percent':contract['acceptance']['min_pass_percent'],
               'failed_critical':failed_critical,
               'status':('ELIGIBLE_FOR_HUMAN_TASK_APPROVAL' if eligible else 'NOT_ELIGIBLE'),
               'independently_verified':False,'execution_authorized':False,
               'knowledge_approved':False,
               'evidence_note':'Results/evaluator notes are supplied claims; fitness is task-scoped and requires independent operator verification.'}
    payload['assessment_sha256'] = digest(payload)
    return payload

def check_assessment(assessment, *, today=None):
    """Intact, eligible, unexpired v2 assessment; returns its digest."""
    if type(assessment) is not dict or assessment.get('schema') != ASSESSMENT_SCHEMA:
        raise FitnessError('Expected v2 assessment')
    value = dict(assessment)
    pin = value.pop('assessment_sha256', None)
    if not _sha(pin) or digest(value) != pin or value.get('status') != 'ELIGIBLE_FOR_HUMAN_TASK_APPROVAL':
        raise FitnessError('Assessment is not intact or eligible')
    if type(value.get('critical_case_count')) is not int or value['critical_case_count'] < 1:
        raise FitnessError('Assessment lacks a critical case')
    if _parse_date(value.get('valid_until'), 'valid_until') < (today or _today()):
        raise FitnessError('Signed task scope has expired')
    return pin

def signing_message(assessment, *, today=None):
    pin = check_assessment(assessment, today=today)
    return canonical({'purpose':'HWI task-specific human fitness decision, not PVS or execution authorization',
                      'schema':'hwi.task_fitness.owner_review.v2',
                      'assessment_sha256':pin,
                      'task_id':assessment['task_id'],'notebook':assessment['notebook'],
                      'allowed_operations':assessment['allowed_operations'],
                      'valid_until':assessment['valid_until'],
                      'max_proposals':assessment['max_proposals']}).encode('ascii')

def verify_owner_decision(assessment, decision, reviewer_public_key, pinned_public_key_sha256, *, today=None):
    """Only the workspace-pinned operator key may sign an exact eligible assessment.

    ``pinned_public_key_sha256`` must come from ``fitness_policy.load_fitness_pin``
    (operator-provisioned, inside the private workspace), never from the caller.
    """
    message = signing_message(assessment, today=today)
    _keys(decision, ('schema','assessment_sha256','decision','signature_hex'), 'owner decision')
    if (decision['schema'] != DECISION_SCHEMA or
        decision['assessment_sha256'] != assessment['assessment_sha256'] or
        decision['decision'] != 'APPROVE_FOR_DECLARED_TASK'):
        raise FitnessError('Decision does not approve the exact eligible assessment')
    if (type(reviewer_public_key) is not bytes or len(reviewer_public_key) != 32 or
        type(pinned_public_key_sha256) is not str or not SHA.fullmatch(pinned_public_key_sha256) or
        hashlib.sha256(reviewer_public_key).hexdigest() != pinned_public_key_sha256):
        raise FitnessError('Fitness key does not match the workspace operator pin')
    signature = decision['signature_hex']
    if type(signature) is not str or not re.fullmatch(r'[0-9a-f]{128}', signature):
        raise FitnessError('Invalid Ed25519 signature encoding')
    try:
        Ed25519PublicKey.from_public_bytes(reviewer_public_key).verify(bytes.fromhex(signature), message)
    except (InvalidSignature, ValueError) as exc:
        raise FitnessError('Owner task decision signature rejected') from exc
    return {'schema':'hwi.task_fitness.verified_decision.v2',
            'status':'OWNER_SIGNED_TASK_SCOPE_ONLY',
            'task_id':assessment['task_id'],
            'notebook':assessment['notebook'],
            'allowed_operations':assessment['allowed_operations'],
            'valid_until':assessment['valid_until'],
            'max_proposals':assessment['max_proposals'],
            'assessment_sha256':assessment['assessment_sha256'],
            'fitness_ref':fitness_ref(assessment['assessment_sha256']),
            'reviewer_key_sha256':pinned_public_key_sha256,
            'execution_authorized':False,'wiki_write_authorized':False,
            'pvs_approved':False,'general_competence_claimed':False}
