"""HWI production-candidate operator governance: no independent wiki write authority."""
