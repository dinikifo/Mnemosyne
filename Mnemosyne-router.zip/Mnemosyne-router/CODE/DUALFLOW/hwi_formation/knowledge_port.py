"""Read-only Formation practice port; no router, model, or writing authority.

The production implementation delegates to the existing approved broker path.
Tests may inject a compatible in-memory reader at the trusted CLI boundary.
Messages, model text, and operator input cannot inject reader implementations.
"""
from __future__ import annotations

from typing import Protocol

from .good_practices import retrieve_practices, _short


class PracticeReader(Protocol):
    def read(self, workspace: str, notebook: str, query: str) -> tuple[dict, ...]:
        """Return at most three typed broker practices; no writes."""
        ...


class WikiPracticeReader:
    """Only the existing verified broker API reaches the notebook."""
    def read(self, workspace: str, notebook: str, query: str) -> tuple[dict, ...]:
        return tuple(retrieve_practices(workspace, notebook, query))


def validate_practice_query(query: str) -> str:
    """Validate the operator's query BEFORE any adapter or router can read."""
    return _short(query, 'practice query', 100)
