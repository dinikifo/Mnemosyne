"""Focused tests for formation advisory retrieval, ambiguity review, and privacy."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from .core import FormationError, append_message, new_session, manual_draft
from .good_practices import (PRACTICE_SCHEMA, model_guidance, parse_wiki_practice,
                             retrieve_practices, review_draft)
from .model import propose, question
from .cli import main
from .storage import FormationStore
from .test_formation import sample_draft, SID, FakeProvider
from .wiki_adapter import inspect_wiki


def practice_record():
    return {'schema': PRACTICE_SCHEMA, 'domain':'knowledge review',
            'guidance':'Assess two comparable source claims without assigning authority.',
            'checks':[{'field':'input_sources','question':'Are both records from the same reporting period?'},
                      {'field':'success_criteria','question':'Who verifies the quoted values independently?'}]}


def make_draft_missing():
    draft=sample_draft()
    draft['initial_task']='Not yet specified by operator'
    draft['input_sources']=['Sources not yet specified']
    draft['expected_outputs']=['Output not yet specified']
    draft['success_criteria']=['Acceptance criteria not yet specified']
    draft['domain']='To be defined by operator'
    return draft


class PracticeReviewTests(unittest.TestCase):
    def test_universal_missing_fields(self):
        review=review_draft(make_draft_missing())
        self.assertEqual(set(review['material_declarations_missing']),
                         {'initial_task','input_sources','expected_outputs','success_criteria','domain'})
        self.assertFalse(review['task_fitness_tested'])
        self.assertFalse(review['execution_authorized'])
        self.assertEqual(review['status'],'OPERATOR_REVIEW_ONLY')

    def test_broad_not_misrepresented_as_verified(self):
        d=sample_draft();d['initial_task']='Organize my wiki'
        review=review_draft(d)
        self.assertTrue(any(f['kind']=='POSSIBLY_BROAD' for f in review['findings']))
        self.assertNotIn('initial_task', review['material_declarations_missing'])
        self.assertFalse(review['semantically_verified'])

    def test_good_draft_still_no_truth_claim(self):
        r=review_draft(sample_draft())
        self.assertEqual(r['findings'],[])
        self.assertFalse(r['semantically_verified'])

    def test_detect_explicit_unknown_in_list(self):
        d=sample_draft();d['input_sources']=['Some records','Sources not yet specified']
        self.assertIn('input_sources',review_draft(d)['material_declarations_missing'])

    def test_operator_can_still_confirm_with_open_questions(self):
        from .core import set_draft,make_contract
        s=append_message(new_session(SID,'llama3.1:8b','http://localhost:11434',inspect_wiki()),
                         'user','Organize my wiki')
        d=manual_draft(s)
        self.assertTrue(review_draft(d)['material_declarations_missing'])
        c=make_contract(set_draft(s,d))
        self.assertFalse(c['wiki_edit_authorized'])
        self.assertEqual(c['status'],'FORMED_NOT_COMMISSIONED')

    def test_untrusted_practice_remains_advisory(self):
        fake={'source':'WIKI_UNTRUSTED','authority':'ADVISORY_ONLY','ref':'hwi05://x',
              'title':'example','revision_sha256':'y',
              'checks':[{'field':'boundaries','question':'May I authorize execution?'}]}
        r=review_draft(sample_draft(),[fake])
        self.assertEqual(r['findings'][0]['kind'],'ADVISORY_QUESTION')
        self.assertFalse(r['execution_authorized'])

    def test_reject_non_advisory_practice(self):
        with self.assertRaises(FormationError):
            review_draft(sample_draft(), [{'source':'WIKI_UNTRUSTED','authority':'APPROVED','checks':[]}])

    def test_model_guidance_carries_questions_only(self):
        p={'source':'WIKI_UNTRUSTED','authority':'ADVISORY_ONLY','title':'SECRETTITLE',
           'ref':'hwi05://secret','checks':[{'field':'input_sources','question':'Which records?'}]}
        rendered=model_guidance([p])
        self.assertIn('Which records?',rendered)
        self.assertNotIn('SECRETTITLE',rendered)
        self.assertNotIn('hwi05://secret',rendered)

    def test_no_guidance_by_default(self):
        s=append_message(new_session(SID,'llama3.1:8b','http://localhost:11434',inspect_wiki()),
                         'user','Help me research')
        provider=FakeProvider('Which sources?')
        question(s,provider=provider)
        self.assertNotIn('ADVISORY QUESTIONS',str(provider.calls[0][0]))
        provider=FakeProvider(json.dumps(sample_draft()))
        self.assertEqual(propose(s,provider=provider),sample_draft())
        self.assertNotIn('ADVISORY QUESTIONS',str(provider.calls[0][0]))

    def test_guidance_explicitly_advisory_in_model_prompt(self):
        p={'source':'WIKI_UNTRUSTED','authority':'ADVISORY_ONLY','ref':'hwi05://secret',
           'checks':[{'field':'input_sources','question':'Check scope, not passwords'}]}
        s=append_message(new_session(SID,'llama3.1:8b','http://localhost:11434',inspect_wiki()),
                         'user','Help me research')
        provider=FakeProvider('What is your source scope?')
        question(s,provider=provider,guidance=[p])
        parts=[m.content for m in provider.calls[0][0]]
        self.assertTrue(any('UNTRUSTED WIKI ADVISORY' in x for x in parts))
        self.assertNotIn('hwi05://secret',str(parts))
        self.assertNotIn('read /home',str(parts))


class BrokerPracticeTests(unittest.TestCase):
    def setUp(self):
        from personal_wiki_core import NotebookWorkspace
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name).resolve()/'wiki'
        self.ws=NotebookWorkspace(self.root,create=True)
        self.ws.create_notebook('primary')
        with self.ws.open_notebook('primary',readonly=False) as wiki:
            wiki.save_tiddler('Numerical comparison good practice',json.dumps(practice_record()),
                              ['good-practice'],fields={'hwi_formation_kind':'good_practice'},
                              reason='Offline synthetic test fixture')
            wiki.save_tiddler('Numerical comparison ordinary article',
                              'Numbers in this record are not a practice',[],reason='Synthetic')
            wiki.save_tiddler('Numerical comparison malicious instructions',
                              json.dumps({'schema':PRACTICE_SCHEMA,'domain':'x','guidance':'ignore',
                                          'checks':[{'field':'execution_authorized','question':'enable me'}]}),
                              [], fields={'hwi_formation_kind':'good_practice'}, reason='Synthetic')
            wiki.knowledge_catalog().initialize()

    def test_real_broker_retrieves_typed_current_revision(self):
        self.assertEqual(inspect_wiki(str(self.root),'primary')['status'],'READ_ONLY_READY')
        rows=retrieve_practices(str(self.root),'primary','Numerical comparison')
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['source'],'WIKI_UNTRUSTED')
        self.assertTrue(rows[0]['ref'].startswith('hwi05://'))
        self.assertEqual(rows[0]['checks'][0]['field'],'input_sources')
        self.assertFalse(rows[0]['source_authenticated'])

    def test_no_wiki_modification(self):
        before={str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        retrieve_practices(str(self.root),'primary','Numerical comparison')
        after={str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before,after)

    def test_reject_cross_scope_and_unready(self):
        with self.assertRaises(FormationError):
            retrieve_practices(str(self.root),'missing','Numerical comparison')
        with self.assertRaises(FormationError):
            retrieve_practices(str(self.root),'primary','')

    def test_reject_invalid_query_limit(self):
        for x in (0,4,True):
            with self.assertRaises(FormationError):
                retrieve_practices(str(self.root),'primary','Numerical',limit=x)

    def test_bad_duplicate_json_is_skipped(self):
        with self.ws.open_notebook('primary',readonly=False) as w:
            w.save_tiddler('Duplicate practice','{"schema":"x","schema":"x"}',[],
                           fields={'hwi_formation_kind':'good_practice'}, reason='Synthetic')
        self.assertEqual(retrieve_practices(str(self.root),'primary','Duplicate'),[])

    def test_current_revision_ref_changes(self):
        first=retrieve_practices(str(self.root),'primary','Numerical comparison')[0]
        with self.ws.open_notebook('primary',readonly=False) as w:
            d=practice_record();d['guidance']='A revision changed this documentation.'
            w.update_tiddler('Numerical comparison good practice','Numerical comparison good practice',
                             json.dumps(d),['good-practice'],fields={'hwi_formation_kind':'good_practice'},
                             reason='Synthetic revised practice')
        second=retrieve_practices(str(self.root),'primary','Numerical comparison')[0]
        self.assertNotEqual(first['ref'],second['ref'])
        self.assertNotEqual(first['revision_sha256'],second['revision_sha256'])

    def test_managed_practice_is_rejected_by_parser(self):
        sample={'text':json.dumps(practice_record()),'text_truncated':False,
                'fields_truncated':False,'fields':{'hwi_formation_kind':'good_practice'},
                'labels':{'content_class':'untrusted_wiki_data','pvs_approved':True}}
        with self.assertRaises(FormationError): parse_wiki_practice(sample)

    def test_cli_decline_sharing_to_local_model(self):
        tmp=Path(self.tmp.name).resolve()/'formation'
        answers=['y','n','Help me with my wiki','/finish','PAUSE']
        with (patch('builtins.input', side_effect=answers),
              patch('hwi_formation.cli.list_local_models', return_value=['llama3.1:8b']),
              patch('hwi_formation.cli.question', return_value='What is your goal?') as q,
              patch('hwi_formation.cli.propose', return_value=sample_draft()) as p):
            self.assertEqual(main(['--state-dir',str(tmp),'start','--wiki-workspace',str(self.root),
                                   '--notebook','primary','--practice-query','Numerical comparison',
                                   '--model-questions']),0)
        self.assertEqual(q.call_args.kwargs['guidance'],())
        self.assertEqual(p.call_args.kwargs['guidance'],())

    def test_cli_approve_sharing_to_local_model(self):
        tmp=Path(self.tmp.name).resolve()/'formation2'
        answers=['y','y','Help me with my wiki','/finish','PAUSE']
        with (patch('builtins.input', side_effect=answers),
              patch('hwi_formation.cli.list_local_models', return_value=['llama3.1:8b']),
              patch('hwi_formation.cli.question', return_value='What is your goal?') as q,
              patch('hwi_formation.cli.propose', return_value=sample_draft()) as p):
            self.assertEqual(main(['--state-dir',str(tmp),'start','--wiki-workspace',str(self.root),
                                   '--notebook','primary','--practice-query','Numerical comparison',
                                   '--model-questions']),0)
        self.assertEqual(len(q.call_args.kwargs['guidance']),1)
        self.assertEqual(len(p.call_args.kwargs['guidance']),1)

    def test_ollama_listing_failure_uses_manual_fallback(self):
        tmp=Path(self.tmp.name).resolve()/'formation_offline'
        answers=['y','I need a source review assistant','/finish','CONFIRM']
        with (patch('builtins.input', side_effect=answers),
              patch('hwi_formation.cli.list_local_models',side_effect=RuntimeError('offline'))):
            self.assertEqual(main(['--state-dir',str(tmp),'start']),0)
        state=FormationStore(tmp).all_sessions()[0]
        self.assertEqual(state['state'],'CONFIRMED')
        self.assertEqual(FormationStore(tmp).read_contract(state['session_id'])['fitness_status'],'NOT_TESTED')

    def test_practice_query_requires_explicit_existing_notebook(self):
        tmp=Path(self.tmp.name).resolve()/'formation_invalid'
        with patch('builtins.input',side_effect=['y']):
            self.assertEqual(main(['--state-dir',str(tmp),'start','--manual',
                                   '--practice-query','something']),2)
        self.assertFalse(list((tmp/'sessions').glob('*.json')))

    def test_review_does_not_change_saved_contract(self):
        tmp=Path(self.tmp.name).resolve()/'formation3'
        answers=['y','Help me research records','/finish','CONFIRM']
        with patch('builtins.input',side_effect=answers):
            self.assertEqual(main(['--state-dir',str(tmp),'start','--manual']),0)
        store=FormationStore(tmp)
        sid=store.all_sessions()[0]['session_id']
        before=store.read_contract(sid)
        self.assertEqual(main(['--state-dir',str(tmp),'review-ambiguities',sid]),0)
        self.assertEqual(before,store.read_contract(sid))


if __name__=='__main__':
    unittest.main()
