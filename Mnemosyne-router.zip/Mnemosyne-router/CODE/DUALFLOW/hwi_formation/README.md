# HWI Agent Formation — experimental first-run feature

**Status:** Experimental Python-only integration on governance repository/SQLite
candidate `061c9cc`; original Formation branch forked from `b00411b`.
QSECD is intentionally excluded. This merged version has a single shared
wiki repository boundary, with scope-pinned good-practice retrieval.

## Purpose

Agent Formation is a conversation with the operator about *why* they created
HWI and what one narrow task should be evaluated first. It is **not** another
installation authority, a general-purpose agent, or automatic commissioning.

It uses the approved `autogpt_lite.llm.ollama.OllamaProvider` behind a
Formation-only numeric-loopback HTTP session that denies redirects and ambient
proxy inheritance (CMR-08). The separately approved provider is not modified. If Ollama or the selected model is unavailable, HWI continues
with operator-guided questions. No model is required to inspect or verify a
saved local Purpose Contract.

Run from the consolidated release root:

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_AGENT_FORMATION.command start --model 'llama3.1:8b'
```

The CLI requests permission to save a **local transcript** before creating any
files. Do **not** enter passwords, API keys, private tokens, or sensitive source
text into the formation conversation. The default local directory is
`~/.hwi-formation/` (mode 0700); transcripts and contracts are mode 0600.

For offline mode:

```sh
bash RUN_AGENT_FORMATION.command start --manual
```

To inspect a previously created PERSONAL.WIKI notebook *read-only*:

```sh
bash RUN_AGENT_FORMATION.command start --model 'llama3.1:8b' \
  --wiki-workspace '/path/to/private/wiki-workspace' --notebook primary
```

This checks an **existing** notebook. It does not create a wiki, initialize a
catalog, change records, enroll keys, or publish any agent purpose into the wiki.
Connection status, not wiki content or credentials, enters the local session.

During the conversation:

- Answer the initial "Why did you create this agent?" question.
- Type `/finish` when the objective, first task, evidence scope, success criteria,
  and boundaries have been discussed (up to eight operator turns).
- Type `/pause` at any time to save progress and resume later.
- Review the JSON draft; use `EDIT` to correct one field at a time.
- Type **`CONFIRM`** exactly to save an immutable local purpose contract, or
  `PAUSE` to keep the unconfirmed draft.
- By default HWI asks only its own guided questions; the local model writes
  the draft but not the questions. Each answer is saved with the exact question
  it answers, and the model receives them as pairs when drafting. Resuming after a
  model question shows it again only with `--model-questions`; otherwise HWI
  asks its own guided question. Add `--model-questions` to `start` or
  `resume` to let the model write follow-up questions. They are filtered: a
  reply is shown only if it is one short plain question (no code, commands,
  paths or links, no instruction, and no talk of approvals, permissions or
  credentials). The filter is lexical and cannot prove a question is
  appropriate, which is why it is off by default. Otherwise it is withheld and HWI
  asks its own guided question instead; the session stays in model mode.
- To validate model-generated follow-up questions through the typed advisory
  router, opt in with **both** `--model-questions --router-model-questions`.
  T03/T05/T08 check the request, validated response and suggested delivery;
  there is one model request and no model retry on rejected output.
  This is experimental and does not grant tool or wiki authority. The default
  remains guided questions without model-written follow-ups.
- If a CONFIRM was interrupted and the draft was then edited, the unused
  contract from the interrupted attempt is moved to `contracts/orphaned/` and
  the new one is saved. Only the session record decides which contract counts.
- Formation state is for one machine and a local disk: do not put it in a
  synced or network folder.

List/resume/inspect:

```sh
bash RUN_AGENT_FORMATION.command list
bash RUN_AGENT_FORMATION.command resume <24-hex-session-id>
bash RUN_AGENT_FORMATION.command show <24-hex-session-id>
bash RUN_AGENT_FORMATION.command show-contract <24-hex-session-id>
```

The contract has `status=FORMED_NOT_COMMISSIONED`, `fitness_status=NOT_TESTED`,
`execution_authorized=false`, `wiki_edit_authorized=false`, and
`knowledge_approved=false`. `CONFIRM` is **not** an Ed25519 signature, task
fitness approval, wiki approval, or production permission.

## The next operator step

Using the saved human-confirmed purpose as a *proposal*, independently define
representative task-fitness cases, supply true evidence digests, and run the
existing `hwi_governance fitness-assess` / `fitness-verify` workflow. The
existing v2 fitness contract's test thresholds and separately enrolled owner
key must not be inferred from the conversation or filled in by the model.

This initial feature intentionally stops **before** commissioning, tool
installation, tool execution, wiki edits, or unrestricted multi-task operation.

## Implementation boundary

- `core.py`: strict session/draft/contract shapes, digest checks, permission
  non-claims; all decisions replay without model calls.
- `model.py`: bounded Ollama conversation and JSON drafting, no tools.
- `model_port.py`: substitutable question/draft interfaces; draft generation
  intentionally retains its existing validated non-routed contract.
- `local_transport.py`: Formation-only numeric-loopback HTTP, no proxy/redirect.
- `wiki_adapter.py`: narrowly scoped read-only discovery and notebook-instance
  matching via `hwi_governance.repository.Repository`. It does not duplicate
  approved wiki-core/broker access or query the underlying SQLite tables.
- `storage.py`: private local state, one-time contract publication, bounded
  output, no wiki writes.
- `cli.py`: operator questions, local review and explicit confirmation.

Tests: `python3 -B -m unittest -q hwi_formation.test_formation`.
They use temporary private local folders, synthetic Ollama responses, and an
isolated PERSONAL.WIKI test notebook. A real native macOS Ollama trial is
still required. Checksums are **integrity** evidence, not independent identity
attestation; processes with the same OS account can edit local records.

**Known limitation:** The shared governance repository still has one tested
private `wiki._db.conn` read for HWI-08 receipts because the frozen approved
core lacks a public query. `queue-status` provides a live *on-demand read-only*
projection of ledger/receipt state, **not** a live PERSONAL.WIKI panel. Cross-DB
ledger/quota submission remains a pair of transactions. Formation contracts
remain local advisory files, not signed fitness approvals or wiki pages.
See `docs/integration/STORAGE_FORMATION_BOUNDARY.md`.

## Optional good-practice-guided ambiguity review

The Python-only formation pilot can retrieve **operator-selected** typed
advisory practices from the existing wiki's read-only broker. Guidance is
shared with local Ollama only after a separate explicit consent question;
otherwise it is shown to the human only. Every Purpose Draft displays a
conservative ambiguity review, even offline. Use `review-ambiguities SESSION_ID`
for read-only inspection of a draft or confirmed contract.

See [GOOD_PRACTICE_GUIDE.md](GOOD_PRACTICE_GUIDE.md) for the exact CLI commands,
wiki record schema, consent behavior, and limitations. The retrieved records
are *untrusted*, not governance policy or test evidence.
