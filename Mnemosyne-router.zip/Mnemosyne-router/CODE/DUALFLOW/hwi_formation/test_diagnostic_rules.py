"""DiagnosticRule unit tests and formation review behavior-preservation tests."""
from __future__ import annotations

import copy
import unittest

from .diagnostic_rules import DiagnosticEngine, DiagnosticRule
from .good_practices import UNIVERSAL, _REVIEW_RULES, review_draft
from .test_formation import sample_draft


class RuleEngineTests(unittest.TestCase):
    def test_match_and_non_match_both_advance(self):
        last = DiagnosticRule('SECOND', {'b': True}, 'Check B', lambda _: 'second')
        first = DiagnosticRule('FIRST', {'a': True}, 'Check A', lambda _: 'first', last)
        self.assertEqual(DiagnosticEngine(first).diagnose({'a': False, 'b': True}), ['second'])
        self.assertEqual(DiagnosticEngine(first).diagnose({'a': True, 'b': True}),
                         ['first', 'second'])
        self.assertEqual(DiagnosticEngine(first).diagnose({'a': False, 'b': False}), [])

    def test_missing_fact_does_not_match_none(self):
        rule = DiagnosticRule('MISSING', {'absent': None}, 'Requires explicit None',
                              lambda _: 'bad')
        self.assertEqual(DiagnosticEngine(rule).diagnose({}), [])
        self.assertEqual(DiagnosticEngine(rule).diagnose({'absent': None}), ['bad'])

    def test_callback_receives_readonly_facts(self):
        state = {'ready': True}
        def mutate(facts):
            facts['ready'] = False
        rule = DiagnosticRule('READONLY', {'ready': True}, 'Read only', mutate)
        with self.assertRaises(TypeError):
            DiagnosticEngine(rule).diagnose(state)
        self.assertEqual(state, {'ready': True})

    def test_none_callback_is_not_an_error(self):
        rule = DiagnosticRule('NOOP', {}, 'Documented check with no finding')
        self.assertEqual(DiagnosticEngine(rule).diagnose({}), [])

    def test_cycle_and_step_limit_fail_closed(self):
        # A deliberately malformed chain is rejected rather than looping.
        a = DiagnosticRule('A', {}, 'Check A')
        b = DiagnosticRule('B', {}, 'Check B', next_rule=a)
        object.__setattr__(a, 'next_rule', b)
        with self.assertRaisesRegex(ValueError, 'cycle'):
            DiagnosticEngine(a).diagnose({})
        with self.assertRaisesRegex(ValueError, 'max_steps'):
            DiagnosticEngine(a, max_steps=1).diagnose({})
        with self.assertRaises(ValueError):
            DiagnosticEngine(a, max_steps=0)

    def test_exception_halts_chain(self):
        calls = []
        def fail(_):
            raise RuntimeError('diagnostic failure')
        following = DiagnosticRule('AFTER', {}, 'Never run', lambda _: calls.append('after'))
        rule = DiagnosticRule('FAIL', {}, 'Fail', fail, following)
        with self.assertRaisesRegex(RuntimeError, 'diagnostic failure'):
            DiagnosticEngine(rule).diagnose({})
        self.assertEqual(calls, [])


class FormationRuleTests(unittest.TestCase):
    def test_rule_chain_is_self_describing(self):
        rule = _REVIEW_RULES.start_rule
        labels = []
        while rule is not None:
            labels.append((rule.rule_id, rule.description))
            rule = rule.next_rule
        self.assertEqual([key for key, _ in labels],
                         [f'MISSING_{field.upper()}' for field, _ in UNIVERSAL]
                         + ['POSSIBLY_BROAD_TASK'])
        self.assertTrue(all(description for _, description in labels))

    def test_all_six_missing_findings_keep_question_order(self):
        draft = sample_draft()
        values = {
            'initial_task': 'Not yet specified by operator',
            'domain': 'To be defined by operator',
            'input_sources': ['Sources not yet specified'],
            'expected_outputs': ['Output not yet specified'],
            'success_criteria': ['Acceptance criteria not yet specified'],
            'boundaries': ['Boundaries not yet specified'],
        }
        draft.update(values)
        original = copy.deepcopy(draft)
        review = review_draft(draft)
        expected = [{'field': field, 'kind': 'MISSING_DECLARATION',
                     'question': question, 'source': 'HWI_UNIVERSAL'}
                    for field, question in UNIVERSAL]
        self.assertEqual(review['findings'], expected)
        self.assertEqual(draft, original)
        self.assertEqual(review['material_declarations_missing'], sorted(values))
        self.assertFalse(review['execution_authorized'])

    def test_broad_check_keeps_original_position(self):
        draft = sample_draft()
        draft['initial_task'] = 'Help me research'
        draft['input_sources'] = ['Sources not yet specified']
        findings = review_draft(draft)['findings']
        self.assertEqual([x['kind'] for x in findings],
                         ['MISSING_DECLARATION', 'POSSIBLY_BROAD'])
        self.assertEqual(findings[1]['question'],
                         'Can you state one observable, bounded first result?')

    def test_good_draft_generates_no_findings(self):
        self.assertEqual(review_draft(sample_draft())['findings'], [])


if __name__ == '__main__':
    unittest.main()
