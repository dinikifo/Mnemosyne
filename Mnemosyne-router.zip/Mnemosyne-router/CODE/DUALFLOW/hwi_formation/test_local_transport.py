"""CMR-08 loopback network boundary tests using local HTTP servers only."""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from contextlib import contextmanager
from unittest import TestCase
from unittest.mock import patch
import json
import os

from .core import append_message, new_session
from .model import list_local_models, propose, question
from .test_formation import sample_draft
from .local_transport import local_provider
import requests


@contextmanager
def local_server(handler):
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    worker = Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=5)


class _Recording(BaseHTTPRequestHandler):
    seen = None
    destination = None
    status = 200

    def log_message(self, *_):
        pass

    def _response(self):
        n = int(self.headers.get('Content-Length', 0))
        self.seen.append((self.command, self.path, self.rfile.read(n)))
        self.send_response(self.status)
        if 300 <= self.status < 400:
            self.send_header('Location', self.destination)
            body = b''
        else:
            body = (json.dumps({'models': [{'name': 'llama3.1:8b'}]}) if self.command == 'GET'
                    else json.dumps({'message': {'content': 'Which notes matter most?'}})).encode()
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._response()

    def do_POST(self):
        self._response()


def handler(seen, *, status=200, destination=None):
    return type('Recorder', (_Recording,), {'seen': seen, 'status': status,
                                           'destination': destination})


class LocalTransportTests(TestCase):
    def test_redirect_never_forwards_model_transcript(self):
        for code in (301, 302, 307, 308):
            with self.subTest(code=code):
                stolen, sent = [], []
                with local_server(handler(stolen)) as receiver:
                    target = f'http://127.0.0.1:{receiver.server_port}/collect'
                    with local_server(handler(sent, status=code, destination=target)) as source:
                        endpoint = f'http://127.0.0.1:{source.server_port}'
                        s = new_session('c'*24, 'llama3.1:8b', endpoint, {'status': 'NOT_CONFIGURED'})
                        s = append_message(s, 'user', 'PRIVATE TEST TRANSCRIPT')
                        with self.assertRaises(Exception):
                            question(s)
                self.assertEqual(len(sent), 1)
                self.assertIn(b'PRIVATE TEST TRANSCRIPT', sent[0][2])
                self.assertEqual(stolen, [], 'request followed a redirect to a different host')

    def test_model_listing_redirect_is_not_followed(self):
        stolen, sent = [], []
        with local_server(handler(stolen)) as receiver:
            with local_server(handler(sent, status=307,
                                      destination=f'http://127.0.0.1:{receiver.server_port}/collect')) as source:
                self.assertEqual(list_local_models(f'http://127.0.0.1:{source.server_port}'), [])
        self.assertEqual(len(sent), 1)
        self.assertEqual(stolen, [])

    def test_proxies_ignored_even_with_no_proxy_disabled(self):
        proxy_seen, direct_seen = [], []
        with local_server(handler(proxy_seen)) as proxy:
            with local_server(handler(direct_seen)) as direct:
                env = {'HTTP_PROXY': f'http://127.0.0.1:{proxy.server_port}',
                       'http_proxy': f'http://127.0.0.1:{proxy.server_port}',
                       'ALL_PROXY': f'http://127.0.0.1:{proxy.server_port}',
                       'NO_PROXY': ''}
                with patch.dict(os.environ, env):
                    self.assertEqual(list_local_models(f'http://127.0.0.1:{direct.server_port}'),
                                     ['llama3.1:8b'])
        self.assertEqual(proxy_seen, [])
        self.assertEqual([x[1] for x in direct_seen], ['/api/tags'])

    def test_localhost_normalizes_to_numeric_loopback(self):
        provider = local_provider('http://localhost:11434')
        self.assertEqual(provider.base_url, 'http://127.0.0.1:11434')
        self.assertFalse(provider._session.trust_env)

    def test_forbidden_url_or_method_does_not_reach_server(self):
        seen = []
        with local_server(handler(seen)) as source:
            p = local_provider(f'http://127.0.0.1:{source.server_port}')
            import requests
            for method, url in (('GET', f'http://127.0.0.1:{source.server_port}/unexpected'),
                                ('POST', 'http://127.0.0.1:1/api/chat'),
                                ('PUT', f'http://127.0.0.1:{source.server_port}/api/chat')):
                with self.subTest(method=method, url=url), self.assertRaises(requests.ConnectionError):
                    p._session.request(method, url)
        self.assertEqual(seen, [])

    def test_question_and_draft_timeout_budgets_are_bounded(self):
        calls = []
        class DummyResponse:
            status_code = 200
        def fake_request(_session, method, url, **kwargs):
            calls.append((method, url, kwargs))
            return DummyResponse()
        provider = local_provider('http://127.0.0.1:11434')
        with patch.object(requests.Session, 'request', fake_request):
            for payload in ({'model': 'test'}, {'model': 'test', 'format': 'json'}):
                provider._session.request('POST', provider.base_url + '/api/chat',
                                          json=payload, timeout=300)
            provider._session.request('GET', provider.base_url + '/api/tags', timeout=300)
        self.assertEqual([kw['timeout'] for _, _, kw in calls], [120, 300, 10])
        self.assertTrue(all(kw['allow_redirects'] is False for _, _, kw in calls))

    def test_existing_approved_provider_protocol_preserved(self):
        seen = []
        with local_server(handler(seen)) as source:
            endpoint = f'http://127.0.0.1:{source.server_port}'
            s = new_session('c'*24, 'llama3.1:8b', endpoint, {'status': 'NOT_CONFIGURED'})
            s = append_message(s, 'user', 'Summarize weekly notes')
            self.assertEqual(question(s), 'Which notes matter most?')
            self.assertEqual(len(seen), 1)
            request = json.loads(seen[0][2])
            self.assertEqual(request['model'], 'llama3.1:8b')
            self.assertIn('Summarize weekly notes', json.dumps(request))
