"""Regression tests for the Formation review findings (fallback draft, CONFIRM
retry, visible invisible-characters at review)."""
from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from .cli import main
from .core import (FormationError, append_message, manual_draft, new_session, set_draft,
                   validate_draft)
from .storage import FormationStore
from .test_formation import SID, WIKI, sample_draft


def model_led():
    s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
    for role, text in (('user', 'I want help linking my planning notes'),
                       ('assistant', 'Which notes should it look at?'),
                       ('user', 'Only the posts in my planning notebook'),
                       ('assistant', 'What would count as success?'),
                       ('user', 'It never proposes a wrong link')):
        s = append_message(s, role, text)
    return s


class FallbackDraftTests(unittest.TestCase):
    def test_model_led_answers_are_not_assigned_by_position(self):
        d = manual_draft(model_led())
        self.assertEqual(d['purpose'], 'I want help linking my planning notes')
        self.assertEqual(d['initial_task'], 'Not yet specified by operator')
        self.assertEqual(d['input_sources'], ['Sources not yet specified'])
        self.assertEqual(d['success_criteria'], ['Acceptance criteria not yet specified'])
        self.assertIn('Unassigned answer: Only the posts in my planning notebook', d['open_questions'])
        self.assertIn('Unassigned answer: It never proposes a wrong link', d['open_questions'])
        self.assertTrue(d['open_questions'][0].startswith('Model-led conversation'))

    def test_operator_prompted_answers_keep_positions(self):
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=True)
        for text in ('Purpose', 'Task', 'Sources', 'Success', 'Avoid'):
            s = append_message(s, 'user', text)
        d = manual_draft(s)
        self.assertEqual((d['initial_task'], d['input_sources'], d['success_criteria'], d['boundaries']),
                         ('Task', ['Sources'], ['Success'], ['Avoid']))

    def test_many_long_answers_stay_valid(self):
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        for i in range(8):
            s = append_message(s, 'user', f'answer {i} ' + 'x' * 600)
            if i < 7:
                s = append_message(s, 'assistant', f'question {i}?')
        validate_draft(manual_draft(s))  # at most 8 items of at most 320 characters


class ConfirmRetryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name).resolve()
        os.chmod(root, 0o700)
        self.store = FormationStore(root / 'f', create=True)
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=True)
        self.store.create(s)
        s2 = append_message(s, 'user', 'Purpose')
        self.store.save(s2, previous_sha256=s['record_sha256'])
        self.ready = set_draft(s2, sample_draft())
        self.store.save(self.ready, previous_sha256=s2['record_sha256'])

    def tearDown(self):
        self.temp.cleanup()

    def test_retry_after_session_save_failure_completes(self):
        with patch.object(FormationStore, '_save_unlocked', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                self.store.confirm(self.ready)
        loaded = self.store.load(SID)
        self.assertEqual(loaded['state'], 'DRAFT_READY')
        self.store.confirm(loaded)
        self.assertEqual(self.store.load(SID)['state'], 'CONFIRMED')
        self.assertEqual(self.store.read_contract(SID)['status'], 'FORMED_NOT_COMMISSIONED')

    def test_orphaned_contract_is_set_aside_after_edit(self):
        with patch.object(FormationStore, '_save_unlocked', side_effect=OSError('disk full')):
            with self.assertRaises(OSError):
                self.store.confirm(self.ready)
        orphan_bytes = (self.store.contracts / (SID + '.json')).read_bytes()
        edited = dict(self.store.load(SID))
        draft = dict(edited['draft'], purpose='A different purpose')
        from .core import check_session, seal_session
        edited = check_session(seal_session({**edited, 'draft':draft}))
        self.store.save(edited, previous_sha256=self.ready['record_sha256'])
        self.store.confirm(edited)
        self.assertEqual(self.store.load(SID)['state'], 'CONFIRMED')
        self.assertEqual(self.store.read_contract(SID)['purpose'], 'A different purpose')
        kept = list((self.store.contracts / 'orphaned').iterdir())
        self.assertEqual(len(kept), 1)
        self.assertEqual(kept[0].read_bytes(), orphan_bytes)
        self.assertEqual((self.store.contracts / 'orphaned').stat().st_mode & 0o777, 0o700)

    def test_confirmed_contract_is_never_set_aside(self):
        self.store.confirm(self.ready)
        with self.assertRaisesRegex(FormationError, 'already confirmed'):
            self.store.confirm(self.ready)
        self.assertFalse((self.store.contracts / 'orphaned').exists())


class VisibleOutputTests(unittest.TestCase):
    def test_show_escapes_invisible_characters_keeps_greek(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name).resolve()
        os.chmod(root, 0o700)
        store = FormationStore(root / 'f', create=True)
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=True)
        store.create(s)
        s2 = append_message(s, 'user', 'Σκοπός')
        store.save(s2, previous_sha256=s['record_sha256'])
        s3 = set_draft(s2, dict(sample_draft(), purpose='Link ‮esrever‬ notes ​'))
        store.save(s3, previous_sha256=s2['record_sha256'])
        out = StringIO()
        with redirect_stdout(out):
            self.assertEqual(main(['--state-dir', str(root / 'f'), 'show', SID]), 0)
        text = out.getvalue()
        self.assertIn('Σκοπός', text)
        self.assertNotIn('‮', text)
        self.assertNotIn('​', text)
        self.assertIn('\\u202e', text)



# ---- concurrency: one locked compare-and-swap per save / confirm --------------
def _race_writer(root, sid, prev, text, action, out):
    import time
    from hwi_formation import storage
    from hwi_formation.core import append_message, set_draft
    real = storage.os.replace
    def slow_replace(a, b):
        time.sleep(0.3)  # widen the window between hash check and replace
        real(a, b)
    storage.os.replace = slow_replace
    store = storage.FormationStore(root)
    base = store.load(sid)
    try:
        if action == 'save':
            store.save(append_message(base, 'user', text), previous_sha256=prev)
        else:
            store.confirm(base)
        out.put((text, 'OK'))
    except Exception as exc:  # reported, not raised, across the process boundary
        out.put((text, f'{type(exc).__name__}: {exc}'))


class ConcurrencyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name).resolve()
        os.chmod(root, 0o700)
        self.root = root / 'f'
        self.store = FormationStore(self.root, create=True)
        self.base = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=True)
        self.store.create(self.base)

    def race(self, action, texts):
        import multiprocessing
        ctx = multiprocessing.get_context('spawn')
        q = ctx.Queue()
        prev = self.store.load(SID)['record_sha256']
        ps = [ctx.Process(target=_race_writer, args=(str(self.root), SID, prev, t, action, q)) for t in texts]
        for p in ps:
            p.start()
        for p in ps:
            p.join(30)
        return dict(q.get(timeout=5) for _ in ps)

    def test_concurrent_saves_never_lose_an_update(self):
        results = self.race('save', ['writer A', 'writer B'])
        winners = [t for t, r in results.items() if r == 'OK']
        self.assertEqual(len(winners), 1, results)
        loser = next(r for r in results.values() if r != 'OK')
        self.assertIn('Stale formation session', loser)
        users = [m['text'] for m in self.store.load(SID)['messages'] if m['role'] == 'user']
        self.assertEqual(users, winners)

    def test_concurrent_confirms_publish_one_contract(self):
        s = append_message(self.store.load(SID), 'user', 'Purpose')
        self.store.save(s, previous_sha256=self.base['record_sha256'])
        ready = set_draft(s, sample_draft())
        self.store.save(ready, previous_sha256=s['record_sha256'])
        results = self.race('confirm', ['first', 'second'])
        self.assertEqual(sorted(r == 'OK' for r in results.values()), [False, True], results)
        self.assertIn('already confirmed', next(r for r in results.values() if r != 'OK'))
        self.assertEqual(self.store.load(SID)['state'], 'CONFIRMED')
        self.store.read_contract(SID)

    def test_stale_confirm_publishes_nothing(self):
        s = append_message(self.store.load(SID), 'user', 'Purpose')
        self.store.save(s, previous_sha256=self.base['record_sha256'])
        ready = set_draft(s, sample_draft())
        self.store.save(ready, previous_sha256=s['record_sha256'])
        from .core import check_session, seal_session
        newer = dict(self.store.load(SID), draft=dict(sample_draft(), purpose='Different purpose'))
        newer = check_session(seal_session(newer))  # exactly what the CLI's EDIT does
        self.store.save(newer, previous_sha256=ready['record_sha256'])
        with self.assertRaisesRegex(FormationError, 'Stale formation session'):
            self.store.confirm(ready)  # caller still holds the older draft
        self.assertFalse((self.root / 'contracts' / f'{SID}.json').exists())
        self.store.confirm(self.store.load(SID))  # the current draft confirms cleanly

    def test_lock_file_is_private(self):
        self.store.save(append_message(self.base, 'user', 'x'), previous_sha256=self.base['record_sha256'])
        self.assertEqual(os.stat(self.root / '.store.lock').st_mode & 0o777, 0o600)


class TransitionTests(unittest.TestCase):
    """save() accepts only changes the Formation workflow itself produces."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name).resolve()
        os.chmod(root, 0o700)
        self.store = FormationStore(root / 'f', create=True)
        self.s0 = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        self.store.create(self.s0)
        self.s1 = append_message(self.s0, 'user', 'Summarise weekly notes')
        self.store.save(self.s1, previous_sha256=self.s0['record_sha256'])

    def tearDown(self):
        self.temp.cleanup()

    def forged(self, base, **changes):
        from .core import check_session, seal_session
        return check_session(seal_session({**base, **changes}))

    def refused(self, record, base, pattern):
        with self.assertRaisesRegex(FormationError, pattern):
            self.store.save(record, previous_sha256=base['record_sha256'])
        self.assertEqual(self.store.load(SID), base)

    def ready(self):
        s2 = set_draft(self.s1, sample_draft())
        self.store.save(s2, previous_sha256=self.s1['record_sha256'])
        return s2

    def test_direct_confirmed_save_is_refused(self):
        s2 = self.ready()
        forged = self.forged(s2, state='CONFIRMED', contract_sha256='a' * 64)
        self.refused(forged, s2, 'Only CONFIRM')

    def test_identity_and_configuration_are_immutable(self):
        for key, value in (('model', 'other:7b'), ('endpoint', 'http://127.0.0.1:11435'),
                           ('wiki_capabilities', {'status': 'READ_ONLY_READY'})):
            with self.subTest(key=key):
                self.refused(self.forged(self.s1, **{key: value}), self.s1, key + ' is immutable')

    def test_conversation_is_append_only(self):
        rewritten = self.forged(self.s1, messages=[{'role': 'user', 'text': 'Something else'}])
        self.refused(rewritten, self.s1, 'append-only')
        two = append_message(append_message(self.s1, 'assistant', 'Which notes?'), 'user', 'All')
        self.refused(two, self.s1, 'append-only')

    def test_closed_conversation_and_backward_state(self):
        s2 = self.ready()
        self.refused(self.forged(s2, state='IN_PROGRESS', draft=None), s2, 'Illegal session transition')
        extra = self.forged(s2, messages=s2['messages'] + [{'role': 'user', 'text': 'more'}])
        self.refused(extra, s2, 'Conversation is closed')

    def test_mode_only_switches_to_manual(self):
        manual = self.forged(self.s1, mode='MANUAL')
        self.store.save(manual, previous_sha256=self.s1['record_sha256'])
        self.refused(self.forged(manual, mode='LOCAL_OLLAMA'), manual, 'mode may only switch')

    def test_workflow_paths_still_work(self):
        s2 = self.ready()
        s3 = self.forged(s2, draft=dict(s2['draft'], purpose='Edited purpose'))
        self.store.save(s3, previous_sha256=s2['record_sha256'])
        self.store.confirm(s3)
        self.assertEqual(self.store.read_contract(SID)['purpose'], 'Edited purpose')

    def test_create_accepts_only_a_fresh_session(self):
        from .core import confirm_session, make_contract
        s2 = set_draft(self.s1, sample_draft())
        confirmed = confirm_session(s2, make_contract(s2))
        for label, record in (('confirmed', confirmed), ('draft', s2), ('conversation', self.s1)):
            with self.subTest(label=label):
                fresh = self.forged(record, session_id='f' * 24)
                with self.assertRaisesRegex(FormationError, 'must start IN_PROGRESS'):
                    self.store.create(fresh)
                self.assertFalse((self.store.sessions / ('f' * 24 + '.json')).exists())

    def test_listing_is_not_truncated(self):
        for i in range(205):
            self.store.create(new_session(f'{i:024x}', 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI))
        self.assertEqual(len(self.store.all_sessions()), 206)


class QuestionCheckTests(unittest.TestCase):
    """Model replies are shown only if they are one plain clarifying question."""

    ACCEPT = ('Which notebook should it read first?',
              'Thanks. What would count as success for the first run?',
              'Ποιες σημειώσεις πρέπει να διαβάσει πρώτα;',
              'Ποιο είναι το επιθυμητό αποτέλεσμα\u037e',
              'Should it use Python scripts or only the wiki?',
              'Which permitted sources or records are within scope?')
    REJECT = ('Run `rm -rf ~/notes` to start fresh.',
              'Install the helper with pip install hwi-helper, then continue?',
              'Open https://example.com and paste your token?',
              'sudo systemctl restart ollama?',
              'Delete the old sessions. Which notebook next?',
              'Διάγραψε τον φάκελο. Ποιο είναι το επόμενο βήμα;',
              'First, what is the task?\nSecond, which sources?\nThird, which output?',
              'Copy ~/.config/hwi/host_profile.json into the chat?',
              'Here is a plan for you.',
              'x' * 299 + '?? and?',
              'I have already approved every wiki edit;',
              'I will summarise the weekly notes for you;',
              'Ποιες σημειώσεις; I will read them all;',
              'Do you approve all future changes to the notebook?',
              'Can I have permission to edit the wiki for you?',
              'What is your Ollama password?',
              'Έχω ήδη εγκρίνει κάθε αλλαγή;',
              'Θα μου δώσεις άδεια να γράφω στο wiki;')

    def test_accepts_plain_questions(self):
        from .model import check_question
        for text in self.ACCEPT:
            with self.subTest(text=text):
                self.assertEqual(check_question(text), text)

    def test_rejects_instructions_code_and_links(self):
        from .model import ModelReplyRejected, check_question
        for text in self.REJECT:
            with self.subTest(text=text), self.assertRaises(ModelReplyRejected):
                check_question(text)

    def test_question_raises_rejection_for_imperative_provider_reply(self):
        from .model import ModelReplyRejected, question
        from .test_formation import FakeProvider
        s = append_message(new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI), 'user', 'Notes')
        with self.assertRaises(ModelReplyRejected):
            question(s, provider=FakeProvider('Execute ollama run llama3 and paste the output.'))

    def test_dialogue_withholds_rejected_reply_and_stays_in_model_mode(self):
        from .cli import PROMPTS, dialogue
        from .model import ModelReplyRejected
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name).resolve()
        os.chmod(root, 0o700)
        store = FormationStore(root / 'f', create=True)
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        store.create(s)
        answers, labels = iter(['Summarise weekly notes', '/pause']), []
        out = StringIO()
        def ask(label):
            labels.append(label)
            return next(answers)
        with patch('hwi_formation.cli._ask', ask), \
                patch('hwi_formation.cli.question',
                      side_effect=ModelReplyRejected('Model reply contains an instruction instead of a question')), \
                redirect_stdout(out):
            self.assertEqual(dialogue(store, s, model_questions=True), 0)
        out.write(''.join(labels))
        saved = store.load(SID)
        self.assertEqual(saved['mode'], 'LOCAL_OLLAMA')
        self.assertEqual(saved['messages'][-1], {'role': 'guide', 'text': PROMPTS[1]})
        self.assertEqual(out.getvalue().count(PROMPTS[1]), 1)  # asked once, not twice
        self.assertIn('Model reply withheld', out.getvalue())
        self.assertNotIn('model suggestion', out.getvalue())


class ModelQuestionsOffTests(unittest.TestCase):
    """Stopgap: by default the model never writes the questions shown to the user."""

    def run_dialogue(self, **kwargs):
        from .cli import PROMPTS, dialogue
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name).resolve()
        os.chmod(root, 0o700)
        store = FormationStore(root / 'f', create=True)
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        store.create(s)
        answers = iter(['Summarise weekly notes', 'The notes folder', '/pause'])
        out = StringIO()
        with patch('hwi_formation.cli._ask', lambda _label: next(answers)), \
                patch('hwi_formation.cli.question', return_value='Which notes matter most?') as asked, \
                redirect_stdout(out):
            self.assertEqual(dialogue(store, s, **kwargs), 0)
        return store.load(SID), asked, out.getvalue(), PROMPTS

    def test_default_uses_guided_questions_only(self):
        saved, asked, out, PROMPTS = self.run_dialogue()
        asked.assert_not_called()
        self.assertEqual(saved['messages'], [
            {'role': 'guide', 'text': PROMPTS[0]}, {'role': 'user', 'text': 'Summarise weekly notes'},
            {'role': 'guide', 'text': PROMPTS[1]}, {'role': 'user', 'text': 'The notes folder'}])
        self.assertEqual(saved['mode'], 'LOCAL_OLLAMA')  # the model still drafts
        self.assertIn('Guided questions only', out)
        self.assertNotIn('model suggestion', out)

    def test_opt_in_restores_filtered_model_questions(self):
        saved, asked, out, _ = self.run_dialogue(model_questions=True)
        self.assertEqual(asked.call_count, 2)
        self.assertEqual(saved['messages'][2], {'role': 'assistant', 'text': 'Which notes matter most?'})
        self.assertIn('model suggestion', out)

    def test_cli_flag_defaults_off(self):
        from .cli import main
        with patch('hwi_formation.cli.dialogue', return_value=0) as run, \
                patch('hwi_formation.cli.FormationStore') as store:
            store.return_value.load.return_value = {}
            with patch('hwi_formation.cli._practice_options', return_value=((), False)):
                main(['resume', SID])
                self.assertFalse(run.call_args.kwargs['model_questions'])
                main(['resume', SID, '--model-questions'])
                self.assertTrue(run.call_args.kwargs['model_questions'])


class GuidedPairTests(unittest.TestCase):
    """The model sees each answer paired with the exact HWI question it answered."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name).resolve()
        os.chmod(root, 0o700)
        self.store = FormationStore(root / 'f', create=True)

    def tearDown(self):
        self.temp.cleanup()

    def converse(self, session, answers, **kwargs):
        from .cli import dialogue
        it, asked = iter(answers), []
        def ask(label):
            asked.append(label)
            return next(it)
        with patch('hwi_formation.cli._ask', ask), redirect_stdout(StringIO()) as out:
            dialogue(self.store, session, **kwargs)
        return self.store.load(SID), out.getvalue() + ''.join(asked)

    def test_draft_request_contains_question_answer_pairs(self):
        import json
        from .cli import PROMPTS
        from .model import propose
        from .test_formation import FakeProvider
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        self.store.create(s)
        answers = ['Help manage my research project', 'Review selected evidence', 'The dated project records']
        saved, _ = self.converse(s, answers + ['/pause'])
        fake = FakeProvider(json.dumps(sample_draft()))
        propose(saved, provider=fake)
        sent = [(m.role, m.content) for m in fake.calls[0][0] if m.role != 'system']
        expected = []
        for q, a in zip(PROMPTS, answers):
            expected += [('assistant', q), ('user', a)]
        self.assertEqual(sent[:6], expected)

    def test_resume_asks_a_stored_unanswered_question_once(self):
        from .cli import PROMPTS
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        self.store.create(s)
        s1 = append_message(s, 'guide', PROMPTS[0])
        self.store.save(s1, previous_sha256=s['record_sha256'])
        saved, out = self.converse(s1, ['Organise my notes', '/pause'])
        self.assertEqual(saved['messages'][:2], [{'role': 'guide', 'text': PROMPTS[0]},
                                                 {'role': 'user', 'text': 'Organise my notes'}])
        self.assertEqual(sum(m['text'] == PROMPTS[0] for m in saved['messages']), 1)
        self.assertEqual(out.count(PROMPTS[0]), 1)

    def test_older_session_without_guides_continues(self):
        from .cli import PROMPTS
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        self.store.create(s)
        s1 = append_message(s, 'user', 'Organise my notes')  # written before guides were stored
        self.store.save(s1, previous_sha256=s['record_sha256'])
        saved, _ = self.converse(s1, ['Tag the weekly notes', '/pause'])
        self.assertEqual(saved['messages'][1:], [{'role': 'guide', 'text': PROMPTS[1]},
                                                 {'role': 'user', 'text': 'Tag the weekly notes'}])

    def test_manual_draft_mapping_unchanged_by_guides(self):
        from .cli import PROMPTS
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=True)
        plain, paired = s, s
        for i, answer in enumerate(['Purpose', 'Task', 'Sources', 'Success', 'Limits']):
            plain = append_message(plain, 'user', answer)
            paired = append_message(append_message(paired, 'guide', PROMPTS[i]), 'user', answer)
        self.assertEqual(manual_draft(paired), manual_draft(plain))


class ResumeAtModelQuestionTests(unittest.TestCase):
    """Resuming after a stored model question never leaves a bare 'You>' prompt."""

    def setUp(self):
        from .cli import PROMPTS
        self.PROMPTS = PROMPTS
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name).resolve()
        os.chmod(root, 0o700)
        self.store = FormationStore(root / 'f', create=True)
        s = new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
        self.store.create(s)
        self.s = s
        for role, text in (('guide', PROMPTS[0]), ('user', 'Organise my notes')):
            nxt = append_message(self.s, role, text)
            self.store.save(nxt, previous_sha256=self.s['record_sha256'])
            self.s = nxt

    def tearDown(self):
        self.temp.cleanup()

    def paused_at(self, text):
        nxt = append_message(self.s, 'assistant', text)
        self.store.save(nxt, previous_sha256=self.s['record_sha256'])
        return nxt

    def resume(self, session, answers, **kwargs):
        from .cli import dialogue
        it, labels = iter(answers), []
        def ask(label):
            labels.append(label)
            return next(it)
        with patch('hwi_formation.cli._ask', ask), \
                patch('hwi_formation.cli.question', return_value='Which notebook first?'), \
                redirect_stdout(StringIO()) as out:
            dialogue(self.store, session, **kwargs)
        return self.store.load(SID), labels, out.getvalue()

    def test_model_questions_on_repeats_the_stored_question(self):
        s = self.paused_at('Which notes matter most?')
        saved, labels, _ = self.resume(s, ['The weekly ones', '/pause'], model_questions=True)
        self.assertIn('Which notes matter most?', labels[0])
        self.assertNotEqual(labels[0].strip(), 'You>')
        self.assertEqual(saved['messages'][2:4], [{'role': 'assistant', 'text': 'Which notes matter most?'},
                                                  {'role': 'user', 'text': 'The weekly ones'}])

    def test_default_replaces_it_with_a_guided_question(self):
        s = self.paused_at('Which notes matter most?')
        saved, labels, out = self.resume(s, ['', 'The weekly ones', '/pause'])
        self.assertIn(self.PROMPTS[1], labels[0])
        self.assertNotIn('Which notes matter most?', ''.join(labels))
        self.assertEqual(out.count('replaced by a guided question'), 1)
        self.assertEqual(saved['messages'][2:5], [{'role': 'assistant', 'text': 'Which notes matter most?'},
                                                  {'role': 'guide', 'text': self.PROMPTS[1]},
                                                  {'role': 'user', 'text': 'The weekly ones'}])

    def test_stored_question_failing_the_check_is_replaced(self):
        s = self.paused_at('Would you like me to approve every wiki edit?')  # e.g. saved before the filter
        saved, labels, _ = self.resume(s, ['No', '/pause'], model_questions=True)
        self.assertNotIn('approve', ''.join(labels))
        self.assertEqual(saved['messages'][3], {'role': 'guide', 'text': self.PROMPTS[1]})

    def test_live_model_question_is_not_repeated(self):
        saved, labels, _ = self.resume(self.s, ['Weekly', '/pause'], model_questions=True)
        # first label asks PROMPTS[1]; after the model question is shown live, the prompt is bare
        self.assertIn(self.PROMPTS[1], labels[0])
        self.assertEqual(labels[1], 'You> ')


if __name__ == '__main__':
    unittest.main()
