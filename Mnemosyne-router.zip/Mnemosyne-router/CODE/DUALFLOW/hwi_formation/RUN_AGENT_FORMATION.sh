#!/bin/bash
# Source-tree convenience launcher: run from CODE/DUALFLOW; no automatic writes.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT:${HWI_WIKI_CORE:?set HWI_WIKI_CORE to the approved wiki-core path}:${HWI_AGENT_PROVIDER:?set HWI_AGENT_PROVIDER to the approved provider path}${PYTHONPATH:+:$PYTHONPATH}"
exec "${HWI_PYTHON:-python3}" -B -m hwi_formation "$@"
