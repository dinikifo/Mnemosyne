"""Operator-controlled Agent Formation. No authority is conferred by conversation."""
