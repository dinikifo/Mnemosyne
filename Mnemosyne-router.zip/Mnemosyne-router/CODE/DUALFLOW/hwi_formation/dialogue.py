"""Formation conversation as an explicit state machine (pure: no input/output).

States
  NEED_QUESTION  no open question; HWI asks its next guided question, which is
                 stored together with the answer
  GUIDE_OPEN     a guided question is stored and unanswered (resume, or fallback
                 after a withheld model reply)
  MODEL_OPEN     a model question is stored and unanswered; ``live`` means it was
                 just shown in this run (bare ``You>`` prompt), otherwise it is
                 shown again (resume with model questions on, still passing the check)
  ASKING_MODEL   an answer was stored; the next question comes from the local model
  DONE           ``reason`` is 'finish', 'pause' or 'max_turns'

The state is derived from the stored record by ``start()``, so resuming and
continuing are the same path. ``step(state, event)`` returns the next state and
a list of effects; the caller performs them (print, store, switch to manual).

Transition table (also the test plan in ``test_dialogue_machine.py``):

  from           event                       to                       effects
  NEED_QUESTION  Reply(answer)               ASKING_MODEL|NEED_Q|DONE store guide, store user
  GUIDE_OPEN     Reply(answer)               ASKING_MODEL|NEED_Q|DONE store user
  MODEL_OPEN     Reply(answer)               ASKING_MODEL|NEED_Q|DONE store user
  any open       Reply('')                   same                     print hint
  any open       Reply('/pause')             DONE(pause)              -
  any open       Reply('/finish')            DONE(finish)             -
  ASKING_MODEL   ModelOK(q)                  MODEL_OPEN(live)         print q, store assistant
  ASKING_MODEL   ModelRejected(reason)       GUIDE_OPEN               print note, store guide
  ASKING_MODEL   ModelDown(reason)           NEED_QUESTION            print note, switch to manual
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable, Optional

from .core import MAX_TURNS, FormationError, append_message, use_manual_mode

PROMPTS = (
    'Why did you create this agent? What would be useful to you?',
    'What ONE concrete task should it attempt first?',
    'Which sources or records should it use for that task?',
    'What observable result would make you consider the task successful?',
    'What must it avoid, and when should it stop and ask you?',
    'Any other constraints or questions to resolve?',
)
FINAL_PROMPT = 'Anything else to define?'

NEED_QUESTION, GUIDE_OPEN, MODEL_OPEN, ASKING_MODEL, DONE = (
    'NEED_QUESTION', 'GUIDE_OPEN', 'MODEL_OPEN', 'ASKING_MODEL', 'DONE')
OPEN = (NEED_QUESTION, GUIDE_OPEN, MODEL_OPEN)


def guided_question(turns: int) -> str:
    return PROMPTS[turns] if turns < len(PROMPTS) else FINAL_PROMPT


@dataclass(frozen=True)
class State:
    kind: str
    turns: int                 # user answers stored so far
    model_on: bool             # LOCAL_OLLAMA mode and --model-questions
    text: Optional[str] = None  # the open question (GUIDE_OPEN / MODEL_OPEN)
    live: bool = False         # MODEL_OPEN: shown in this run
    reason: Optional[str] = None  # DONE


# Events
@dataclass(frozen=True)
class Reply:
    text: str


@dataclass(frozen=True)
class ModelOK:
    question: str


@dataclass(frozen=True)
class ModelRejected:
    reason: str


@dataclass(frozen=True)
class ModelDown:
    reason: str


# Effects are tuples: ('print', text) | ('store', role, text) | ('manual',)

def _after_answer(state: State, turns: int) -> State:
    if turns >= MAX_TURNS:
        return State(DONE, turns, state.model_on, reason='max_turns')
    if state.model_on:
        return State(ASKING_MODEL, turns, state.model_on)
    return State(NEED_QUESTION, turns, state.model_on)


def start(session: dict, *, model_questions: bool,
          check: Callable[[str], str]) -> tuple[State, list]:
    """Derive the state from a stored IN_PROGRESS record (new or resumed)."""
    messages = session['messages']
    turns = sum(m['role'] == 'user' for m in messages)
    model_on = session['mode'] == 'LOCAL_OLLAMA' and model_questions
    if turns >= MAX_TURNS:
        return State(DONE, turns, model_on, reason='max_turns'), []
    last = messages[-1] if messages else None
    if last is None or last['role'] == 'user':
        return State(NEED_QUESTION, turns, model_on), []
    if last['role'] == 'guide':
        return State(GUIDE_OPEN, turns, model_on, text=last['text']), []
    # A stored model question from an earlier run: show it again only when model
    # questions are on and it still passes the check; otherwise replace it.
    if model_questions:
        try:
            return State(MODEL_OPEN, turns, model_on, text=check(last['text']), live=False), []
        except FormationError:
            pass
    return (State(NEED_QUESTION, turns, model_on),
            [('print', '(The earlier model question is replaced by a guided question.)')])


def prompt_for(state: State, *, show: Callable[[str], str] = lambda s: s) -> str:
    """The exact prompt for an open state (``show`` makes model text visible-safe)."""
    if state.kind == NEED_QUESTION:
        return f'\nHWI> {guided_question(state.turns)}\nYou> '
    if state.kind == GUIDE_OPEN:
        return f'\nHWI> {state.text}\nYou> '
    if state.kind == MODEL_OPEN:
        if state.live:
            return 'You> '
        return '\nHWI (model suggestion)> ' + show(state.text) + '\nYou> '
    raise FormationError(f'No prompt in state {state.kind}')


def step(state: State, event, *, show: Callable[[str], str] = lambda s: s) -> tuple[State, list]:
    if state.kind in OPEN and isinstance(event, Reply):
        text = event.text
        low = text.lower()
        if low == '/pause':
            return replace(state, kind=DONE, reason='pause'), []
        if low == '/finish':
            return replace(state, kind=DONE, reason='finish'), []
        if not text:
            return state, [('print', 'Please provide a brief objective or type /finish.')]
        effects = []
        if state.kind == NEED_QUESTION:
            # The exact guided question is stored just before its answer.
            effects.append(('store', 'guide', guided_question(state.turns)))
        effects.append(('store', 'user', text))
        return _after_answer(state, state.turns + 1), effects
    if state.kind == ASKING_MODEL:
        if isinstance(event, ModelOK):
            return (State(MODEL_OPEN, state.turns, state.model_on, text=event.question, live=True),
                    [('print', '\nHWI (model suggestion)> ' + show(event.question)),
                     ('store', 'assistant', event.question)])
        if isinstance(event, ModelRejected):
            fallback = guided_question(state.turns)
            return (State(GUIDE_OPEN, state.turns, state.model_on, text=fallback),
                    [('print', f'\n(Model reply withheld: {event.reason}.)'),
                     ('store', 'guide', fallback)])
        if isinstance(event, ModelDown):
            return (State(NEED_QUESTION, state.turns, False),
                    [('print', f'Local Ollama unavailable: {event.reason}. '
                               'Switching to guided manual questions.'),
                     ('manual',)])
    raise FormationError(f'Event {type(event).__name__} is not valid in state {state.kind}')


def stage(session: dict, effects: list) -> list:
    """Records to save, in order (one change each); raises before anything is saved."""
    records, current = [], session
    for effect in effects:
        if effect[0] == 'store':
            current = append_message(current, effect[1], effect[2])
            records.append(current)
        elif effect[0] == 'manual':
            current = use_manual_mode(current)
            records.append(current)
    return records
