"""Formation-only loopback transport for the separately approved Ollama provider.

The approved provider is reused without modifying its source. This wrapper
prevents redirects and ambient proxy settings from carrying Formation text to
other hosts. It deliberately accepts only numeric loopback destinations, so
``localhost`` is normalized before network I/O (no hostname resolution).
"""
from __future__ import annotations

from urllib.parse import urlsplit, urlunsplit

import requests

from .core import validate_endpoint


class _LocalSession(requests.Session):
    """A constrained Session for the two fixed Ollama endpoints."""

    def __init__(self, base_url: str):
        super().__init__()
        self.trust_env = False
        self.proxies.clear()
        self._base = urlsplit(base_url)

    def request(self, method, url, **kwargs):
        target = urlsplit(url)
        if (method.upper() not in ('GET', 'POST') or
                target.scheme != self._base.scheme or
                target.netloc != self._base.netloc or
                target.username is not None or target.password is not None or
                target.path not in ('/api/chat', '/api/tags') or
                target.query or target.fragment or
                (method.upper(), target.path) not in
                (('GET', '/api/tags'), ('POST', '/api/chat'))):
            raise requests.ConnectionError('Formation refuses non-loopback or non-Ollama requests')
        # Do not allow the caller or any provider default to override this.
        kwargs['allow_redirects'] = False
        kwargs.pop('proxies', None)
        # The approved provider currently passes 300 seconds for every chat.
        # Bound question-generation network reads to CMR-05's 120-second intent;
        # preserve the existing 300-second budget for JSON purpose drafts.
        payload = kwargs.get('json')
        is_draft = (type(payload) is dict and payload.get('format') == 'json')
        budget = (300 if is_draft else 120) if target.path == '/api/chat' else 10
        requested = kwargs.get('timeout')
        kwargs['timeout'] = (min(requested, budget)
                             if type(requested) in (int, float) and requested > 0
                             else budget)
        response = super().request(method, url, **kwargs)
        if 300 <= response.status_code < 400:
            response.close()
            raise requests.ConnectionError('Formation refuses Ollama HTTP redirects')
        return response


def local_provider(base_url: str):
    """Use the existing provider's API, with a Formation-owned safe Session."""
    from autogpt_lite.llm.ollama import OllamaProvider

    parsed = urlsplit(validate_endpoint(base_url))
    # A DNS-resolved localhost can be remapped; use literal numeric loopback.
    host = '127.0.0.1' if parsed.hostname == 'localhost' else parsed.hostname
    netloc = f'[{host}]' if ':' in host else host
    if parsed.port is not None:
        netloc += f':{parsed.port}'
    safe_url = urlunsplit(('http', netloc, '', '', ''))
    provider = OllamaProvider(safe_url)
    provider._session.close()
    provider._session = _LocalSession(safe_url)
    return provider
