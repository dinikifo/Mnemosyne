"""Substitutable advisory model-question port owned by Formation.

The port is a trusted Python injection boundary. A message cannot supply a
reader implementation, and the model cannot approve an effect. Draft creation
remains in the existing Formation draft service, using the hardened provider.
"""
from __future__ import annotations

from typing import Callable, Protocol


class ModelQuestionReader(Protocol):
    def ask(self, session: dict, *, guidance: tuple[dict, ...] = ()) -> str:
        """Return one validated, advisory clarifying question."""
        ...


class DirectModelQuestionReader:
    """Default adapter: same existing Formation question call, no router."""

    def __init__(self, question_fn: Callable):
        self._question = question_fn

    def ask(self, session: dict, *, guidance: tuple[dict, ...] = ()) -> str:
        return self._question(session, guidance=guidance)


class ModelDraftReader(Protocol):
    def draft(self, session: dict, *, guidance: tuple[dict, ...] = ()) -> dict:
        """Return a model-draft object; validation and confirmation stay in Formation."""
        ...


class DirectModelDraftReader:
    """Current validated draft service behind a replaceable, non-routed port.

    CMR-04 has no draft-message kind. Adding a model-draft routing message
    requires a reviewed schema change rather than widening question contracts.
    """

    def __init__(self, propose_fn: Callable):
        self._propose = propose_fn

    def draft(self, session: dict, *, guidance: tuple[dict, ...] = ()) -> dict:
        return self._propose(session, guidance=guidance)
