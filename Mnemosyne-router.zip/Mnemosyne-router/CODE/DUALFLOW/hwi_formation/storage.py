"""Private local storage; no workspace or wiki writes, no in-place overwrite of contracts.

Concurrency: every read-check-write sequence (create, save, confirm) runs under
one exclusive store lock (``flock`` on ``<root>/.store.lock``), so two processes
resuming the same session cannot both pass the expected-hash check and silently
lose an update. The lock serializes processes on ONE machine and a local disk;
it is not a cross-device lock (sessions must not be shared by sync tools or
network filesystems).
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat

from .core import FormationError, check_session, check_transition, confirm_session, digest, make_contract, seal_session

_ID = re.compile('^[a-f0-9]{24}$')


def _private_dir(path: Path, create: bool):
    path = path.expanduser()
    if path.is_symlink():
        raise FormationError('Session directory cannot be a symlink')
    if create and not path.exists():
        path.mkdir(mode=0o700, parents=True, exist_ok=False)
    if not path.is_dir() or (os.name == 'posix' and path.stat().st_mode & 0o077):
        raise FormationError('Formation directory must exist and be private (0700)')
    return path.resolve(strict=True)


class FormationStore:
    def __init__(self, root=None, *, create=False):
        self.root = _private_dir(Path(root) if root is not None else Path.home()/'.hwi-formation', create)
        self.sessions = _private_dir(self.root/'sessions', create)
        self.contracts = _private_dir(self.root/'contracts', create)

    @contextlib.contextmanager
    def _locked(self):
        """Exclusive store lock for one read-check-write sequence (not re-entrant)."""
        path = self.root / '.store.lock'
        fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or (os.name == 'posix' and info.st_mode & 0o077):
                raise FormationError('Unsafe formation lock file')
            fcntl.flock(fd, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)

    def _file(self, folder, session_id):
        if type(session_id) is not str or not _ID.fullmatch(session_id):
            raise FormationError('Invalid session id')
        return folder / (session_id + '.json')

    @staticmethod
    def _read(path):
        if path.is_symlink() or not path.is_file():
            raise FormationError('Missing or unsafe session file')
        info = path.stat(follow_symlinks=False)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
                (os.name == 'posix' and info.st_mode & 0o077) or info.st_size > 80000):
            raise FormationError('Unsafe session file or permissions')
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except (UnicodeError, ValueError) as exc:
            raise FormationError('Invalid session JSON') from exc

    @staticmethod
    def _write_once(path, data):
        raw = (json.dumps(data, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode('utf-8')
        if len(raw) > 80000:
            raise FormationError('Formation record is too large')
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, 'O_NOFOLLOW'):
            flags |= os.O_NOFOLLOW
        fd = os.open(path, flags, 0o600)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
        except BaseException:
            try:
                path.unlink()
            except OSError:
                pass
            raise

    def create(self, session):
        """Store a NEW session: it must be exactly what ``new_session`` produces."""
        check_session(session)
        if (session['state'] != 'IN_PROGRESS' or session['messages'] or
                session['draft'] is not None or session['contract_sha256'] is not None):
            raise FormationError('A new session must start IN_PROGRESS with no conversation, draft or contract')
        with self._locked():
            self._write_once(self._file(self.sessions, session['session_id']), session)

    def load(self, session_id):
        return check_session(self._read(self._file(self.sessions, session_id)))

    def save(self, session, *, previous_sha256):
        """Atomic replacement of a private session; enforce expected prior hash.

        The hash check and the replacement form one locked compare-and-swap."""
        check_session(session)
        with self._locked():
            self._save_unlocked(session, previous_sha256=previous_sha256)

    def _save_unlocked(self, session, *, previous_sha256, confirming=False):
        path = self._file(self.sessions, session['session_id'])
        prior = self.load(session['session_id'])
        if prior['record_sha256'] != previous_sha256:
            raise FormationError('Stale formation session; refuse to overwrite')
        check_transition(prior, session, confirming=confirming)
        tmp = self.sessions / ('.'+secrets.token_hex(12)+'.tmp')
        try:
            self._write_once(tmp, session)
            # Reject symlink and type replacement since initial read.
            if path.is_symlink() or not path.is_file():
                raise FormationError('Session was replaced unexpectedly')
            os.replace(tmp, path)
        finally:
            if tmp.exists():
                tmp.unlink()

    def confirm(self, session):
        """Publish contract once, then update session. Never authorize actions."""
        contract = make_contract(session)
        old_pin = session['record_sha256']
        path = self._file(self.contracts, session['session_id'])
        # Contract first, then session, both under one store lock. The SESSION
        # record is the commit point: a contract counts only once the session is
        # CONFIRMED with its digest. If the session update fails, a retry of
        # CONFIRM finds the identical contract and completes the update. A
        # different contract left by such a failure (the draft was edited
        # afterwards) is unreferenced: it is moved to contracts/orphaned/ for
        # inspection, never overwritten in place or accepted.
        with self._locked():
            current = self.load(session['session_id'])
            if current['state'] == 'CONFIRMED':
                raise FormationError('Session is already confirmed; its contract is immutable')
            if current['record_sha256'] != old_pin:
                raise FormationError('Stale formation session; refuse to confirm')
            expected = {**contract, 'contract_sha256':digest(contract)}
            try:
                self._write_once(path, expected)
            except FileExistsError:
                if self._read(path) != expected:
                    self._set_aside_orphan(path)
                    self._write_once(path, expected)
            self._save_unlocked(confirm_session(session, contract), previous_sha256=old_pin, confirming=True)
        return path, contract

    def _set_aside_orphan(self, path):
        """Move an unreferenced contract (caller holds the lock) to contracts/orphaned/."""
        self._read(path)  # same safety checks as any record: regular, private, single link
        folder = _private_dir(self.contracts / 'orphaned', True)
        raw = path.read_bytes()
        target = folder / f'{path.stem}.{hashlib.sha256(raw).hexdigest()[:16]}.json'
        if target.exists() or target.is_symlink():
            if target.is_symlink() or target.read_bytes() != raw:
                raise FormationError('Cannot set aside orphaned contract safely')
            path.unlink()
        else:
            os.rename(path, target)

    def read_contract(self, session_id):
        """Verify that contract still matches the exact confirmed session draft."""
        saved = self.load(session_id)
        if saved['state'] != 'CONFIRMED':
            raise FormationError('Session is not confirmed')
        contract_file = self._read(self._file(self.contracts, session_id))
        if type(contract_file) is not dict:
            raise FormationError('Malformed purpose contract')
        actual = dict(contract_file)
        pin = actual.pop('contract_sha256', None)
        if type(pin) is not str or pin != digest(actual) or pin != saved['contract_sha256']:
            raise FormationError('Purpose contract integrity failed')
        earlier = dict(saved)
        earlier['state'] = 'DRAFT_READY'
        earlier['contract_sha256'] = None
        original_draft_state = check_session(seal_session(earlier))
        if actual != make_contract(original_draft_state):
            raise FormationError('Purpose contract does not match the recorded draft')
        return contract_file

    def all_sessions(self):
        out = []
        # Every session is listed: a silent cap made sessions disappear as the store grew.
        for path in sorted(self.sessions.glob('*.json')):
            try:
                session = self.load(path.stem)
                out.append({'session_id':session['session_id'], 'state':session['state'],
                            'model':session['model'], 'turns':sum(m['role']=='user' for m in session['messages'])})
            except FormationError:
                out.append({'session_id':path.stem, 'state':'INVALID_RECORD'})
        return out
