# HWI Agent Formation — Good-practice-guided ambiguity review

**Experimental, advisory-only; Python / corrected pre-QSECD codebase.**

## What changed

Agent Formation can ask clarifying questions informed by *operator-selected*,
revision-pinned, typed good-practice records retrieved from a pre-existing
PERSONAL.WIKI notebook through the approved read-only knowledge broker. It also
checks the Purpose Draft for **explicitly missing** task, domain, sources,
outputs, success criteria and boundaries. Broad task names may be flagged for
review. It does **not** establish semantic correctness or task fitness.

Universal checks work even when the wiki and Ollama are unavailable.

## Run

From the release directory, with an existing initialized wiki catalog:

```sh
python3 VERIFY_ARCHIVE.py
bash RUN_AGENT_FORMATION.command start --model 'llama3.1:8b' \
  --wiki-workspace '/path/to/wiki-workspace' --notebook primary \
  --practice-query 'numerical comparison'
```

The explicit `--practice-query` triggers read-only discovery of at most three
current typed practice records, chosen by an ordinary bounded text search.
Unrelated or malformed records are skipped. You are asked separately whether
to send the **advisory questions only** to your *local* Ollama model; declining
still lets you see the ambiguity review. No raw wiki articles, paths,
revision references, or whole practice texts enter the model prompt.

If no matching practices exist, the universal checks still run:

```sh
bash RUN_AGENT_FORMATION.command start --manual
```

After `/finish`, the Purpose Draft and ambiguity questions appear together.
Choose `EDIT` to clarify a field; `CONFIRM` is still allowed if some ambiguities
remain, because this is formation **not** commissioning or permission approval.
The confirmed purpose remains `FORMED_NOT_COMMISSIONED` and `NOT_TESTED`.

To inspect a saved draft or confirmed contract without changing it:

```sh
bash RUN_AGENT_FORMATION.command review-ambiguities SESSION_ID
```

To re-run a wiki-guided review against *current* wiki revisions:

```sh
bash RUN_AGENT_FORMATION.command review-ambiguities SESSION_ID \
  --wiki-workspace '/path/to/wiki-workspace' --notebook primary \
  --practice-query 'numerical comparison'
```

On resume, the operator must re-provide the wiki selection/query if guidance
should be used. Retrieved wiki text is intentionally **not persisted** in
formation sessions or automatically replayed after a pause. Historical refs
may become stale; a fresh search always uses current revisions.

## Suggested good-practice record format

Create a regular, **unprotected** wiki page through the normal wiki UI with a
custom field `hwi_formation_kind` whose value is `good_practice`. Set the page's
*text* to the contents of `docs/formation/example_good_practice.json`. Choose a
searchable title and add an appropriate tag. This is an explicit opt-in; HWI
never seeds or edits your notebook during Formation.

The JSON format is `hwi.formation.good_practice.v0` with only:

- `schema`: the exact format identifier
- `domain`: short description of the field of use
- `guidance`: an advisory description, not executable instructions
- `checks`: 1–4 objects with `field` (a Purpose Draft field) and `question`

Only questions about `initial_task`, `domain`, `input_sources`,
`expected_outputs`, `success_criteria` and `boundaries` are allowed. A typed
record is *not* automatically approved or authentic merely because it is in
the wiki. Protected/PVS-managed records remain inaccessible via this path.

This is a narrow retrieval adapter, **not** the proposed full wiki HWI-07/HWI-08
receipt-query compatibility adapter. It does not remove unrelated private
wiki access elsewhere in the governance code.

## Limits and testing

- Ambiguity detection only catches obvious missing declarations and a few
  conservative hints. A complete-looking field may still be semantically
  ambiguous or factually incorrect.
- A model might still ask an irrelevant question or be influenced by malicious
  content in a question. The questions are untrusted data and have no tool or
  policy authority. Use only good-practice records you are comfortable sharing.
- The wiki search is lexical and operator-specified, not semantic embedding
  search. It requires an existing verified knowledge catalog.
- The current task-fitness gate requires **independently prepared evidence**;
  Formation cannot self-commission or grant wiki-edit or execution permission.
- Offline tests cover retrieval, stale revisions, consent, ambiguous drafts,
  malformed records and privacy boundaries. A native macOS Ollama A/B study
  is still needed to determine whether guided questions improve real usability.

Run focused tests:

```sh
bash RUN_ALL_OFFLINE.command
```

The new suite is `hwi_formation.test_good_practices`.
