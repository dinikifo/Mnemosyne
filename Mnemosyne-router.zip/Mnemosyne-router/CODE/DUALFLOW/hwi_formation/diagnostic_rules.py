"""Small, readable diagnostic rule chains for *advisory* checks.

Rules inspect a fixed set of facts; matching callbacks produce findings. They
must not be used as authorization, persistence, or external-effect handlers.
"""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Callable, Mapping


@dataclass(frozen=True)
class DiagnosticRule:
    rule_id: str
    conditions: Mapping[str, object]
    description: str
    callback: Callable[[Mapping[str, object]], object] | None = None
    next_rule: DiagnosticRule | None = None

    def matches(self, state: Mapping[str, object]) -> bool:
        """Missing facts never satisfy prerequisites, even when None is expected."""
        return all(key in state and state[key] == value
                   for key, value in self.conditions.items())

    def execute(self, state: Mapping[str, object]) -> object | None:
        return self.callback(state) if self.callback is not None else None


class DiagnosticEngine:
    """Walk each check in order, including after a non-match.

    This is a chain of independent diagnostics, not a branching workflow.
    Each callback returns one finding (or None), never performs a side effect.
    """

    def __init__(self, start_rule: DiagnosticRule, *, max_steps: int = 32):
        if type(max_steps) is not int or max_steps < 1:
            raise ValueError('max_steps must be a positive integer')
        self.start_rule = start_rule
        self.max_steps = max_steps

    def diagnose(self, system_state: Mapping[str, object]) -> list[object]:
        # Advisory facts are flat values. Prevent callbacks from changing the
        # top-level state during a diagnostic pass.
        facts = MappingProxyType(dict(system_state))
        results = []
        visited = set()
        rule = self.start_rule
        steps = 0
        while rule is not None:
            if id(rule) in visited:
                raise ValueError(f'Diagnostic rule cycle at {rule.rule_id}')
            if steps >= self.max_steps:
                raise ValueError('Diagnostic rule chain exceeds max_steps')
            visited.add(id(rule))
            steps += 1
            if rule.matches(facts):
                finding = rule.execute(facts)
                if finding is not None:
                    results.append(finding)
            rule = rule.next_rule
        return results
