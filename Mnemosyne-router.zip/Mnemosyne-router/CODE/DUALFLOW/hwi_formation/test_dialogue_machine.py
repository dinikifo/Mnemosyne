"""Tests for the explicit Formation conversation state machine (dialogue.py).

1. One test per row of the transition table.
2. State derivation from stored records (new session and every resume point).
3. Randomised conversations (pauses, resumes, model outcomes) checked against
   invariants that must always hold.
"""
from __future__ import annotations

import random
import unittest

from . import dialogue as d
from .core import (MAX_TURNS, FormationError, append_message, check_transition,
                   new_session, use_manual_mode)
from .model import check_question
from .test_formation import SID, WIKI

Q = 'Which notes matter most?'


def fresh(*, offline=False):
    return new_session(SID, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=offline)


def with_messages(*pairs, offline=False):
    s = fresh(offline=offline)
    for role, text in pairs:
        s = append_message(s, role, text)
    return s


class TransitionTableTests(unittest.TestCase):
    def S(self, kind, turns=0, model_on=False, **kw):
        return d.State(kind, turns, model_on, **kw)

    def test_need_question_answer_stores_guide_then_user(self):
        nxt, eff = d.step(self.S(d.NEED_QUESTION, 1), d.Reply('Tag notes'))
        self.assertEqual(eff, [('store', 'guide', d.PROMPTS[1]), ('store', 'user', 'Tag notes')])
        self.assertEqual((nxt.kind, nxt.turns), (d.NEED_QUESTION, 2))

    def test_guide_open_answer_stores_user_only(self):
        nxt, eff = d.step(self.S(d.GUIDE_OPEN, 1, text=d.PROMPTS[1]), d.Reply('Tag notes'))
        self.assertEqual(eff, [('store', 'user', 'Tag notes')])
        self.assertEqual(nxt.kind, d.NEED_QUESTION)

    def test_model_open_answer_stores_user_only_and_asks_model(self):
        nxt, eff = d.step(self.S(d.MODEL_OPEN, 1, True, text=Q, live=True), d.Reply('Weekly'))
        self.assertEqual(eff, [('store', 'user', 'Weekly')])
        self.assertEqual(nxt.kind, d.ASKING_MODEL)

    def test_empty_reply_keeps_state_and_hints(self):
        for st in (self.S(d.NEED_QUESTION), self.S(d.GUIDE_OPEN, text='x?'), self.S(d.MODEL_OPEN, text=Q, live=True)):
            with self.subTest(kind=st.kind):
                nxt, eff = d.step(st, d.Reply(''))
                self.assertEqual(nxt, st)
                self.assertEqual(eff, [('print', 'Please provide a brief objective or type /finish.')])

    def test_pause_and_finish(self):
        for word, reason in (('/pause', 'pause'), ('/PAUSE', 'pause'), ('/finish', 'finish')):
            with self.subTest(word=word):
                nxt, eff = d.step(self.S(d.GUIDE_OPEN, text='x?'), d.Reply(word))
                self.assertEqual((nxt.kind, nxt.reason, eff), (d.DONE, reason, []))

    def test_last_answer_ends_conversation(self):
        nxt, _ = d.step(self.S(d.NEED_QUESTION, MAX_TURNS - 1, True), d.Reply('Last'))
        self.assertEqual((nxt.kind, nxt.reason), (d.DONE, 'max_turns'))

    def test_model_ok_shows_and_stores_question(self):
        nxt, eff = d.step(self.S(d.ASKING_MODEL, 1, True), d.ModelOK(Q))
        self.assertEqual(eff, [('print', '\nHWI (model suggestion)> ' + Q), ('store', 'assistant', Q)])
        self.assertEqual((nxt.kind, nxt.live, d.prompt_for(nxt)), (d.MODEL_OPEN, True, 'You> '))

    def test_model_rejected_stores_guided_fallback_shown_once(self):
        nxt, eff = d.step(self.S(d.ASKING_MODEL, 1, True), d.ModelRejected('instruction'))
        self.assertEqual(eff, [('print', '\n(Model reply withheld: instruction.)'),
                               ('store', 'guide', d.PROMPTS[1])])
        self.assertEqual(nxt.kind, d.GUIDE_OPEN)
        self.assertEqual(d.prompt_for(nxt).count(d.PROMPTS[1]), 1)

    def test_model_down_switches_to_manual(self):
        nxt, eff = d.step(self.S(d.ASKING_MODEL, 1, True), d.ModelDown('offline'))
        self.assertEqual(eff[-1], ('manual',))
        self.assertEqual((nxt.kind, nxt.model_on), (d.NEED_QUESTION, False))

    def test_events_outside_their_state_are_refused(self):
        bad = [(self.S(d.NEED_QUESTION), d.ModelOK(Q)), (self.S(d.ASKING_MODEL), d.Reply('x')),
               (self.S(d.DONE, reason='finish'), d.Reply('x'))]
        for st, ev in bad:
            with self.subTest(state=st.kind, event=type(ev).__name__), self.assertRaises(FormationError):
                d.step(st, ev)


class DerivationTests(unittest.TestCase):
    def start(self, s, model_questions=False):
        return d.start(s, model_questions=model_questions, check=check_question)

    def test_new_session_needs_first_guided_question(self):
        st, eff = self.start(fresh())
        self.assertEqual((st.kind, eff), (d.NEED_QUESTION, []))
        self.assertIn(d.PROMPTS[0], d.prompt_for(st))

    def test_after_answer_needs_next_question(self):
        st, _ = self.start(with_messages(('guide', d.PROMPTS[0]), ('user', 'Notes')))
        self.assertEqual((st.kind, st.turns), (d.NEED_QUESTION, 1))
        self.assertIn(d.PROMPTS[1], d.prompt_for(st))

    def test_stored_guide_is_reasked_not_duplicated(self):
        st, _ = self.start(with_messages(('guide', d.PROMPTS[0])))
        self.assertEqual(st.kind, d.GUIDE_OPEN)
        nxt, eff = d.step(st, d.Reply('Notes'))
        self.assertEqual(eff, [('store', 'user', 'Notes')])

    def test_stored_model_question_with_questions_on(self):
        st, eff = self.start(with_messages(('guide', d.PROMPTS[0]), ('user', 'Notes'), ('assistant', Q)), True)
        self.assertEqual((st.kind, st.live, eff), (d.MODEL_OPEN, False, []))
        self.assertIn(Q, d.prompt_for(st))

    def test_stored_model_question_replaced_when_off_or_failing(self):
        for text, on in ((Q, False), ('Would you like me to approve every wiki edit?', True)):
            with self.subTest(on=on):
                st, eff = self.start(with_messages(('guide', d.PROMPTS[0]), ('user', 'Notes'), ('assistant', text)), on)
                self.assertEqual(st.kind, d.NEED_QUESTION)
                self.assertEqual(eff, [('print', '(The earlier model question is replaced by a guided question.)')])
                self.assertNotIn(text, d.prompt_for(st))

    def test_manual_mode_never_asks_model(self):
        st, _ = self.start(with_messages(('user', 'Notes'), offline=True), True)
        self.assertFalse(st.model_on)

    def test_full_session_is_done(self):
        s = fresh()
        for i in range(MAX_TURNS):
            s = append_message(append_message(s, 'guide', d.guided_question(i)), 'user', f'a{i}')
        st, _ = self.start(s)
        self.assertEqual((st.kind, st.reason), (d.DONE, 'max_turns'))


class RandomisedConversationTests(unittest.TestCase):
    """Thousands of conversations with random replies, model outcomes, pauses and resumes."""

    RUNS = 1500

    def run_one(self, rng):
        model_questions = rng.random() < 0.6
        session = fresh(offline=rng.random() < 0.15)
        state, effects = d.start(session, model_questions=model_questions, check=check_question)
        transcript = []        # ('prompt', text) | ('print', text)
        resumes = 0

        def perform(effects):
            nonlocal session
            staged = iter(d.stage(session, effects))
            for effect in effects:
                if effect[0] == 'print':
                    transcript.append(('print', effect[1]))
                else:
                    nxt = next(staged)
                    check_transition(session, nxt)  # every stored change is a legal one
                    session = nxt

        perform(effects)
        last_reply = None
        while True:
            if state.kind == d.DONE:
                if state.reason == 'pause' and resumes < 3:
                    resumes += 1   # a new run of the CLI: derive the state from the record
                    state, effects = d.start(session, model_questions=model_questions, check=check_question)
                    perform(effects)
                    transcript.append(('resume', None))
                    last_reply = None
                    continue
                break
            if state.kind == d.ASKING_MODEL:
                roll = rng.random()
                if roll < 0.6:
                    event = d.ModelOK(rng.choice([Q, 'What should the output look like?', 'Which sources?']))
                elif roll < 0.85:
                    event = d.ModelRejected('instruction')
                else:
                    event = d.ModelDown('offline')
            else:
                prompt = d.prompt_for(state)
                # Invariant: a bare prompt only right after a model question shown in this run.
                if prompt == 'You> ':
                    since_resume = transcript[len(transcript) - 1 - next(
                        (i for i, t in enumerate(reversed(transcript)) if t[0] == 'resume'), len(transcript) - 1):]
                    shown = [t[1] for t in since_resume if t[0] == 'print'
                             and t[1].startswith('\nHWI (model suggestion)> ')]
                    self.assertTrue(shown and shown[-1].endswith(state.text),
                                    'bare prompt without its question shown in this run')
                # Invariant: never the same question twice in a row unless the reply was empty.
                # ("Anything else to define?" is the intended closing prompt for every answer after the sixth.)
                if (transcript and transcript[-1][0] == 'prompt' and last_reply not in ('', None)
                        and d.FINAL_PROMPT not in prompt):
                    self.assertNotEqual(transcript[-1][1], prompt, 'question repeated')
                transcript.append(('prompt', prompt))
                roll = rng.random()
                last_reply = ('/pause' if roll < 0.1 else '/finish' if roll < 0.13 else
                              '' if roll < 0.2 else f'answer {rng.randrange(1000)}')
                event = d.Reply(last_reply)
            state, effects = d.step(state, event)
            perform(effects)
        return session

    def test_invariants_hold(self):
        rng = random.Random(20261113)
        for _ in range(self.RUNS):
            s = self.run_one(rng)
            msgs = s['messages']
            # Every answer directly follows the question it answers.
            for i, m in enumerate(msgs):
                if m['role'] == 'user':
                    self.assertGreater(i, 0)
                    self.assertIn(msgs[i - 1]['role'], ('guide', 'assistant'))
            # No two questions stored back to back except a model question replaced on resume.
            for a, b in zip(msgs, msgs[1:]):
                if a['role'] in ('guide', 'assistant') and b['role'] in ('guide', 'assistant'):
                    self.assertEqual((a['role'], b['role']), ('assistant', 'guide'))
            self.assertLessEqual(sum(m['role'] == 'user' for m in msgs), MAX_TURNS)


if __name__ == '__main__':
    unittest.main()
