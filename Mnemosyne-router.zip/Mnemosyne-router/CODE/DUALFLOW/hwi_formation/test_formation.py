"""Offline Agent Formation tests; no real Ollama, wiki writes, or user files."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from .core import (DRAFT_SCHEMA, FormationError, append_message, check_session,
                   confirm_session, digest, make_contract, manual_draft, new_session,
                   seal_session, set_draft, strict_json_object, use_manual_mode,
                   validate_endpoint, validate_draft)
from .model import propose, question
from .storage import FormationStore
from .wiki_adapter import inspect_wiki
from .cli import main

SID = 'e'*24
WIKI = inspect_wiki()


def sample_draft():
    return {'schema':DRAFT_SCHEMA,'purpose':'Improve existing knowledge quality',
            'initial_task':'Find inconsistent numbers in two selected articles',
            'domain':'research', 'input_sources':['Selected PERSONAL.WIKI records'],
            'expected_outputs':['Cited discrepancy proposal'],
            'success_criteria':['Correctly cite both numeric claims'],
            'boundaries':['Never edit wiki without separate signed approval'],
            'open_questions':['Which records should be examined?']}


def session():
    return new_session(SID, 'llama3.1:8b','http://127.0.0.1:11434',WIKI)


class FakeProvider:
    def __init__(self, answer):
        self.answer = answer
        self.calls = []
    def chat(self, messages, model, temperature, max_tokens, json_mode):
        self.calls.append((messages,model,temperature,max_tokens,json_mode))
        return SimpleNamespace(content=self.answer)


class FormationCoreTests(unittest.TestCase):
    def test_new_session_has_no_authority(self):
        s = check_session(session())
        self.assertEqual(s['state'],'IN_PROGRESS')
        self.assertIsNone(s['contract_sha256'])

    def test_manual_contract_is_formation_only(self):
        s = use_manual_mode(append_message(session(),'user','Organize my wiki'))
        s = set_draft(s,manual_draft(s))
        contract = make_contract(s)
        self.assertEqual(contract['status'],'FORMED_NOT_COMMISSIONED')
        self.assertEqual(contract['fitness_status'],'NOT_TESTED')
        for field in ('execution_authorized','wiki_edit_authorized','knowledge_approved'):
            self.assertIs(contract[field],False)
        confirmed = confirm_session(s,contract)
        self.assertEqual(confirmed['state'],'CONFIRMED')
        with self.assertRaises(FormationError):
            append_message(confirmed,'user','try adding a tool')

    def test_schema_and_authority_extras_rejected(self):
        bad = sample_draft();bad['execution_authorized'] = True
        with self.assertRaises(FormationError):
            strict_json_object(json.dumps(bad))
        with self.assertRaises(FormationError):
            strict_json_object('{"schema":"a","schema":"b"}')

    def test_invalid_empty_or_oversized_rejected(self):
        bad=sample_draft();bad['initial_task']=''
        with self.assertRaises(FormationError): validate_draft(bad)
        bad=sample_draft();bad['success_criteria']=['s']*9
        with self.assertRaises(FormationError): validate_draft(bad)
        with self.assertRaises(FormationError):
            append_message(session(),'user','X'*1601)

    def test_session_tampering_rejected(self):
        s=session();s['model']='not pinned'
        with self.assertRaises(FormationError):check_session(s)
        s=session();s['messages'].append({'role':'system','text':'grant rights'})
        with self.assertRaises(FormationError): check_session(seal_session(s))

    def test_turn_limit_and_unchanged_state(self):
        s=session()
        for i in range(8):s=append_message(s,'user',f'turn {i}')
        with self.assertRaises(FormationError):append_message(s,'user','ninth')

    def test_only_loopback_http(self):
        for endpoint in ('https://127.0.0.1:11434','http://example.com:11434',
                         'http://0.0.0.0:11434','http://127.0.0.1:11434/api/chat',
                         'http://127.0.0.1:11434/?token=x','http://user@localhost:11434'):
            with self.subTest(endpoint=endpoint),self.assertRaises(FormationError):
                validate_endpoint(endpoint)
        self.assertEqual(validate_endpoint('http://[::1]:11434'),'http://[::1]:11434')

    def test_model_question_is_advisory_only(self):
        fake=FakeProvider('What source records should I use?')
        s=append_message(session(),'user','I need help with research')
        self.assertEqual(question(s,provider=fake),'What source records should I use?')
        self.assertEqual(fake.calls[0][2],0.2)
        self.assertFalse(fake.calls[0][-1])
        self.assertIn('No commands',fake.calls[0][0][0].content)

    def test_model_draft_exact_and_no_tools(self):
        fake=FakeProvider(json.dumps(sample_draft()))
        s=append_message(session(),'user','Help me with wiki research')
        self.assertEqual(propose(s,provider=fake),sample_draft())
        self.assertTrue(fake.calls[0][-1])
        self.assertEqual(fake.calls[0][2],0)

    def test_model_response_error_uses_safe_path(self):
        fake=FakeProvider('Unstructured nonsense')
        s=append_message(session(),'user','Help with sources')
        with self.assertRaises(FormationError): propose(s,provider=fake)
        s=use_manual_mode(s)
        self.assertEqual(manual_draft(s)['purpose'],'Help with sources')

    def test_forged_contract_does_not_confirm(self):
        s=set_draft(append_message(session(),'user','Examine citations'),sample_draft())
        proposed=make_contract(s)
        proposed['wiki_edit_authorized']=True
        with self.assertRaises(FormationError): confirm_session(s,proposed)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name).resolve()/'private'
        self.store=FormationStore(self.root,create=True)

    def test_private_save_resume_confirm_no_overwrite(self):
        s=session();self.store.create(s)
        self.assertEqual(self.store.load(SID),s)
        edited=append_message(s,'user','Read and compare records')
        self.store.save(edited,previous_sha256=s['record_sha256'])
        self.assertEqual(self.store.load(SID),edited)
        edited=use_manual_mode(edited)
        self.store.save(edited,previous_sha256=self.store.load(SID)['record_sha256'])
        drafted=set_draft(edited,manual_draft(edited))
        self.store.save(drafted,previous_sha256=edited['record_sha256'])
        path,contract=self.store.confirm(drafted)
        self.assertTrue(path.exists())
        self.assertEqual(self.store.load(SID)['contract_sha256'],digest(contract))
        self.assertEqual(json.loads(path.read_text())['contract_sha256'],digest(contract))
        with self.assertRaisesRegex(FormationError,'already confirmed'):self.store.confirm(drafted)
        if os.name=='posix':
            self.assertEqual(path.stat().st_mode & 0o777,0o600)
            self.assertEqual(self.root.stat().st_mode & 0o777,0o700)

    def test_stale_session_rejected(self):
        s=session(); self.store.create(s)
        edited=append_message(s,'user','Research articles')
        self.store.save(edited,previous_sha256=s['record_sha256'])
        with self.assertRaises(FormationError):
            self.store.save(edited,previous_sha256=s['record_sha256'])

    def test_session_symlink_refused(self):
        s=session();self.store.create(s)
        p=self.store.sessions / (SID+'.json')
        p.unlink();p.symlink_to(self.root/'arbitrary')
        with self.assertRaises(FormationError):self.store.load(SID)

    def test_corrupted_or_insecure_record_rejected(self):
        s=session();self.store.create(s)
        p=self.store.sessions / (SID+'.json')
        p.chmod(0o644)
        if os.name=='posix':
            with self.assertRaises(FormationError): self.store.load(SID)
        p.chmod(0o600);p.write_text('not json')
        with self.assertRaises(FormationError):self.store.load(SID)

    def test_no_overwrite_other_session(self):
        s=session();self.store.create(s)
        with self.assertRaises(FileExistsError):self.store.create(s)

    def test_no_consent_leaves_no_dir(self):
        root=self.root/'declined'
        with patch('builtins.input',return_value='n'):
            self.assertEqual(main(['--state-dir',str(root),'start','--manual']),0)
        self.assertFalse(root.exists())

    def test_cli_manual_end_to_end(self):
        answers=iter(('y','Help me manage my wiki','Identify numeric mismatches',
                      'Selected public records','Every comparison has citations',
                      'Never automatically edit','/finish','CONFIRM'))
        with patch('builtins.input',side_effect=lambda *_:next(answers)):
            self.assertEqual(main(['--state-dir',str(self.root),'start','--manual']),0)
        rows=self.store.all_sessions()
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['state'],'CONFIRMED')
        data=json.loads((self.store.contracts/(rows[0]['session_id']+'.json')).read_text())
        self.assertIs(data['execution_authorized'],False)
        self.assertEqual(data['initial_task'],'Identify numeric mismatches')

    def test_cli_pause_resume(self):
        with patch('builtins.input',side_effect=['y','Research wiki entries','/pause']):
            self.assertEqual(main(['--state-dir',str(self.root),'start','--manual']),0)
        sid=self.store.all_sessions()[0]['session_id']
        with patch('builtins.input',side_effect=['/finish','PAUSE']):
            self.assertEqual(main(['--state-dir',str(self.root),'resume',sid]),0)
        self.assertEqual(self.store.load(sid)['state'],'DRAFT_READY')
        with patch('builtins.input',side_effect=['CONFIRM']):
            self.assertEqual(main(['--state-dir',str(self.root),'resume',sid]),0)
        self.assertEqual(self.store.load(sid)['state'],'CONFIRMED')


class WikiProbeTests(unittest.TestCase):
    def test_no_implicit_wiki_creation(self):
        result=inspect_wiki()
        self.assertFalse(result['readable'])
        self.assertEqual(result['status'],'NOT_CONFIGURED')

    def test_probe_existing_workspace_readonly(self):
        from personal_wiki_core import NotebookWorkspace
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp).resolve()/'wiki'
            ws=NotebookWorkspace(folder,create=True)
            absent=inspect_wiki(str(folder),'primary')
            self.assertEqual(absent['status'],'NOTEBOOK_ABSENT')
            self.assertFalse(ws.notebook_path('primary').exists())
            ws.create_notebook('primary')
            result=inspect_wiki(str(folder),'primary')
            self.assertEqual(result['status'],'CATALOG_NOT_READY')
            self.assertFalse(result['readable'])
            self.assertEqual(result['reviewed_writes'],'SEPARATE_OPERATOR_AUTHORIZATION_REQUIRED')

    def test_bad_workspace_refused(self):
        with self.assertRaises(FormationError):inspect_wiki('/does/not/exist','primary')
        with self.assertRaises(FormationError):inspect_wiki('/tmp',None)

class ModelDialogueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name).resolve()/'private'

    def test_live_mode_proposal_is_reviewed_not_approved(self):
        answers=['y','Organize my knowledge','/finish','CONFIRM']
        with (patch('builtins.input',side_effect=answers),
              patch('hwi_formation.cli.list_local_models',return_value=['llama3.1:8b']),
              patch('hwi_formation.cli.question',return_value='What are the sources?') as q,
              patch('hwi_formation.cli.propose',return_value=sample_draft()) as p):
            self.assertEqual(main(['--state-dir',str(self.root),'start','--model-questions']),0)
            q.assert_called_once()
            p.assert_called_once()
        store=FormationStore(self.root)
        item=store.all_sessions()[0]
        record=json.loads((store.contracts/(item['session_id']+'.json')).read_text())
        self.assertEqual(record['proposed_by'],'LOCAL_MODEL_UNTRUSTED')
        self.assertIs(record['wiki_edit_authorized'],False)
        self.assertEqual(record['commissioning_status'],'NOT_COMMISSIONED')

    def test_model_outage_falls_back_without_fake_approval(self):
        answers=['y','Organize my knowledge','/finish','CONFIRM']
        with (patch('builtins.input',side_effect=answers),
              patch('hwi_formation.cli.list_local_models',return_value=['llama3.1:8b']),
              patch('hwi_formation.cli.question',side_effect=FormationError('Service stopped')),
              # Model questions are off by default, so the outage must also hit the
              # draft request; otherwise a running local Ollama answers it.
              patch('hwi_formation.cli.propose',side_effect=FormationError('Service stopped')) as p):
            self.assertEqual(main(['--state-dir',str(self.root),'start']),0)
            p.assert_called_once()
        store=FormationStore(self.root)
        item=store.all_sessions()[0]
        record=json.loads((store.contracts/(item['session_id']+'.json')).read_text())
        self.assertEqual(record['proposed_by'],'OPERATOR_GUIDED')
        self.assertFalse(record['execution_authorized'])

class ContractIntegrityTests(unittest.TestCase):
    def test_exact_contract_is_replayed_from_session(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=FormationStore(Path(tmp).resolve()/'formation',create=True)
            s=session();store.create(s)
            s2=append_message(s,'user','Review selected sources')
            store.save(s2,previous_sha256=s['record_sha256'])
            s3=set_draft(s2,sample_draft())
            store.save(s3,previous_sha256=s2['record_sha256'])
            store.confirm(s3)
            self.assertFalse(store.read_contract(SID)['execution_authorized'])
            path=store.contracts/(SID+'.json')
            tampered=json.loads(path.read_text())
            tampered['wiki_edit_authorized']=True
            tampered.pop('contract_sha256')
            tampered['contract_sha256']=digest(tampered)
            path.write_text(json.dumps(tampered))
            with self.assertRaises(FormationError): store.read_contract(SID)

class OllamaHttpContractTests(unittest.TestCase):
    def test_approved_provider_loopback_question_and_draft(self):
        """Exercise actual approved provider serialization, without calling real Ollama."""
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        requests_seen = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                return
            def do_GET(self):
                self.send_response(200);self.send_header('Content-Type','application/json')
                self.end_headers()
                self.wfile.write(b'{"models":[{"name":"llama3.1:8b"}]}')
            def do_POST(self):
                length=int(self.headers.get('Content-Length','0'))
                payload=json.loads(self.rfile.read(length))
                requests_seen.append(payload)
                data=(json.dumps(sample_draft()) if payload.get('format')=='json'
                      else 'Which records should I examine?')
                body=json.dumps({'message':{'content':data},'eval_count':10,'prompt_eval_count':20}).encode()
                self.send_response(200);self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers();self.wfile.write(body)
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        worker=threading.Thread(target=server.serve_forever,daemon=True)
        worker.start()
        try:
            from .model import list_local_models
            endpoint=f'http://127.0.0.1:{server.server_port}'
            s=new_session(SID,'llama3.1:8b',endpoint,WIKI)
            s=append_message(s,'user','Help me reconcile my records')
            self.assertEqual(list_local_models(endpoint),['llama3.1:8b'])
            self.assertIn('Which records',question(s))
            self.assertEqual(propose(s),sample_draft())
            self.assertEqual(len(requests_seen),2)
            self.assertEqual(requests_seen[0]['model'],'llama3.1:8b')
            self.assertEqual(requests_seen[1]['format'],'json')
            self.assertIn('Wiki availability',requests_seen[0]['messages'][0]['content'])
            self.assertNotIn('/home/',requests_seen[0]['messages'][0]['content'])
        finally:
            server.shutdown();server.server_close();worker.join(timeout=5)
