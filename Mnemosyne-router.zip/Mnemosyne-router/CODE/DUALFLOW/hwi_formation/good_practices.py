"""Read-only, advisory good-practice retrieval and purpose-draft ambiguity review.

No retrieved practice may grant authority, determine task fitness, or become an
execution rule. A wiki practice must be explicitly retrieved by an operator
query from the current read-only broker; nonconforming records are skipped.
"""
from __future__ import annotations

import json
import re

from .core import DRAFT_SCHEMA, FormationError, validate_draft
from .diagnostic_rules import DiagnosticEngine, DiagnosticRule

PRACTICE_SCHEMA = 'hwi.formation.good_practice.v0'
REVIEW_SCHEMA = 'hwi.formation.ambiguity_review.v0'
FIELDS = ('initial_task', 'domain', 'input_sources', 'expected_outputs',
          'success_criteria', 'boundaries')
# These are *questions for the human*, not authorizations or fitness tests.
UNIVERSAL = (
    ('initial_task', 'Which ONE observable task should the agent attempt first?'),
    ('domain', 'What domain and constraints define this task?'),
    ('input_sources', 'Which permitted sources or records are within scope?'),
    ('expected_outputs', 'What concrete result should the agent produce?'),
    ('success_criteria', 'How will an independent reviewer assess success?'),
    ('boundaries', 'What must the agent avoid, and when should it stop?'),
)
_PLACEHOLDER = re.compile(r'\b(not yet|not specified|to be defined|unknown|tbd|unspecified|n/?a|none provided)\b', re.I)
_BROAD_TASK = re.compile(r'^(?:help(?: me)?(?: with)?|organize|improve|manage|research|assist|do)\b', re.I)


def _short(value, key, max_length=320):
    if (type(value) is not str or not 1 <= len(value.strip()) <= max_length or
            any(ord(c) < 32 and c != '\n' for c in value)):
        raise FormationError(f'{key}: short printable text required')
    return value.strip()


def _pairs(items):
    output = {}
    for k, v in items:
        if k in output:
            raise FormationError('Duplicate JSON fields in wiki practice')
        output[k] = v
    return output


def parse_wiki_practice(record):
    """Extract a small typed *advisory* record from a broker-retrieved revision."""
    if (type(record) is not dict or record.get('text_truncated') is not False or
            record.get('fields_truncated') is not False or
            record.get('labels', {}).get('content_class') != 'untrusted_wiki_data' or
            record.get('labels', {}).get('pvs_approved') is not False or
            record.get('fields', {}).get('hwi_formation_kind') != 'good_practice'):
        raise FormationError('Not a complete, unrestricted, typed practice record')
    raw = record.get('text')
    if type(raw) is not str or len(raw) > 2200:
        raise FormationError('Practice JSON exceeds limit')
    try:
        obj = json.loads(raw, object_pairs_hook=_pairs)
    except (ValueError, TypeError, RecursionError) as exc:
        raise FormationError('Malformed wiki practice JSON') from exc
    if (type(obj) is not dict or set(obj) != {'schema', 'domain', 'guidance', 'checks'} or
            obj['schema'] != PRACTICE_SCHEMA):
        raise FormationError('Invalid practice schema')
    domain = _short(obj['domain'], 'domain', 100)
    guidance = _short(obj['guidance'], 'guidance', 450)
    checks = obj['checks']
    if type(checks) is not list or not 1 <= len(checks) <= 4:
        raise FormationError('Expected 1-4 advisory questions')
    result = []
    seen = set()
    for row in checks:
        if type(row) is not dict or set(row) != {'field', 'question'} or row['field'] not in FIELDS:
            raise FormationError('Practice may only ask about declared purpose fields')
        question = _short(row['question'], 'question', 240)
        if row['field'] in seen:
            raise FormationError('Duplicate practice check field')
        seen.add(row['field'])
        result.append({'field': row['field'], 'question': question})
    ref = record.get('ref')
    sha = record.get('revision_sha256')
    if (type(ref) is not str or not re.fullmatch(r'hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*', ref) or
            type(sha) is not str or not re.fullmatch(r'[0-9a-f]{64}', sha)):
        raise FormationError('Missing pinned broker reference')
    return {'source': 'WIKI_UNTRUSTED', 'title': _short(record.get('title'), 'title', 180),
            'ref': ref, 'revision_sha256': sha, 'domain': domain,
            'guidance': guidance, 'checks': result,
            'authority': 'ADVISORY_ONLY', 'source_authenticated': False}


def retrieve_practices(workspace_path, notebook, query, *, limit=3):
    """Search only the operator-selected existing wiki; never initialize or write.

    Only typed current revisions with intact broker pins are returned. Search
    matches that aren't practices are quietly skipped, not promoted to guidance.
    """
    _short(query, 'practice query', 100)
    if type(limit) is not int or not 1 <= limit <= 3:
        raise FormationError('Practice retrieval limit is 1-3')
    from .wiki_adapter import open_readonly_repository
    repo = open_readonly_repository(workspace_path, notebook)
    result = []
    for hit in repo.search(query, mode='Text', limit=10):
        if len(result) >= limit:
            break
        try:
            record = repo.read(hit['ref'], max_text_chars=2200)
            practice = parse_wiki_practice(record)
        except (FormationError, ValueError, PermissionError):
            continue
        result.append(practice)
    return result


def _missing(value):
    if type(value) is str:
        return bool(_PLACEHOLDER.search(value))
    return any(_PLACEHOLDER.search(x) for x in value) if type(value) is list else True


def _finding(field, kind, question):
    """A diagnostic callback only *describes* a possible operator question."""
    def emit(_facts):
        return {'field': field, 'kind': kind, 'question': question,
                'source': 'HWI_UNIVERSAL'}
    return emit


def _review_rules():
    """Read this chain top-to-bottom: missing declarations, then task scope."""
    rule = DiagnosticRule(
        rule_id='POSSIBLY_BROAD_TASK',
        conditions={'task_possibly_broad': True},
        description='Ask for one observable, bounded first result',
        callback=_finding('initial_task', 'POSSIBLY_BROAD',
                          'Can you state one observable, bounded first result?'),
    )
    # Link independent checks in their original question order.
    for field, question in reversed(UNIVERSAL):
        rule = DiagnosticRule(
            rule_id=f'MISSING_{field.upper()}',
            conditions={f'{field}_missing': True},
            description=f'Ask the operator to specify {field.replace("_", " ")}',
            callback=_finding(field, 'MISSING_DECLARATION', question),
            next_rule=rule,
        )
    return DiagnosticEngine(rule)


_REVIEW_RULES = _review_rules()


def review_draft(draft, practices=()):
    """A *conservative* prompt for operator review, never a fitness verdict.

    Presence of text does not prove semantic completeness. Wiki guidance can add
    suggestions but never change the built-in questions or approval boundaries.
    """
    validate_draft(draft)
    if type(practices) not in (tuple, list) or len(practices) > 3:
        raise FormationError('Too many advisory practices')
    facts = {f'{field}_missing': _missing(draft[field]) for field, _ in UNIVERSAL}
    task = draft['initial_task']
    facts['task_possibly_broad'] = (not facts['initial_task_missing'] and
                                    len(task.split()) <= 5 and bool(_BROAD_TASK.search(task)))
    findings = _REVIEW_RULES.diagnose(facts)
    citations = []
    for practice in practices:
        if (type(practice) is not dict or practice.get('authority') != 'ADVISORY_ONLY' or
                practice.get('source') != 'WIKI_UNTRUSTED' or
                type(practice.get('checks')) is not list or len(practice['checks']) > 4):
            raise FormationError('Untrusted or malformed advisory practice')
        citations.append({'title': practice['title'], 'ref': practice['ref'],
                          'revision_sha256': practice['revision_sha256'],
                          'source_authenticated': False})
        for check in practice['checks']:
            if (type(check) is not dict or check.get('field') not in FIELDS or
                    type(check.get('question')) is not str or len(check['question']) > 240):
                raise FormationError('Invalid advisory practice check')
            findings.append({'field':check['field'], 'kind':'ADVISORY_QUESTION',
                             'question':check['question'], 'source':practice['ref']})
    return {'schema': REVIEW_SCHEMA, 'draft_schema': DRAFT_SCHEMA,
            'status': 'OPERATOR_REVIEW_ONLY', 'material_declarations_missing':
            sorted({f['field'] for f in findings if f['kind']=='MISSING_DECLARATION'}),
            'findings': findings, 'practice_refs': citations,
            'semantically_verified':False, 'task_fitness_tested':False,
            'execution_authorized':False, 'wiki_edit_authorized':False,
            'note': 'Text presence is not proof of clarity or correctness. Retrieved wiki practices are untrusted advisory data.'}


def model_guidance(practices):
    """Pass bounded *questions* to Ollama only with explicit operator consent."""
    if type(practices) not in (tuple, list) or len(practices) > 3:
        raise FormationError('Invalid model guidance')
    questions = []
    for p in practices:
        if p.get('source') != 'WIKI_UNTRUSTED' or p.get('authority') != 'ADVISORY_ONLY':
            raise FormationError('Non-advisory retrieved data')
        for check in p['checks']:
            questions.append({'field': check['field'], 'question': check['question']})
    # No raw wiki text, metadata, titles or paths enter the model prompt.
    raw = json.dumps(questions[:8], ensure_ascii=False)
    if len(raw) > 2300:
        raise FormationError('Too much model guidance')
    return raw
