# Agent Formation boundary and lifecycle (Python implementation)

Accepted dual-flow research baseline: `e1af2e0`. Corrected governance
candidate used here: `b00411b`. This new feature is **separately unaccepted**.

1. **Installation / bootstrap** verifies local runtime availability and
   optionally inspects an *existing*, explicitly named wiki notebook read-only.
2. **Formation** is a voluntary, bounded operator-model conversation. The
   model proposes a task and clarification questions, without tool invocation.
3. **Human review** can edit the draft and confirm its exact content. A local
   SHA-256 pin detects accidental changes; it is not a signature or trust root.
4. **Task fitness** remains the existing governance v2 mechanism with real
   case evidence and separately provisioned owner signature. It is **not**
   automatically passed, generated as true, or bypassed by Formation.
5. **Commissioning / operations** are outside this candidate. Neither purpose
   confirmation nor fitness verification confers general execution authority.

Separate identities: `session_id` (local conversation), immutable
`contract_sha256` (purpose draft content), and the future distinct Task Fitness
Contract (signed scope after measured evaluation). The wiki is not used as
storage by Formation and is not auto-modified.

**Safety and data model:** User responses are stored in plaintext, protected
by private filesystem modes, and never sent to external endpoints by the
formation code. Ollama is limited to loopback. Model responses are untrusted,
strictly validated, and cannot alter fixed permission fields. A one-time
saved contract is reconstructable from the recorded draft. Session files are
not tamper-proof against another process running under the same OS user.

**Failure policy:** unavailable Ollama -> manual dialogue. Invalid JSON ->
operator-guided draft. Missing wiki catalog -> explicit not-ready status,
no initialization. Rejected draft or no confirmation -> no purpose contract.
Failed model output -> no execution or wiki write. Stale session -> no
silent overwrite. Confirmed purposes are immutable; start a new session to
propose a revision.

**Not a solved problem:** Evaluating real task usefulness, full wiki A3 adapter,
external authenticated identity, credential custody, GUI onboarding, full
fitness/commissioning automation, and native macOS revalidation are follow-up
features and must not be claimed as implemented.

## Advisory good-practice retrieval and ambiguity review (experimental)

`good_practices.py` reads at most three typed practices via HWI-05's current-
revision read-only broker only when the operator explicitly names a query and
wiki workspace. It adds non-authoritative clarification questions to the
human's draft review and, with separate consent, to a local Ollama question
prompt. Missing draft declarations are detected deterministically, but
semantic completeness is *not* proven. No session/contract schema changes or
new authorizations were introduced. This is not the general governance/wiki
compatibility adapter and does not change the accepted wiki core.

## Conversation state machine

The conversation is an explicit state machine in `dialogue.py` (pure, no
input/output); `cli.dialogue` only asks, calls the model, prints and saves.
States: `NEED_QUESTION`, `GUIDE_OPEN`, `MODEL_OPEN` (live or resumed),
`ASKING_MODEL`, `DONE` (finish, pause, max turns). `start()` derives the state
from the stored record, so resuming and continuing are the same path.
`step(state, event)` returns the next state and its effects; `stage()` builds
and validates every record change before anything is saved. The transition
table is in the module docstring; `test_dialogue_machine.py` has one test per
row, the derivation for every resume point, and 1,500 randomised conversations
(pauses, resumes, model outcomes) checked against invariants: every answer
follows the question it answers, no bare `You>` prompt without its question
shown in the same run, no question repeated, every stored change legal.

