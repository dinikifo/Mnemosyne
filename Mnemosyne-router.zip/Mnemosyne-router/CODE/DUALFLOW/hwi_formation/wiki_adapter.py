"""Read-only PERSONAL.WIKI discovery via the single governance repository.

This is not a second wiki integration layer. All approved wiki API calls,
HWI-05 broker operations, and knowledge-catalog checks live in
``hwi_governance.repository``. Formation has neither direct SQLite nor
private ``NotebookWorkspace`` access. No notebook or catalog is created.
"""
from __future__ import annotations

from pathlib import Path

from .core import FormationError


def _repository(workspace_path, notebook):
    if type(workspace_path) is not str or type(notebook) is not str:
        raise FormationError('Wiki connection needs both workspace and notebook name')
    path = Path(workspace_path).expanduser()
    if not path.is_dir():
        raise FormationError('Wiki workspace directory does not exist')
    if path.is_symlink():
        raise FormationError('Symlinked workspace is not permitted')
    from hwi_governance.repository import Repository, open_workspace
    try:
        return Repository(open_workspace(path.resolve(strict=True)), notebook)
    except (ValueError, RuntimeError, OSError, PermissionError) as exc:
        raise FormationError('Wiki connection refused; inspect with governance tools') from exc


def inspect_wiki(workspace_path=None, notebook=None):
    """Report capability only; no source content or path enters Ollama."""
    if workspace_path is None and notebook is None:
        return {'status': 'NOT_CONFIGURED', 'notebook': None,
                'readable': False, 'catalog_ready': False, 'notebook_scope': None,
                'reviewed_writes': 'SEPARATE_OPERATOR_AUTHORIZATION_REQUIRED'}
    repo = _repository(workspace_path, notebook)
    if not repo.notebook_exists():
        status = 'NOTEBOOK_ABSENT'
    else:
        try:
            status = 'READ_ONLY_READY' if repo.knowledge_catalog_ready() else 'CATALOG_NOT_READY'
            scope = repo.scope() if status == 'READ_ONLY_READY' else None
        except (ValueError, RuntimeError, OSError, PermissionError) as exc:
            raise FormationError('Wiki verification failed; inspect with governance tools') from exc
    if status == 'NOTEBOOK_ABSENT':
        scope = None
    return {'status': status, 'notebook': notebook,
            'readable': status == 'READ_ONLY_READY',
            'catalog_ready': status == 'READ_ONLY_READY',
            'notebook_scope': scope,
            'reviewed_writes': 'SEPARATE_OPERATOR_AUTHORIZATION_REQUIRED'}


def open_readonly_repository(workspace_path, notebook):
    """Return the existing repository API, never a broker/DB handle."""
    status = inspect_wiki(workspace_path, notebook)
    if status['status'] != 'READ_ONLY_READY':
        raise FormationError('Formation practice retrieval requires an existing verified knowledge catalog')
    return _repository(workspace_path, notebook)
