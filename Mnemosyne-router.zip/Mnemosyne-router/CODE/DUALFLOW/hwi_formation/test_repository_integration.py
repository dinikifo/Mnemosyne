"""Cross-branch contract tests: Formation now uses governance repository only."""
from __future__ import annotations

import ast
import argparse
from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from .core import FormationError
from .good_practices import retrieve_practices
from .wiki_adapter import inspect_wiki, open_readonly_repository
from hwi_governance.repository import Repository
from hwi_governance.review_queue import status_projection
from hwi_governance.test_wiki_contract import Fixture


class FormationBoundaryTests(unittest.TestCase):
    def test_formation_code_imports_neither_wiki_core_nor_sqlite(self):
        folder = Path(__file__).parent
        offenders = []
        for source in folder.glob('*.py'):
            if source.name.startswith('test_'):
                continue
            tree = ast.parse(source.read_text('utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    names = [item.name for item in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0:
                    names = [node.module or '']
                else:
                    continue
                if any(name.split('.')[0] in ('personal_wiki_core', 'hwi', 'sqlite3')
                       for name in names):
                    offenders.append((source.name, names))
                # hwi_governance is allowed; it is the single repository boundary.
        self.assertEqual(offenders, [])

    def test_missing_workspace_raises_without_creating_it(self):
        with tempfile.TemporaryDirectory() as d:
            missing = Path(d) / 'missing'
            with self.assertRaises(FormationError):
                inspect_wiki(str(missing), 'primary')
            self.assertFalse(missing.exists())

    def test_symlinked_workspace_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / 'real'; target.mkdir()
            link = Path(d) / 'alias'; link.symlink_to(target, target_is_directory=True)
            with self.assertRaises(FormationError):
                inspect_wiki(str(link), 'primary')


class RepositoryIntegrationTests(Fixture):
    def test_formation_reuses_the_same_repository(self):
        self.assertTrue(self.repo.knowledge_catalog_ready())
        status = inspect_wiki(str(self.ws.root), 'primary')
        self.assertEqual(status['status'], 'READ_ONLY_READY')
        r = open_readonly_repository(str(self.ws.root), 'primary')
        self.assertIsInstance(r, Repository)
        self.assertEqual(r.scope(), self.repo.scope())
        self.assertEqual(r.search('Evidence', mode='Title', limit=1)[0]['title'], 'Evidence')
        record = r.read(r.search('Evidence')[0]['ref'], max_text_chars=15)
        self.assertTrue(record['text_truncated'] is False)

    def test_resumed_practice_retrieval_cannot_switch_wiki_instance(self):
        from personal_wiki_core import NotebookWorkspace
        from hwi_formation.core import new_session
        from hwi_formation.cli import _practice_options
        other_root = Path(self.temp.name).resolve() / 'other_workspace'
        other = NotebookWorkspace(other_root, create=True)
        other.create_notebook('primary')
        with other.open_notebook('primary', readonly=False) as wiki:
            wiki.save_tiddler('A', 'irrelevant', [], reason='test')
            wiki.knowledge_catalog().initialize()
        first = inspect_wiki(str(self.ws.root), 'primary')
        second = inspect_wiki(str(other_root), 'primary')
        self.assertNotEqual(first['notebook_scope'], second['notebook_scope'])
        session = new_session('a' * 24, 'llama3.1:8b', 'http://127.0.0.1:11434', first, offline=True)
        args = argparse.Namespace(wiki_workspace=str(other_root), notebook='primary',
                                  practice_query='anything')
        with self.assertRaisesRegex(FormationError, 'differs'):
            _practice_options(args, session)

    def test_notebook_without_catalog_refused(self):
        self.ws.create_notebook('new')
        self.assertEqual(inspect_wiki(str(self.ws.root), 'new')['status'], 'CATALOG_NOT_READY')
        with self.assertRaises(FormationError):
            open_readonly_repository(str(self.ws.root), 'new')

    def test_status_projection_live_without_article_data(self):
        empty = status_projection(self.repo, 'primary')
        self.assertEqual(empty['pending'], 0)
        self.assertEqual(empty['proposals'], [])
        entry = self.submit('UNTRUSTED SECRET CONTENT')
        result = status_projection(self.repo, 'primary')
        self.assertEqual(result['pending'], 1)
        self.assertEqual(result['proposals'][0]['proposal_id'], entry['proposal_id'])
        self.assertEqual(result['proposals'][0]['fitness_gate_status'], 'UNGATED')
        self.assertFalse(result['approval_authorized'])
        self.assertNotIn('UNTRUSTED SECRET CONTENT', str(result))
        self.apply(entry)
        applied = status_projection(self.repo, 'primary')
        self.assertEqual(applied['pending'], 0)
        self.assertEqual(applied['applied'], 1)
        self.assertEqual(applied['proposals'][0]['wiki_receipt_present'], True)

    def test_status_cli_is_read_only_and_without_creating_proposal_ledger(self):
        from hwi_governance.cli import main
        # Fixture initially has a proposal ledger; snapshot of all workspace files
        # validates a normal query doesn't rewrite or migrate any SQLite store.
        before = {p.relative_to(self.ws.root): p.read_bytes()
                  for p in self.ws.root.rglob('*') if p.is_file()}
        stdout = StringIO()
        with redirect_stdout(stdout), redirect_stderr(StringIO()):
            self.assertEqual(main(['queue-status', '--workspace', str(self.ws.root),
                                   '--notebook', 'primary']), 0)
        self.assertIn('LIVE_QUERY_READ_ONLY', stdout.getvalue())
        after = {p.relative_to(self.ws.root): p.read_bytes()
                 for p in self.ws.root.rglob('*') if p.is_file()}
        self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main()
