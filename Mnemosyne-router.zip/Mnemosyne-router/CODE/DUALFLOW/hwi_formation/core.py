"""Pure, bounded Agent Formation records and model-draft validation.

Agent Formation is a *proposal* workflow, not task fitness, commissioning,
installation privilege, or authorization. All model output remains untrusted.
The operator confirms an exact draft before any local contract is saved.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from urllib.parse import urlsplit

SESSION_SCHEMA = 'hwi.formation.session.v0'
DRAFT_SCHEMA = 'hwi.formation.model_draft.v0'
PURPOSE_SCHEMA = 'hwi.formation.purpose_contract.v0'
MAX_TURNS = 8
MAX_TEXT = 1600
MAX_REPLY = 1200
MAX_MODEL_DRAFT = 10000
# 'guide' = a fixed question written by HWI (Python-owned) that the next user
# answer responds to; 'assistant' = a model-written question.
_ALLOWED_ROLES = frozenset(('user', 'assistant', 'guide'))
_ID = re.compile(r'^[a-f0-9]{24}$')
_MODEL = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,99}$')
_DRAFT_FIELDS = frozenset(('schema', 'purpose', 'initial_task', 'domain',
                          'input_sources', 'expected_outputs', 'success_criteria',
                          'boundaries', 'open_questions'))


class FormationError(ValueError):
    """Invalid or untrusted formation content or state."""


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('ascii')).hexdigest()


def _string(value, label, limit=MAX_TEXT):
    if (type(value) is not str or not 1 <= len(value.strip()) <= limit or
            any(ord(ch) < 32 and ch != '\n' for ch in value)):
        raise FormationError(f'{label}: bounded printable text required')
    return value.strip()


def validate_endpoint(endpoint):
    if type(endpoint) is not str or len(endpoint) > 160:
        raise FormationError('Ollama endpoint must be a bounded loopback URL')
    try:
        p = urlsplit(endpoint)
        port = p.port
    except ValueError as exc:
        raise FormationError('Invalid Ollama URL') from exc
    if (p.scheme != 'http' or p.hostname not in ('localhost', '127.0.0.1', '::1') or
            p.username is not None or p.password is not None or p.path not in ('', '/') or
            p.query or p.fragment or (port is not None and not 1 <= port <= 65535)):
        raise FormationError('Only a local HTTP Ollama endpoint is permitted')
    return endpoint.rstrip('/')


def validate_model(model):
    if type(model) is not str or not _MODEL.fullmatch(model):
        raise FormationError('Invalid local model identifier')
    return model


def new_session(session_id, model, endpoint, wiki, *, offline=False):
    if not _ID.fullmatch(session_id):
        raise FormationError('Invalid session id')
    validate_model(model)
    validate_endpoint(endpoint)
    if type(offline) is not bool or type(wiki) is not dict:
        raise FormationError('Invalid initial conditions')
    record = {
        'schema': SESSION_SCHEMA,
        'session_id': session_id,
        'model': model,
        'endpoint': endpoint,
        'mode': 'MANUAL' if offline else 'LOCAL_OLLAMA',
        'wiki_capabilities': copy.deepcopy(wiki),
        'messages': [],
        'state': 'IN_PROGRESS',
        'draft': None,
        'contract_sha256': None,
    }
    return seal_session(record)


def seal_session(record):
    value = copy.deepcopy(record)
    value.pop('record_sha256', None)
    value['record_sha256'] = digest(value)
    return value


def check_session(session):
    if type(session) is not dict or set(session) != {
        'schema','session_id','model','endpoint','mode','wiki_capabilities','messages',
        'state','draft','contract_sha256','record_sha256'
    }:
        raise FormationError('Unexpected session fields')
    if session['schema'] != SESSION_SCHEMA or not _ID.fullmatch(session['session_id']):
        raise FormationError('Invalid session identity')
    validate_model(session['model'])
    validate_endpoint(session['endpoint'])
    if session['mode'] not in ('MANUAL','LOCAL_OLLAMA') or type(session['wiki_capabilities']) is not dict:
        raise FormationError('Invalid session configuration')
    if session['state'] not in ('IN_PROGRESS','DRAFT_READY','CONFIRMED'):
        raise FormationError('Invalid session state')
    if type(session['messages']) is not list or len(session['messages']) > 2 * MAX_TURNS + 2:
        raise FormationError('Conversation length exceeded')
    users = 0
    for row in session['messages']:
        if type(row) is not dict or set(row) != {'role','text'} or row['role'] not in _ALLOWED_ROLES:
            raise FormationError('Malformed conversation entry')
        _string(row['text'], 'conversation', MAX_TEXT)
        users += row['role'] == 'user'
    if users > MAX_TURNS:
        raise FormationError('Maximum user turns exceeded')
    if session['state'] == 'IN_PROGRESS' and session['draft'] is not None:
        raise FormationError('In-progress session cannot contain a draft')
    if session['state'] in ('DRAFT_READY','CONFIRMED'):
        validate_draft(session['draft'])
    if session['state'] != 'CONFIRMED' and session['contract_sha256'] is not None:
        raise FormationError('Unconfirmed session cannot contain contract digest')
    if session['state'] == 'CONFIRMED' and not (type(session['contract_sha256']) is str and
                                                re.fullmatch('[0-9a-f]{64}', session['contract_sha256'])):
        raise FormationError('Confirmed session needs a contract digest')
    pin = session['record_sha256']
    if type(pin) is not str or pin != digest({k:v for k,v in session.items() if k != 'record_sha256'}):
        raise FormationError('Session integrity check failed')
    return session


def append_message(session, role, content):
    check_session(session)
    if session['state'] != 'IN_PROGRESS' or role not in _ALLOWED_ROLES:
        raise FormationError('Session is no longer accepting messages')
    text = _string(content, role, MAX_TEXT)
    if role == 'user' and sum(x['role']=='user' for x in session['messages']) >= MAX_TURNS:
        raise FormationError('Maximum formation turns reached')
    updated = copy.deepcopy(session)
    updated['messages'].append({'role':role,'text':text})
    return check_session(seal_session(updated))


def _unique_list(value, key, limit=8):
    if type(value) is not list or not 1 <= len(value) <= limit:
        raise FormationError(f'{key}: 1 to {limit} entries required')
    items = [_string(x, key, 320) for x in value]
    if len(set(items)) != len(items):
        raise FormationError(f'{key}: repeated entry')
    return items


def validate_draft(value):
    if type(value) is not dict or set(value) != _DRAFT_FIELDS or value['schema'] != DRAFT_SCHEMA:
        raise FormationError('Model purpose draft must use exact schema and fields')
    for key in ('purpose','initial_task','domain'):
        _string(value[key], key, 1000 if key != 'domain' else 120)
    for key in ('input_sources','expected_outputs','success_criteria','boundaries','open_questions'):
        _unique_list(value[key], key)
    return value


def strict_json_object(raw):
    if type(raw) is not str or len(raw) > MAX_MODEL_DRAFT:
        raise FormationError('Bounded model JSON required')
    def pairs(values):
        result = {}
        for k, v in values:
            if k in result:
                raise FormationError('Duplicate JSON property rejected')
            result[k] = v
        return result
    try:
        obj = json.loads(raw, object_pairs_hook=pairs)
    except (ValueError, TypeError) as exc:
        raise FormationError('Invalid model JSON') from exc
    return validate_draft(obj)


def manual_draft(session):
    """Use only user-supplied words; explicit missing values need further review.

    Answers are mapped to fields by position ONLY when the fixed operator prompts
    asked every question (no assistant turns). After a model-led conversation the
    answers responded to the model's own questions, so positions mean nothing:
    the draft keeps the purpose, marks every other field unspecified and carries
    the remaining answers verbatim for the operator to place with EDIT.
    """
    check_session(session)
    replies = [m['text'] for m in session['messages'] if m['role']=='user']
    if not replies:
        raise FormationError('At least one user objective is required')
    if any(m['role'] == 'assistant' for m in session['messages']):
        unassigned = []
        for text in replies[1:]:
            item = 'Unassigned answer: ' + ' '.join(text.split())
            item = item if len(item) <= 320 else item[:317] + '...'
            if item not in unassigned:
                unassigned.append(item)
        return validate_draft({
            'schema':DRAFT_SCHEMA,
            'purpose': replies[0],
            'initial_task': 'Not yet specified by operator',
            'domain': 'To be defined by operator',
            'input_sources': ['Sources not yet specified'],
            'expected_outputs': ['Output not yet specified'],
            'success_criteria': ['Acceptance criteria not yet specified'],
            'boundaries': ['No action or wiki editing authorized'],
            'open_questions': (['Model-led conversation: place each answer into its field with EDIT '
                                'before confirming'] + unassigned)[:8],
        })
    return validate_draft({
        'schema':DRAFT_SCHEMA,
        'purpose': replies[0],
        'initial_task': replies[1] if len(replies)>1 else 'Not yet specified by operator',
        'domain': 'To be defined by operator',
        'input_sources': [replies[2]] if len(replies)>2 else ['Sources not yet specified'],
        'expected_outputs': ['Output not yet specified'],
        'success_criteria': [replies[3]] if len(replies)>3 else ['Acceptance criteria not yet specified'],
        'boundaries': [replies[4]] if len(replies)>4 else ['No action or wiki editing authorized'],
        'open_questions':['Review and replace all unspecified fields before testing task fitness'],
    })


def set_draft(session, draft):
    check_session(session)
    validate_draft(draft)
    if session['state'] != 'IN_PROGRESS' or not any(m['role']=='user' for m in session['messages']):
        raise FormationError('A conversation is required before drafting')
    result = copy.deepcopy(session)
    result['draft'] = copy.deepcopy(draft)
    result['state'] = 'DRAFT_READY'
    return check_session(seal_session(result))


def make_contract(session):
    check_session(session)
    if session['state'] != 'DRAFT_READY':
        raise FormationError('Only a pending draft can become a purpose contract')
    draft = session['draft']
    return {
        'schema':PURPOSE_SCHEMA,
        'status':'FORMED_NOT_COMMISSIONED',
        'session_id':session['session_id'],
        'session_sha256':session['record_sha256'],
        'proposed_by':'LOCAL_MODEL_UNTRUSTED' if session['mode']=='LOCAL_OLLAMA' else 'OPERATOR_GUIDED',
        'model':session['model'],
        'purpose':draft['purpose'],
        'initial_task':draft['initial_task'],
        'domain':draft['domain'],
        'input_sources':draft['input_sources'],
        'expected_outputs':draft['expected_outputs'],
        'success_criteria':draft['success_criteria'],
        'boundaries':draft['boundaries'],
        'open_questions':draft['open_questions'],
        'wiki_capabilities':copy.deepcopy(session['wiki_capabilities']),
        'fitness_status':'NOT_TESTED',
        'commissioning_status':'NOT_COMMISSIONED',
        'execution_authorized':False,
        'wiki_edit_authorized':False,
        'knowledge_approved':False,
        'owner_confirmed_draft_only':True,
        'note':'Purpose confirmation is not task fitness, permission, credential enrollment, or a wiki approval.',
    }


_IDENTITY = ('schema', 'session_id', 'model', 'endpoint', 'wiki_capabilities')


def check_transition(prior, new, *, confirming=False):
    """Refuse any stored change the Formation workflow cannot produce.

    Identity and configuration never change. Allowed: conversation growth by one
    message (IN_PROGRESS), LOCAL_OLLAMA -> MANUAL (IN_PROGRESS), drafting
    (IN_PROGRESS -> DRAFT_READY), draft edits (DRAFT_READY), and, only through
    the store's confirm path, DRAFT_READY -> CONFIRMED with the draft unchanged.
    """
    check_session(prior)
    check_session(new)
    for key in _IDENTITY:
        if new[key] != prior[key]:
            raise FormationError(f'Session {key} is immutable')
    before, after = prior['state'], new['state']
    if before == 'CONFIRMED':
        raise FormationError('Confirmed session is immutable')
    if after == 'CONFIRMED' or confirming:
        if not confirming:
            raise FormationError('Only CONFIRM may confirm a session')
        if (before != 'DRAFT_READY' or after != 'CONFIRMED' or
                {k: v for k, v in new.items() if k not in ('state', 'contract_sha256', 'record_sha256')} !=
                {k: v for k, v in prior.items() if k not in ('state', 'contract_sha256', 'record_sha256')}):
            raise FormationError('Confirmation may change only the state and contract digest')
        return new
    if new['mode'] != prior['mode'] and not (
            before == after == 'IN_PROGRESS' and prior['mode'] == 'LOCAL_OLLAMA' and new['mode'] == 'MANUAL'):
        raise FormationError('Session mode may only switch to MANUAL during the conversation')
    old_msgs, new_msgs = prior['messages'], new['messages']
    if before == after == 'IN_PROGRESS':
        if not (len(old_msgs) <= len(new_msgs) <= len(old_msgs) + 1 and new_msgs[:len(old_msgs)] == old_msgs):
            raise FormationError('Conversation history is append-only, one message at a time')
        return new
    if new_msgs != old_msgs:
        raise FormationError('Conversation is closed once a draft exists')
    if (before, after) in (('IN_PROGRESS', 'DRAFT_READY'), ('DRAFT_READY', 'DRAFT_READY')):
        return new
    raise FormationError(f'Illegal session transition {before} -> {after}')


def confirm_session(session, contract):
    check_session(session)
    if make_contract(session) != contract:
        raise FormationError('Contract changed since review')
    record = copy.deepcopy(session)
    record['state'] = 'CONFIRMED'
    record['contract_sha256'] = digest(contract)
    return check_session(seal_session(record))


def use_manual_mode(session):
    check_session(session)
    if session['state'] != 'IN_PROGRESS':
        raise FormationError('Cannot switch a finalized formation session')
    record = copy.deepcopy(session)
    record['mode'] = 'MANUAL'
    return check_session(seal_session(record))
