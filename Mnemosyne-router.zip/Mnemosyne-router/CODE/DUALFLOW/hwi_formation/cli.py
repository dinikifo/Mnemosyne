"""Human-controlled first-run CLI. All writes are to local private formation files."""
from __future__ import annotations

import argparse
import copy
import json
import secrets
import sys

from .core import (FormationError, MAX_TURNS, append_message, check_session,
                   manual_draft, make_contract, new_session, set_draft,
                   use_manual_mode, validate_draft, validate_endpoint, validate_model)
from .model import ModelReplyRejected, check_question, list_local_models, propose, question
from .good_practices import review_draft
from .knowledge_port import PracticeReader, WikiPracticeReader, validate_practice_query
from .model_port import (ModelQuestionReader, DirectModelQuestionReader,
                         ModelDraftReader, DirectModelDraftReader)
from . import dialogue as dialogue_machine
from .storage import FormationStore
from hwi_governance.display import readable_json, visible_text
from .wiki_adapter import inspect_wiki

PROMPTS = dialogue_machine.PROMPTS


def _ask(label):
    try:
        return input(label).strip()
    except (EOFError, KeyboardInterrupt):
        print('\nSession paused; you may resume it by ID.')
        return '/pause'


def _save(store, old, new):
    store.save(new, previous_sha256=old['record_sha256'])
    return new


def _perform(store, session, effects):
    """Apply state-machine effects: validate all record changes, then print/save in order."""
    staged = iter(dialogue_machine.stage(session, effects))
    for effect in effects:
        if effect[0] == 'print':
            print(effect[1])
        else:
            session = _save(store, session, next(staged))
    return session


def _edit_draft(draft):
    """One-field-at-a-time operator edits; never accepts a model permission flag."""
    current = copy.deepcopy(draft)
    print('Editable fields:', ', '.join(k for k in current if k != 'schema'))
    field = _ask('Field to edit (blank to return): ')
    if not field:
        return current
    if field not in current or field == 'schema':
        print('Unknown field; draft unchanged.')
        return current
    if isinstance(current[field], list):
        print('Enter one item per line. End with an empty line.')
        values = []
        while len(values) < 8:
            item = _ask(' - ')
            if not item:
                break
            if item == '/pause':
                return current
            values.append(item)
        current[field] = values
    else:
        current[field] = _ask('New value: ')
    try:
        validate_draft(current)
    except FormationError as exc:
        print(f'Edit rejected: {exc}')
        return draft
    return current


def _draft_review(store, session, *, practices=(), share_guidance=False,
                  draft_reader: ModelDraftReader | None = None):
    trusted_draft_reader = (draft_reader if draft_reader is not None
                            else DirectModelDraftReader(propose))
    if session['state'] == 'IN_PROGRESS':
        if session['mode'] == 'LOCAL_OLLAMA':
            try:
                draft = trusted_draft_reader.draft(
                    session, guidance=practices if share_guidance else ())
            except FormationError as exc:
                print(f'Could not obtain a valid model draft: {exc}. Using an operator-guided draft.')
                before = session
                session = _save(store, before, use_manual_mode(session))
                draft = manual_draft(session)
        else:
            draft = manual_draft(session)
        before = session
        session = _save(store, before, set_draft(session, draft))
    while True:
        print('\n=== AGENT PURPOSE DRAFT (NOT A FITNESS APPROVAL) ===')
        print(readable_json(session['draft']))
        audit = review_draft(session['draft'], practices)
        print('\n=== GOOD-PRACTICE AMBIGUITY REVIEW (ADVISORY) ===')
        for item in audit['findings'][:18]:
            print(visible_text(f" - {item['kind']} [{item['field']}]: {item['question']}"))
        if not audit['findings']:
            print('No flagged gaps in the declared fields; semantic adequacy is NOT verified.')
        if audit['practice_refs']:
            print('Untrusted, current wiki revision references:')
            for item in audit['practice_refs']:
                print(visible_text(f" - {item['title']}: {item['ref']} ({item['revision_sha256']})"))
        print('No execution, wiki edits, task fitness, or commissioning are authorized.')
        choice = _ask('Type CONFIRM to save the purpose contract, EDIT, or PAUSE: ')
        if choice == 'CONFIRM':
            path, _ = store.confirm(session)
            print(f'FORMED_NOT_COMMISSIONED: local purpose contract saved to {path}')
            print('Next: declare task fitness cases and obtain separate owner approval before use.')
            return 0
        if choice.upper() in ('PAUSE','/PAUSE','/pause',''):
            print(f'Draft retained for resume: {session["session_id"]}')
            return 0
        if choice.upper() == 'EDIT':
            new_draft = _edit_draft(session['draft'])
            if new_draft != session['draft']:
                updated = copy.deepcopy(session)
                updated['draft'] = new_draft
                from .core import seal_session
                session = _save(store, session, check_session(seal_session(updated)))
        else:
            print('No changes made. Confirmation must be explicit.')


def dialogue(store, session, *, practices=(), share_guidance=False, model_questions=False,
             router_shadow=False, router_model_questions=False,
             question_reader: ModelQuestionReader | None = None):
    """Run the conversation. Model-written questions are OFF unless requested.

    Stabilisation stopgap: a lexical filter cannot prove that free model text is
    an appropriate clarification, so by default HWI asks only its own guided
    questions and the local model is used for the draft alone. ``--model-questions``
    re-enables filtered model questions until constrained question cards exist.
    """
    check_session(session)
    if router_model_questions and not model_questions:
        raise FormationError('--router-model-questions requires --model-questions')
    trusted_question_reader = (question_reader if question_reader is not None
                               else DirectModelQuestionReader(question))
    print(f'Formation session: {session["session_id"]} ({session["mode"]})')
    print('Conversation is saved locally in private files. Do not type passwords or secrets.')
    print('The model can suggest purposes, not grant permissions. /finish drafts; /pause resumes later.')
    if session['mode'] == 'LOCAL_OLLAMA' and session['state'] == 'IN_PROGRESS':
        print('Guided questions only; the local model writes the draft. '
              '(--model-questions turns on filtered model-written questions.)' if not model_questions else
              'Model-written questions are ON (filtered, advisory).')
    if session['state'] == 'CONFIRMED':
        print('This purpose contract is already confirmed; start a new session for changes.')
        return 0
    if session['state'] == 'DRAFT_READY':
        return _draft_review(store, session, practices=practices, share_guidance=share_guidance)
    show = lambda text: visible_text(text, keep_newlines=True)
    state, effects = dialogue_machine.start(session, model_questions=model_questions, check=check_question)
    session = _perform(store, session, effects)
    while state.kind != dialogue_machine.DONE:
        if state.kind == dialogue_machine.ASKING_MODEL:
            try:
                guidance = practices if share_guidance else ()
                if router_model_questions:
                    from hwi_router.formation_model import route_model_question
                    fields = ('initial_task', 'input_sources', 'success_criteria',
                              'boundaries', 'expected_outputs', 'domain')
                    routed = route_model_question(
                        trusted_question_reader, session,
                        field=fields[min(max(state.turns - 1, 0), len(fields) - 1)],
                        model_questions_opt_in=True, guidance=tuple(guidance),
                        guidance_sharing_opt_in=share_guidance)
                    if routed.question is None:
                        raise ModelReplyRejected('Routed question not validated')
                    suggested = routed.question
                else:
                    suggested = trusted_question_reader.ask(session, guidance=guidance)
                event = dialogue_machine.ModelOK(suggested)
            except ModelReplyRejected as exc:
                event = dialogue_machine.ModelRejected(str(exc))
            except FormationError as exc:
                event = dialogue_machine.ModelDown(str(exc))
        else:
            if router_shadow and state.kind == dialogue_machine.NEED_QUESTION and state.turns == 1:
                # Shadow only the first-task question, which maps exactly to
                # CMR-04's initial_task field. Keep the existing question.
                try:
                    from hwi_router.formation_shadow import observe_guided
                    obs = observe_guided('initial_task',
                                         dialogue_machine.guided_question(state.turns),
                                         active=session['state'] == 'IN_PROGRESS')
                    status = obs.status
                except Exception:
                    status = 'shadow_unavailable'
                print(f'CMR-07 shadow guided: {status} (no effect executed)')
            event = dialogue_machine.Reply(_ask(dialogue_machine.prompt_for(state, show=show)))
        new_state, effects = dialogue_machine.step(state, event, show=show)
        try:
            session = _perform(store, session, effects)
        except FormationError as exc:
            if isinstance(event, dialogue_machine.Reply):
                print(f'Input rejected: {exc}')
                continue
            new_state, effects = dialogue_machine.step(state, dialogue_machine.ModelDown(str(exc)), show=show)
            session = _perform(store, session, effects)
        state = new_state
    if state.reason == 'pause':
        print(f'Resume later with: bash RUN_AGENT_FORMATION.command resume {session["session_id"]}')
        return 0
    if not any(m['role']=='user' for m in session['messages']):
        print('No purpose supplied; session remains in progress.')
        return 0
    return _draft_review(store,session, practices=practices, share_guidance=share_guidance)


def _practice_options(args, session, *, reader: PracticeReader | None = None):
    """Only an explicitly scoped operator query may read wiki practices.

    Records are ephemeral and must be re-retrieved after resume; an old
    snapshot is never silently treated as current evidence.
    """
    if getattr(args, 'router_practices', False) and getattr(args, 'router_shadow', False):
        raise FormationError('--router-practices and --router-shadow are mutually exclusive')
    query = getattr(args, 'practice_query', None)
    if not query:
        if (getattr(args, 'wiki_workspace', None) and not getattr(args, 'notebook', None)):
            raise FormationError('A workspace requires an explicit notebook')
        return (), False
    validate_practice_query(query)
    if not args.wiki_workspace or not args.notebook:
        raise FormationError('--practice-query requires --wiki-workspace and --notebook')
    if (session['wiki_capabilities'].get('status') != 'READ_ONLY_READY' or
            session['wiki_capabilities'].get('notebook') != args.notebook):
        raise FormationError('Practice query requires the originally connected, ready notebook')
    # The notebook name alone is insufficient: after a pause, a different
    # workspace can have the same notebook name. HWI-05 physically pins the
    # instance; we refuse to silently mix sources across wiki instances.
    originally_pinned = session['wiki_capabilities'].get('notebook_scope')
    if not originally_pinned or inspect_wiki(args.wiki_workspace, args.notebook).get('notebook_scope') != originally_pinned:
        raise FormationError('Current wiki instance differs from the formation session pin')
    trusted_reader = reader if reader is not None else WikiPracticeReader()
    if getattr(args, 'router_practices', False) and session['state'] == 'IN_PROGRESS':
        from hwi_router.formation_knowledge import route_practices
        routed = route_practices(trusted_reader, args.wiki_workspace, args.notebook,
                                 query, active=True, notebook_pinned=True)
        practices = routed.practices
        print(f'CMR-07 routed practices: {routed.status} '
              f'({routed.read_count} read; {len(routed.transitions)} transitions)')
    else:
        practices = trusted_reader.read(args.wiki_workspace, args.notebook, query)
    if (getattr(args, 'router_shadow', False) and
            not getattr(args, 'router_practices', False) and
            session['state'] == 'IN_PROGRESS'):
        try:
            from hwi_router.formation_shadow import observe_practices
            obs = observe_practices(query, practices,
                                    active=True, notebook_pinned=True,
                                    broker_read_complete=True)
            status = obs.status
        except Exception:
            status = 'shadow_unavailable'
        print(f'CMR-07 shadow practices: {status} (no effect executed)')
    print(f'Advisory wiki practices found: {len(practices)} (read-only; NOT approved guidance)')
    for item in practices:
        print(visible_text(f"  {item['title']} — {item['ref']}"))
    share = False
    if practices and session['mode'] == 'LOCAL_OLLAMA':
        share = _ask('Send bounded advisory questions (no wiki text or paths) to LOCAL Ollama? [y/N] ').lower() == 'y'
    return practices, share


def main(argv=None):
    parser = argparse.ArgumentParser(description='HWI Agent Formation: conversational, advisory-only purpose bootstrap')
    parser.add_argument('--state-dir', help='Private local folder for sessions/contracts (default ~/.hwi-formation)')
    sub = parser.add_subparsers(dest='command')
    start = sub.add_parser('start',help='Start an Ollama or manual formation conversation')
    start.add_argument('--model', default='llama3.1:8b')
    start.add_argument('--endpoint', default='http://127.0.0.1:11434')
    start.add_argument('--manual', action='store_true', help='Do not contact Ollama')
    start.add_argument('--wiki-workspace', help='Existing private PERSONAL.WIKI workspace; never created or modified')
    start.add_argument('--notebook', help='Existing named notebook to inspect read-only')
    start.add_argument('--practice-query', help='Optional explicit query for typed good practices in existing wiki')
    start.add_argument('--router-shadow', action='store_true',
                       help='Observe advisory typed-message parity; no routing effects executed')
    start.add_argument('--router-practices', action='store_true',
                       help='Opt-in validated read-only practice delivery via typed router')
    start.add_argument('--model-questions', action='store_true',
                       help='Let the local model write follow-up questions (filtered; off by default)')
    start.add_argument('--router-model-questions', action='store_true',
                       help='Opt-in typed validation of local model questions; requires --model-questions')
    resume = sub.add_parser('resume', help='Resume a private formation session')
    resume.add_argument('session_id')
    resume.add_argument('--wiki-workspace', help='Existing workspace from original session')
    resume.add_argument('--notebook', help='Notebook from original session')
    resume.add_argument('--practice-query', help='Re-retrieve current good practices (not retained across pauses)')
    resume.add_argument('--router-shadow', action='store_true',
                        help='Observe advisory typed-message parity; no routing effects executed')
    resume.add_argument('--router-practices', action='store_true',
                        help='Opt-in validated read-only practice delivery via typed router')
    resume.add_argument('--model-questions', action='store_true',
                        help='Let the local model write follow-up questions (filtered; off by default)')
    resume.add_argument('--router-model-questions', action='store_true',
                        help='Opt-in typed validation of local model questions; requires --model-questions')
    sub.add_parser('list',help='List local formation sessions')
    show = sub.add_parser('show',help='Show a saved session and its draft')
    show.add_argument('session_id')
    audit = sub.add_parser('review-ambiguities', help='Review pending/confirmed draft against universal and optional wiki practices')
    audit.add_argument('session_id')
    audit.add_argument('--wiki-workspace')
    audit.add_argument('--notebook')
    audit.add_argument('--practice-query')
    contract = sub.add_parser('show-contract',help='Verify and display the confirmed purpose contract')
    contract.add_argument('session_id')
    argv = sys.argv[1:] if argv is None else argv
    args = parser.parse_args(argv or ["start"])
    if getattr(args, 'router_model_questions', False) and not args.model_questions:
        print('Formation refused: --router-model-questions requires --model-questions', file=sys.stderr)
        return 2
    try:
        if args.command in (None,'start'):
            # No file is created until the user opts in to local conversation storage.
            if _ask('Save a private local formation transcript to enable resume? [y/N] ').lower() != 'y':
                print('No files created. Declined local session storage.')
                return 0
            if sys.version_info < (3, 11):
                raise FormationError('Python 3.11 or newer is required')
            validate_model(args.model)
            validate_endpoint(args.endpoint)
            from hwi_governance.repository import check_storage_environment
            try:
                check_storage_environment()
                print('Python and local SQLite JSON/FTS5 prerequisites: available')
            except (RuntimeError, OSError, ValueError) as exc:
                print('Wiki storage prerequisites unavailable; wiki operations will remain disabled.')
            # Wiki is inspected *only* at explicit operator request; no data is sent to the model.
            wiki = inspect_wiki(args.wiki_workspace,args.notebook)
            print('PERSONAL.WIKI probe:',readable_json(wiki, indent=None))
            offline = args.manual
            if not offline:
                try:
                    models = list_local_models(args.endpoint)
                except Exception:
                    # The provider is optional for formation; never require a
                    # working Ollama service to define the user's purpose.
                    print('Local Ollama unavailable; switching to operator-guided formation.')
                    offline = True
                else:
                    if args.model not in models:
                        print('Model not listed by local Ollama; switching to offline guided formation.')
                        offline = True
            store = FormationStore(args.state_dir,create=True)
            session = new_session(secrets.token_hex(12),args.model,args.endpoint,wiki,offline=offline)
            practices, share = _practice_options(args, session)
            store.create(session)
            return dialogue(store,session, practices=practices, share_guidance=share,
                            model_questions=args.model_questions,
                            router_shadow=args.router_shadow,
                            router_model_questions=args.router_model_questions)
        store = FormationStore(args.state_dir,create=False)
        if args.command == 'list':
            print(readable_json(store.all_sessions()))
            return 0
        if args.command == 'show-contract':
            print(readable_json(store.read_contract(args.session_id)))
            return 0
        session = store.load(args.session_id)
        if args.command == 'resume':
            practices, share = _practice_options(args, session)
            return dialogue(store,session, practices=practices, share_guidance=share,
                            model_questions=args.model_questions,
                            router_shadow=args.router_shadow,
                            router_model_questions=args.router_model_questions)
        if args.command == 'review-ambiguities':
            if session['draft'] is None:
                raise FormationError('Draft the purpose before reviewing ambiguities')
            practices, _ = _practice_options(args, session)
            print(readable_json(review_draft(session['draft'], practices)))
            return 0
        if args.command == 'show':
            print(readable_json(session))
            return 0
    except FormationError as exc:
        print(f'Formation refused: {exc}',file=sys.stderr)
        return 2
    except (OSError, ValueError) as exc:
        print(f'Formation filesystem or input error: {type(exc).__name__}',file=sys.stderr)
        return 2
    return 2
