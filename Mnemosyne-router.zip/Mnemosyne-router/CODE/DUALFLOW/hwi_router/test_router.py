"""CMR-06 offline adversarial and behavioral tests; no external service calls."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import FrozenInstanceError
from pathlib import Path
import json
import time
import unittest

from hwi_router.core import (AdvisoryRouter, Decision, FlowHandle,
                             SessionHandle, SourceHandle)

DOC = Path(__file__).resolve().parents[1] / 'docs' / 'consolidation'
DOC_FILES = ('CMR-04_MESSAGE_SCHEMA_V1.json', 'CMR-04_COMPATIBILITY.json',
             'CMR-05_TRANSITION_MATRIX.json', 'CMR-05_EFFECT_POLICY.json')
REF = 'hwi05://' + 'a' * 64 + '/' + 'b' * 32 + '@1'
PAYLOAD = {
    'formation.practice.request': {'query': 'what makes the task complete', 'limit': 2},
    'knowledge.practice.result': {'practices': [
        {'field': 'success_criteria', 'question': 'How will success be tested?',
         'ref': REF, 'revision_sha256': 'c' * 64}]},
    'formation.model_question.request': {'field': 'success_criteria',
                                          'prompt': 'Ask one clarifying question?', 'practice_refs': []},
    'model.question.result': {'question': 'What would count as success?'},
    'formation.question.suggestion': {'field': 'success_criteria',
                                       'question': 'How would you measure success?',
                                       'practice_refs': []},
}
SOURCES = {
    'formation.practice.request': 'formation',
    'knowledge.practice.result': 'knowledge_adapter',
    'formation.model_question.request': 'formation',
    'model.question.result': 'model_adapter',
    'formation.question.suggestion': 'formation',
}


def contracts():
    return {name: json.loads((DOC / name).read_text(encoding='utf-8')) for name in DOC_FILES}


def packet(kind, flow, *, parent=None, message_id=None, **edits):
    base = dict(schema_id='hwi.router.message.v1', version=1,
                kind=kind, message_id=message_id or '1' * 32,
                correlation_id=flow.correlation_id, causation_id=parent,
                origin=SOURCES[kind], sensitivity='confidential', trace_ref=None,
                payload=deepcopy(PAYLOAD[kind]))
    base.update(edits)
    return base


def fixture(*, max_hops=None, cache=1024, clock=time.monotonic,
            handler_overrides=None, guard_overrides=None, modified_contracts=None):
    r = AdvisoryRouter(contracts=modified_contracts, max_hops=max_hops,
                       max_replay_entries=cache, clock=clock)
    sources = {name: r.register_source(name)
               for name in ('formation', 'knowledge_adapter', 'model_adapter')}
    session = r.register_session('test-session')
    all_guards = {g for rule in r._rules.values() for g in rule.guards}
    for name in all_guards:
        fn = (guard_overrides or {}).get(name, lambda _message, _snapshot: True)
        r.register_guard(name, fn)
    for rule in r._rules.values():
        fn = (handler_overrides or {}).get(rule.id, lambda *_args, intents=rule.effect_intents: Decision(intents))
        r.register_handler(rule.id, fn)
    r.seal()
    return r, session, sources


class RouterTests(unittest.TestCase):
    def test_all_eight_rules_follow_matrix(self):
        r, session, src = fixture()
        for seq, (kind, expected) in enumerate([('formation.practice.request', 'T01'),
                               ('formation.model_question.request', 'T03'),
                               ('formation.question.suggestion', 'T06')]):
            flow = r.open_flow(session)
            v = r.dispatch(flow, src['formation'], packet(kind, flow, message_id=f'{seq+10:032x}'))
            self.assertTrue(v.accepted, v)
            self.assertEqual(v.transition_id, expected)
        flow = r.open_flow(session)
        req = packet('formation.practice.request', flow, message_id='1'*32)
        self.assertTrue(r.dispatch(flow, src['formation'], req).accepted)
        out = r.dispatch(flow, src['knowledge_adapter'], packet(
            'knowledge.practice.result', flow, parent=req['message_id'], message_id='2'*32))
        self.assertEqual(out.transition_id, 'T02')
        self.assertEqual(r.snapshot(flow).phase, 'HAVE_PRACTICE')
        model = packet('formation.model_question.request', flow, parent='2'*32, message_id='3'*32)
        self.assertEqual(r.dispatch(flow, src['formation'], model).transition_id, 'T04')
        result = packet('model.question.result', flow, parent='3'*32, message_id='4'*32)
        self.assertEqual(r.dispatch(flow, src['model_adapter'], result).transition_id, 'T05')
        suggest = packet('formation.question.suggestion', flow, parent='4'*32, message_id='5'*32)
        self.assertEqual(r.dispatch(flow, src['formation'], suggest).transition_id, 'T08')
        self.assertEqual(r.snapshot(flow).phase, 'SUGGESTED')
        flow2 = r.open_flow(session)
        self.assertTrue(r.dispatch(flow2, src['formation'], packet('formation.practice.request', flow2, message_id='6'*32)).accepted)
        self.assertTrue(r.dispatch(flow2, src['knowledge_adapter'], packet('knowledge.practice.result', flow2, message_id='7'*32, parent='6'*32)).accepted)
        self.assertEqual(r.dispatch(flow2, src['formation'], packet('formation.question.suggestion', flow2, message_id='8'*32, parent='7'*32)).transition_id, 'T07')

    def test_effects_are_descriptors_only(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        v = r.dispatch(f, src['formation'], packet('formation.practice.request', f))
        self.assertEqual(len(v.effects), 1)
        self.assertEqual(v.effects[0].kind, 'knowledge.practice.read')
        self.assertEqual(v.effects[0].executor, 'knowledge_adapter')
        self.assertEqual(v.effects[0].timeout_ms, 10_000)

    def test_unknown_source_and_forged_source(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        m = packet('formation.practice.request', f)
        self.assertEqual(r.dispatch(f, SourceHandle('formation'), m).code, 'F02')
        self.assertEqual(r.dispatch(f, src['model_adapter'], m).code, 'F02')
        self.assertEqual(r.snapshot(f).phase, 'READY')
        self.assertTrue(r.dispatch(f, src['formation'], m).accepted)

    def test_origin_rejects_claim_in_actual_payload(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        m = packet('formation.practice.request', f, origin='model_adapter')
        self.assertEqual(r.dispatch(f, src['formation'], m).code, 'F01')

    def test_no_string_represented_as_capability(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, 'formation', packet('formation.practice.request', f)).code, 'F02')

    def test_unknown_and_forbidden_kind(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        for kind in ('governance.queue.apply', 'wiki.write', 'agent.execute'):
            m = packet('formation.practice.request', f)
            m['kind'] = kind
            self.assertEqual(r.dispatch(f, src['formation'], m).code, 'F01')
        self.assertEqual(r.snapshot(f).hops, 0)

    def test_schema_version_and_fields_default_deny(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        for extra in (dict(version=2), dict(version=True), dict(approved=True),
                      dict(payload={'query':'hi', 'limit':1, 'effect':'wiki.write'})):
            self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f, **extra)).code, 'F01')

    def test_duplicate_json_keys_and_nan(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        m = json.dumps(packet('formation.practice.request', f))
        self.assertEqual(r.dispatch(f, src['formation'], m[:-1] + ',"origin":"formation"}').code, 'F01')
        self.assertEqual(r.dispatch(f, src['formation'], m.replace('"limit": 2', '"limit": NaN')).code, 'F01')

    def test_bytes_and_utf8_and_non_json(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], b'\xff').code, 'F01')
        self.assertEqual(r.dispatch(f, src['formation'], {'something': object()}).code, 'F01')
        self.assertTrue(r.dispatch(f, src['formation'], json.dumps(packet('formation.practice.request', f)).encode()).accepted)

    def test_size_depth_nodes_and_control_bounds(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], ' '*16_385).code, 'F13')
        self.assertEqual(r.dispatch(f, src['formation'], '{"x":' * 10 + '1' + '}'*10).code, 'F13')
        large = {str(i): i for i in range(260)}
        self.assertEqual(r.dispatch(f, src['formation'], large).code, 'F13')
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f, payload={'query':'x\nhello', 'limit':1})).code, 'F01')

    def test_parent_or_correlation_mismatch(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f, parent='a'*32)).code, 'F02')
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f, correlation_id='b'*32)).code, 'F02')
        self.assertEqual(r.snapshot(f).phase, 'READY')

    def test_orphan_result_wrong_phase_and_unexpected_result(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, parent='0'*32)).code, 'F03')
        self.assertEqual(r.dispatch(f, src['model_adapter'], packet('model.question.result', f, parent='0'*32, message_id='2'*32)).code, 'F03')

    def test_wrong_pending_parent_rejected(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='a'*32)).accepted)
        self.assertEqual(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, parent='b'*32, message_id='c'*32)).code, 'F02')
        self.assertEqual(r.snapshot(f).phase, 'WAIT_PRACTICE')

    def test_wrong_latest_parent_rejected(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='a'*32)).accepted)
        self.assertTrue(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, parent='a'*32, message_id='b'*32)).accepted)
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.model_question.request', f, parent='a'*32, message_id='c'*32)).code, 'F02')
        self.assertEqual(r.snapshot(f).phase, 'HAVE_PRACTICE')

    def test_guard_failure_does_not_run_handler(self):
        seen = []
        r, session, src = fixture(handler_overrides={'T01': lambda *_: seen.append('ran')},
                                  guard_overrides={'explicit_practice_query': lambda *_: False})
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).code, 'F04')
        self.assertEqual(seen, [])
        self.assertEqual(r.snapshot(f).phase, 'READY')

    def test_guard_exception_fail_closed(self):
        def bad(*_): raise RuntimeError('secret: do not log')
        r, session, src = fixture(guard_overrides={'notebook_scope_pin': bad})
        f = r.open_flow(session)
        v = r.dispatch(f, src['formation'], packet('formation.practice.request', f))
        self.assertEqual(v.code, 'F04')
        self.assertNotIn('secret', str(v))

    def test_consent_model_opt_in_and_transport(self):
        for flag in ('model_questions_opt_in', 'guidance_sharing_opt_in_if_refs', 'transport_hardened_for_sensitive_input'):
            r, session, src = fixture(guard_overrides={flag: lambda *_: False})
            f = r.open_flow(session)
            self.assertEqual(r.dispatch(f, src['formation'], packet('formation.model_question.request', f)).code, 'F04')

    def test_immutable_message_and_nested_payload(self):
        seen = []
        def attempt(msg, _):
            seen.append(msg)
            with self.assertRaises(TypeError): msg.payload['practices'] = []
            with self.assertRaises(TypeError): msg.payload['practices'][0]['question'] = 'mutated'
            with self.assertRaises(FrozenInstanceError): msg.origin = 'formation'
            return Decision()
        r, session, src = fixture(handler_overrides={'T02': attempt})
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='1'*32)).accepted)
        m = packet('knowledge.practice.result', f, message_id='2'*32, parent='1'*32)
        self.assertTrue(r.dispatch(f, src['knowledge_adapter'], m).accepted)
        m['payload']['practices'][0]['question'] = 'changed from caller'
        self.assertEqual(seen[0].payload['practices'][0]['question'], 'How will success be tested?')

    def test_exact_duplicate_cached_without_rerun(self):
        seen = []
        def handler(*args):
            seen.append(1)
            return Decision(('knowledge.practice.read',))
        r, session, src = fixture(handler_overrides={'T01': handler})
        f = r.open_flow(session)
        m = packet('formation.practice.request', f)
        v = r.dispatch(f, src['formation'], m)
        repeated = r.dispatch(f, src['formation'], json.dumps(m))
        self.assertEqual(seen, [1])
        self.assertEqual(repeated.transition_id, v.transition_id)
        self.assertTrue(repeated.replayed)
        self.assertEqual(r.snapshot(f).hops, 1)

    def test_duplicate_id_different_digest_denied(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).accepted)
        changed = packet('formation.practice.request', f)
        changed['payload']['query'] = 'changed query'
        self.assertEqual(r.dispatch(f, src['formation'], changed).code, 'F10')

    def test_cache_full_fails_closed(self):
        r, session, src = fixture(cache=1)
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='1'*32)).accepted)
        self.assertEqual(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, message_id='2'*32, parent='1'*32)).code, 'F13')

    def test_replay_cache_only_in_process(self):
        r1, s1, src1 = fixture()
        f1 = r1.open_flow(s1)
        self.assertTrue(r1.dispatch(f1, src1['formation'], packet('formation.practice.request', f1)).accepted)
        r2, s2, src2 = fixture()
        f2 = r2.open_flow(s2)
        self.assertTrue(r2.dispatch(f2, src2['formation'], packet('formation.practice.request', f2)).accepted)
        self.assertTrue(r2.dispatch(f2, src2['formation'], packet('formation.practice.request', f2)).replayed)

    def test_forbidden_output_effect_rejected_and_phase_unchanged(self):
        for effect in ('wiki.write', 'governance.queue.apply', 'agent.execute'):
            r, session, src = fixture(handler_overrides={'T01': lambda *_, e=effect: Decision((e,))})
            f = r.open_flow(session)
            self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).code, 'F05')
            self.assertEqual(r.snapshot(f).phase, 'READY')

    def test_invalid_handler_output_rejected(self):
        r, session, src = fixture(handler_overrides={'T01': lambda *_: {'effect_intents':['knowledge.practice.read']}})
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).code, 'F05')

    def test_handler_interrupt_aborts_and_does_not_retry(self):
        seen = []
        def interrupt(*_):
            seen.append(1)
            raise InterruptedError('simulated interrupt')
        r, session, src = fixture(handler_overrides={'T01': interrupt})
        f = r.open_flow(session)
        m = packet('formation.practice.request', f)
        self.assertEqual(r.dispatch(f, src['formation'], m).code, 'F07')
        self.assertTrue(r.snapshot(f).aborted)
        self.assertTrue(r.dispatch(f, src['formation'], m).replayed)
        self.assertEqual(seen, [1])

    def test_handler_time_overrun_caught_post_execution(self):
        clock = [0.0]
        def slow(*_):
            clock[0] += 140
            return Decision(('knowledge.practice.read',))
        r, session, src = fixture(clock=lambda: clock[0], handler_overrides={'T01': slow})
        f = r.open_flow(session)
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).code, 'F06')
        self.assertTrue(r.snapshot(f).aborted)
        self.assertEqual(r.snapshot(f).hops, 0)

    def test_expired_flow_rejects_without_handler(self):
        clock = [0.0]
        r, session, src = fixture(clock=lambda: clock[0])
        f = r.open_flow(session)
        clock[0] = 136.0
        self.assertEqual(r.dispatch(f, src['formation'], packet('formation.practice.request', f)).code, 'F13')
        self.assertEqual(r.snapshot(f).phase, 'READY')

    def test_nested_dispatch_is_rejected(self):
        holder = {}
        def handler(_msg, _ctx):
            nested = holder['router'].dispatch(holder['flow'], holder['source'], holder['msg'])
            self.assertEqual(nested.code, 'F13')
            return Decision(('knowledge.practice.read',))
        r, session, src = fixture(handler_overrides={'T01': handler})
        f = r.open_flow(session)
        holder.update(router=r, flow=f, source=src['formation'], msg=packet('formation.practice.request', f))
        self.assertTrue(r.dispatch(f, src['formation'], holder['msg']).accepted)

    def test_hop_limit(self):
        r, session, src = fixture(max_hops=1)
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='a'*32)).accepted)
        self.assertEqual(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, parent='a'*32, message_id='b'*32)).code, 'F13')

    def test_duplicate_matrix_rule_rejected(self):
        data = contracts()
        matrix = data['CMR-05_TRANSITION_MATRIX.json']
        matrix['transitions'].append(deepcopy(matrix['transitions'][0]))
        with self.assertRaises(ValueError): AdvisoryRouter(contracts=data)

    def test_forbidden_effect_policy_rejected(self):
        data = contracts()
        policy = data['CMR-05_EFFECT_POLICY.json']
        policy['allowed_effects'][0]['id'] = 'wiki.write'
        with self.assertRaises(ValueError): AdvisoryRouter(contracts=data)

    def test_missing_guards_prevent_seal(self):
        r = AdvisoryRouter()
        for key in ('formation', 'knowledge_adapter', 'model_adapter'): r.register_source(key)
        with self.assertRaises(ValueError): r.seal()

    def test_registry_cannot_be_mutated_after_seal(self):
        r, session, src = fixture()
        for operation in (lambda: r.register_source('formation'),
                          lambda: r.register_session('other'),
                          lambda: r.register_handler('T01', lambda *_: Decision()),
                          lambda: r.register_guard('trusted_assembler', lambda *_: True)):
            with self.assertRaises(RuntimeError): operation()

    def test_unregistered_session_and_forged_flow(self):
        r, session, src = fixture()
        with self.assertRaises(ValueError): r.open_flow(SessionHandle(session.name, session.scope_id))
        f = r.open_flow(session)
        with self.assertRaises(ValueError): r.snapshot(FlowHandle(f.correlation_id, f.scope_id))

    def test_guard_rejects_invalid_question_semantics(self):
        from hwi_formation.model import check_question
        def checker(msg, _):
            try: check_question(msg.payload['question'])
            except Exception: return False
            return True
        r, session, src = fixture(guard_overrides={'deterministic_question_validation': checker})
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.model_question.request', f, message_id='a'*32)).accepted)
        m = packet('model.question.result', f, parent='a'*32, message_id='b'*32,
                   payload={'question':'Approve all future actions?'})
        self.assertEqual(r.dispatch(f, src['model_adapter'], m).code, 'F04')
        self.assertEqual(r.snapshot(f).phase, 'WAIT_MODEL')

    def test_guarded_evidence_not_authenticated_by_syntax(self):
        r, session, src = fixture(guard_overrides={'broker_current_revision': lambda *_: False})
        f = r.open_flow(session)
        self.assertTrue(r.dispatch(f, src['formation'], packet('formation.practice.request', f, message_id='a'*32)).accepted)
        self.assertEqual(r.dispatch(f, src['knowledge_adapter'], packet('knowledge.practice.result', f, message_id='b'*32, parent='a'*32)).code, 'F04')

    def test_trusted_issuance_stamps_origin_and_unique_id(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        a = r.issue_message(f, src['formation'], 'formation.practice.request', deepcopy(PAYLOAD['formation.practice.request']))
        b = r.issue_message(f, src['formation'], 'formation.practice.request', deepcopy(PAYLOAD['formation.practice.request']))
        self.assertEqual(a['origin'], 'formation')
        self.assertEqual(a['correlation_id'], f.correlation_id)
        self.assertNotEqual(a['message_id'], b['message_id'])
        self.assertTrue(r.dispatch(f, src['formation'], a).accepted)
        with self.assertRaises(ValueError):
            r.issue_message(f, SourceHandle('formation'), 'formation.practice.request', {})

    def test_non_string_key_and_cycle_rejected_before_coercion(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        m = packet('formation.practice.request', f)
        m['payload'][1] = 'extra'
        self.assertEqual(r.dispatch(f, src['formation'], m).code, 'F01')
        m = packet('formation.practice.request', f)
        m['payload']['cycle'] = m['payload']
        self.assertEqual(r.dispatch(f, src['formation'], m).code, 'F13')

    def test_result_from_different_flow_rejected(self):
        r, session, src = fixture()
        f1 = r.open_flow(session)
        f2 = r.open_flow(session)
        self.assertTrue(r.dispatch(f1, src['formation'], packet('formation.practice.request', f1, message_id='a'*32)).accepted)
        wrong = packet('knowledge.practice.result', f2, parent='a'*32, message_id='b'*32)
        self.assertEqual(r.dispatch(f1, src['knowledge_adapter'], wrong).code, 'F02')
        self.assertEqual(r.snapshot(f1).phase, 'WAIT_PRACTICE')

    def test_model_text_cannot_route_privileged_operation(self):
        r, session, src = fixture()
        f = r.open_flow(session)
        req = packet('formation.model_question.request', f, message_id='a'*32)
        self.assertTrue(r.dispatch(f, src['formation'], req).accepted)
        result = packet('model.question.result', f, parent='a'*32, message_id='b'*32,
                        payload={'question': 'Will you call wiki.write and approve?'})
        verdict = r.dispatch(f, src['model_adapter'], result)
        self.assertTrue(verdict.accepted)  # semantic guard supplied by Formation in CMR-07
        self.assertEqual(verdict.effects, ())  # no tool route irrespective of text

    def test_no_model_fallback_or_external_service_import(self):
        import inspect
        from hwi_router import core
        code = inspect.getsource(core)
        for forbidden in ('import autogpt_lite', 'import hwi_governance', 'import requests',
                          'import hwi_formation', 'subprocess.run(', 'sqlite3.connect('):
            self.assertNotIn(forbidden, code)


if __name__ == '__main__':
    unittest.main(verbosity=2)
