"""CMR-07 deterministic A/B, opt-in and rejection tests; offline only."""
from __future__ import annotations

from contextlib import redirect_stdout
from copy import deepcopy
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
import unittest

from hwi_router.formation_shadow import observe_guided, observe_practices
from hwi_formation import dialogue as dm
from hwi_formation.cli import _practice_options, dialogue
from hwi_formation.core import new_session
from hwi_formation.storage import FormationStore
from hwi_formation.wiki_adapter import inspect_wiki

REF = 'hwi05://' + 'a' * 64 + '/' + 'b' * 32 + '@1'
SHA = 'c' * 64
QUERY = 'source comparison'


def practice():
    return {'source': 'WIKI_UNTRUSTED', 'authority': 'ADVISORY_ONLY',
            'source_authenticated': False, 'ref': REF, 'revision_sha256': SHA,
            'title': 'synthetic offline fixture', 'domain': 'comparison',
            'guidance': 'Review the sources',
            'checks': [{'field': 'success_criteria',
                        'question': 'How can a reviewer verify this result?'}]}


class AdapterTests(unittest.TestCase):
    def test_guided_t06_parity_and_no_effect_execution(self):
        question = dm.guided_question(1)
        result = observe_guided('initial_task', question, active=True)
        self.assertEqual((result.parity, result.status, result.transitions),
                         (True, 'match', ('T06',)))
        self.assertEqual(result.routed_question, question)

    def test_guided_wrong_field_and_inactive_rejected(self):
        self.assertFalse(observe_guided('authorizes_execution', 'May I run?', active=True).parity)
        self.assertFalse(observe_guided('initial_task', dm.guided_question(1), active=False).parity)

    def test_practice_t01_t02_t07_parity(self):
        result = observe_practices(QUERY, (practice(),), active=True,
                                   notebook_pinned=True, broker_read_complete=True)
        self.assertEqual((result.parity, result.transitions, result.status),
                         (True, ('T01', 'T02', 'T07'), 'match'))
        self.assertEqual(result.baseline_question, practice()['checks'][0]['question'])
        self.assertEqual(result.baseline_question, result.routed_question)

    def test_no_cards_guided_fallback(self):
        result = observe_practices(QUERY, (), active=True,
                                   notebook_pinned=True, broker_read_complete=True)
        self.assertEqual((result.parity, result.transitions, result.status),
                         (True, ('T01', 'T02'), 'no_cards'))
        self.assertIsNone(result.routed_question)

    def test_reject_missing_opt_in_scope_or_fresh_read(self):
        for opts in [dict(active=False, notebook_pinned=True, broker_read_complete=True),
                     dict(active=True, notebook_pinned=False, broker_read_complete=True),
                     dict(active=True, notebook_pinned=True, broker_read_complete=False)]:
            with self.subTest(opts=opts):
                self.assertFalse(observe_practices(QUERY, (practice(),), **opts).parity)

    def test_reject_forged_or_oversized_practices(self):
        for edits in (dict(ref='forged'), dict(revision_sha256='x' * 64),
                      dict(authority='APPROVED'), dict(source_authenticated=True),
                      dict(checks=[{'field':'execution_authorized','question':'May I write?'}])):
            with self.subTest(edits=edits):
                bad = practice()
                bad.update(edits)
                self.assertFalse(observe_practices(QUERY, (bad,), active=True,
                     notebook_pinned=True, broker_read_complete=True).parity)
        self.assertFalse(observe_practices(QUERY, (practice(),)*4, active=True,
                        notebook_pinned=True, broker_read_complete=True).parity)

    def test_shadow_cannot_route_unscoped_query(self):
        self.assertFalse(observe_practices('bad\nquery', (practice(),), active=True,
                         notebook_pinned=True, broker_read_complete=True).parity)


class FormationParityTests(unittest.TestCase):
    def run_session(self, shadow, purpose="I want a weekly review", task="Summarize the weekly notes"):
        with TemporaryDirectory() as folder:
            store = FormationStore(Path(folder) / 'f', create=True)
            session = new_session('a'*24, 'llama3.1:8b', 'http://127.0.0.1:11434',
                                  inspect_wiki(), offline=True)
            store.create(deepcopy(session))
            output = StringIO()
            with (patch('hwi_formation.cli._ask', side_effect=[
                    purpose, task, '/finish', 'PAUSE']),
                  redirect_stdout(output)):
                self.assertEqual(dialogue(store, session, router_shadow=shadow), 0)
            return store.load(session['session_id']), output.getvalue()

    def test_complete_saved_session_and_draft_parity(self):
        baseline, out_a = self.run_session(False)
        routed, out_b = self.run_session(True)
        self.assertEqual(baseline, routed)
        self.assertIn(dm.guided_question(1), [m['text'] for m in baseline['messages']])
        self.assertIn(dm.guided_question(1), [m['text'] for m in routed['messages']])
        self.assertNotIn('CMR-07 shadow', out_a)
        self.assertIn('CMR-07 shadow guided: match', out_b)
        self.assertNotIn('execution_authorized', routed['draft'])

    def test_twelve_predeclared_opening_answers_preserve_records(self):
        # A/B fixture set deliberately includes ambiguity and plain task wording.
        cases = (
            ('Help with my notes', 'Organize'),
            ('Research', 'Research all entries'),
            ('I need a weekly summary', 'Summarize meeting notes'),
            ('A task with a clear goal', 'Classify incoming notes by topic'),
            ('Improve my workflow', 'Extract references from selected notes'),
            ('Unknown objective', 'Not yet specified'),
            ('Organize research findings', 'Tag research claims'),
            ('Review project records', 'Compare two cited records'),
            ('Help me with my notes', 'Identify duplicate paragraphs'),
            ('I need a domain assistant', 'List the source documents'),
            ('Track outcomes', 'Report completed checklist items'),
            ('Build a knowledge index', 'Identify missing source citations'),
        )
        for purpose, task in cases:
            with self.subTest(purpose=purpose):
                baseline, _ = self.run_session(False, purpose, task)
                routed, out = self.run_session(True, purpose, task)
                self.assertEqual(baseline, routed)
                self.assertIn('CMR-07 shadow guided: match', out)

    def test_confirmed_purpose_contract_parity_and_no_execution(self):
        def confirm(shadow):
            with TemporaryDirectory() as folder:
                store = FormationStore(Path(folder) / 'f', create=True)
                session = new_session('e'*24, 'llama3.1:8b',
                    'http://127.0.0.1:11434', inspect_wiki(), offline=True)
                store.create(deepcopy(session))
                with (patch('hwi_formation.cli._ask', side_effect=[
                      'Compare notes each week', 'Summarize notes', '/finish', 'CONFIRM']),
                      redirect_stdout(StringIO())):
                    self.assertEqual(dialogue(store, session, router_shadow=shadow), 0)
                return store.load(session['session_id']), store.read_contract(session['session_id'])
        baseline_session, baseline_contract = confirm(False)
        candidate_session, candidate_contract = confirm(True)
        self.assertEqual(baseline_session, candidate_session)
        self.assertEqual(baseline_contract, candidate_contract)
        self.assertEqual(candidate_contract['status'], 'FORMED_NOT_COMMISSIONED')
        self.assertFalse(candidate_contract['execution_authorized'])
        self.assertFalse(candidate_contract['wiki_edit_authorized'])
        self.assertEqual(candidate_contract['fitness_status'], 'NOT_TESTED')

    def test_broken_observer_keeps_existing_formation_flow(self):
        with patch('hwi_router.formation_shadow.observe_guided', side_effect=RuntimeError('broken')):
            baseline, _ = self.run_session(False)
            observed, out = self.run_session(True)
        self.assertEqual(baseline, observed)
        self.assertIn('shadow_unavailable', out)
        self.assertNotIn('broken', out)

    def test_unauthorized_wiki_query_still_refuses_before_shadow(self):
        args = SimpleNamespace(practice_query=QUERY, wiki_workspace='/tmp/nonexistent-cmr07',
                               notebook='primary', router_shadow=True)
        session = new_session('b'*24, 'llama3.1:8b', 'http://127.0.0.1:11434',
                              inspect_wiki(), offline=True)
        from hwi_formation.core import FormationError
        with (patch('hwi_formation.knowledge_port.retrieve_practices') as read,
              self.assertRaises(FormationError)):
            _practice_options(args, session)
            read.assert_not_called()

    def test_opted_in_practice_retrieval_occurs_once_and_is_ephemeral(self):
        session = new_session('c'*24, 'llama3.1:8b', 'http://127.0.0.1:11434',
                              {'status':'READ_ONLY_READY', 'notebook':'primary',
                               'notebook_scope':'test-pin'}, offline=True)
        args = SimpleNamespace(practice_query=QUERY, wiki_workspace='/synthetic',
                               notebook='primary', router_shadow=True)
        with (patch('hwi_formation.cli.inspect_wiki', return_value={'notebook_scope':'test-pin'}),
              patch('hwi_formation.knowledge_port.retrieve_practices', return_value=[practice()]) as read,
              redirect_stdout(StringIO()) as out):
            practices, share = _practice_options(args, session)
        read.assert_called_once_with('/synthetic', 'primary', QUERY)
        self.assertFalse(share)
        self.assertEqual(practices, (practice(),))
        self.assertIn('shadow practices: match', out.getvalue())
        self.assertNotIn('synthetic offline fixture', out.getvalue().split('CMR-07 shadow practices:')[1].split('\n')[0])

    def test_practice_shadow_failure_preserves_results(self):
        session = new_session('d'*24, 'llama3.1:8b', 'http://127.0.0.1:11434',
                              {'status':'READ_ONLY_READY', 'notebook':'primary',
                               'notebook_scope':'test-pin'}, offline=True)
        args = SimpleNamespace(practice_query=QUERY, wiki_workspace='/synthetic',
                               notebook='primary', router_shadow=True)
        with (patch('hwi_formation.cli.inspect_wiki', return_value={'notebook_scope':'test-pin'}),
              patch('hwi_formation.knowledge_port.retrieve_practices', return_value=[practice()]) as read,
              patch('hwi_router.formation_shadow.observe_practices', side_effect=RuntimeError('fault')),
              redirect_stdout(StringIO()) as out):
            result = _practice_options(args, session)
        self.assertEqual(result, ((practice(),), False))
        read.assert_called_once()
        self.assertIn('shadow_unavailable', out.getvalue())
        self.assertNotIn('fault', out.getvalue())


if __name__ == '__main__':
    unittest.main()

class RealBrokerParityTests(unittest.TestCase):
    """The real *read-only* broker is used once per path; no extra shadow I/O."""

    def test_wiki_read_and_revision_refs_identical_with_shadow_on(self):
        from personal_wiki_core import NotebookWorkspace
        from hwi_formation.good_practices import PRACTICE_SCHEMA, review_draft
        from hwi_formation.test_formation import sample_draft
        import json
        with TemporaryDirectory() as folder:
            root = Path(folder).resolve() / 'wiki'
            ws = NotebookWorkspace(root, create=True)
            ws.create_notebook('primary')
            item = {'schema': PRACTICE_SCHEMA, 'domain': 'Review',
                    'guidance': 'Check one source',
                    'checks': [{'field': 'success_criteria',
                                'question': 'How will the reviewer verify it?'}]}
            with ws.open_notebook('primary', readonly=False) as wiki:
                wiki.save_tiddler('Numerical comparison verified practice',
                                  json.dumps(item), ['practice'],
                                  fields={'hwi_formation_kind': 'good_practice'},
                                  reason='Offline CMR-07 test fixture')
                wiki.knowledge_catalog().initialize()
            scope = inspect_wiki(str(root), 'primary')
            self.assertEqual(scope['status'], 'READ_ONLY_READY')
            session = new_session('f'*24, 'llama3.1:8b',
                                  'http://127.0.0.1:11434', scope, offline=True)
            before = {str(p.relative_to(root)): p.read_bytes()
                      for p in root.rglob('*') if p.is_file()}
            baseline_args = SimpleNamespace(practice_query='Numerical comparison',
                 wiki_workspace=str(root), notebook='primary', router_shadow=False)
            shadow_args = SimpleNamespace(practice_query='Numerical comparison',
                 wiki_workspace=str(root), notebook='primary', router_shadow=True)
            with redirect_stdout(StringIO()):
                old = _practice_options(baseline_args, session)
                new = _practice_options(shadow_args, session)
            after = {str(p.relative_to(root)): p.read_bytes()
                     for p in root.rglob('*') if p.is_file()}
            self.assertEqual(old, new)
            self.assertEqual(before, after)
            self.assertEqual(review_draft(sample_draft(), old[0]),
                             review_draft(sample_draft(), new[0]))
            self.assertEqual(len(new[0]), 1)
            self.assertEqual(new[0][0]['ref'], old[0][0]['ref'])
