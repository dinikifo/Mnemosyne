"""CMR-06: exact-match, in-process, advisory-only message dispatcher.

Its input is trusted ONLY as far as the integrating application protects the
source/session capability objects. This is not a process sandbox, signature,
authorization service, or protection against malicious in-process Python code.
No executor is implemented: accepted side effects are *descriptors*, never run.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Mapping
import json
import secrets
import threading
import time

from jsonschema import Draft202012Validator

_CONTRACT_ROOT = Path(__file__).resolve().parents[1] / 'docs' / 'consolidation'
_FILES = ('CMR-04_MESSAGE_SCHEMA_V1.json', 'CMR-04_COMPATIBILITY.json',
          'CMR-05_TRANSITION_MATRIX.json', 'CMR-05_EFFECT_POLICY.json')


class _Rejected(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True, eq=False)
class SourceHandle:
    """Identity-only binding issued at trusted router bootstrap (not a credential)."""
    name: str


@dataclass(frozen=True, eq=False)
class SessionHandle:
    """Identity-only session capability; caller must keep it away from untrusted code."""
    name: str
    scope_id: str


@dataclass(frozen=True, eq=False)
class FlowHandle:
    correlation_id: str
    scope_id: str


@dataclass(frozen=True)
class FrozenMessage:
    kind: str
    version: int
    message_id: str
    correlation_id: str
    causation_id: str | None
    origin: str
    sensitivity: str
    payload: Mapping[str, Any]
    digest: str


@dataclass(frozen=True)
class RouteSnapshot:
    phase: str
    correlation_id: str
    hops: int
    pending_request_id: str | None
    latest_result_id: str | None
    aborted: bool


@dataclass(frozen=True)
class EffectIntent:
    kind: str
    executor: str
    message_id: str
    correlation_id: str
    timeout_ms: int


@dataclass(frozen=True)
class Decision:
    """Pure handler declaration, not permission or a command to execute."""
    effect_intents: tuple[str, ...] = ()


@dataclass(frozen=True)
class Verdict:
    accepted: bool
    code: str
    phase: str
    transition_id: str | None = None
    effects: tuple[EffectIntent, ...] = ()
    digest: str | None = None
    replayed: bool = False


@dataclass
class _State:
    handle: FlowHandle
    start: float
    phase: str = 'READY'
    hops: int = 0
    pending_request_id: str | None = None
    latest_result_id: str | None = None
    aborted: bool = False


@dataclass(frozen=True)
class _Rule:
    id: str
    phase: str
    kind: str
    trusted_origin: str
    next_phase: str
    parent_rule: str
    guards: tuple[str, ...]
    effect_intents: tuple[str, ...]


def _freeze(value: Any) -> Any:
    if type(value) is dict:
        return MappingProxyType({key: _freeze(v) for key, v in value.items()})
    if type(value) is list:
        return tuple(_freeze(v) for v in value)
    return value  # JSON primitives are immutable


def _pairs_unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    obj: dict[str, Any] = {}
    for key, value in pairs:
        if key in obj:
            raise _Rejected('F01')
        obj[key] = value
    return obj


def _reject_constant(_: str) -> None:
    raise _Rejected('F01')


def _count_nodes_and_depth(root: Any, *, max_nodes: int, max_depth: int) -> None:
    stack = [(root, 1)]
    nodes = 0
    while stack:
        value, depth = stack.pop()
        nodes += 1
        if nodes > max_nodes or depth > max_depth:
            raise _Rejected('F13')
        if type(value) is dict:
            if any(type(key) is not str for key in value):
                raise _Rejected('F01')
            stack.extend((item, depth + 1) for item in value.values())
        elif type(value) is list:
            stack.extend((item, depth + 1) for item in value)
        elif type(value) not in (str, int, float, bool, type(None)):
            raise _Rejected('F01')


class AdvisoryRouter:
    """Isolated router using CMR-04/05 as fixed contract sources.

    All registration occurs during trusted bootstrap; ``seal`` makes the
    registries read-only. All guard hooks and handlers must be pure and trusted.
    A private in-memory cache prevents replay only within this router instance.
    """

    def __init__(self, *, contracts: Mapping[str, Any] | None = None,
                 clock: Callable[[], float] = time.monotonic,
                 max_hops: int | None = None, max_replay_entries: int = 1024):
        if contracts is None:
            docs = [json.loads((_CONTRACT_ROOT / f).read_text(encoding='utf-8'))
                    for f in _FILES]
        else:
            docs = [contracts[f] for f in _FILES]
        schema, compat, matrix, policy = docs
        Draft202012Validator.check_schema(schema)
        self._validator = Draft202012Validator(schema)
        schema_ids = {r['properties']['schema_id']['const'] for r in schema['oneOf']}
        schema_versions = {r['properties']['version']['const'] for r in schema['oneOf']}
        if len(schema_ids) != 1 or len(schema_versions) != 1 or type(next(iter(schema_versions))) is not int:
            raise ValueError('inconsistent message profile')
        self._schema_id = next(iter(schema_ids))
        self._schema_version = next(iter(schema_versions))
        self._limits = dict(policy['limits'])
        if max_hops is not None:
            if type(max_hops) is not int or not (1 <= max_hops <= self._limits['max_dispatch_hops']):
                raise ValueError('max_hops must be a stricter policy bound')
            self._limits['max_dispatch_hops'] = max_hops
        if type(max_replay_entries) is not int or not (1 <= max_replay_entries <= 100_000):
            raise ValueError('invalid replay-cache capacity')
        self._max_replays = max_replay_entries
        self._clock = clock
        self._effects = {e['id']: e for e in policy['allowed_effects']}
        self._rules: dict[tuple[str, str, str], _Rule] = {}
        self._rules_by_id: dict[str, _Rule] = {}
        self._guards: dict[str, Callable[[FrozenMessage, RouteSnapshot], bool]] = {}
        self._handlers: dict[str, Callable[[FrozenMessage, RouteSnapshot], Decision]] = {}
        self._sources: dict[str, SourceHandle] = {}
        self._sessions: dict[int, SessionHandle] = {}
        self._flows: dict[int, _State] = {}
        self._replays: dict[tuple[str, str], tuple[str, Verdict]] = {}
        self._lock = threading.Lock()
        self._sealed = False

        kinds = {row['kind']: row['producer'] for row in compat['messages']}
        # Source identities are allowlisted by this trusted profile, not by payloads.
        self._allowed_sources = frozenset(kinds.values())
        if (not self._allowed_sources or not self._allowed_sources.issubset({
                'formation', 'knowledge_adapter', 'model_adapter',
                'dualflow_review', 'dualflow_simulator',
                'agent_evaluation', 'wiki_selection',
                'governance_operator', 'governance_projection'})):
            raise ValueError('unsupported trusted source in profile')
        schema_kinds = {row['properties']['kind']['const'] for row in schema['oneOf']}
        if (kinds.keys() != schema_kinds or policy['authority'] != 'advisory_only'
                or not policy['no_router_writes'] or policy['default_effect_policy'] != 'deny'
                or not policy['no_automatic_fallback_dispatch']):
            raise ValueError('incompatible advisory policies')
        if len(self._effects) != len(policy['allowed_effects']):
            raise ValueError('duplicate effect intent')
        if self._effects.keys() & set(policy['explicitly_denied_effects']):
            raise ValueError('forbidden effect in allowlist')
        for eff in self._effects.values():
            if eff['auto_retry'] is not False or eff['effect_class'] not in (
                    'external_read', 'external_model_call', 'advisory_delivery'):
                raise ValueError('unsafe effect definition')
        for row in matrix['transitions']:
            rule = _Rule(row['id'], row['phase'], row['kind'], row['trusted_origin'],
                         row['next_phase'], row['parent_rule'], tuple(row['guards']),
                         tuple(row['effect_intents']))
            key = (rule.phase, rule.kind, rule.trusted_origin)
            if key in self._rules or rule.id in self._rules_by_id:
                raise ValueError('ambiguous or duplicate rule')
            if (rule.kind not in kinds or rule.trusted_origin != kinds[rule.kind]
                    or rule.phase not in matrix['phases'] or rule.next_phase not in matrix['phases']
                    or row['authority'] != 'advisory_only'
                    or rule.parent_rule not in ('root', 'pending_request', 'latest_result')):
                raise ValueError('invalid transition')
            if rule.parent_rule == 'root' and rule.phase != 'READY':
                raise ValueError('invalid root parent')
            for effect_id in rule.effect_intents:
                effect = self._effects.get(effect_id)
                if effect is None or effect['input_kind'] != rule.kind or not set(
                        effect['required_guards']).issubset(rule.guards):
                    raise ValueError('unapproved effect or missing guard')
            self._rules[key] = rule
            self._rules_by_id[rule.id] = rule
        if set(r.kind for r in self._rules.values()) != schema_kinds:
            raise ValueError('missing registered message kind')
        self._initial_phase = matrix['initial_phase']
        self._terminal = frozenset(matrix['terminal_phases'])

    def register_source(self, name: str) -> SourceHandle:
        self._require_open()
        if name not in self._allowed_sources or name in self._sources:
            raise ValueError('invalid or duplicate source')
        source = SourceHandle(name)
        self._sources[name] = source
        return source

    def register_session(self, name: str) -> SessionHandle:
        self._require_open()
        if type(name) is not str or not name or len(name) > 64:
            raise ValueError('invalid session name')
        session = SessionHandle(name, secrets.token_hex(16))
        self._sessions[id(session)] = session
        return session

    def register_guard(self, name: str, predicate: Callable[[FrozenMessage, RouteSnapshot], bool]) -> None:
        self._require_open()
        if name not in {g for r in self._rules.values() for g in r.guards} or name in self._guards or not callable(predicate):
            raise ValueError('unknown, duplicate, or invalid guard')
        self._guards[name] = predicate

    def register_handler(self, rule_id: str, handler: Callable[[FrozenMessage, RouteSnapshot], Decision]) -> None:
        self._require_open()
        if rule_id not in self._rules_by_id or rule_id in self._handlers or not callable(handler):
            raise ValueError('unknown, duplicate, or invalid handler')
        self._handlers[rule_id] = handler

    def _require_open(self) -> None:
        if self._sealed:
            raise RuntimeError('router registry is sealed')

    def seal(self) -> None:
        self._require_open()
        needed_guards = {g for r in self._rules.values() for g in r.guards}
        needed_sources = {r.trusted_origin for r in self._rules.values()}
        if (set(self._handlers) != set(self._rules_by_id) or set(self._guards) != needed_guards
                or set(self._sources) != needed_sources):
            raise ValueError('missing handler, guard, or source at trusted bootstrap')
        self._sealed = True

    def open_flow(self, session: SessionHandle) -> FlowHandle:
        if not self._sealed:
            raise RuntimeError('seal the router before opening flows')
        if self._sessions.get(id(session)) is not session:
            raise ValueError('unregistered session capability')
        handle = FlowHandle(secrets.token_hex(16), session.scope_id)
        self._flows[id(handle)] = _State(handle, self._clock(), self._initial_phase)
        return handle

    def issue_message(self, flow: FlowHandle, source: SourceHandle, kind: str,
                      payload: Mapping[str, Any], *, parent: str | None = None,
                      sensitivity: str = 'confidential') -> dict[str, Any]:
        """Trusted-adapter convenience: stamp identity and fresh message ID.

        The caller must already hold the trusted source and flow handles. This
        helper does not interpret model content as a command, approve anything,
        or replace the schema/parent/guard checks made during dispatch.
        """
        self._lookup(flow)
        if type(source) is not SourceHandle or self._sources.get(source.name) is not source:
            raise ValueError('unregistered source capability')
        if type(payload) is not dict:
            raise ValueError('payload must be a plain JSON dictionary')
        return {'schema_id': self._schema_id, 'version': self._schema_version,
                'kind': kind, 'message_id': secrets.token_hex(16),
                'correlation_id': flow.correlation_id, 'causation_id': parent,
                'origin': source.name, 'sensitivity': sensitivity,
                'trace_ref': None, 'payload': payload}

    def snapshot(self, handle: FlowHandle) -> RouteSnapshot:
        state = self._lookup(handle)
        return self._snapshot_state(state)

    def _lookup(self, handle: FlowHandle) -> _State:
        state = self._flows.get(id(handle))
        if state is None or state.handle is not handle:
            raise ValueError('unknown flow handle')
        return state

    @staticmethod
    def _snapshot_state(state: _State) -> RouteSnapshot:
        return RouteSnapshot(state.phase, state.handle.correlation_id, state.hops,
                             state.pending_request_id, state.latest_result_id, state.aborted)

    def _parse(self, raw: str | bytes | Mapping[str, Any]) -> tuple[dict[str, Any], str]:
        max_bytes = self._limits['max_envelope_bytes']
        try:
            if type(raw) in (str, bytes):
                encoded = raw.encode('utf-8') if type(raw) is str else raw
                if len(encoded) > max_bytes:
                    raise _Rejected('F13')
                packet = json.loads(encoded, object_pairs_hook=_pairs_unique,
                                    parse_constant=_reject_constant)
            elif type(raw) is dict:
                # Check Python data BEFORE JSON conversion to prevent key coercion,
                # excessive nested structures or cyclic references.
                _count_nodes_and_depth(raw, max_nodes=self._limits['max_json_nodes'],
                                       max_depth=self._limits['max_json_depth'])
                encoded = json.dumps(raw, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False).encode('utf-8')
                if len(encoded) > max_bytes:
                    raise _Rejected('F13')
                packet = json.loads(encoded)
            else:
                raise _Rejected('F01')
        except _Rejected:
            raise
        except (TypeError, ValueError, UnicodeError, OverflowError, RecursionError) as exc:
            raise _Rejected('F01') from exc
        _count_nodes_and_depth(packet, max_nodes=self._limits['max_json_nodes'],
                               max_depth=self._limits['max_json_depth'])
        if type(packet) is not dict or not self._validator.is_valid(packet):
            raise _Rejected('F01')
        canonical = json.dumps(packet, ensure_ascii=False, sort_keys=True,
                               separators=(',', ':'), allow_nan=False).encode('utf-8')
        return packet, sha256(canonical).hexdigest()

    def dispatch(self, flow: FlowHandle, source: SourceHandle,
                 raw: str | bytes | Mapping[str, Any]) -> Verdict:
        """Perform one atomic in-memory transition; NEVER execute effect intents.

        A nonblocking lock prevents overlapping and nested dispatch; errors are
        generic verdicts and never log/echo private payloads. Hard cancellation
        of a blocking handler is not possible in this synchronous prototype.
        """
        if not self._sealed:
            raise RuntimeError('router not sealed')
        state = self._lookup(flow)
        if not self._lock.acquire(blocking=False):
            return Verdict(False, 'F13', state.phase)
        try:
            return self._dispatch_locked(state, source, raw)
        finally:
            self._lock.release()

    def _dispatch_locked(self, state: _State, source: SourceHandle,
                         raw: str | bytes | Mapping[str, Any]) -> Verdict:
        phase = state.phase
        try:
            if type(source) is not SourceHandle or self._sources.get(source.name) is not source:
                raise _Rejected('F02')
            packet, digest = self._parse(raw)
            if packet['origin'] != source.name or packet['correlation_id'] != state.handle.correlation_id:
                raise _Rejected('F02')
            replay_key = (state.handle.scope_id, packet['message_id'])
            previous = self._replays.get(replay_key)
            if previous:
                old_digest, old_verdict = previous
                if old_digest != digest:
                    raise _Rejected('F10')
                return replace(old_verdict, replayed=True)
            if len(self._replays) >= self._max_replays:
                raise _Rejected('F13')  # fail closed rather than evict a replay record
            if state.aborted or state.phase in self._terminal:
                raise _Rejected('F03')
            if self._clock() - state.start > self._limits['max_workflow_deadline_ms'] / 1000:
                raise _Rejected('F13')
            if state.hops >= self._limits['max_dispatch_hops']:
                raise _Rejected('F13')
            rule = self._rules.get((phase, packet['kind'], source.name))
            if rule is None:
                raise _Rejected('F03')
            parent = packet['causation_id']
            if rule.parent_rule == 'root' and parent is not None:
                raise _Rejected('F02')
            if rule.parent_rule == 'pending_request' and (
                    state.pending_request_id is None or parent != state.pending_request_id):
                raise _Rejected('F02')
            if rule.parent_rule == 'latest_result' and (
                    state.latest_result_id is None or parent != state.latest_result_id):
                raise _Rejected('F02')
            msg = FrozenMessage(packet['kind'], packet['version'], packet['message_id'],
                                packet['correlation_id'], parent, source.name,
                                packet['sensitivity'], _freeze(packet['payload']), digest)
            snapshot = self._snapshot_state(state)
            for guard_name in rule.guards:
                try:
                    permitted = self._guards[guard_name](msg, snapshot) is True
                except Exception:
                    permitted = False
                if not permitted:
                    raise _Rejected('F04')
            try:
                decision = self._handlers[rule.id](msg, snapshot)
            except BaseException:
                # A handler might already have had non-rollbackable effects if
                # it violated the pure-handler contract: never blindly retry.
                state.aborted = True
                raise _Rejected('F07')
            if (type(decision) is not Decision or type(decision.effect_intents) is not tuple
                    or decision.effect_intents != rule.effect_intents):
                raise _Rejected('F05')
            if self._clock() - state.start > self._limits['max_workflow_deadline_ms'] / 1000:
                state.aborted = True
                raise _Rejected('F06')
            intents = tuple(EffectIntent(id_, self._effects[id_]['executor'], msg.message_id,
                                         msg.correlation_id, self._effects[id_]['timeout_ms'])
                            for id_ in decision.effect_intents)
            # All checks done: commit coordinator-only state in one local step.
            state.phase = rule.next_phase
            state.hops += 1
            if rule.effect_intents:
                state.pending_request_id = msg.message_id
                state.latest_result_id = None
            elif rule.parent_rule == 'pending_request' and not rule.effect_intents:
                state.latest_result_id = msg.message_id
                state.pending_request_id = None
            accepted = Verdict(True, 'OK', state.phase, rule.id, intents, digest)
            self._replays[replay_key] = digest, accepted
            return accepted
        except _Rejected as err:
            verdict = Verdict(False, err.code, phase)
            # Valid, authenticated packets with a stable key are cached even on
            # guard/output failures: same ID must never rerun a handler.
            if ('packet' in locals() and 'digest' in locals()
                    and 'replay_key' in locals() and err.code not in ('F10',)
                    and len(self._replays) < self._max_replays):
                self._replays.setdefault(replay_key, (digest, verdict))
            return verdict
