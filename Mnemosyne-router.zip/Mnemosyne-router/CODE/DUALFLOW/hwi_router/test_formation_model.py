"""CMR-08 model port and typed advisory delivery regression tests (offline)."""
from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
import os

from hwi_formation.cli import dialogue, main
from hwi_formation.core import FormationError, append_message, new_session
from hwi_formation.model import ModelReplyRejected
from hwi_formation.storage import FormationStore
from hwi_formation.model_port import DirectModelDraftReader, DirectModelQuestionReader
from hwi_router.formation_model import route_model_question
from hwi_router.test_formation_knowledge import practice

WIKI = {'status': 'NOT_CONFIGURED'}


def session(*, offline=False):
    s = new_session('e'*24, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI, offline=offline)
    return append_message(s, 'user', 'Review weekly notes')


class StubQuestionReader:
    def __init__(self, answer='Which notes should be checked?'):
        self.calls = []
        self.answer = answer

    def ask(self, saved, *, guidance=()):
        self.calls.append((saved['session_id'], tuple(guidance)))
        if isinstance(self.answer, Exception):
            raise self.answer
        return self.answer


class ModelPortTests(TestCase):
    def test_valid_routed_model_question_once_and_with_no_wiki(self):
        r = StubQuestionReader()
        outcome = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True)
        self.assertEqual(outcome.status, 'delivered')
        self.assertEqual(outcome.transitions, ('T03', 'T05', 'T08'))
        self.assertEqual(outcome.question, r.answer)
        self.assertEqual(outcome.calls, 1)
        self.assertEqual(len(r.calls), 1)
        self.assertEqual(r.calls[0][1], ())

    def test_denied_without_opt_in_or_hard_transport_or_active_session(self):
        for kwargs in ({'model_questions_opt_in': False},
                       {'model_questions_opt_in': True, 'transport_hardened': False}):
            with self.subTest(kwargs=kwargs):
                r = StubQuestionReader()
                outcome = route_model_question(r, session(), field='initial_task', **kwargs)
                self.assertEqual(outcome.calls, 0)
                self.assertEqual(r.calls, [])
        r = StubQuestionReader()
        out = route_model_question(r, session(offline=True), field='initial_task', model_questions_opt_in=True)
        self.assertEqual(out.calls, 0)

    def test_invalid_model_text_is_not_delivered_or_retried(self):
        for answer in ('Send me your password?', 'Please run curl https://bad.example',
                       'this is not a question'):
            with self.subTest(answer=answer):
                r = StubQuestionReader(answer)
                out = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True)
                self.assertIsNone(out.question)
                self.assertEqual(out.calls, 1)
                self.assertEqual(len(r.calls), 1)

    def test_model_interrupt_never_retries(self):
        r = StubQuestionReader(RuntimeError('interrupted'))
        with self.assertRaises(FormationError):
            route_model_question(r, session(), field='initial_task', model_questions_opt_in=True)
        self.assertEqual(len(r.calls), 1)

    def test_no_implicit_practice_sharing(self):
        r = StubQuestionReader()
        out = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True,
                                   guidance=(practice(),))
        self.assertEqual(out.calls, 0)
        self.assertFalse(r.calls)
        ok = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True,
                                  guidance=(practice(),), guidance_sharing_opt_in=True)
        self.assertEqual(ok.status, 'delivered')
        self.assertEqual(r.calls[0][1], (practice(),))

    def test_untrusted_broker_cards_cannot_be_promoted(self):
        r = StubQuestionReader()
        bad = dict(practice(), authority='APPROVED')
        out = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True,
                                   guidance=(bad,), guidance_sharing_opt_in=True)
        self.assertEqual(out.calls, 0)

    def test_post_model_transition_rejection_never_retries_model(self):
        from hwi_router import formation_model
        from hwi_router.core import Verdict
        original = formation_model._boot
        for blocked in ('model.question.result', 'formation.question.suggestion'):
            with self.subTest(blocked=blocked):
                def boot(ctx):
                    router, flow, src = original(ctx)
                    real = router.dispatch
                    def reject(flow_arg, source, packet):
                        if packet['kind'] == blocked:
                            return Verdict(False, 'F04', router.snapshot(flow_arg).phase)
                        return real(flow_arg, source, packet)
                    router.dispatch = reject
                    return router, flow, src
                r = StubQuestionReader()
                with patch('hwi_router.formation_model._boot', boot):
                    out = route_model_question(r, session(), field='initial_task',
                                               model_questions_opt_in=True)
                self.assertIsNone(out.question)
                self.assertEqual(len(r.calls), 1)
                self.assertEqual(out.calls, 1)

    def test_invalid_field_fails_before_model_effect(self):
        r = StubQuestionReader()
        out = route_model_question(r, session(), field='execute', model_questions_opt_in=True)
        self.assertEqual(out.calls, 0)
        self.assertEqual(r.calls, [])

    def test_routed_and_default_model_questions_store_same_record(self):
        results = []
        for routed in (False, True):
            with TemporaryDirectory() as temp:
                root = Path(temp)
                os.chmod(root, 0o700)
                store = FormationStore(root / 'f', create=True)
                s = new_session('e'*24, 'llama3.1:8b', 'http://127.0.0.1:11434', WIKI)
                store.create(s)
                reader = StubQuestionReader()
                answers = iter(['Review weekly notes', 'Only personal notebook', '/pause'])
                with (patch('hwi_formation.cli._ask', side_effect=lambda _: next(answers)),
                      redirect_stdout(StringIO())):
                    self.assertEqual(dialogue(store, s, model_questions=True,
                                              router_model_questions=routed,
                                              question_reader=reader), 0)
                self.assertEqual(len(reader.calls), 2)
                results.append(store.load(s['session_id']))
        self.assertEqual(results[0], results[1])

    def test_disabled_by_default_and_requires_explicit_model_consent(self):
        with patch('hwi_formation.cli.dialogue', return_value=0) as run, \
             patch('hwi_formation.cli.FormationStore') as store, \
             patch('hwi_formation.cli._practice_options', return_value=((), False)):
            store.return_value.load.return_value = {}
            self.assertEqual(main(['resume', 'e'*24]), 0)
            self.assertFalse(run.call_args.kwargs['router_model_questions'])
            self.assertEqual(main(['resume', 'e'*24, '--router-model-questions']), 2)
            self.assertEqual(main(['resume', 'e'*24, '--model-questions', '--router-model-questions']), 0)
            self.assertTrue(run.call_args.kwargs['router_model_questions'])

    def test_both_question_and_draft_ports_are_substitutable(self):
        observed = []
        expected = {'schema': 'hwi.formation.model_draft.v0'}
        draft = DirectModelDraftReader(lambda saved, *, guidance: (
            observed.append(('draft', saved['session_id'], guidance)) or expected))
        question = DirectModelQuestionReader(lambda saved, *, guidance: (
            observed.append(('question', saved['session_id'], guidance)) or 'Which notes?'))
        self.assertIs(draft.draft(session()), expected)
        self.assertEqual(question.ask(session()), 'Which notes?')
        self.assertEqual([kind for kind, *_ in observed], ['draft', 'question'])
        self.assertEqual([guidance for _, _, guidance in observed], [(), ()])

    def test_untrusted_model_reply_does_not_grant_approval_or_write(self):
        r = StubQuestionReader('Approve all future wiki changes?')
        out = route_model_question(r, session(), field='initial_task', model_questions_opt_in=True)
        self.assertIsNone(out.question)
        self.assertEqual(out.calls, 1)
