# Experimental advisory router — CMR-06

This package is an **isolated spike**, not a replacement for Formation,
PERSONAL.WIKI, governance, or AutoGPT Lite. It has **no tool, file, database,
network, model, queue, or privileged-effect executor**.

It implements the exact CMR-04 v1 JSON envelope and the eight CMR-05
advisory transitions. Contracts are read from `docs/consolidation` at trusted
bootstrap. `jsonschema` 4.x is required. There are no runtime imports from
approved provider/wiki sources or other candidate packages.

## API and trust boundary

An integrating application (not model-generated text) registers the trusted
`formation`, `knowledge_adapter`, and `model_adapter` source handles, registers
trusted session handles, supplies **pure** guard callbacks and handlers for
all transitions, then seals the registry. The application must keep capability
objects out of model prompts, untrusted plugins, tools, and chat content.
After sealing, registrations cannot change.

`AdvisoryRouter.issue_message(flow, source, kind, payload, ...)` issues a
fresh message ID and stamps the source from the held source handle. It is a
convenience for trusted adapters. `dispatch(flow, source, envelope)` also
supports preexisting serialized envelopes, but the trusted adapter is
responsible for ID creation. The router verifies producer-object identity,
origin, correlation, phase, causation parent, JSON schema, size/depth limits,
consent/scope guard callbacks, handler decision and exact effect allowlist
before committing the ephemeral coordinator phase. It deep-freezes JSON
payloads before calling handlers. No source string inside the message confers
identity.

**Important:** This is *in-process cooperation*, not a security sandbox.
Handles are not cryptographic credentials; a malicious Python component with
arbitrary memory or module access can violate the assumptions. All bound
callbacks and handlers must be trusted and side-effect free. Guard
implementations must check the **actual** Formation consent and broker pins,
not untrusted message-supplied Boolean flags. The test fixtures often use
`True` guards *only to exercise dispatch mechanics*.

The router returns an immutable `Verdict`, including **effect descriptors**
for three allowlisted advisory operations. A verdict never authorizes an
executor. Authorized adapters, introduced only in later checkpoints, must
recheck real session consent, notebook scope, sensitivity and transport
security independently before a single external call. No handler outputs
are automatically dispatched; future results require independent new
messages with correct parent IDs.

## Limits and known gaps

- Maximum 16 KiB UTF-8 message, 8 levels, 256 nodes and 8 dispatch hops.
- Exactly one sequential dispatch active at a time; concurrent or nested
  calls reject. There is **no** nested-task stack, network bus, or worker.
- No automatic retries, no error-to-LLM fallback and no privileged effects.
- Replay cache is bounded to 1,024 records by default, per live process;
  full cache rejects new IDs. It is **not durable exactly-once semantics**.
- Workflow deadline is checked before and after synchronous handlers; it
  **cannot preempt a blocked handler or an external request**. External
  adapters must implement their own transport timeouts.
- An interrupted handler marks the ephemeral flow aborted. The router does
  not roll back external side effects that a contract-violating handler
  might already have performed.
- No persistent audit store, live broker freshness proof, real Ollama
  transport fix or independent Formation adapter exists in CMR-06.
- No functional savings or reduced import count are claimed until vertical
  migrations are independently measured at CMR-07 and later.

## Reproduce

From the repository root:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B -m unittest -q hwi_router.test_router
PYTHONDONTWRITEBYTECODE=1 python -B -m hwi_router.benchmark
```

The benchmark compares an in-process no-op Python call to one fully validated
router dispatch. It is a rough overhead measurement, not an I/O or latency
benchmark. See `docs/consolidation/CMR-06_ROUTER_SPIKE.md` for coverage,
failures, scope and release status.

## CMR-07: optional Formation shadow observer

`formation_shadow.py` is an **opt-in, no-effect observer**. The Formation CLI
runs it only with `--router-shadow` (`start` / `resume`). It mirrors T06 on the
existing first-task guided question and, for already-consented read-only wiki
practice queries, T01→T02→T07 after the existing retrieval. It never executes
the router's effect descriptors, calls a model or wiki itself, or changes a
stored purpose contract. Both exceptions and rejection verdicts leave the
original Formation path in charge. The model guards are deliberately disabled
for this candidate. The return value is diagnostic parity only, not approval
or independent broker freshness proof.

Historical shadow-only evidence: `docs/consolidation/CMR-07_FORMATION_SHADOW.md`.
The shadow comparison alone did not reduce coupling; CMR-07 was subsequently
reworked into an actual knowledge port and accepted on 2026-11-14.

## CMR-07 rework: opt-in delivered knowledge port

`formation_knowledge.py` now provides an actual T01→T02→T07 read-only
practice-delivery adapter behind Formation's `PracticeReader` Protocol
(`hwi_formation/knowledge_port.py`). The normal CLI path still uses the
existing broker through `WikiPracticeReader`; `start` or `resume` with
`--router-practices` opts in to routed advisory data. Both paths require an
operator-provided query and a currently verified notebook pin. The new flag
may not be combined with `--router-shadow`. There is at most one broker
retrieval per request; a post-read route failure discards advisory results
and retains the guided dialogue. No permissions, model calls or wiki writes
are conferred by the router. The revised port received explicit operator engineering acceptance on
2026-11-14; it is **not** a production release. Details:
`docs/consolidation/CMR-07_REWORK_IMPLEMENTATION.md`.

## CMR-08: opt-in model-question port and hardened Formation transport

`formation_model.py` dispatches T03→T05→T08 for an explicitly opted-in
Formation model question. It executes **no** effect: trusted Formation calls
its `ModelQuestionReader` after a validated `model.question.generate`
descriptor, exactly once. The result must pass `check_question()` and typed
result/delivery checks before Formation's dialogue state machine may show it.
The existing direct model-question and draft services use injectable ports,
so the CLI no longer calls those functions directly. Drafts are deliberately
not represented as a question-message kind.

`hwi_formation/local_transport.py` wraps the separately approved Ollama
provider using numeric loopback destinations, `trust_env=False`, forbidden
redirects and constrained request paths/methods. This addresses the verified
redirect/proxy boundary for Formation only; it does not harden other callers
of the approved provider, prove process isolation, or provide a wall-clock
cancellation of synchronous Ollama calls. `--router-model-questions` also
requires `--model-questions`. Existing guided defaults and permissions remain.
