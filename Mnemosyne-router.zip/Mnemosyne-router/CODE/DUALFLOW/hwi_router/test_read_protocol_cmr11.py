"""CMR-11: profile isolation and strict transition/effect descriptor checks."""
from __future__ import annotations

import unittest

from .read_protocol import dispatch_read_message, open_read_profile


class ReadProfileTests(unittest.TestCase):
    def _open(self, profile):
        return open_read_profile(profile, lambda _name, _msg, _snapshot: True)

    def test_unknown_or_nonliteral_profiles_fail_closed(self):
        for value in ('CMR-08', '../CMR-10', 'CMR-10/../../', '', None, 10):
            with self.subTest(value=value), self.assertRaises(ValueError):
                open_read_profile(value, lambda _n, _m, _s: True)
        with self.assertRaises(ValueError):
            open_read_profile('CMR-10', None)

    def test_profile_sources_and_effects_are_independent(self):
        gov, _, gov_sources = self._open('CMR-10')
        dual, _, dual_sources = self._open('CMR-09')
        self.assertEqual(set(gov_sources), {'governance_operator', 'governance_projection'})
        self.assertEqual(set(dual_sources), {'dualflow_review', 'dualflow_simulator',
                                             'agent_evaluation', 'wiki_selection'})
        self.assertEqual(set(gov._effects), {'governance.status.read',
                                             'governance.proposal.review_read'})
        self.assertEqual(set(dual._effects), {'dualflow.simulation.read', 'agent.pinned_read'})
        for router in (gov, dual):
            self.assertNotIn('wiki.write', router._effects)
            self.assertNotIn('agent.execute', router._effects)
            with self.assertRaises(RuntimeError):
                router.register_session('post-seal')

    def test_known_transition_and_exact_effects(self):
        router, flow, src = self._open('CMR-09')
        request = dispatch_read_message(router, flow, src['dualflow_review'],
                         'dualflow.regression.request',
                         {'design_sha256': 'a'*64, 'scenario_sha256': 'b'*64},
                         transition='R01', effect='dualflow.simulation.read')
        self.assertEqual(len(request), 32)
        response = dispatch_read_message(router, flow, src['dualflow_simulator'],
                         'dualflow.regression.result',
                         {'design_sha256': 'a'*64, 'trace_sha256': 'c'*64},
                         parent=request, transition='R02')
        self.assertEqual(len(response), 32)

    def test_wrong_effect_or_transition_fails_closed(self):
        for check in ({'transition': 'R04', 'effect': 'dualflow.simulation.read'},
                      {'transition': 'R01', 'effect': 'agent.pinned_read'},
                      {'transition': 'R01'}):
            router, flow, src = self._open('CMR-09')
            with self.subTest(check=check), self.assertRaisesRegex(ValueError, 'read-only'):
                dispatch_read_message(router, flow, src['dualflow_review'],
                                      'dualflow.regression.request',
                                      {'design_sha256': 'a'*64, 'scenario_sha256': 'b'*64},
                                      **check)

    def test_untrusted_result_origin_rejected(self):
        router, flow, src = self._open('CMR-10')
        with self.assertRaises(ValueError):
            dispatch_read_message(router, flow, src['governance_projection'],
                                  'governance.status.request',
                                  {'notebook': 'primary', 'scope_sha256': 'a'*64},
                                  transition='G01', effect='governance.status.read')

    def test_component_guards_are_not_overridden(self):
        router, flow, src = open_read_profile('CMR-09', lambda _n, _m, _s: False)
        with self.assertRaises(ValueError):
            dispatch_read_message(router, flow, src['dualflow_review'],
                                  'dualflow.regression.request',
                                  {'design_sha256': 'a'*64, 'scenario_sha256': 'b'*64},
                                  transition='R01', effect='dualflow.simulation.read')


if __name__ == '__main__':
    unittest.main()
