"""Trusted, in-process Formation advisory routing guard bootstrap.

Internal adapter infrastructure, not an authorization or provenance service.
Source handles are issued only by this trusted integration; model-provided
strings never become trusted source identities. No effect is executed here.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping
import re

from .core import AdvisoryRouter, Decision, FrozenMessage, RouteSnapshot

_FIELDS = frozenset(('initial_task', 'domain', 'input_sources', 'expected_outputs',
                     'success_criteria', 'boundaries'))
_REF = re.compile(r'^hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*$')
_SHA = re.compile(r'^[0-9a-f]{64}$')

@dataclass
class _TrustedContext:
    active: bool
    query: str | None
    notebook_pinned: bool
    broker_read_complete: bool
    cards: tuple[tuple[str, str, str, str], ...]
    field: str
    question: str
    refs: tuple[str, ...]
    # CMR-08: enabled only when the trusted Formation owner explicitly opts in.
    model_questions_opt_in: bool = False
    guidance_sharing_opt_in: bool = False
    transport_hardened: bool = False
    pending_model_complete: bool = False


def _read_card(practice: Mapping[str, Any]) -> tuple[str, str, str, str]:
    """Use only one advisory check per previously verified broker result."""
    if (type(practice) is not dict or practice.get('source') != 'WIKI_UNTRUSTED'
            or practice.get('authority') != 'ADVISORY_ONLY'
            or practice.get('source_authenticated') is not False):
        raise ValueError('not a validated advisory broker practice')
    checks = practice.get('checks')
    if type(checks) is not list or not checks or type(checks[0]) is not dict:
        raise ValueError('missing advisory question')
    check = checks[0]
    field, question = check.get('field'), check.get('question')
    ref, sha = practice.get('ref'), practice.get('revision_sha256')
    if (field not in _FIELDS or type(question) is not str or not 1 <= len(question) <= 240
            or '\n' in question or any(ord(c) < 32 for c in question)
            or type(ref) is not str or not _REF.fullmatch(ref)
            or type(sha) is not str or not _SHA.fullmatch(sha)):
        raise ValueError('invalid pinned advisory card')
    return (field, question, ref, sha)


def _boot(ctx: _TrustedContext):
    router = AdvisoryRouter()
    sources = {name: router.register_source(name) for name in
               ('formation', 'knowledge_adapter', 'model_adapter')}
    session = router.register_session('cmr07-formation-shadow')

    def guard(name: str, msg: FrozenMessage, snap: RouteSnapshot) -> bool:
        payload = msg.payload
        if name in ('authenticated_formation_session', 'session_still_active'):
            return ctx.active
        if name == 'explicit_practice_query':
            return ctx.query is not None and payload.get('query') == ctx.query
        if name == 'notebook_scope_pin':
            return ctx.notebook_pinned
        if name == 'pending_knowledge_read':
            return ctx.broker_read_complete and snap.pending_request_id is not None
        if name == 'broker_current_revision':
            # The existing trusted broker adapter performed the current read.
            # Routing does not independently establish revision freshness.
            actual = tuple((p['field'], p['question'], p['ref'], p['revision_sha256'])
                           for p in payload.get('practices', ()))
            return ctx.broker_read_complete and actual == ctx.cards
        if name == 'bounded_cards':
            return len(ctx.cards) <= 3
        if name == 'trusted_assembler':
            return (msg.origin == 'formation' and payload.get('field') == ctx.field
                    and payload.get('question') == ctx.question)
        if name == 'question_field_valid':
            return payload.get('field') in _FIELDS and payload.get('field') == ctx.field
        if name == 'pinned_practice_refs_verified':
            return (bool(ctx.refs) and tuple(payload.get('practice_refs', ())) == ctx.refs
                    and ctx.broker_read_complete)
        # Model paths are CMR-08-only and must be explicitly activated by the
        # trusted owner, never by a message's self-declared origin or content.
        if name == 'model_questions_opt_in':
            return ctx.active and ctx.model_questions_opt_in
        if name == 'guidance_sharing_opt_in_if_refs':
            return not payload.get('practice_refs') or ctx.guidance_sharing_opt_in
        if name == 'transport_hardened_for_sensitive_input':
            return ctx.transport_hardened
        if name == 'pending_model_request':
            return ctx.pending_model_complete and snap.pending_request_id is not None
        if name == 'deterministic_question_validation':
            if not ctx.pending_model_complete:
                return False
            from hwi_formation.model import check_question
            try:
                return (check_question(payload.get('question')) == ctx.question)
            except ValueError:
                return False
        return False

    for name in {g for rule in router._rules.values() for g in rule.guards}:
        router.register_guard(name, lambda m, s, guard_name=name: guard(guard_name, m, s))
    for rule in router._rules.values():
        router.register_handler(rule.id, lambda _m, _s, intents=rule.effect_intents:
                                Decision(intents))
    router.seal()
    return router, router.open_flow(session), sources
