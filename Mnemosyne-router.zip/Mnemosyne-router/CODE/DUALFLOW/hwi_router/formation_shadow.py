"""CMR-07 opt-in Formation shadow observer; never an effect executor.

Observes already-selected Formation questions and already-completed explicitly
consented practice reads. It does not own the dialogue, perform I/O, authorize
anything, change a purpose draft, or touch persisted Formation state.

This is an in-process comparison experiment. Source handles are kept within
this trusted adapter; callers must not accept shadow context from model output.
"""
from __future__ import annotations

from dataclasses import dataclass
from .formation_bridge import _TrustedContext, _boot, _read_card


@dataclass(frozen=True)
class Observation:
    """Transient, non-authoritative comparison (not a persistence record)."""
    parity: bool
    transitions: tuple[str, ...]
    status: str
    baseline_question: str | None = None
    routed_question: str | None = None


def observe_guided(field: str, question: str, *, active: bool) -> Observation:
    """Compare routed T06 advisory suggestion with the current guided prompt.

    The caller still renders and saves its original question independently.
    """
    if type(field) is not str or type(question) is not str:
        return Observation(False, (), 'invalid_input')
    ctx = _TrustedContext(active, None, False, False, (), field, question, ())
    try:
        router, flow, sources = _boot(ctx)
        msg = router.issue_message(flow, sources['formation'],
                'formation.question.suggestion',
                {'field': field, 'question': question, 'practice_refs': []})
        verdict = router.dispatch(flow, sources['formation'], msg)
        matched = (verdict.accepted and verdict.transition_id == 'T06'
                   and tuple(e.kind for e in verdict.effects) == ('formation.question.deliver',))
        return Observation(matched, (verdict.transition_id,) if matched else (),
                           'match' if matched else 'rejected', question,
                           question if matched else None)
    except Exception:
        # Shadow cannot affect Formation's existing guided fallback.
        return Observation(False, (), 'shadow_unavailable', question)


def observe_practices(query: str, practices: tuple[dict, ...], *, active: bool,
                      notebook_pinned: bool, broker_read_complete: bool) -> Observation:
    """Mirror T01 -> T02 -> T07 AFTER the existing authorized read.

    No additional retrieval or model call occurs. The first check in the
    first broker result is a test suggestion, not a replacement for the
    existing multi-finding ``review_draft`` output.
    """
    try:
        if type(query) is not str or type(practices) is not tuple or len(practices) > 3:
            raise ValueError('invalid shadow input')
        cards = tuple(_read_card(p) for p in practices)
        chosen = cards[0] if cards else (None, None, None, None)
        refs = (chosen[2],) if cards else ()
        ctx = _TrustedContext(active, query, notebook_pinned,
                              broker_read_complete, cards, chosen[0], chosen[1], refs)
        router, flow, src = _boot(ctx)
        request = router.issue_message(flow, src['formation'], 'formation.practice.request',
                                       {'query': query, 'limit': 3})
        v1 = router.dispatch(flow, src['formation'], request)
        if (not v1.accepted or v1.transition_id != 'T01' or
                tuple(e.kind for e in v1.effects) != ('knowledge.practice.read',)):
            return Observation(False, (), 'request_rejected')
        result = router.issue_message(flow, src['knowledge_adapter'],
                   'knowledge.practice.result',
                   {'practices': [{'field': f, 'question': q, 'ref': ref,
                                  'revision_sha256': sha} for f, q, ref, sha in cards]},
                   parent=request['message_id'])
        v2 = router.dispatch(flow, src['knowledge_adapter'], result)
        if not v2.accepted or v2.transition_id != 'T02':
            return Observation(False, ('T01',), 'result_rejected')
        if not cards:
            return Observation(True, ('T01', 'T02'), 'no_cards')
        suggestion = router.issue_message(flow, src['formation'],
                     'formation.question.suggestion',
                     {'field': chosen[0], 'question': chosen[1], 'practice_refs': list(refs)},
                     parent=result['message_id'])
        v3 = router.dispatch(flow, src['formation'], suggestion)
        matched = (v3.accepted and v3.transition_id == 'T07' and
                   tuple(e.kind for e in v3.effects) == ('formation.question.deliver',))
        return Observation(matched, ('T01', 'T02', 'T07') if matched else ('T01', 'T02'),
                           'match' if matched else 'suggestion_rejected', chosen[1],
                           chosen[1] if matched else None)
    except Exception:
        return Observation(False, (), 'shadow_unavailable')
