"""CMR-07 opt-in read-only routed practice delivery.

The Formation CLI validates explicit operator query + current notebook pin
before calling this adapter. Router T01 allows a trusted owner to invoke the
read-only PracticeReader ONCE; T02 validates a bounded evidence projection,
then T07 permits advisory delivery. The broker's original fully parsed practice
records are handed to Formation only if routing validates their projection.

The adapter never runs an arbitrary effect, writes, calls Ollama or authorizes
anything. If a route fails before a read, the existing authorized direct port
may be used once. After a read, a failed validation discards the advisory
result rather than accepting unverified frames or repeating the broker query.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .formation_bridge import _TrustedContext, _boot, _read_card

if TYPE_CHECKING:
    from hwi_formation.knowledge_port import PracticeReader


@dataclass(frozen=True)
class RoutedPractices:
    practices: tuple[dict, ...]
    status: str
    transitions: tuple[str, ...]
    read_count: int


def route_practices(reader: PracticeReader, workspace: str, notebook: str,
                    query: str, *, active: bool, notebook_pinned: bool) -> RoutedPractices:
    """Route one trusted, previously consented practice request.

    Reader substitution is a trusted Python integration hook, never a message
    field. The same reader supports both the direct and routed CLI paths.
    """
    if not active or not notebook_pinned:
        return RoutedPractices((), 'scope_rejected', (), 0)
    reads = 0
    transitions: list[str] = []

    def read_once() -> tuple[dict, ...]:
        nonlocal reads
        if reads:
            raise RuntimeError('practice port already used for this request')
        reads += 1
        result = reader.read(workspace, notebook, query)
        if type(result) is not tuple:
            raise ValueError('PracticeReader must return a tuple')
        return result

    def fallback() -> RoutedPractices:
        # This is an *already-authorized* direct read, never an effect
        # executed by the router or an automatic retry of a completed read.
        if reads:
            return RoutedPractices((), 'route_rejected_after_read', tuple(transitions), reads)
        return RoutedPractices(read_once(), 'direct_fallback', tuple(transitions), reads)

    ctx = _TrustedContext(active, query, notebook_pinned, False,
                          (), '', '', ())
    try:
        router, flow, src = _boot(ctx)
        request = router.issue_message(flow, src['formation'],
                      'formation.practice.request', {'query': query, 'limit': 3})
        v1 = router.dispatch(flow, src['formation'], request)
        if (not v1.accepted or v1.replayed or v1.transition_id != 'T01' or
                tuple(e.kind for e in v1.effects) != ('knowledge.practice.read',)):
            return fallback()
        transitions.append('T01')
    except Exception:
        return fallback()

    # The only real I/O is the same existing, explicitly scoped broker read.
    # Errors from the port are not suppressed or automatically retried.
    practices = read_once()
    try:
        if len(practices) > 3:
            return fallback()
        cards = tuple(_read_card(p) for p in practices)
        ctx.cards = cards
        ctx.broker_read_complete = True
        result = router.issue_message(flow, src['knowledge_adapter'],
                   'knowledge.practice.result',
                   {'practices': [{'field': f, 'question': q, 'ref': ref,
                                  'revision_sha256': sha} for f, q, ref, sha in cards]},
                   parent=request['message_id'])
        v2 = router.dispatch(flow, src['knowledge_adapter'], result)
        if not v2.accepted or v2.replayed or v2.transition_id != 'T02' or v2.effects:
            return fallback()
        transitions.append('T02')
        if not cards:
            return RoutedPractices((), 'no_cards', tuple(transitions), reads)
        chosen = cards[0]
        ctx.field, ctx.question, ctx.refs = chosen[0], chosen[1], (chosen[2],)
        suggestion = router.issue_message(flow, src['formation'],
                     'formation.question.suggestion',
                     {'field': ctx.field, 'question': ctx.question,
                      'practice_refs': list(ctx.refs)}, parent=result['message_id'])
        v3 = router.dispatch(flow, src['formation'], suggestion)
        if (not v3.accepted or v3.replayed or v3.transition_id != 'T07' or
                tuple(e.kind for e in v3.effects) != ('formation.question.deliver',)):
            return fallback()
        transitions.append('T07')
        # Real consumption: Formation receives these broker-validated practices
        # *only* through this successful routed result; shadow merely compared.
        return RoutedPractices(practices, 'delivered', tuple(transitions), reads)
    except Exception:
        return fallback()
