"""Experimental, advisory-only deterministic router (CMR-06).

No integration with Formation, the wiki, governance, or the agent runtime.
"""
from .core import (AdvisoryRouter, Decision, EffectIntent, FrozenMessage,
                   RouteSnapshot, SourceHandle, SessionHandle, FlowHandle, Verdict)

__all__ = ['AdvisoryRouter', 'Decision', 'EffectIntent', 'FrozenMessage',
           'RouteSnapshot', 'SourceHandle', 'SessionHandle', 'FlowHandle', 'Verdict']
