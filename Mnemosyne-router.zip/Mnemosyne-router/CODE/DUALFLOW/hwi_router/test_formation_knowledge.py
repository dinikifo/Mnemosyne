"""CMR-07 actual port-substitution, parity and failure tests (offline only)."""
from __future__ import annotations

from contextlib import redirect_stdout
from copy import deepcopy
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest import TestCase, main
from unittest.mock import patch

from hwi_formation.cli import _practice_options, dialogue
from hwi_formation.core import FormationError, new_session
from hwi_formation.good_practices import review_draft
from hwi_formation.storage import FormationStore
from hwi_formation.wiki_adapter import inspect_wiki
from hwi_router.formation_knowledge import route_practices
def practice():
    return {'source':'WIKI_UNTRUSTED', 'authority':'ADVISORY_ONLY',
            'source_authenticated':False,
            'ref':'hwi05://' + 'a'*64 + '/' + 'b'*32 + '@1',
            'revision_sha256':'c'*64,
            'title':'synthetic offline fixture', 'domain':'comparison',
            'guidance':'Review sources',
            'checks':[{'field':'success_criteria',
                       'question':'How can a reviewer verify this result?'}]}

QUERY = 'Numerical comparison'


class StubReader:
    """Same read-only PracticeReader protocol; never opens a notebook."""
    def __init__(self, practices=None):
        self.data = (practice(),) if practices is None else practices
        self.calls = []

    def read(self, workspace, notebook, query):
        self.calls.append((workspace, notebook, query))
        return self.data


def args(*, routed=False, query=QUERY, notebook='primary'):
    return SimpleNamespace(practice_query=query, wiki_workspace='/synthetic',
                           notebook=notebook, router_practices=routed,
                           router_shadow=False)


def session():
    return new_session('9'*24, 'llama3.1:8b', 'http://127.0.0.1:11434',
                       {'status':'READ_ONLY_READY', 'notebook':'primary',
                        'notebook_scope':'test-pin'}, offline=True)


def run_options(reader, *, routed):
    with (patch('hwi_formation.cli.inspect_wiki', return_value={'notebook_scope': 'test-pin'}),
          redirect_stdout(StringIO()) as text):
        result = _practice_options(args(routed=routed), session(), reader=reader)
    return result, text.getvalue()


class KnowledgePortTests(TestCase):
    def test_real_substitution_not_monkeypatch_of_formation_logic(self):
        source = StubReader()
        (data, share), output = run_options(source, routed=True)
        self.assertEqual(data, source.data)
        self.assertFalse(share)
        self.assertEqual(source.calls, [('/synthetic', 'primary', QUERY)])
        self.assertIn('routed practices: delivered (1 read; 3 transitions)', output)
        self.assertNotIn('test-pin', output)
        self.assertNotIn('/synthetic', output)

    def test_default_and_routed_are_exactly_the_same_advisory_data(self):
        default, _ = run_options(StubReader(), routed=False)
        candidate, _ = run_options(StubReader(), routed=True)
        self.assertEqual(default, candidate)

    def test_zero_cards_are_a_valid_route(self):
        r = StubReader(())
        data, output = run_options(r, routed=True)
        self.assertEqual(data, ((), False))
        self.assertEqual(len(r.calls), 1)
        self.assertIn('no_cards', output)

    def test_shadow_and_routed_flags_cannot_be_combined(self):
        r = StubReader()
        choice = args(routed=True)
        choice.router_shadow = True
        with self.assertRaises(FormationError):
            _practice_options(choice, session(), reader=r)
        self.assertEqual(r.calls, [])

    def test_no_explicit_query_never_touches_port(self):
        r = StubReader()
        with redirect_stdout(StringIO()):
            self.assertEqual(_practice_options(args(routed=True, query=None), session(), reader=r), ((), False))
        self.assertEqual(r.calls, [])

    def test_notebook_mismatch_refuses_before_any_read(self):
        r = StubReader()
        with self.assertRaises(FormationError):
            _practice_options(args(routed=True, notebook='another'), session(), reader=r)
        self.assertEqual(r.calls, [])

    def test_instance_scope_mismatch_refuses_before_any_read(self):
        r = StubReader()
        with patch('hwi_formation.cli.inspect_wiki', return_value={'notebook_scope':'new-pin'}):
            with self.assertRaises(FormationError):
                _practice_options(args(routed=True), session(), reader=r)
        self.assertEqual(r.calls, [])

    def test_bad_query_rejected_before_read_even_if_stub_would_allow_it(self):
        r = StubReader()
        with self.assertRaises(FormationError):
            _practice_options(args(routed=True, query='bad\nquery'), session(), reader=r)
        self.assertEqual(r.calls, [])

    def test_no_scope_returns_nothing_without_read(self):
        r = StubReader()
        result = route_practices(r, '/synthetic', 'primary', QUERY,
                                 active=False, notebook_pinned=True)
        self.assertEqual(result.status, 'scope_rejected')
        self.assertEqual(result.read_count, 0)
        self.assertEqual(r.calls, [])

    def test_malformed_evidence_is_not_delivered_or_read_again(self):
        for edits in (dict(ref='forged'), dict(authority='APPROVED'),
                      dict(source_authenticated=True),
                      dict(checks=[{'field':'execution_authorized','question':'Write now'}])):
            with self.subTest(edits=edits):
                item = practice()
                item.update(edits)
                r = StubReader((item,))
                result = route_practices(r, '/synthetic', 'primary', QUERY,
                                        active=True, notebook_pinned=True)
                self.assertEqual(result.practices, ())
                self.assertEqual(result.status, 'route_rejected_after_read')
                self.assertEqual(result.read_count, 1)
                self.assertEqual(len(r.calls), 1)

    def test_oversized_practice_result_is_discarded_once(self):
        r = StubReader((practice(),)*4)
        result = route_practices(r, '/synthetic', 'primary', QUERY,
                                 active=True, notebook_pinned=True)
        self.assertEqual(result.practices, ())
        self.assertEqual(result.read_count, 1)
        self.assertEqual(len(r.calls), 1)

    def test_router_fails_before_read_then_original_authorized_reader_runs_once(self):
        r = StubReader()
        with patch('hwi_router.formation_knowledge._boot', side_effect=RuntimeError('broken')):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.practices, r.data)
        self.assertEqual(result.status, 'direct_fallback')
        self.assertEqual(len(r.calls), 1)

    def test_rejected_t01_effect_cannot_trigger_reader_directly(self):
        r = StubReader()
        from hwi_router import formation_knowledge as adapter
        original = adapter._boot
        def reject(ctx):
            router, flow, sources = original(ctx)
            old = router.dispatch
            def dispatch(flow_handle, source, raw):
                if raw['kind'] == 'formation.practice.request':
                    from hwi_router.core import Verdict
                    return Verdict(False, 'F04', 'READY')
                return old(flow_handle, source, raw)
            router.dispatch = dispatch
            return router, flow, sources
        with patch('hwi_router.formation_knowledge._boot', side_effect=reject):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.status, 'direct_fallback')
        self.assertEqual(len(r.calls), 1)

    def test_forged_origin_after_read_fails_closed_without_second_read(self):
        r = StubReader()
        from hwi_router import formation_knowledge as adapter
        original = adapter._boot
        def spoof(ctx):
            router, flow, sources = original(ctx)
            old = router.issue_message
            def issue(flow_handle, source, kind, payload, **kwargs):
                packet = old(flow_handle, source, kind, payload, **kwargs)
                if kind == 'knowledge.practice.result':
                    packet['origin'] = 'formation'
                return packet
            router.issue_message = issue
            return router, flow, sources
        with patch('hwi_router.formation_knowledge._boot', side_effect=spoof):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.practices, ())
        self.assertEqual(result.read_count, 1)
        self.assertEqual(len(r.calls), 1)

    def test_replay_id_after_read_fails_closed(self):
        r = StubReader()
        from hwi_router import formation_knowledge as adapter
        original = adapter._boot
        def replay(ctx):
            router, flow, sources = original(ctx)
            old = router.issue_message
            first = []
            def issue(flow_handle, source, kind, payload, **kwargs):
                packet = old(flow_handle, source, kind, payload, **kwargs)
                if kind == 'formation.practice.request':
                    first.append(packet['message_id'])
                if kind == 'knowledge.practice.result':
                    packet['message_id'] = first[0]
                return packet
            router.issue_message = issue
            return router, flow, sources
        with patch('hwi_router.formation_knowledge._boot', side_effect=replay):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.practices, ())
        self.assertEqual(len(r.calls), 1)

    def test_timeout_after_read_fails_closed_without_retry(self):
        r = StubReader()
        from hwi_router import formation_knowledge as adapter
        original = adapter._boot
        def expire(ctx):
            router, flow, sources = original(ctx)
            old = router.dispatch
            def dispatch(flow_handle, source, raw):
                if raw['kind'] == 'knowledge.practice.result':
                    router._flows[id(flow_handle)].start -= 99999
                return old(flow_handle, source, raw)
            router.dispatch = dispatch
            return router, flow, sources
        with patch('hwi_router.formation_knowledge._boot', side_effect=expire):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.practices, ())
        self.assertEqual(len(r.calls), 1)

    def test_interrupted_handler_after_read_fails_closed_without_retry(self):
        r = StubReader()
        from hwi_router import formation_knowledge as adapter
        original = adapter._boot
        def interrupt(ctx):
            router, flow, sources = original(ctx)
            def broken(*_):
                raise RuntimeError('interrupted')
            router._handlers['T02'] = broken
            return router, flow, sources
        with patch('hwi_router.formation_knowledge._boot', side_effect=interrupt):
            result = route_practices(r, '/synthetic', 'primary', QUERY,
                                     active=True, notebook_pinned=True)
        self.assertEqual(result.practices, ())
        self.assertEqual(len(r.calls), 1)

    def test_port_read_failure_is_not_hidden_or_retried(self):
        class BadReader(StubReader):
            def read(self, workspace, notebook, query):
                self.calls.append((workspace,notebook,query))
                raise FormationError('broker unavailable')
        r = BadReader()
        with self.assertRaises(FormationError):
            route_practices(r, '/synthetic', 'primary', QUERY,
                             active=True, notebook_pinned=True)
        self.assertEqual(len(r.calls), 1)

    def test_verified_real_broker_has_identical_references_and_no_writes(self):
        import json
        from personal_wiki_core import NotebookWorkspace
        from hwi_formation.good_practices import PRACTICE_SCHEMA
        from hwi_formation.knowledge_port import retrieve_practices
        with TemporaryDirectory() as folder:
            root = Path(folder) / 'wiki'
            ws = NotebookWorkspace(root, create=True)
            ws.create_notebook('primary')
            item = {'schema': PRACTICE_SCHEMA, 'domain': 'Review',
                    'guidance': 'Check one source',
                    'checks': [{'field':'success_criteria',
                                'question':'How will the reviewer verify it?'}]}
            with ws.open_notebook('primary', readonly=False) as wiki:
                wiki.save_tiddler('Numerical comparison verified practice',
                                  json.dumps(item), ['practice'],
                                  fields={'hwi_formation_kind':'good_practice'},
                                  reason='Offline routed port test fixture')
                wiki.knowledge_catalog().initialize()
            scope = inspect_wiki(str(root), 'primary')
            record = new_session('f'*24, 'llama3.1:8b',
                        'http://127.0.0.1:11434', scope, offline=True)
            before = {str(p.relative_to(root)): p.read_bytes()
                      for p in root.rglob('*') if p.is_file()}
            base_args = SimpleNamespace(practice_query=QUERY,
                      wiki_workspace=str(root), notebook='primary',
                      router_practices=False, router_shadow=False)
            route_args = SimpleNamespace(practice_query=QUERY,
                      wiki_workspace=str(root), notebook='primary',
                      router_practices=True, router_shadow=False)
            with (patch('hwi_formation.knowledge_port.retrieve_practices', wraps=retrieve_practices) as calls,
                  redirect_stdout(StringIO()) as output):
                baseline = _practice_options(base_args,record)
                routed = _practice_options(route_args,record)
            self.assertEqual(calls.call_count, 2)  # one broker retrieval per operator request
            self.assertEqual(baseline, routed)
            self.assertEqual(len(routed[0]),1)
            self.assertEqual(routed[0][0]['ref'],baseline[0][0]['ref'])
            self.assertEqual(routed[0][0]['revision_sha256'],baseline[0][0]['revision_sha256'])
            self.assertIn('routed practices: delivered',output.getvalue())
            self.assertEqual(before, {str(p.relative_to(root)):p.read_bytes()
                                      for p in root.rglob('*') if p.is_file()})

    def test_twelve_opening_answers_have_the_same_records_with_routed_practices(self):
        cases = (
            ('Help with my notes', 'Organize'),
            ('Research', 'Research all entries'),
            ('I need a weekly summary', 'Summarize meeting notes'),
            ('A task with a clear goal', 'Classify incoming notes by topic'),
            ('Improve my workflow', 'Extract references from selected notes'),
            ('Unknown objective', 'Not yet specified'),
            ('Organize research findings', 'Tag research claims'),
            ('Review project records', 'Compare two cited records'),
            ('Help me with my notes', 'Identify duplicate paragraphs'),
            ('I need a domain assistant', 'List the source documents'),
            ('Track outcomes', 'Report completed checklist items'),
            ('Build a knowledge index', 'Identify missing source citations'),
        )
        def execute(purpose, task, routed):
            reader = StubReader()
            with TemporaryDirectory() as folder:
                store = FormationStore(Path(folder) / 'formation', create=True)
                record = session()
                store.create(deepcopy(record))
                practices, _ = run_options(reader, routed=routed)[0]
                with (patch('hwi_formation.cli._ask',side_effect=[purpose,task,'/finish','PAUSE']),
                      redirect_stdout(StringIO())):
                    self.assertEqual(dialogue(store, record, practices=practices), 0)
                return store.load(record['session_id']), review_draft(store.load(record['session_id'])['draft'], practices), len(reader.calls)
        for purpose, task in cases:
            with self.subTest(purpose=purpose):
                a, ar, acalls = execute(purpose,task,False)
                b, br, bcalls = execute(purpose,task,True)
                self.assertEqual(a,b)
                self.assertEqual(ar,br)
                self.assertEqual((acalls,bcalls), (1,1))

    def test_explicit_confirm_contract_parity_with_routed_practices(self):
        def execute(routed):
            with TemporaryDirectory() as folder:
                store = FormationStore(Path(folder) / 'formation', create=True)
                record = session()
                store.create(deepcopy(record))
                practices, _ = run_options(StubReader(), routed=routed)[0]
                with (patch('hwi_formation.cli._ask',side_effect=['Compare notes','Summarize notes','/finish','CONFIRM']),
                      redirect_stdout(StringIO())):
                    self.assertEqual(dialogue(store,record,practices=practices),0)
                return store.load(record['session_id']), store.read_contract(record['session_id'])
        self.assertEqual(execute(False),execute(True))


if __name__ == '__main__':
    main()
