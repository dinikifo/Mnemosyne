"""CMR-11: shared bootstrap for two *fixed*, read-only advisory profiles.

This removes duplicated bootstrap/dispatch plumbing in CMR-09/10 without
centralizing business validation. No handlers perform I/O and an accepted
EffectIntent is not authorization to execute an effect. Only trusted Python
callers can select a hardcoded profile; message payloads cannot select one.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Mapping

from .core import AdvisoryRouter, Decision, FrozenMessage, RouteSnapshot

_ROOT = Path(__file__).resolve().parents[1] / 'docs' / 'consolidation'
_BASE = ('CMR-04_MESSAGE_SCHEMA_V1.json', 'CMR-04_COMPATIBILITY.json',
         'CMR-05_TRANSITION_MATRIX.json', 'CMR-05_EFFECT_POLICY.json')
_PROFILES = {
    'CMR-09': {
        'files': ('CMR-09_MESSAGE_SCHEMA.json', 'CMR-09_COMPATIBILITY.json',
                  'CMR-09_TRANSITION_MATRIX.json', 'CMR-09_EFFECT_POLICY.json'),
        'sources': ('dualflow_review', 'dualflow_simulator', 'agent_evaluation', 'wiki_selection'),
        'session': 'cmr09-read-only',
    },
    'CMR-10': {
        'files': ('CMR-10_MESSAGE_SCHEMA.json', 'CMR-10_COMPATIBILITY.json',
                  'CMR-10_TRANSITION_MATRIX.json', 'CMR-10_EFFECT_POLICY.json'),
        'sources': ('governance_operator', 'governance_projection'),
        'session': 'cmr10-governance-read',
    },
}


def open_read_profile(profile: str,
                      guard: Callable[[str, FrozenMessage, RouteSnapshot], bool]):
    """Build a fresh single-session router from an immutable allowlisted profile.

    The supplied guard belongs to the owning component. The helper binds all
    guards fail closed and never supplies a universal success/authority guard.
    """
    if type(profile) is not str or profile not in _PROFILES or not callable(guard):
        raise ValueError('unknown CMR read-only profile or guard')
    definition = _PROFILES[profile]
    contracts = {base: json.loads((_ROOT / replacement).read_text('utf-8'))
                 for base, replacement in zip(_BASE, definition['files'])}
    router = AdvisoryRouter(contracts=contracts)
    sources = {name: router.register_source(name) for name in definition['sources']}
    session = router.register_session(definition['session'])
    for name in {g for rule in router._rules.values() for g in rule.guards}:
        router.register_guard(name, lambda m, s, key=name: guard(key, m, s))
    for rule in router._rules.values():
        router.register_handler(rule.id, lambda _m, _s, intents=rule.effect_intents:
                                Decision(intents))
    router.seal()
    return router, router.open_flow(session), sources


def dispatch_read_message(router: AdvisoryRouter, flow, source, kind: str,
                          payload: Mapping, *, parent: str | None = None,
                          transition: str, effect: str | None = None) -> str:
    """Require exact transition and effect *descriptor* before returning an ID.

    Does not retry failed/uncertain reads, trigger handlers twice, or execute
    an effect. A message id is a causality reference, not an approval token.
    """
    packet = router.issue_message(flow, source, kind, payload, parent=parent)
    verdict = router.dispatch(flow, source, packet)
    expected = () if effect is None else (effect,)
    if (not verdict.accepted or verdict.replayed or
            verdict.transition_id != transition or
            tuple(item.kind for item in verdict.effects) != expected):
        raise ValueError('CMR typed read contract rejected (read-only)')
    return packet['message_id']
