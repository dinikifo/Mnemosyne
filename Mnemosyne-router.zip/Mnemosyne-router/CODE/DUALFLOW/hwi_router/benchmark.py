"""CMR-06 rough isolated-dispatch overhead comparison; NOT performance acceptance."""
from __future__ import annotations

import json
import platform
import statistics
import sys
from time import perf_counter

from hwi_router.test_router import fixture, packet


def measure(n: int = 500, repetitions: int = 3) -> dict:
    direct_samples = []
    router_samples = []
    for repeat in range(repetitions):
        seen = []
        def handler(message=None, context=None):
            seen.append(1)
        t0 = perf_counter()
        for _ in range(n):
            handler()
        direct_samples.append((perf_counter() - t0) / n * 1_000_000)
        r, session, src = fixture()
        flows_and_messages = []
        for i in range(n):
            flow = r.open_flow(session)
            msg = packet('formation.practice.request', flow, message_id=f'{repeat*n+i+1:032x}')
            flows_and_messages.append((flow, msg))
        t0 = perf_counter()
        for flow, msg in flows_and_messages:
            verdict = r.dispatch(flow, src['formation'], msg)
            if not verdict.accepted:
                raise RuntimeError(verdict.code)
        router_samples.append((perf_counter() - t0) / n * 1_000_000)
    return {
        'scope': 'microbenchmark: direct Python noop vs in-process schema validation/dispatch; no I/O, no LLM, no payload serialization in timed setup',
        'python': sys.version.split()[0],
        'platform': platform.platform(),
        'iterations_per_run': n, 'repetitions': repetitions,
        'direct_call_median_us': round(statistics.median(direct_samples), 3),
        'router_dispatch_median_us': round(statistics.median(router_samples), 3),
        'caveat': 'Direct baseline is a trivial no-op; ratios do not measure production workflow speed or model latency.'
    }


if __name__ == '__main__':
    print(json.dumps(measure(), indent=2))
