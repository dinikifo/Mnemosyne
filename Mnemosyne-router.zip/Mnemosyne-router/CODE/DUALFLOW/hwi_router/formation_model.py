"""CMR-08: opt-in typed routing of one Formation model question.

Router effects are descriptors; the trusted Formation owner calls its own
substitutable ModelQuestionReader once after T03 validates. This module never
instantiates Ollama, reads the wiki, persists a state, or expands authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from hwi_formation.model import ModelReplyRejected, check_question
from hwi_formation.core import FormationError
from .formation_bridge import _TrustedContext, _boot, _read_card

if TYPE_CHECKING:
    from hwi_formation.model_port import ModelQuestionReader


@dataclass(frozen=True)
class RoutedQuestion:
    question: str | None
    status: str
    transitions: tuple[str, ...]
    calls: int


def route_model_question(reader: ModelQuestionReader, session: dict, *,
                         field: str, model_questions_opt_in: bool,
                         guidance: tuple[dict, ...] = (),
                         guidance_sharing_opt_in: bool = False,
                         transport_hardened: bool = True) -> RoutedQuestion:
    """T03 -> T05 -> T08. No automatic model retry or fallback model call.

    Calling a model is never possible without session/model-question consent.
    Failure before a model call returns no answer. Failure after it returns no
    answer and leaves existing Formation guided fallback to the state machine.
    """
    if (not model_questions_opt_in or session.get('mode') != 'LOCAL_OLLAMA' or
            session.get('state') != 'IN_PROGRESS' or not transport_hardened):
        return RoutedQuestion(None, 'consent_or_transport_rejected', (), 0)

    steps: list[str] = []
    calls = 0
    try:
        if type(guidance) is not tuple or len(guidance) > 3:
            return RoutedQuestion(None, 'invalid_guidance', (), 0)
        cards = tuple(_read_card(item) for item in guidance)
        refs = tuple(card[2] for card in cards)
        if len(set(refs)) != len(refs) or (refs and not guidance_sharing_opt_in):
            return RoutedQuestion(None, 'guidance_consent_rejected', (), 0)
        # Prompt and field are selected by the trusted Formation owner.
        from hwi_formation.dialogue import guided_question
        prompt = guided_question(min(sum(m['role'] == 'user' for m in session['messages']), 6))
        ctx = _TrustedContext(True, None, False, False, cards, field, '', refs,
                              model_questions_opt_in=True,
                              guidance_sharing_opt_in=guidance_sharing_opt_in,
                              transport_hardened=transport_hardened)
        router, flow, src = _boot(ctx)
        request = router.issue_message(flow, src['formation'],
                        'formation.model_question.request',
                        {'field': field, 'prompt': prompt, 'practice_refs': list(refs)})
        v1 = router.dispatch(flow, src['formation'], request)
        if (not v1.accepted or v1.replayed or v1.transition_id != 'T03' or
                tuple(e.kind for e in v1.effects) != ('model.question.generate',)):
            return RoutedQuestion(None, 'request_rejected', (), 0)
        steps.append('T03')
    except Exception:
        return RoutedQuestion(None, 'request_rejected', tuple(steps), 0)

    # The one external model call crosses no router-held execution authority.
    # No retries: its outcome can be uncertain after a timeout/interruption.
    calls += 1
    try:
        answer = reader.ask(session, guidance=guidance if guidance_sharing_opt_in else ())
    except FormationError:
        raise
    except Exception as exc:
        raise FormationError('Local model unavailable; switch to manual mode') from exc
    try:
        validated = check_question(answer)
        ctx.question = validated
        ctx.pending_model_complete = True
        result = router.issue_message(flow, src['model_adapter'], 'model.question.result',
                                      {'question': validated}, parent=request['message_id'])
        v2 = router.dispatch(flow, src['model_adapter'], result)
        if not v2.accepted or v2.replayed or v2.transition_id != 'T05' or v2.effects:
            return RoutedQuestion(None, 'result_rejected', tuple(steps), calls)
        steps.append('T05')
        suggestion = router.issue_message(flow, src['formation'],
                          'formation.question.suggestion',
                          {'field': field, 'question': validated, 'practice_refs': list(refs)},
                          parent=result['message_id'])
        v3 = router.dispatch(flow, src['formation'], suggestion)
        if (not v3.accepted or v3.replayed or v3.transition_id != 'T08' or
                tuple(e.kind for e in v3.effects) != ('formation.question.deliver',)):
            return RoutedQuestion(None, 'suggestion_rejected', tuple(steps), calls)
        steps.append('T08')
        return RoutedQuestion(validated, 'delivered', tuple(steps), calls)
    except Exception:
        return RoutedQuestion(None, 'result_rejected', tuple(steps), calls)
