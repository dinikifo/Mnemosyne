#!/usr/bin/env python3
"""HWI-I02 local Ollama evaluation runner (read-only, no model install/pull).

Uses the approved CR03 OllamaProvider, strictly loopback endpoints, pinned
workflow inputs, and revision-bound WL-03 validation. A local protocol response
is not independent proof of model identity, output truth, or authority.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import platform
import re
import sys
import time
from urllib.parse import urlsplit
from typing import Any

from check_dualflow_design import DesignError, _need, load_design
from evaluate_dualflow_model import _model_id, _predeclared_reference, _task_text, evaluate_model_proposal
from patch_dualflow import load_patch
from review_dualflow import load_suite
from validate_dualflow_application import load_application
from simulate_dualflow import canonical_digest

DEFAULT_ENDPOINT = 'http://127.0.0.1:11434'
MAX_MODELS = 8
MAX_TAGS_BYTES = 1_048_576
SCHEMA = 'hwi.dualflow.local_ollama_trials.v0'


class ModelUnavailable(RuntimeError):
    """Local Ollama endpoint is not responding, not a model validation failure."""



def validate_loopback_endpoint(value: str) -> str:
    _need(type(value) is str and len(value) <= 100, 'invalid endpoint')
    parsed = urlsplit(value)
    _need(parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', '::1')
          and not parsed.username and not parsed.password and
          not parsed.path.strip('/') and not parsed.query and not parsed.fragment,
          'only explicit loopback HTTP endpoints are allowed')
    try:
        port = parsed.port
    except ValueError as exc:
        raise DesignError('invalid endpoint port') from exc
    _need(type(port) is int and 1 <= port <= 65535, 'loopback endpoint requires port')
    return f'http://[{parsed.hostname}]:{port}' if parsed.hostname == '::1' else f'http://127.0.0.1:{port}'


def installed_models(provider: Any) -> list[dict]:
    """Read local Ollama tags via the already approved provider's requests session.

    The caller uses an explicit loopback URL, disables environmental proxies,
    and refuses redirects. The returned metadata is locally reported, not signed.
    """
    try:
        response = provider._session.get(provider.base_url + '/api/tags',
                                         timeout=10, allow_redirects=False)
    except Exception as exc:
        if type(exc).__name__ == 'TooManyRedirects':
            raise DesignError('local Ollama redirected request') from exc
        raise ModelUnavailable('local Ollama endpoint not responding') from exc
    if response.status_code >= 500 or response.status_code == 404:
        raise ModelUnavailable('local Ollama tags unavailable')
    try:
        _need(response.status_code == 200, 'local Ollama tags rejected or redirected')
        _need(len(response.content) <= MAX_TAGS_BYTES, 'Ollama tags too large')
        data = response.json()
        _need(type(data) is dict and type(data.get('models')) is list,
              'Ollama tags malformed')
        _need(len(data['models']) <= 512, 'Ollama model list too large')
        output: list[dict] = []
        seen: set[str] = set()
        for entry in data['models']:
            _need(type(entry) is dict, 'invalid model metadata')
            name = _model_id(entry.get('name'))
            _need(name not in seen, 'duplicate Ollama model')
            seen.add(name)
            raw_digest = entry.get('digest')
            digest = None
            if type(raw_digest) is str:
                digest_text = raw_digest.removeprefix('sha256:').lower()
                if re.fullmatch('[0-9a-f]{64}', digest_text):
                    digest = digest_text
            output.append({'name': name, 'reported_digest_sha256': digest})
        return sorted(output, key=lambda x: x['name'])
    except (ValueError, TypeError, KeyError, AttributeError, OSError) as exc:
        raise DesignError('Ollama tags unavailable or invalid') from exc


def load_inputs(*, design: Path, task_file: Path, reference_patch: Path | None,
                regression: Path | None, application: Path | None) -> tuple[dict,str,dict|None,dict|None,dict|None]:
    _need(task_file.stat().st_size <= 4_800, 'task too large')
    task = _task_text(task_file.read_text(encoding='utf-8'))
    base = load_design(design)
    paths = (reference_patch, regression, application)
    _need(all(p is None for p in paths) or all(p is not None for p in paths),
          'reference benchmark needs patch, regression and application')
    if reference_patch is None:
        return base, task, None, None, None
    patch = load_patch(reference_patch)
    reg = load_suite(regression)
    app = load_application(application)
    _predeclared_reference(base, patch, reg, app)  # verify BEFORE contacting Ollama
    return base, task, patch, reg, app


def evaluate_local_models(*, provider: Any, installed: list[dict], model_names: list[str],
                          base: dict, task: str, reference_patch: dict | None,
                          regression_suite: dict | None, application_suite: dict | None,
                          repeats: int, pin_digests: dict[str, str] | None = None,
                          endpoint: str = DEFAULT_ENDPOINT) -> dict:
    _need(type(repeats) is int and 1 <= repeats <= 12, 'repeats must be 1..12')
    _need(type(model_names) is list and 1 <= len(model_names) <= MAX_MODELS,
          'select 1..8 models')
    _need(len(model_names) == len(set(model_names)), 'duplicate requested model')
    known = {m['name']:m for m in installed}
    pin_digests = pin_digests or {}
    _need(set(pin_digests).issubset(model_names), 'pin for unrequested model')
    for name in model_names:
        _model_id(name)
        _need(name in known, 'requested model not installed locally')
        expected = pin_digests.get(name)
        if expected is not None:
            _need(re.fullmatch('[0-9a-f]{64}', expected) is not None,
                  'invalid pinned model digest')
            _need(known[name]['reported_digest_sha256'] == expected,
                  'local Ollama model digest differs from the pin')
    # Validate external benchmark even when this is called programmatically.
    if reference_patch is not None:
        _need(regression_suite is not None and application_suite is not None,
              'incomplete reference suite')
        _predeclared_reference(base, reference_patch, regression_suite, application_suite)
    else:
        _need(regression_suite is None and application_suite is None,
              'incomplete reference suite')

    data = []
    for name in model_names:
        trials=[]
        for i in range(repeats):
            start = time.monotonic()
            result = evaluate_model_proposal(
                provider=provider, model=name, task=task, base=base,
                reference_patch=reference_patch, regression_suite=regression_suite,
                application_suite=application_suite, provider_kind='LOCAL_OLLAMA')
            duration = round(time.monotonic() - start, 3)
            trials.append({'index':i+1, 'duration_seconds':duration, 'report':result})
        counts = dict(sorted(Counter(t['report']['status'] for t in trials).items()))
        good_statuses = {'MODEL_PATCH_MATCHES_PINNED_REFERENCE',
                         'VALID_CANDIDATE_UNTESTED',
                         'CANDIDATE_MATCHES_DESIGN_DIFFERENT_PATCH_UNTESTED',
                         'VALID_ALTERNATIVE_NOT_BENCHMARK_VERIFIED'}
        valid_count = sum(counts.get(status, 0) for status in good_statuses)
        data.append({'model':name,
                     'local_reported_model_digest_sha256':known[name]['reported_digest_sha256'],
                     'trials':trials, 'outcome_counts':counts,
                     'structurally_valid_proposals':valid_count,
                     'structural_valid_percent':round(100.0 * valid_count/repeats,2),
                     'exact_reference_matches':counts.get('MODEL_PATCH_MATCHES_PINNED_REFERENCE',0),
                     'reference_match_percent':round(100.0 * counts.get('MODEL_PATCH_MATCHES_PINNED_REFERENCE',0)/repeats,2)})
    report = {'schema':SCHEMA, 'mode':'LOCAL_LOOPBACK_OLLAMA_PROTOCOL',
              'endpoint':validate_loopback_endpoint(endpoint),
              'workstation':{'os':platform.system(),'machine':platform.machine(),
                             'python':platform.python_version()},
              'base_sha256':canonical_digest(base), 'task_sha256':canonical_digest(task),
              'repeats_per_model':repeats,
              'benchmark_kind': 'PREDECLARED_SYNTHETIC_REFERENCE' if reference_patch is not None else 'STRUCTURAL_PROPOSALS_ONLY',
              'models':data,
              'all_outcomes':dict(sorted(Counter(t['report']['status'] for m in data for t in m['trials']).items())),
              'locally_reported_identity_not_independently_attested':True,
              'factual_correctness_not_independently_verified':True,
              'human_acceptance_obtained':False, 'execution_authorized':False,
              'protected_knowledge_write_authorized':False,
              'note': 'A live Ollama protocol response requires human review before any genuine-model competence claim.'}
    report['report_sha256'] = canonical_digest(report)
    return report


def parse_pins(values: list[str]) -> dict[str,str]:
    result={}
    for value in values:
        _need(type(value) is str and value.count('=') == 1, 'model pins must be NAME=SHA256')
        name,digest=value.split('=',1)
        _model_id(name)
        _need(name not in result, 'duplicate model pin')
        _need(re.fullmatch('[0-9a-f]{64}',digest) is not None, 'model pin must be 64 hex characters')
        result[name]=digest
    return result


def save_report_exclusive(path: Path, report: dict) -> None:
    text=json.dumps(report, sort_keys=True, indent=2, ensure_ascii=True)+'\n'
    # The report contains proposed workflow content and should not be world-readable.
    flags=os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd=os.open(path, flags, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(text)


def main(argv: list[str] | None = None) -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--endpoint', default=DEFAULT_ENDPOINT, help='HTTP loopback only; default 127.0.0.1:11434')
    p.add_argument('--list-models',action='store_true', help='list locally installed Ollama models and exit')
    p.add_argument('--model',action='append', default=[], help='installed model name; repeat for a comparison')
    p.add_argument('--pin-model',action='append',default=[],metavar='NAME=SHA256',help='optional installed model digest pin')
    p.add_argument('--design',type=Path)
    p.add_argument('--task-file',type=Path)
    p.add_argument('--reference-patch',type=Path)
    p.add_argument('--regression',type=Path)
    p.add_argument('--application',type=Path)
    p.add_argument('--repeats',type=int,default=3)
    p.add_argument('--output',type=Path,help='new, private JSON report file (never overwritten)')
    args=p.parse_args(argv)
    try:
        endpoint=validate_loopback_endpoint(args.endpoint)
        # Prevalidate input and pins before any network call.
        pins=parse_pins(args.pin_model)
        for m in args.model:_model_id(m)
        _need(type(args.repeats) is int and 1 <= args.repeats <= 12,
              'repeats must be 1..12')
        if args.list_models:
            _need(not args.model and not pins, '--list-models cannot run trials')
        else:
            _need(args.design is not None and args.task_file is not None and args.model,
                  'design, task-file and at least one model are required')
            base,task,patch,reg,app=load_inputs(
                design=args.design, task_file=args.task_file,
                reference_patch=args.reference_patch, regression=args.regression,
                application=args.application)
        from autogpt_lite.llm.ollama import OllamaProvider
        provider=OllamaProvider(base_url=endpoint)
        provider._session.trust_env=False  # no proxy environment overrides
        provider._session.max_redirects=0  # no redirect to other hosts
        installed=installed_models(provider)
        if args.list_models:
            print(json.dumps({'endpoint':endpoint,'installed_models':installed},indent=2))
            return 0
        output=evaluate_local_models(
            provider=provider,installed=installed,model_names=args.model,
            base=base,task=task,reference_patch=patch,regression_suite=reg,
            application_suite=app,repeats=args.repeats,pin_digests=pins,endpoint=endpoint)
        if args.output:
            save_report_exclusive(args.output,output)
            print(json.dumps({'report_path':str(args.output), 'report_sha256':output['report_sha256'],
                              'outcomes':output['all_outcomes']},sort_keys=True))
        else:
            print(json.dumps(output,sort_keys=True,indent=2,ensure_ascii=True))
        return 0
    except ModelUnavailable:
        print('MODEL_UNAVAILABLE: local Ollama endpoint not responding',file=sys.stderr)
        return 3
    except DesignError as exc:
        print('LOCAL_MODEL_TRIAL_REJECTED: '+ascii(str(exc)),file=sys.stderr)
        return 2
    except (OSError, ValueError, ImportError, UnicodeError, RuntimeError) as exc:
        # Avoid leaking HTTP credentials, model content or filesystem details.
        print('MODEL_UNAVAILABLE_OR_IO_ERROR: '+type(exc).__name__,file=sys.stderr)
        return 3


if __name__ == '__main__':
    raise SystemExit(main())
