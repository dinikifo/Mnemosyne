#!/usr/bin/env python3
"""Read-only offline wheelhouse preflight for RC-05.clean.

The check deliberately does NOT certify supplier custody or test completion.
A READY result means only that direct pins are present and pip's dry-run
resolver can construct a plan without accessing a package index.
"""

from __future__ import annotations

import argparse
import email
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone
from zipfile import BadZipFile, ZipFile

PIN_RE = re.compile(r"^\s*([A-Za-z0-9_.-]+)==([A-Za-z0-9_.!+]+)\s*(?:#.*)?$")


def canonical_name(value: str) -> str:
    return re.sub(r"[-_.]+", "-", value).lower()


def parse_requirements(path: Path) -> dict[str, str]:
    pins: dict[str, str] = {}
    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = PIN_RE.fullmatch(line)
        if not match:
            raise ValueError(f"Non-exact requirement at line {i}: {line.strip()!r}")
        name, version = canonical_name(match.group(1)), match.group(2)
        if name in pins:
            raise ValueError(f"Duplicate requirement: {name}")
        pins[name] = version
    if not pins:
        raise ValueError("No exact requirements found")
    return pins


def wheel_metadata(path: Path) -> tuple[str, str]:
    """Return normalized name and exact version after cross-checking wheel filename."""
    parts = path.name.removesuffix(".whl").split("-")
    if not path.name.endswith(".whl") or len(parts) < 5:
        raise ValueError("Invalid wheel filename")
    filename_name, filename_version = canonical_name(parts[0]), parts[1]
    try:
        with ZipFile(path) as archive:
            entries = [name for name in archive.namelist() if name.endswith(".dist-info/METADATA")]
            if len(entries) != 1:
                raise ValueError("Expected exactly one METADATA entry")
            content = archive.read(entries[0])
            if len(content) > 1024 * 1024:
                raise ValueError("METADATA too large")
    except BadZipFile as exc:
        raise ValueError("Corrupt wheel ZIP") from exc
    message = email.message_from_bytes(content)
    name = canonical_name(message.get("Name", ""))
    version = message.get("Version", "")
    if not name or not version or (name, version) != (filename_name, filename_version):
        raise ValueError("Wheel filename and METADATA disagree")
    return name, version


def inspect(wheelhouse: Path, requirements: Path, *, resolve: bool = True) -> dict:
    pins = parse_requirements(requirements)
    report = {
        "schema": "hwi.rc05.wheelhouse-preflight.v1",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "requirements_sha256": hashlib.sha256(requirements.read_bytes()).hexdigest(),
        "wheelhouse": str(wheelhouse.resolve()),
        "direct_requirements": pins,
        "wheels": [],
        "invalid_wheels": [],
        "missing_direct_pins": [],
        "status": "BLOCKED",
        "limits": [
            "Wheel presence and pip resolution are not human-controlled evidence custody",
            "A READY result is not a completed clean-environment test run",
        ],
    }
    if not wheelhouse.is_dir():
        report["status"] = "BLOCKED_NO_WHEELHOUSE"
        return report
    found: set[tuple[str, str]] = set()
    for wheel in sorted(wheelhouse.glob("*.whl")):
        try:
            name, version = wheel_metadata(wheel)
        except (ValueError, OSError) as exc:
            report["invalid_wheels"].append({"file": wheel.name, "error": str(exc)})
            continue
        digest = hashlib.sha256(wheel.read_bytes()).hexdigest()
        report["wheels"].append({"file": wheel.name, "name": name, "version": version, "sha256": digest})
        found.add((name, version))
    report["missing_direct_pins"] = [f"{name}=={version}" for name, version in pins.items() if (name, version) not in found]
    if report["invalid_wheels"]:
        report["status"] = "BLOCKED_INVALID_WHEELS"
        return report
    if report["missing_direct_pins"]:
        report["status"] = "BLOCKED_MISSING_DIRECT_WHEELS"
        return report
    if not resolve:
        report["status"] = "DIRECT_PINS_PRESENT_TRANSITIVES_UNCHECKED"
        return report
    cmd = [sys.executable, "-m", "pip", "install", "--dry-run", "--ignore-installed", "--no-index", "--only-binary=:all:",
           "--disable-pip-version-check", "--no-input", "--find-links", str(wheelhouse.resolve()), "-r", str(requirements.resolve())]
    env = dict(os.environ, PIP_NO_INDEX="1", PIP_CONFIG_FILE=os.devnull)
    try:
        finished = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env, check=False)
        report["resolver"] = {"exit_code": finished.returncode, "stdout_tail": finished.stdout[-4000:], "stderr_tail": finished.stderr[-4000:]}
        report["status"] = "READY_FOR_ISOLATED_INSTALL_NOT_TESTED" if finished.returncode == 0 else "BLOCKED_OFFLINE_RESOLUTION"
    except subprocess.TimeoutExpired:
        report["resolver"] = {"error": "Timed out after 90 seconds"}
        report["status"] = "BLOCKED_RESOLVER_TIMEOUT"
    return report


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--wheelhouse", type=Path, required=True)
    ap.add_argument("--requirements", type=Path, default=Path(__file__).resolve().parent.parent / "requirements-test.txt")
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    try:
        report = inspect(args.wheelhouse, args.requirements)
    except (ValueError, OSError) as exc:
        report = {"schema": "hwi.rc05.wheelhouse-preflight.v1", "status": "BLOCKED_INVALID_REQUIREMENTS", "error": str(exc)}
    data = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(data, encoding="utf-8")
    print(data, end="")
    return 0 if report["status"] == "READY_FOR_ISOLATED_INSTALL_NOT_TESTED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
