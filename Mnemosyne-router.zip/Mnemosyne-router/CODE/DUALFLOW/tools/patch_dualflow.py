#!/usr/bin/env python3
"""WL-03: bounded, review-only revisions of simulation-only dual-flow designs.

No workflow execution, wiki/PVS writes, signatures, approval, or tool dispatch.
All outputs, including declared tests and rationales, are untrusted proposals.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
from typing import Any

from check_dualflow_design import (
    DesignError, _items, _need, _object, _positive_int, _symbol,
    _unique_object, _reject_constant, check_design, load_design,
)
from simulate_dualflow import canonical_digest

PATCH_SCHEMA = "hwi.dualflow.patch.v0"
MAX_PATCH_BYTES = 128_000
MAX_OPERATIONS = 16


def load_patch(path: str | Path) -> dict:
    """Strict JSON input; duplicate keys and nonstandard numbers are forbidden."""
    path = Path(path)
    _need(path.stat().st_size <= MAX_PATCH_BYTES, "patch exceeds byte limit")
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)


def _patch_text(value: Any, where: str, *, min_length: int, max_length: int) -> str:
    _need(type(value) is str and min_length <= len(value) <= max_length
          and all(ch.isprintable() or ch == "\n" for ch in value),
          f"{where}: invalid bounded review text")
    return value


def _validate_patch_envelope(base: dict, patch: Any) -> list[dict]:
    _object(patch, {"schema", "workflow_id", "base_revision", "base_sha256",
                    "rationale", "tests_to_run", "operations"}, "patch")
    _need(patch["schema"] == PATCH_SCHEMA, "unsupported patch schema")
    _need(type(patch["workflow_id"]) is str and
          patch["workflow_id"] == base["workflow_id"], "workflow_id mismatch")
    _need(type(patch["base_revision"]) is int and
          patch["base_revision"] == base["revision"], "stale base revision")
    _need(type(patch["base_sha256"]) is str and
          patch["base_sha256"] == canonical_digest(base), "stale base SHA-256")
    _patch_text(patch["rationale"], "rationale", min_length=10, max_length=1000)
    _items(patch["tests_to_run"], "tests_to_run", minimum=1, maximum=16)
    ops = patch["operations"]
    _need(type(ops) is list and 1 <= len(ops) <= MAX_OPERATIONS,
          "operations: expected 1..16 entries")
    return ops


def propose_revision(base: Any, patch: Any) -> dict[str, Any]:
    """Apply a strictly bounded patch to a defensive copy, validate the complete design.

    Result is a *candidate*, not an accepted revision. Inputs remain unchanged.
    Raises DesignError without emitting partially modified designs.
    """
    check_design(base)
    _need(base["revision"] < 1_000_000, "revision range exhausted")
    operations = _validate_patch_envelope(base, patch)
    candidate = copy.deepcopy(base)
    seen: set[tuple[str, str]] = set()
    changes: list[dict] = []

    for index, raw in enumerate(operations):
        _need(type(raw) is dict and type(raw.get("op")) is str,
              f"operations[{index}]: invalid operation")
        verb = raw["op"]
        target: str
        before: Any
        after: Any
        if verb in {"add_flow", "replace_flow", "remove_flow"}:
            required = {"op", "value"} if verb == "add_flow" else (
                {"op", "id", "value"} if verb == "replace_flow" else {"op", "id"})
            _object(raw, required, f"operations[{index}]")
            if verb == "add_flow":
                value = _object(raw["value"], {"id", "capability", "inputs", "outputs",
                          "guards", "observations", "on_failure", "on_unknown"}, "flow.value")
                target = _symbol(value["id"], "flow.id")
            else:
                target = _symbol(raw["id"], "flow.id")
                if verb == "replace_flow":
                    value = _object(raw["value"], {"id", "capability", "inputs", "outputs",
                              "guards", "observations", "on_failure", "on_unknown"}, "flow.value")
                    _need(type(value["id"]) is str and value["id"] == target,
                          "replace_flow cannot rename ID")
            key = ("flow", target)
            existing = next((i for i, f in enumerate(candidate["flows"]) if f["id"] == target), None)
            if verb == "add_flow":
                _need(existing is None, "add_flow requires a fresh ID")
                before, after = None, copy.deepcopy(value)
                candidate["flows"].append(after)
            else:
                _need(existing is not None, "flow target does not exist")
                before = copy.deepcopy(candidate["flows"][existing])
                after = copy.deepcopy(value) if verb == "replace_flow" else None
                if verb == "replace_flow":
                    _need(before != after, "replace_flow must change content")
                    candidate["flows"][existing] = after
                else:
                    del candidate["flows"][existing]
        elif verb in {"add_stock", "remove_stock"}:
            _object(raw, {"op", "value"} if verb == "add_stock" else {"op", "id"},
                    f"operations[{index}]")
            if verb == "add_stock":
                value = _object(raw["value"], {"id", "kind", "initial"}, "stock.value")
                target = _symbol(value["id"], "stock.id")
                _need(type(value["initial"]) is list and not value["initial"],
                      "new stock must be empty")
            else:
                target = _symbol(raw["id"], "stock.id")
            key = ("stock", target)
            existing = next((i for i, s in enumerate(candidate["stocks"]) if s["id"] == target), None)
            if verb == "add_stock":
                _need(existing is None, "add_stock requires a fresh ID")
                before, after = None, copy.deepcopy(value)
                candidate["stocks"].append(after)
            else:
                _need(existing is not None, "stock target does not exist")
                before = copy.deepcopy(candidate["stocks"][existing])
                _need(not before["initial"], "cannot remove stock containing initial artifacts")
                after = None
                del candidate["stocks"][existing]
        elif verb == "set_resource":
            _object(raw, {"op", "name", "value"}, f"operations[{index}]")
            target = raw["name"]
            _need(type(target) is str and target in {"max_steps", "max_artifacts"},
                  "unknown resource limit")
            _positive_int(raw["value"], target, 100 if target == "max_steps" else 256)
            key = ("resource", target)
            before, after = candidate["resources"][target], raw["value"]
            _need(before != after, "resource limit must change")
            candidate["resources"][target] = after
        elif verb == "set_terminal_stocks":
            _object(raw, {"op", "value"}, f"operations[{index}]")
            target, key = "terminal_stocks", ("terminal", "terminal_stocks")
            after = _items(raw["value"], "terminal_stocks", minimum=1, maximum=16)
            before = copy.deepcopy(candidate["terminal_stocks"])
            _need(before != after, "terminal_stocks must change")
            candidate["terminal_stocks"] = list(after)
        else:
            raise DesignError("unsupported patch operation")

        _need(key not in seen, "multiple edits to the same target in one patch")
        seen.add(key)
        changes.append({"operation": verb, "target": target,
                        "before": before, "after": after})

    candidate["revision"] += 1
    check_design(candidate)
    _need(candidate["schema"] == base["schema"] and
          candidate["workflow_id"] == base["workflow_id"] and
          candidate["mode"] == base["mode"] and
          candidate["invariants"] == base["invariants"],
          "protected design identity or invariants changed")

    return {
        "status": "UNREVIEWED_CANDIDATE_SHAPE_VALID_ONLY",
        "workflow_id": candidate["workflow_id"],
        "base_revision": base["revision"],
        "candidate_revision": candidate["revision"],
        "base_sha256": canonical_digest(base),
        "patch_sha256": canonical_digest(patch),
        "candidate_sha256": canonical_digest(candidate),
        "rationale": patch["rationale"],
        "tests_proposed_not_executed": list(patch["tests_to_run"]),
        "changes": changes,
        "candidate_design": candidate,
        "owner_accepted": False,
        "workflow_published": False,
        "execution_authorized": False,
        "knowledge_approved": False,
        "observations_independently_verified": False,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_design", type=Path)
    parser.add_argument("patch", type=Path)
    args = parser.parse_args(argv)
    try:
        result = propose_revision(load_design(args.base_design), load_patch(args.patch))
    except (DesignError, ValueError, OSError, UnicodeError, RecursionError) as err:
        print(f"PATCH_REJECTED: {ascii(str(err))}", file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
