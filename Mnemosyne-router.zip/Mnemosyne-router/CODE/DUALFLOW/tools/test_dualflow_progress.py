"""Fixed-denominator and acceptance/technical separation for roadmap reporting."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest
from check_dualflow_design import DesignError
from progress_dualflow import DEFAULT, load_roadmap, summarize_roadmap


class RoadmapSummaryTests(unittest.TestCase):
    def setUp(self):
        self.roadmap = load_roadmap(DEFAULT)

    def test_expected_current_counts(self):
        s = summarize_roadmap(self.roadmap)
        self.assertEqual((s['goals_accepted'], s['goals_total'], s['accepted_percent']), (10,10,100.0))
        self.assertEqual((s['goals_technically_complete'], s['goals_total'], s['technical_percent']), (10,10,100.0))
        self.assertEqual(s['goals_awaiting_acceptance'], 0)

    def test_missing_goal_rejected(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'].pop()
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_duplicate_goal_rejected(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][1]['id'] = d['goals'][0]['id']
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_mixed_track_rejected(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][0]['id'] = 'HWI-C14'
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_accepted_goal_requires_exact_commit_reference(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][9]['evidence'] = 'Owner accepted pending production fixes'
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_invalid_accepted_commit_digest_rejected(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][0]['evidence'] = 'Git commit ' + 'x'*40
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_in_progress_does_not_count_as_technical(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][6]['status'] = 'IN_PROGRESS'
        s = summarize_roadmap(d)
        self.assertEqual(s['goals_technically_complete'], 9)

    def test_no_unknown_status(self):
        d = copy.deepcopy(self.roadmap)
        d['goals'][7]['status'] = 'APPROVED_BY_LLM'
        with self.assertRaises(DesignError): summarize_roadmap(d)

    def test_cli(self):
        proc = subprocess.run([sys.executable, str(DEFAULT.parents[2] / 'tools/progress_dualflow.py')],
                              capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        s = json.loads(proc.stdout)
        self.assertEqual(s['technical_percent'], 100.0)
        self.assertEqual(s['accepted_percent'], 100.0)


if __name__ == '__main__':
    unittest.main()
