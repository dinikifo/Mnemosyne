#!/usr/bin/env python3
"""Offline WL-02/SF-02 deterministic *simulation*, never workflow execution.

All guard/observation results and claimed artifacts are supplied by a frozen test
scenario. This program cannot verify that an observation occurred in the world,
perform operations, approve knowledge, or authorize writes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

from check_dualflow_design import (
    DesignError, _object, _items, _symbol, _need, check_design, load_design,
    _unique_object, _reject_constant,
)

OUTCOMES = frozenset({"VERIFIED", "VIOLATED", "UNKNOWN"})
SCHEMA = "hwi.dualflow.simulation.v0"
MAX_SCENARIO_BYTES = 256_000


def canonical_digest(doc: dict) -> str:
    """SHA-256 over canonical JSON as an identity aid, not approval evidence."""
    return hashlib.sha256(json.dumps(doc, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False)
                           .encode("utf-8")).hexdigest()


def load_scenario(path: str | Path) -> dict:
    p = Path(path)
    _need(p.stat().st_size <= MAX_SCENARIO_BYTES, "scenario exceeds size limit")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def _outcome_map(value: Any, names: list[str], where: str) -> dict[str, str]:
    _need(type(value) is dict and set(value) == set(names),
          f"{where}: outcome keys must match declared obligations")
    for name, result in value.items():
        _need(type(result) is str and result in OUTCOMES,
              f"{where}.{name}: expected VERIFIED, VIOLATED or UNKNOWN")
    return value


def _classify(results: dict[str, str]) -> str:
    if "VIOLATED" in results.values():
        return "FAILURE"
    if "UNKNOWN" in results.values():
        return "UNKNOWN"
    return "SUCCESS"


def simulate(design: Any, scenario: Any) -> dict[str, Any]:
    """Pure deterministic replay; input evaluations are assertions, not measured facts.

    Raises DesignError for malformed/rejected scenarios; never mutates inputs.
    """
    check_design(design)
    scenario = _object(scenario, {"schema", "workflow_id", "revision", "design_sha256", "steps"},
                       "simulation")
    _need(scenario["schema"] == SCHEMA, "unsupported simulation schema")
    _need(type(scenario["workflow_id"]) is str and
          scenario["workflow_id"] == design["workflow_id"], "workflow_id mismatch")
    _need(type(scenario["revision"]) is int and
          scenario["revision"] == design["revision"], "revision mismatch")
    _need(type(scenario["design_sha256"]) is str and
          scenario["design_sha256"] == canonical_digest(design), "design digest mismatch")
    steps = scenario["steps"]
    _need(type(steps) is list and 1 <= len(steps) <= design["resources"]["max_steps"],
          "scenario exceeds bounded step budget or contains no steps")

    kind = {s["id"]: s["kind"] for s in design["stocks"]}
    stocks = {s["id"]: set(s["initial"]) for s in design["stocks"]}
    flows = {f["id"]: f for f in design["flows"]}
    terminals = set(design["terminal_stocks"])
    all_initial = [a for s in design["stocks"] for a in s["initial"]]
    initial_work = [a for s in design["stocks"] if s["kind"] == "work" for a in s["initial"]]
    _need(len(initial_work) == 1, "v0 simulator requires exactly one initial work artifact")
    lineage = {a: {"origin": "initial", "parents": [], "kind": kind[s["id"]]}
               for s in design["stocks"] for a in s["initial"]}
    _need(len(lineage) == len(all_initial), "duplicated initial artifact")
    trace: list[dict] = []

    for index, raw in enumerate(steps):
        step = _object(raw, {"flow", "work_artifact", "guards", "observations",
                             "knowledge_produced"}, f"step[{index}]")
        fid = _symbol(step["flow"], f"step[{index}].flow")
        _need(fid in flows, f"step[{index}]: undeclared flow")
        f = flows[fid]
        work_from = next(s for s in f["inputs"] if kind[s] == "work")
        work_to = next(s for s in f["outputs"] if kind[s] == "work")
        work_id = _symbol(step["work_artifact"], "work_artifact", artifact=True)
        _need(work_id in stocks[work_from], f"step[{index}]: missing work input")
        _need(all(not stocks[s] for s in terminals),
              "cannot continue after reaching a terminal work state")

        guard_results = _outcome_map(step["guards"], f["guards"], "guards")
        guard_status = _classify(guard_results)
        if guard_status != "SUCCESS":
            _need(type(step["observations"]) is dict and not step["observations"],
                  "observations cannot be asserted when guards fail or are unknown")
            status = guard_status
        else:
            for s in f["inputs"]:
                if kind[s] == "knowledge":
                    _need(bool(stocks[s]), f"step[{index}]: missing knowledge dependency {s}")
            observations = _outcome_map(step["observations"], f["observations"], "observations")
            status = _classify(observations)

        produced = step["knowledge_produced"]
        _need(type(produced) is list and len(produced) <= 16,
              "knowledge_produced must be a bounded list")
        if status != "SUCCESS":
            _need(not produced, "failed/unknown transitions must not produce knowledge")
            destination = f["on_failure"] if status == "FAILURE" else f["on_unknown"]
        else:
            destination = work_to
            knowledge_outputs = {s for s in f["outputs"] if kind[s] == "knowledge"}
            declared_inputs = {s for s in f["inputs"] if kind[s] == "knowledge"}
            created: set[str] = set()
            produced_stocks: set[str] = set()
            for pindex, raw_produced in enumerate(produced):
                p = _object(raw_produced, {"id", "stock", "parents"},
                            f"step[{index}].knowledge_produced[{pindex}]")
                artifact_id = _symbol(p["id"], "produced.id", artifact=True)
                stock = _symbol(p["stock"], "produced.stock")
                _need(stock in knowledge_outputs, "produced artifact targets undeclared knowledge output")
                parents = _items(p["parents"], "produced.parents", minimum=1,
                                 maximum=16, artifact=True)
                _need(artifact_id not in lineage and artifact_id not in created,
                      "knowledge artifact id must be globally fresh")
                _need(all(x in lineage for x in parents), "knowledge parent does not exist")
                if declared_inputs:
                    _need(any(x in stocks[s] for s in declared_inputs for x in parents),
                          "knowledge creation requires lineage from a declared knowledge input")
                else:
                    _need(work_id in parents,
                          "source creation requires its triggering work artifact as parent")
                produced_stocks.add(stock)
                created.add(artifact_id)
            _need(produced_stocks == knowledge_outputs,
                  "each declared knowledge output must receive an artifact")
            _need(len(lineage) + len(produced) <= design["resources"]["max_artifacts"],
                  "artifact budget exhausted")

        # Atomic transition: all validation above must succeed before any mutation.
        stocks[work_from].remove(work_id)
        stocks[destination].add(work_id)
        if status == "SUCCESS":
            for p in produced:
                stocks[p["stock"]].add(p["id"])
                lineage[p["id"]] = {"origin": fid, "parents": list(p["parents"]),
                                    "kind": "knowledge"}
        trace.append({"index": index + 1, "flow": fid, "status": status,
                      "from": work_from, "to": destination,
                      "work_artifact": work_id,
                      "knowledge_created": sorted(p["id"] for p in produced)})
        _need(sum(len(s) for s in stocks.values()) == len(lineage),
              "artifact conservation/accountability violated")

    terminal = next((s for s in terminals if initial_work[0] in stocks[s]), None)
    result = {"status": "SIMULATED_TERMINAL" if terminal else "SIMULATION_INCOMPLETE",
              "workflow_id": design["workflow_id"], "revision": design["revision"],
              "design_sha256": canonical_digest(design),
              "terminal_stock": terminal,
              "trace": trace,
              "stocks": {s: sorted(ids) for s, ids in sorted(stocks.items())},
              "lineage": {a: lineage[a] for a in sorted(lineage)},
              "execution_authorized": False,
              "knowledge_approved": False,
              "observations_independently_verified": False}
    result["trace_sha256"] = canonical_digest(result)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("design", type=Path)
    parser.add_argument("scenario", type=Path)
    args = parser.parse_args(argv)
    try:
        result = simulate(load_design(args.design), load_scenario(args.scenario))
    except (DesignError, ValueError, OSError, UnicodeError, RecursionError) as err:
        print(f"SIMULATION_REJECTED: {ascii(str(err))}", file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
