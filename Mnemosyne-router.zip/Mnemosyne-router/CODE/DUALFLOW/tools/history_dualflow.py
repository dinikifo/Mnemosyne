#!/usr/bin/env python3
"""WL-05 offline, local-only, non-authorizing, digest-chained review history.

A logically append-only *snapshot* of synthetic regression reports and review
notes. This provides local tamper detection, not signatures, remote custody,
anti-rollback protection, proof of factual truth, or workflow authorization.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import sys
import tempfile
from typing import Any

from check_dualflow_design import DesignError, _need, _object, _symbol, _unique_object, _reject_constant
from review_dualflow import attach_review_note, MAX_CASES
from simulate_dualflow import canonical_digest

ENTRY_SCHEMA = 'hwi.dualflow.history_entry.v0'
REPORT_SCHEMA = 'hwi.dualflow.regression_report.v0'
GENESIS = 'GENESIS'
MAX_LEDGER_BYTES = 4_000_000
MAX_ENTRY_BYTES = 300_000
MAX_EVENTS = 128
FALSE_FLAGS = ('owner_accepted', 'workflow_published', 'execution_authorized',
               'knowledge_approved', 'reviewer_identity_verified',
               'observations_independently_verified',
               'expected_results_independently_verified')
REPORT_FIELDS = {'schema', 'status', 'workflow_id', 'base_sha256', 'patch_sha256',
                 'candidate_sha256', 'suite_sha256', 'cases_passed', 'cases_total',
                 'results', 'review_outcome', 'tests_executed_in_synthetic_simulator',
                 'expected_results_independently_verified',
                 'observations_independently_verified', 'reviewer_identity_verified',
                 'owner_accepted', 'workflow_published', 'execution_authorized',
                 'knowledge_approved', 'evidence_sha256'}
ENTRY_FIELDS = {'schema', 'sequence', 'previous_entry_sha256', 'kind', 'payload',
                'entry_sha256'}


def _sha(value: Any, name: str) -> str:
    _need(type(value) is str and len(value) == 64 and
          all(ch in '0123456789abcdef' for ch in value),
          f'{name}: expected lowercase SHA-256')
    return value


def _strict_load(path: Path, limit: int) -> dict:
    _need(path.stat().st_size <= limit, 'input exceeds size limit')
    with path.open('r', encoding='utf-8') as f:
        obj = json.load(f, object_pairs_hook=_unique_object, parse_constant=_reject_constant)
    _need(type(obj) is dict, 'input must be an object')
    return obj


def verify_report(report: Any) -> None:
    _object(report, REPORT_FIELDS, 'regression_report')
    _need(report['schema'] == REPORT_SCHEMA, 'invalid report schema')
    _symbol(report['workflow_id'], 'workflow_id')
    for key in ('base_sha256', 'patch_sha256', 'candidate_sha256',
                'suite_sha256', 'evidence_sha256'):
        _sha(report[key], key)
    _need(report['review_outcome'] == 'PENDING_OWNER_REVIEW', 'report cannot claim a review decision')
    for key in FALSE_FLAGS:
        _need(report[key] is False, f'report cannot claim {key}')
    _need(report['tests_executed_in_synthetic_simulator'] is True,
          'report must identify synthetic simulation')
    _need(type(report['results']) is list and
          1 <= len(report['results']) <= MAX_CASES, 'invalid report result count')
    ids = []
    matches = 0
    for i, result in enumerate(report['results']):
        _object(result, {'test_id', 'outcome', 'scenario_sha256', 'expected',
                         'observed', 'trace_sha256'}, f'result[{i}]')
        ids.append(_symbol(result['test_id'], f'result[{i}].test_id'))
        _sha(result['scenario_sha256'], f'result[{i}].scenario_sha256')
        if result['trace_sha256'] is not None:
            _sha(result['trace_sha256'], f'result[{i}].trace_sha256')
        _need(type(result['expected']) is dict and type(result['observed']) is dict,
              'result expected/observed must be objects')
        _need(result['outcome'] in ('MATCH', 'MISMATCH'), 'invalid regression outcome')
        if result['outcome'] == 'MATCH':
            matches += 1
    _need(len(ids) == len(set(ids)), 'duplicate result IDs')
    _need(type(report['cases_passed']) is int and report['cases_passed'] == matches and
          type(report['cases_total']) is int and report['cases_total'] == len(ids),
          'report counts mismatch')
    expected_status = 'READY_FOR_OWNER_REVIEW' if matches == len(ids) else 'REGRESSION_MISMATCH'
    _need(report['status'] == expected_status, 'report status inconsistent with case outcomes')
    _need(report['evidence_sha256'] == canonical_digest(
        {k: v for k, v in report.items() if k != 'evidence_sha256'}),
        'report digest mismatch')


def _entry(sequence: int, previous: str | None, kind: str, payload: dict) -> dict:
    record = {'schema': ENTRY_SCHEMA, 'sequence': sequence,
              'previous_entry_sha256': previous, 'kind': kind, 'payload': payload}
    record['entry_sha256'] = canonical_digest(record)
    _need(len(json.dumps(record, sort_keys=True, ensure_ascii=True).encode('ascii'))
          <= MAX_ENTRY_BYTES, 'history entry exceeds size limit')
    return record


def verify_history(entries: Any) -> dict:
    """Verify local structural integrity, ordered chain and note/report binding."""
    _need(type(entries) is list and len(entries) <= MAX_EVENTS, 'too many history entries')
    previous = None
    reports = {}
    notes = set()
    for i, record in enumerate(entries):
        _object(record, ENTRY_FIELDS, f'entry[{i}]')
        _need(record['schema'] == ENTRY_SCHEMA, 'unsupported history entry schema')
        _need(type(record['sequence']) is int and record['sequence'] == i + 1,
              'nonconsecutive history sequence')
        _need(record['previous_entry_sha256'] == previous, 'broken history link')
        _sha(record['entry_sha256'], 'entry_sha256')
        _need(record['entry_sha256'] == canonical_digest(
            {k: v for k, v in record.items() if k != 'entry_sha256'}),
            'history entry digest mismatch')
        kind = record['kind']
        payload = record['payload']
        if kind == 'REGRESSION_REPORT':
            verify_report(payload)
            pin = payload['evidence_sha256']
            _need(pin not in reports, 'duplicate report identity')
            reports[pin] = payload
        elif kind == 'REVIEW_NOTE':
            _need(type(payload) is dict and 'evidence_sha256' in payload,
                  'invalid history review note')
            pin = _sha(payload['evidence_sha256'], 'note evidence_sha256')
            _need(pin in reports, 'note references report absent from history')
            annotation = attach_review_note(reports[pin], payload)
            key = (pin, annotation['note_sha256'])
            _need(key not in notes, 'duplicate review note')
            notes.add(key)
        else:
            raise DesignError('unsupported history event kind')
        previous = record['entry_sha256']
    return {'schema': 'hwi.dualflow.history_summary.v0',
            'status': 'LOCAL_CHAIN_VALID_NOT_AUTHORIZATION',
            'events': len(entries), 'reports': len(reports),
            'review_notes': len(notes), 'head_sha256': previous or GENESIS,
            'reviewer_identity_verified': False, 'owner_accepted': False,
            'execution_authorized': False, 'workflow_published': False,
            'knowledge_approved': False}


def load_history(path: str | Path) -> list[dict]:
    path = Path(path)
    _need(not path.is_symlink(), 'history symlinks not supported')
    if not path.exists():
        return []
    data = path.read_bytes()
    _need(0 < len(data) <= MAX_LEDGER_BYTES, 'history missing data or exceeds size limit')
    _need(data.endswith(b'\n'), 'incomplete history record')
    records = []
    for index, raw in enumerate(data.splitlines()):
        _need(0 < len(raw) <= MAX_ENTRY_BYTES, f'entry[{index}]: invalid byte count')
        record = json.loads(raw.decode('utf-8'), object_pairs_hook=_unique_object,
                            parse_constant=_reject_constant)
        _need(type(record) is dict, f'entry[{index}]: expected object')
        records.append(record)
    verify_history(records)
    return records


def append_event(path: str | Path, kind: str, payload: dict, expected_head: str) -> dict:
    """Atomically replace local ledger with an append-only logical snapshot.

    A separate advisory lock serializes cooperating writers on Unix/macOS.
    This is NOT tamper-proof storage or protection against an OS-level attacker.
    """
    path = Path(path)
    _need(path.parent.is_dir() and not path.is_symlink(), 'invalid history location')
    if expected_head != GENESIS:
        _sha(expected_head, 'expected_head')
    lock_path = path.with_name(path.name + '.lock')
    _need(not lock_path.is_symlink(), 'history lock symlinks not supported')
    lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    temp_name = None
    try:
        with os.fdopen(lock_fd, 'r+b') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            existing = load_history(path)
            summary = verify_history(existing)
            _need(summary['head_sha256'] == expected_head, 'stale history head')
            _need(len(existing) < MAX_EVENTS, 'history capacity reached')
            _need(kind in ('REGRESSION_REPORT', 'REVIEW_NOTE'), 'unsupported event kind')
            if kind == 'REGRESSION_REPORT':
                verify_report(payload)
            else:
                _need(type(payload) is dict, 'review note must be object')
            new_entry = _entry(len(existing)+1,
                               None if not existing else existing[-1]['entry_sha256'],
                               kind, payload)
            candidate = existing + [new_entry]
            result = verify_history(candidate)
            contents = ''.join(json.dumps(record, ensure_ascii=True, sort_keys=True,
                                           separators=(',', ':')) + '\n'
                               for record in candidate).encode('ascii')
            _need(len(contents) <= MAX_LEDGER_BYTES, 'history exceeds byte limit')
            fd, temp_name = tempfile.mkstemp(prefix='.' + path.name + '.tmp-', dir=path.parent)
            with os.fdopen(fd, 'wb') as dest:
                os.fchmod(dest.fileno(), 0o600)
                dest.write(contents)
                dest.flush()
                os.fsync(dest.fileno())
            os.replace(temp_name, path)
            temp_name = None
            dirfd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(dirfd)
            finally:
                os.close(dirfd)
            return result
    finally:
        if temp_name is not None:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for cmd in ('verify', 'append-report', 'append-note'):
        subparser = sub.add_parser(cmd)
        subparser.add_argument('history', type=Path)
        if cmd != 'verify':
            subparser.add_argument('input', type=Path)
            subparser.add_argument('--expected-head', required=True)
        else:
            subparser.add_argument('--expected-head', help='optional independently retained head SHA-256')
    args = parser.parse_args(argv)
    try:
        if args.command == 'verify':
            _need(args.history.exists(), 'history file is absent')
            result = verify_history(load_history(args.history))
            if args.expected_head is not None:
                _need(args.expected_head == result['head_sha256'], 'history head differs from external pin')
        elif args.command == 'append-report':
            result = append_event(args.history, 'REGRESSION_REPORT',
                                  _strict_load(args.input, MAX_ENTRY_BYTES), args.expected_head)
        else:
            result = append_event(args.history, 'REVIEW_NOTE',
                                  _strict_load(args.input, 16_000), args.expected_head)
    except (DesignError, ValueError, TypeError, OSError, UnicodeError, RecursionError) as err:
        print('HISTORY_REJECTED: ' + ascii(str(err)), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
