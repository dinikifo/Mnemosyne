"""Gate A: follow USER_MANUAL.md end to end through the real RUN_GOVERNANCE.command.

Usage: python3 -I gate_a_walkthrough.py <release folder>
Uses a fresh temporary workspace and freshly generated throwaway keys only; never
reads or writes real notebooks, keys, policies or ~/.config/hwi. Prints one line
per step, ends with WALKTHROUGH COMPLETE, and exits non-zero on the first failure.
"""
import hashlib, json, os, subprocess, sys, tempfile, datetime
from pathlib import Path

REL = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(REL / s) for s in ('CODE/DUALFLOW', 'CODE/APPROVED_WIKI_CORE')]
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from personal_wiki_core import NotebookWorkspace

tmp = Path(tempfile.mkdtemp(prefix='hwi-gate-a-walk.')).resolve()
os.chmod(tmp, 0o700)
work = tmp / 'operator'; work.mkdir(mode=0o700)
secure = tmp / 'secure'; secure.mkdir(mode=0o700)

def run(*args, ok=(0,)):
    p = subprocess.run(['bash', str(REL / 'RUN_GOVERNANCE.command'), *args], cwd=work,
                       capture_output=True, text=True)
    if p.returncode not in ok:
        print('   STDERR:', p.stderr.strip()[:400]); print('   STDOUT:', p.stdout.strip()[:400])
        raise SystemExit(f'FAILED: {args[0]} exit {p.returncode}')
    return p

def step(name, fn):
    try:
        out = fn(); print(f'OK   {name}' + (f' -> {out}' if out is not None else ''))
    except SystemExit as e:
        print(f'FAIL {name}: {e}'); raise

# --- Appendix A key generation, verbatim logic, two distinct keys
def keygen(prefix):
    key = Ed25519PrivateKey.generate()
    secret = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    pub = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    for path, data in ((secure / f'{prefix}-private.bin', secret), (secure / f'{prefix}-public.bin', pub),
                       (secure / f'{prefix}-public-pin.txt', hashlib.sha256(pub).hexdigest().encode())):
        with path.open('xb') as f:
            os.chmod(path, 0o600); f.write(data)
    return key, pub
wiki_key, wiki_pub = keygen('wiki-reviewer')
fit_key, fit_pub = keygen('fitness')

# --- §8 workspace prepared by "approved PERSONAL.WIKI process" (API stand-in)
ws_path = tmp / 'HWI-workspace'
ws = NotebookWorkspace(ws_path, create=True); ws.create_notebook('primary')
with ws.open_notebook('primary', readonly=False) as w:
    w.save_tiddler('Example Topic', 'Η αρχική διατύπωση.', ['research'], reason='seed')
    w.knowledge_catalog().initialize()
W = ['--workspace', str(ws_path), '--notebook', 'primary']

step('§4 --help', lambda: run('--help') and None)
init = {}
step('§8 queue-init', lambda: init.update(json.loads(run('queue-init', *W).stdout)) or init['status'])
scope = init['notebook_scope']

# Appendix A: both policies, written by the operator
for folder, body in (('review_policy', {'schema': 'hwi.review.policy.v1', 'notebook_scope': scope,
                                        'reviewer_key_sha256': hashlib.sha256(wiki_pub).hexdigest()}),
                     ('fitness_policy', {'schema': 'hwi.task_fitness.policy.v1', 'notebook_scope': scope,
                                         'fitness_key_sha256': hashlib.sha256(fit_pub).hexdigest()})):
    d = ws_path / folder; d.mkdir(mode=0o700); f = d / 'primary.json'
    f.write_text(json.dumps(body)); f.chmod(0o600)
print('OK   Appendix A policies provisioned')

hits = []
step('§8 queue-search', lambda: hits.extend(json.loads(run('queue-search', *W, '--query', 'Example Topic').stdout)) or len(hits))
target = hits[0]
step('§12 queue-revision', lambda: json.loads(run('queue-revision', *W, '--reference', target['ref']).stdout)['event_id'])

# --- §5/§6 contract from the shipped example, adapted (fresh pins as the manual demands)
ex = REL / 'CODE/DUALFLOW/hwi_governance/examples'
contract = json.loads((ex / 'TASK_FITNESS_CONTRACT.example.json').read_text())
contract['configuration'] = {**contract['configuration'], **{k: hashlib.sha256(k.encode()).hexdigest()
                             for k in contract['configuration'] if k != 'model'}}
contract['valid_until'] = (datetime.datetime.now(datetime.timezone.utc).date() + datetime.timedelta(days=60)).isoformat()
(work / 'task-contract.json').write_text(json.dumps(contract, indent=2))
pins = {}
step('§6 fitness-pins', lambda: pins.update(json.loads(run('fitness-pins', '--contract', 'task-contract.json').stdout)) or pins['case_ids'])
results = json.loads((ex / 'TASK_FITNESS_RESULTS.example.json').read_text())
results['contract_sha256'] = pins['contract_sha256']; results['configuration_sha256'] = pins['configuration_sha256']
(work / 'task-results.json').write_text(json.dumps(results, indent=2))
step('§6 fitness-assess', lambda: run('fitness-assess', '--contract', 'task-contract.json', '--results',
     'task-results.json', '--output', 'task-assessment.json') and json.loads((work / 'task-assessment.json').read_text())['status'])
step('§7 fitness-signing-payload', lambda: run('fitness-signing-payload', '--assessment', 'task-assessment.json',
     '--output', 'task-signing-message.json') and None)
# Appendix A signing snippet
sig = fit_key.sign((work / 'task-signing-message.json').read_bytes()).hex()
assessment = json.loads((work / 'task-assessment.json').read_text())
(work / 'owner-decision.json').write_text(json.dumps({'schema': 'hwi.task_fitness.owner_decision.v2',
    'assessment_sha256': assessment['assessment_sha256'], 'decision': 'APPROVE_FOR_DECLARED_TASK', 'signature_hex': sig}))
step('§7 fitness-verify', lambda: json.loads(run('fitness-verify', '--assessment', 'task-assessment.json',
     '--owner-decision', 'owner-decision.json', '--owner-public-key', str(secure / 'fitness-public.bin'), *W).stdout)['status'])

# --- §9 submit (manual's example spec)
spec = {'task_id': contract['task_id'], 'operation': 'revise', 'reason': 'Correct the reported source discrepancy',
        'source_refs': ['external:reviewed-case-001'], 'author_origin': 'agent', 'target_ref': target['ref'],
        'expected_revision_sha256': target['revision_sha256'],
        'proposed': {'title': 'Example Topic', 'text': 'Διορθωμένη διατύπωση με παραπομπές.', 'tags': ['research'], 'fields': {}}}
(work / 'proposed-edit.json').write_text(json.dumps(spec, ensure_ascii=False))
sub = {}
step('§9 queue-submit', lambda: sub.update(json.loads(run('queue-submit', *W, '--spec', 'proposed-edit.json',
     '--contract', 'task-contract.json', '--results', 'task-results.json', '--assessment', 'task-assessment.json',
     '--owner-decision', 'owner-decision.json', '--owner-public-key', str(secure / 'fitness-public.bin')).stdout)) or sub['status'])
pid = sub['proposal']['proposal_id']
step('§10 queue-list', lambda: [e['fitness_gate']['status'] for e in json.loads(run('queue-list', *W).stdout)])
step('§10 queue-review', lambda: json.loads(run('queue-review', *W, '--proposal-id', pid).stdout)['fitness_gate']['status'])
step('§10 queue-export', lambda: run('queue-export', *W, '--output', 'For_Human_Review_and_Approval.json') and
     json.loads((work / 'For_Human_Review_and_Approval.json').read_text())[0]['title'])
step('§11 queue-signing-payload', lambda: run('queue-signing-payload', *W, '--proposal-id', pid,
     '--output', 'wiki-review-signing-message.json') and None)
wsig = wiki_key.sign((work / 'wiki-review-signing-message.json').read_bytes()).hex()
step('§11 queue-apply', lambda: json.loads(run('queue-apply', *W, '--proposal-id', pid, '--signature-hex', wsig,
     '--reviewer-public-key', str(secure / 'wiki-reviewer-public.bin')).stdout)['status'])
post_id = target['ref'].split('/')[-1].split('@')[0]
hist = []
step('§12 queue-history', lambda: hist.extend(json.loads(run('queue-history', *W, '--post-id', post_id).stdout)) or len(hist))
cur = json.loads(run('queue-search', *W, '--query', 'Example Topic').stdout)[0]
rp = {}
step('§12 queue-restore-proposal', lambda: rp.update(json.loads(run('queue-restore-proposal', *W, '--current-ref', cur['ref'],
     '--historical-ref', target['ref'], '--reason', 'Undo reviewed but incorrect change').stdout)) or rp['status'])
rpid = rp['proposal']['proposal_id']
run('queue-signing-payload', *W, '--proposal-id', rpid, '--output', 'restore-msg.json')
rsig = wiki_key.sign((work / 'restore-msg.json').read_bytes()).hex()
step('§12 apply restore without flag refused', lambda: run('queue-apply', *W, '--proposal-id', rpid, '--signature-hex', rsig,
     '--reviewer-public-key', str(secure / 'wiki-reviewer-public.bin'), ok=(2,)).returncode)
step('§12 apply restore with flag', lambda: json.loads(run('queue-apply', *W, '--proposal-id', rpid, '--signature-hex', rsig,
     '--reviewer-public-key', str(secure / 'wiki-reviewer-public.bin'), '--accept-unverified-gate').stdout)['status'])
with ws.open_notebook('primary', readonly=True) as w:
    restored = w.get_tiddler('Example Topic')['text'] == 'Η αρχική διατύπωση.'
    print('OK   final text restored:' if restored else 'FAIL final text restored:', restored)
    if not restored:
        raise SystemExit('FAILED: restore did not bring back the original text')
# §10 reject / withdraw on fresh proposals
spec2 = dict(spec, reason='second', expected_revision_sha256=json.loads(run('queue-search', *W, '--query', 'Example Topic').stdout)[0]['revision_sha256'],
             target_ref=json.loads(run('queue-search', *W, '--query', 'Example Topic').stdout)[0]['ref'])
for tag, cmd in (('a', 'queue-reject'), ('b', 'queue-withdraw')):
    s2 = dict(spec2, reason=f'variant {tag}'); (work / f'p{tag}.json').write_text(json.dumps(s2))
    p2 = json.loads(run('queue-submit', *W, '--spec', f'p{tag}.json', '--contract', 'task-contract.json', '--results',
         'task-results.json', '--assessment', 'task-assessment.json', '--owner-decision', 'owner-decision.json',
         '--owner-public-key', str(secure / 'fitness-public.bin')).stdout)['proposal']['proposal_id']
    step(f'§10 {cmd}', lambda: json.loads(run(cmd, *W, '--proposal-id', p2, '--actor-claim', 'operator',
         '--reason', 'Evidence insufficient').stdout)['status'])
print('WALKTHROUGH COMPLETE')
