#!/usr/bin/env python3
"""Read and summarize the explicitly scoped, human-maintained dual-flow roadmap.

Counts describe recorded goal status, not independently authenticated approval.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from check_dualflow_design import DesignError, _need, _object, _unique_object, _reject_constant

GOAL_IDS = ('WL-01', 'SF-01', 'WL-02', 'SF-02', 'WL-03',
            'WL-04', 'WL-05', 'WL-06', 'HWI-I01', 'HWI-I02')
STATES = frozenset({'ACCEPTED', 'TECHNICAL_PASS', 'IN_PROGRESS', 'PLANNED'})
DEFAULT = Path(__file__).resolve().parents[1] / 'docs/dualflow/ROADMAP_PROGRESS.json'


def summarize_roadmap(data: object) -> dict:
    _object(data, {'schema', 'scope', 'status_basis', 'goals'}, 'roadmap')
    _need(data['schema'] == 'hwi.dualflow.roadmap_progress.v0', 'roadmap schema mismatch')
    _need(type(data['scope']) is str and type(data['status_basis']) is str,
          'missing roadmap explanation')
    goals = data['goals']
    _need(type(goals) is list and len(goals) == len(GOAL_IDS), 'roadmap denominator changed')
    ids = []
    for i, goal in enumerate(goals):
        _object(goal, {'id', 'title', 'status', 'evidence'}, f'goals[{i}]')
        _need(type(goal['id']) is str and goal['id'] in GOAL_IDS,
              'unknown goal ID')
        ids.append(goal['id'])
        _need(type(goal['status']) is str and goal['status'] in STATES,
              'unknown goal status')
        _need(type(goal['title']) is str and len(goal['title']) >= 8 and
              type(goal['evidence']) is str and len(goal['evidence']) >= 8,
              'invalid goal description or evidence reference')
        if goal['status'] == 'ACCEPTED':
            _need(goal['evidence'].startswith('Git commit ') and
                  len(goal['evidence'].split('Git commit ')[1]) == 40 and
                  all(c in '0123456789abcdef' for c in goal['evidence'][11:]),
                  'accepted goal must reference exact Git commit')
    _need(tuple(ids) == GOAL_IDS, 'roadmap IDs or order changed')
    total = len(goals)
    accepted = sum(g['status'] == 'ACCEPTED' for g in goals)
    technical = sum(g['status'] in ('ACCEPTED', 'TECHNICAL_PASS') for g in goals)
    return {'schema': 'hwi.dualflow.roadmap_summary.v0', 'goals_total': total,
            'goals_accepted': accepted, 'accepted_percent': 100*accepted/total,
            'goals_technically_complete': technical, 'technical_percent': 100*technical/total,
            'goals_awaiting_acceptance': technical-accepted,
            'goals_not_technically_complete': total-technical,
            'basis': 'MAINTAINED_STATUS_NOT_VERIFIED_AUTHORIZATION'}


def load_roadmap(path: Path = DEFAULT) -> dict:
    _need(path.stat().st_size <= 32_000, 'roadmap too large')
    with path.open(encoding='utf-8') as f:
        return json.load(f, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('roadmap', nargs='?', type=Path, default=DEFAULT)
    args = parser.parse_args(argv)
    try:
        summary = summarize_roadmap(load_roadmap(args.roadmap))
    except (DesignError, ValueError, TypeError, OSError) as exc:
        print('ROADMAP_REJECTED: ' + ascii(str(exc)), file=sys.stderr)
        return 2
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
