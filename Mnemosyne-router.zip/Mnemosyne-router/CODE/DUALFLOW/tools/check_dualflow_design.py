#!/usr/bin/env python3
"""WL-01/SF-01 DESIGN-ONLY checker. No execution, wiki writes, or approvals."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from typing import Any


class DesignError(ValueError):
    """A proposed dual-flow design violates the bounded v0 shape contract."""


_ID = re.compile(r"[a-z][a-z0-9_.-]{0,63}\Z")
_REF = re.compile(r"[a-z][a-z0-9_.:-]{0,99}\Z")
_CAPABILITIES = frozenset({"retrieve_readonly", "assess_evidence", "render_report"})
_INVARIANTS = frozenset({"no_protected_writes", "no_unverified_success", "preserve_provenance"})


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise DesignError(message)


def _object(value: Any, required: set[str], where: str) -> dict:
    _need(type(value) is dict and set(value) == required,
          f"{where}: expected exactly {sorted(required)}")
    return value


def _symbol(value: Any, where: str, *, artifact: bool = False) -> str:
    _need(type(value) is str and bool((_REF if artifact else _ID).fullmatch(value)),
          f"{where}: invalid bounded symbolic identifier")
    return value


def _items(value: Any, where: str, *, minimum: int, maximum: int, artifact: bool = False) -> list[str]:
    _need(type(value) is list and minimum <= len(value) <= maximum,
          f"{where}: expected {minimum}..{maximum} items")
    names = [_symbol(x, where, artifact=artifact) for x in value]
    _need(len(set(names)) == len(names), f"{where}: duplicate identifiers")
    return names


def _positive_int(value: Any, where: str, maximum: int) -> int:
    _need(type(value) is int and 1 <= value <= maximum,
          f"{where}: positive exact integer <= {maximum} required")
    return value


def check_design(value: Any) -> dict[str, Any]:
    """Validate shape and bounded graph connections, NOT semantic correctness."""
    doc = _object(value, {"schema", "workflow_id", "revision", "mode", "resources",
                          "stocks", "flows", "invariants", "terminal_stocks"}, "workflow")
    _need(doc["schema"] == "hwi.dualflow.design.v0", "unsupported schema")
    _symbol(doc["workflow_id"], "workflow_id")
    _positive_int(doc["revision"], "revision", 1000000)
    _need(doc["mode"] == "simulation_only", "v0 permits only simulation_only")
    resources = _object(doc["resources"], {"max_steps", "max_artifacts"}, "resources")
    _positive_int(resources["max_steps"], "max_steps", 100)
    capacity = _positive_int(resources["max_artifacts"], "max_artifacts", 256)
    _need(type(doc["stocks"]) is list and 2 <= len(doc["stocks"]) <= 32,
          "stocks: expected 2..32 containers")
    stocks: dict[str, str] = {}
    all_initial: set[str] = set()
    initially_active_work: set[str] = set()
    for i, raw in enumerate(doc["stocks"]):
        stock = _object(raw, {"id", "kind", "initial"}, f"stock[{i}]")
        name = _symbol(stock["id"], "stock.id")
        _need(name not in stocks, f"duplicate stock: {name}")
        kind = stock["kind"]
        _need(type(kind) is str and kind in ("work", "knowledge"), f"invalid stock kind: {name}")
        _need(name.startswith(kind + "."), f"stock {name} must be namespaced {kind}.*")
        tokens = _items(stock["initial"], f"{name}.initial", minimum=0, maximum=16,
                        artifact=True)
        _need(not all_initial.intersection(tokens), f"repeated initial artifact in {name}")
        all_initial.update(tokens)
        if tokens and kind == "work":
            initially_active_work.add(name)
        stocks[name] = kind
    _need(len(all_initial) <= capacity, "initial artifact count exceeds max_artifacts")
    _need(bool(initially_active_work), "at least one work stock must have initial artifacts")
    terminals = _items(doc["terminal_stocks"], "terminal_stocks", minimum=1, maximum=16)
    terminal_set = set(terminals)
    _need(all(stocks.get(s) == "work" for s in terminals), "terminal must be a declared work stock")
    _need(not terminal_set.intersection(initially_active_work), "initial work stock cannot be terminal")
    invariants = _items(doc["invariants"], "invariants", minimum=3, maximum=3)
    _need(set(invariants) == _INVARIANTS, "required invariants missing or unexpected")
    _need(type(doc["flows"]) is list and 1 <= len(doc["flows"]) <= 32,
          "flows: expected 1..32 entries")
    flow_ids: set[str] = set()
    graph: dict[str, set[str]] = {s: set() for s, k in stocks.items() if k == "work"}
    for i, raw in enumerate(doc["flows"]):
        flow = _object(raw, {"id", "capability", "inputs", "outputs", "guards",
                            "observations", "on_failure", "on_unknown"}, f"flow[{i}]")
        name = _symbol(flow["id"], "flow.id")
        _need(name not in flow_ids, f"duplicate flow {name}")
        flow_ids.add(name)
        _need(type(flow["capability"]) is str and flow["capability"] in _CAPABILITIES,
              f"{name}: undeclared/unsafe capability")
        inputs = _items(flow["inputs"], f"{name}.inputs", minimum=1, maximum=8)
        outputs = _items(flow["outputs"], f"{name}.outputs", minimum=1, maximum=8)
        _need(all(s in stocks for s in inputs + outputs), f"{name}: unknown stock reference")
        work_inputs = [s for s in inputs if stocks[s] == "work"]
        work_outputs = [s for s in outputs if stocks[s] == "work"]
        _need(len(work_inputs) == len(work_outputs) == 1,
              f"{name}: v0 requires one work input and one work output")
        source, target = work_inputs[0], work_outputs[0]
        _need(source not in terminal_set, f"{name}: terminal work state has outgoing flow")
        _need(source != target, f"{name}: self-transition forbidden in v0")
        graph[source].add(target)
        for field in ("guards", "observations"):
            _items(flow[field], f"{name}.{field}", minimum=1, maximum=16)
        for field in ("on_failure", "on_unknown"):
            _need(type(flow[field]) is str and flow[field] in terminal_set,
                  f"{name}: {field} must be a declared terminal work stock in v0")
            graph[source].add(flow[field])
    # Catch isolated or cyclic work states; this is not a proof of semantic liveness.
    visited: set[str] = set()
    active: set[str] = set()

    def visit(node: str) -> None:
        if node in active:
            raise DesignError("work-state graph contains a cycle (unsupported in v0)")
        if node in visited:
            return
        active.add(node)
        for nxt in graph[node]:
            visit(nxt)
        active.remove(node)
        visited.add(node)

    for start in graph:
        visit(start)
    reached: set[str] = set()
    frontier = list(initially_active_work)
    while frontier:
        node = frontier.pop()
        if node in reached:
            continue
        reached.add(node)
        frontier.extend(graph[node] - reached)
    _need(all(s in reached for s in graph), "unreachable work stock")
    _need(all(graph[s] or s in terminal_set for s in graph),
          "nonterminal work stock has no outgoing flow")
    _need(bool(reached.intersection(terminal_set)), "no reachable terminal work state")
    return {"status": "DESIGN_SHAPE_VALID_ONLY", "workflow_id": doc["workflow_id"],
            "revision": doc["revision"], "stocks": len(stocks), "flows": len(flow_ids),
            "execution_authorized": False, "knowledge_approved": False}


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    obj: dict[str, Any] = {}
    for key, value in pairs:
        if key in obj:
            raise DesignError(f"duplicate JSON key: {key}")
        obj[key] = value
    return obj


def _reject_constant(value: str) -> None:
    raise DesignError(f"nonstandard JSON constant: {value}")


def load_design(path: str | Path) -> dict:
    # Reject duplicate JSON object fields, NaN and Infinity before validating types.
    content = Path(path).read_text(encoding="utf-8")
    return json.loads(content, object_pairs_hook=_unique_object,
                      parse_constant=_reject_constant)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("json_file", type=Path)
    args = parser.parse_args(argv)
    try:
        result = check_design(load_design(args.json_file))
    except (DesignError, ValueError, OSError) as err:
        print(f"DESIGN_INVALID: {err}", file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
