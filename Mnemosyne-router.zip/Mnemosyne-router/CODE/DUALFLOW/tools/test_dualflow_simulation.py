"""WL-02/SF-02 offline replay tests: no execution, authority, or wiki access."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError, load_design
from simulate_dualflow import canonical_digest, load_scenario, simulate

ROOT = Path(__file__).resolve().parents[1]
DESIGN = ROOT / "docs/dualflow/examples/evidence_review.json"
SCENARIO = ROOT / "docs/dualflow/examples/evidence_review.simulation.json"


class DualFlowSimulationTests(unittest.TestCase):
    def setUp(self):
        self.design = load_design(DESIGN)
        self.scenario = load_scenario(SCENARIO)

    def invalid(self, change_design=None, change_scenario=None):
        design = copy.deepcopy(self.design)
        scenario = copy.deepcopy(self.scenario)
        if change_design:
            change_design(design)
            scenario["design_sha256"] = canonical_digest(design)
        if change_scenario:
            change_scenario(scenario)
        with self.assertRaises(DesignError):
            simulate(design, scenario)

    def test_full_work_and_knowledge_trace(self):
        result = simulate(self.design, self.scenario)
        self.assertEqual(result["status"], "SIMULATED_TERMINAL")
        self.assertEqual(result["terminal_stock"], "work.reported")
        self.assertEqual([s["status"] for s in result["trace"]], ["SUCCESS"] * 3)
        self.assertEqual(result["stocks"]["work.pending"], [])
        self.assertEqual(result["stocks"]["work.reported"], ["request:example"])
        self.assertEqual(result["stocks"]["knowledge.sources"], ["source:alpha"])
        self.assertEqual(result["stocks"]["knowledge.assessments"], ["assessment:alpha"])
        self.assertEqual(result["lineage"]["assessment:alpha"]["parents"], ["source:alpha"])
        self.assertFalse(result["execution_authorized"])
        self.assertFalse(result["knowledge_approved"])
        self.assertFalse(result["observations_independently_verified"])

    def test_pure_replay_and_deterministic_digest(self):
        original_design = copy.deepcopy(self.design)
        original_scenario = copy.deepcopy(self.scenario)
        a = simulate(self.design, self.scenario)
        b = simulate(self.design, self.scenario)
        self.assertEqual(a, b)
        self.assertEqual(self.design, original_design)
        self.assertEqual(self.scenario, original_scenario)

    def test_guard_violation_goes_to_failure_without_knowledge(self):
        s = self.scenario
        s["steps"] = [{"flow":"collect_sources", "work_artifact":"request:example",
                       "guards":{"sources_available":"VIOLATED"},
                       "observations":{},"knowledge_produced":[]}]
        result = simulate(self.design,s)
        self.assertEqual(result["trace"][0]["status"], "FAILURE")
        self.assertEqual(result["terminal_stock"], "work.stopped")
        self.assertEqual(result["stocks"]["knowledge.sources"], [])

    def test_guard_unknown_goes_to_unknown(self):
        self.scenario["steps"] = [{"flow":"collect_sources", "work_artifact":"request:example",
                                   "guards":{"sources_available":"UNKNOWN"},
                                   "observations":{},"knowledge_produced":[]}]
        out = simulate(self.design, self.scenario)
        self.assertEqual(out["trace"][0]["status"], "UNKNOWN")
        self.assertEqual(out["terminal_stock"], "work.stopped")

    def test_observation_violation_does_not_create_artifacts(self):
        self.scenario["steps"] = [{"flow":"collect_sources", "work_artifact":"request:example",
                                   "guards":{"sources_available":"VERIFIED"},
                                   "observations":{"source_refs_recorded":"VIOLATED"},
                                   "knowledge_produced":[]}]
        out = simulate(self.design, self.scenario)
        self.assertEqual(out["trace"][0]["status"], "FAILURE")
        self.assertEqual(len(out["lineage"]), 1)

    def test_observation_unknown_goes_to_unknown(self):
        self.scenario["steps"] = [{"flow":"collect_sources", "work_artifact":"request:example",
                                   "guards":{"sources_available":"VERIFIED"},
                                   "observations":{"source_refs_recorded":"UNKNOWN"},
                                   "knowledge_produced":[]}]
        out = simulate(self.design, self.scenario)
        self.assertEqual(out["trace"][0]["status"], "UNKNOWN")

    def test_incomplete_scenario_is_not_reported_as_success(self):
        self.scenario["steps"] = self.scenario["steps"][:1]
        out = simulate(self.design,self.scenario)
        self.assertEqual(out["status"], "SIMULATION_INCOMPLETE")
        self.assertIsNone(out["terminal_stock"])

    def test_reject_stale_pinned_design(self):
        self.invalid(change_scenario=lambda s: s.__setitem__("design_sha256", "0"*64))

    def test_reject_revision_mismatch(self):
        self.invalid(change_scenario=lambda s: s.__setitem__("revision", 2))

    def test_reject_boolean_revision(self):
        self.invalid(change_scenario=lambda s: s.__setitem__("revision", True))

    def test_reject_wrong_schema(self):
        self.invalid(change_scenario=lambda s: s.__setitem__("schema", "executing.v9"))

    def test_reject_claimed_approval(self):
        self.invalid(change_scenario=lambda s: s.__setitem__("approved", True))

    def test_reject_step_that_exceeds_budget(self):
        self.invalid(change_design=lambda d: d["resources"].__setitem__("max_steps", 2))

    def test_reject_duplicate_initial_work_artifacts(self):
        def change(d):
            d["stocks"][0]["initial"].append("request:two")
        self.invalid(change_design=change)

    def test_reject_unexpected_guard(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["guards"].update({"approval":"VERIFIED"}))

    def test_reject_boolean_guard(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["guards"].__setitem__("sources_available", True))

    def test_reject_missing_observation_when_guards_verified(self):
        self.invalid(change_scenario=lambda s: s["steps"][0].__setitem__("observations", {}))

    def test_reject_observations_when_guard_unknown(self):
        def change(s):
            s["steps"] = [{"flow":"collect_sources", "work_artifact":"request:example",
                           "guards":{"sources_available":"UNKNOWN"},
                           "observations":{"source_refs_recorded":"VERIFIED"},
                           "knowledge_produced":[]}]
        self.invalid(change_scenario=change)

    def test_reject_created_knowledge_when_guard_fails(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["guards"].__setitem__("sources_available", "VIOLATED"))

    def test_reject_created_knowledge_when_observation_fails(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["observations"].__setitem__("source_refs_recorded", "VIOLATED"))

    def test_reject_duplicate_knowledge_identity(self):
        self.invalid(change_scenario=lambda s: s["steps"][1]["knowledge_produced"][0].__setitem__("id", "source:alpha"))

    def test_reject_unknown_provenance_parent(self):
        self.invalid(change_scenario=lambda s: s["steps"][1]["knowledge_produced"][0].__setitem__("parents", ["nonexistent:artifact"]))

    def test_reject_parent_outside_declared_knowledge_inputs(self):
        self.invalid(change_scenario=lambda s: s["steps"][1]["knowledge_produced"][0].__setitem__("parents", ["request:example"]))

    def test_reject_initial_source_not_derived_from_work(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["knowledge_produced"][0].__setitem__("parents", ["another:request"]))

    def test_reject_knowledge_in_wrong_stock(self):
        self.invalid(change_scenario=lambda s: s["steps"][0]["knowledge_produced"][0].__setitem__("stock", "knowledge.assessments"))

    def test_reject_missing_declared_knowledge_output(self):
        self.invalid(change_scenario=lambda s: s["steps"][0].__setitem__("knowledge_produced", []))

    def test_reject_artifact_budget_exceeded(self):
        self.invalid(change_design=lambda d: d["resources"].__setitem__("max_artifacts", 1))

    def test_reject_unresolved_knowledge_dependency(self):
        def change(s):
            s["steps"] = [s["steps"][1]]
        self.invalid(change_scenario=change)

    def test_reject_out_of_order_transition(self):
        self.invalid(change_scenario=lambda s: s["steps"].reverse())

    def test_reject_steps_after_terminal(self):
        self.invalid(change_scenario=lambda s: s["steps"].append(copy.deepcopy(s["steps"][2])))

    def test_reject_fake_work_identity(self):
        self.invalid(change_scenario=lambda s: s["steps"][0].__setitem__("work_artifact", "request:spoof"))

    def test_reject_unsupported_capability_in_design(self):
        self.invalid(change_design=lambda d: d["flows"][0].__setitem__("capability", "shell_exec"))

    def test_reject_workflow_with_direct_authority_claim(self):
        self.invalid(change_design=lambda d: d.__setitem__("approval", "granted"))

    def test_reject_duplicate_scenario_json_keys(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'duplicate.json'
            p.write_text('{"schema":"a","schema":"b"}', encoding='utf-8')
            with self.assertRaises(DesignError):
                load_scenario(p)

    def test_reject_nan_scenario(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'nan.json'
            p.write_text('{"score": NaN}', encoding='utf-8')
            with self.assertRaises(DesignError):
                load_scenario(p)

    def test_reject_oversized_scenario(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'huge.json'
            p.write_text(' '*256_001, encoding='utf-8')
            with self.assertRaises(DesignError):
                load_scenario(p)

    def test_cli_escapes_untrusted_terminal_controls_in_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad_design = copy.deepcopy(self.design)
            bad_design["stocks"][0]["kind"] = "\x1b[2Jmalformed"
            p = Path(tmp) / 'bad_design.json'
            p.write_text(json.dumps(bad_design), encoding='utf-8')
            proc = subprocess.run([sys.executable, str(ROOT/'tools/simulate_dualflow.py'),
                                   str(p), str(SCENARIO)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 2)
            self.assertNotIn("\x1b", proc.stderr)
            self.assertIn("SIMULATION_REJECTED:", proc.stderr)

    def test_failure_after_prior_success_preserves_only_prior_knowledge(self):
        self.scenario["steps"] = [self.scenario["steps"][0], {
            "flow": "assess_sources", "work_artifact": "request:example",
            "guards": {"provenance_inspected": "VERIFIED"},
            "observations": {"assessments_attributed": "VIOLATED"},
            "knowledge_produced": []}]
        r = simulate(self.design, self.scenario)
        self.assertEqual(r["trace"][-1]["status"], "FAILURE")
        self.assertEqual(r["terminal_stock"], "work.stopped")
        self.assertIn("source:alpha", r["lineage"])
        self.assertNotIn("assessment:alpha", r["lineage"])
        self.assertEqual(len(r["lineage"]), 2)

    def test_cli_valid_and_invalid_exit_codes(self):
        valid = subprocess.run([sys.executable, str(ROOT/'tools/simulate_dualflow.py'),
                                str(DESIGN), str(SCENARIO)], capture_output=True, text=True)
        self.assertEqual(valid.returncode, 0)
        self.assertEqual(json.loads(valid.stdout)['status'], 'SIMULATED_TERMINAL')
        invalid = subprocess.run([sys.executable, str(ROOT/'tools/simulate_dualflow.py'),
                                  str(DESIGN), str(ROOT/'docs/dualflow/examples/evidence_review.json')],
                                 capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn('SIMULATION_REJECTED:', invalid.stderr)


if __name__ == '__main__':
    unittest.main()
