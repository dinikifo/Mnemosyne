"""WL-05 offline history tests: deterministic chain and review-only custody."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError, load_design
from history_dualflow import (GENESIS, _entry, append_event, load_history,
                              verify_history, verify_report)
from patch_dualflow import load_patch
from review_dualflow import assess_revision, load_review_note, load_suite
from simulate_dualflow import canonical_digest

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'docs/dualflow/examples'


class DurableReviewHistoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = assess_revision(load_design(EXAMPLES / 'evidence_review.json'),
                                     load_patch(EXAMPLES / 'evidence_review.patch.json'),
                                     load_suite(EXAMPLES / 'evidence_review.regression.json'))
        cls.note = load_review_note(EXAMPLES / 'evidence_review.review_note.json')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'review_history.jsonl'

    def report_entry(self):
        return append_event(self.path, 'REGRESSION_REPORT', self.report, GENESIS)

    def note_entry(self):
        report_result = self.report_entry()
        return append_event(self.path, 'REVIEW_NOTE', self.note, report_result['head_sha256'])

    def test_empty_history_is_genesis_and_non_authorizing(self):
        summary = verify_history([])
        self.assertEqual(summary['head_sha256'], GENESIS)
        self.assertFalse(summary['owner_accepted'])
        self.assertFalse(summary['workflow_published'])

    def test_report_round_trip(self):
        summary = self.report_entry()
        self.assertEqual((summary['events'], summary['reports'], summary['review_notes']), (1,1,0))
        entries = load_history(self.path)
        self.assertEqual(entries[0]['payload'], self.report)
        self.assertIsNone(entries[0]['previous_entry_sha256'])
        self.assertEqual(summary['head_sha256'], entries[0]['entry_sha256'])

    def test_report_note_chained_and_persisted(self):
        summary = self.note_entry()
        self.assertEqual((summary['events'], summary['reports'], summary['review_notes']), (2,1,1))
        first, second = load_history(self.path)
        self.assertEqual(second['previous_entry_sha256'], first['entry_sha256'])
        self.assertEqual(second['payload'], self.note)
        self.assertFalse(summary['owner_accepted'])
        self.assertFalse(summary['knowledge_approved'])

    def test_deterministic_history_bytes(self):
        self.note_entry()
        raw = self.path.read_bytes()
        other = Path(self.tmp.name) / 'other.jsonl'
        s1 = append_event(other, 'REGRESSION_REPORT', self.report, GENESIS)
        append_event(other, 'REVIEW_NOTE', self.note, s1['head_sha256'])
        self.assertEqual(raw, other.read_bytes())

    def test_duplicate_report_rejected_without_mutating_file(self):
        summary = self.report_entry()
        before = self.path.read_bytes()
        with self.assertRaisesRegex(DesignError, 'duplicate report'):
            append_event(self.path, 'REGRESSION_REPORT', self.report, summary['head_sha256'])
        self.assertEqual(self.path.read_bytes(), before)

    def test_duplicate_note_rejected(self):
        summary = self.note_entry()
        with self.assertRaisesRegex(DesignError, 'duplicate review note'):
            append_event(self.path, 'REVIEW_NOTE', self.note, summary['head_sha256'])

    def test_note_first_is_forbidden(self):
        with self.assertRaisesRegex(DesignError, 'report absent'):
            append_event(self.path, 'REVIEW_NOTE', self.note, GENESIS)
        self.assertFalse(self.path.exists())

    def test_stale_history_head_rejected_without_mutation(self):
        self.report_entry()
        before = self.path.read_bytes()
        with self.assertRaisesRegex(DesignError, 'stale history head'):
            append_event(self.path, 'REVIEW_NOTE', self.note, GENESIS)
        self.assertEqual(self.path.read_bytes(), before)

    def test_report_claiming_owner_approval_rejected_even_with_recomputed_hash(self):
        report = copy.deepcopy(self.report)
        report['owner_accepted'] = True
        report['evidence_sha256'] = canonical_digest(
            {k:v for k,v in report.items() if k!='evidence_sha256'})
        with self.assertRaisesRegex(DesignError, 'owner_accepted'):
            append_event(self.path, 'REGRESSION_REPORT', report, GENESIS)

    def test_report_status_inconsistent_with_count_rejected(self):
        report = copy.deepcopy(self.report)
        report['status'] = 'REGRESSION_MISMATCH'
        report['evidence_sha256'] = canonical_digest(
            {k:v for k,v in report.items() if k!='evidence_sha256'})
        with self.assertRaisesRegex(DesignError, 'report status inconsistent'):
            verify_report(report)

    def test_report_forged_test_counts_rejected(self):
        report = copy.deepcopy(self.report)
        report['cases_passed'] = 100
        report['evidence_sha256'] = canonical_digest(
            {k:v for k,v in report.items() if k!='evidence_sha256'})
        with self.assertRaisesRegex(DesignError, 'counts mismatch'):
            verify_report(report)

    def test_report_bogus_digest_rejected(self):
        report = copy.deepcopy(self.report)
        report['evidence_sha256'] = '0'*64
        with self.assertRaisesRegex(DesignError, 'report digest mismatch'):
            append_event(self.path, 'REGRESSION_REPORT', report, GENESIS)

    def test_review_note_claiming_approval_rejected(self):
        summary = self.report_entry()
        note = copy.deepcopy(self.note)
        note['owner_accepted'] = True
        with self.assertRaises(DesignError):
            append_event(self.path, 'REVIEW_NOTE', note, summary['head_sha256'])

    def test_note_from_unrelated_report_rejected(self):
        summary = self.report_entry()
        note = copy.deepcopy(self.note)
        note['evidence_sha256'] = '0'*64
        with self.assertRaises(DesignError):
            append_event(self.path, 'REVIEW_NOTE', note, summary['head_sha256'])

    def test_corrupt_first_digest_detected(self):
        self.note_entry()
        entries = load_history(self.path)
        entries[0]['entry_sha256'] = '0'*64
        with self.assertRaisesRegex(DesignError, 'digest mismatch'):
            verify_history(entries)

    def test_corrupt_link_detected_even_with_valid_local_digest(self):
        self.note_entry()
        entries = load_history(self.path)
        entries[1]['previous_entry_sha256'] = '0'*64
        entries[1]['entry_sha256'] = canonical_digest(
            {k:v for k,v in entries[1].items() if k!='entry_sha256'})
        with self.assertRaisesRegex(DesignError, 'broken history link'):
            verify_history(entries)

    def test_missing_entry_detected(self):
        self.note_entry()
        entries = load_history(self.path)
        with self.assertRaisesRegex(DesignError, 'nonconsecutive'):
            verify_history(entries[1:])

    def test_noncanonical_input_keys_not_allowed(self):
        self.report_entry()
        line = self.path.read_text()
        line = line.replace('"sequence":1', '"sequence":1,"sequence":1', 1)
        self.path.write_text(line)
        with self.assertRaises(DesignError):
            load_history(self.path)

    def test_torn_line_detected(self):
        self.report_entry()
        self.path.write_bytes(self.path.read_bytes()[:-1])
        with self.assertRaisesRegex(DesignError, 'incomplete history'):
            load_history(self.path)

    def test_tampered_payload_detected(self):
        self.note_entry()
        entries = load_history(self.path)
        entries[0]['payload']['cases_passed'] = 0
        with self.assertRaises(DesignError):
            verify_history(entries)

    def test_missing_unknown_or_invalid_event_kind(self):
        with self.assertRaises(DesignError):
            append_event(self.path, 'OWNER_ACCEPTANCE', self.report, GENESIS)
        self.assertFalse(self.path.exists())

    def test_synced_history_is_not_an_authorization_receipt(self):
        self.note_entry()
        summary = verify_history(load_history(self.path))
        for claim in ('reviewer_identity_verified', 'owner_accepted', 'execution_authorized',
                      'workflow_published', 'knowledge_approved'):
            self.assertIs(summary[claim], False)

    def test_external_file_rollback_not_detectable_without_pinned_head(self):
        first = self.report_entry()
        snap = self.path.read_bytes()
        self.note_entry_again(first)
        self.path.write_bytes(snap)  # same valid prefix restored by external actor
        self.assertEqual(verify_history(load_history(self.path))['head_sha256'],
                         first['head_sha256'])
        # Deliberately documents the limit: retaining last head separately is necessary.

    def note_entry_again(self, first):
        append_event(self.path, 'REVIEW_NOTE', self.note, first['head_sha256'])

    def test_cli_end_to_end(self):
        report_file = Path(self.tmp.name) / 'report.json'
        note_file = Path(self.tmp.name) / 'note.json'
        report_file.write_text(json.dumps(self.report), encoding='utf-8')
        note_file.write_text(json.dumps(self.note), encoding='utf-8')
        program = str(ROOT / 'tools/history_dualflow.py')
        first = subprocess.run([sys.executable, program, 'append-report', str(self.path),
                                str(report_file), '--expected-head', 'GENESIS'],
                               capture_output=True, text=True)
        self.assertEqual(first.returncode, 0, first.stderr)
        head = json.loads(first.stdout)['head_sha256']
        second = subprocess.run([sys.executable, program, 'append-note', str(self.path),
                                 str(note_file), '--expected-head', head],
                                capture_output=True, text=True)
        self.assertEqual(second.returncode, 0, second.stderr)
        verified = subprocess.run([sys.executable, program, 'verify', str(self.path)],
                                  capture_output=True, text=True)
        self.assertEqual(verified.returncode, 0, verified.stderr)
        self.assertEqual(json.loads(verified.stdout)['events'], 2)

    def test_cli_verify_detects_external_head_mismatch(self):
        self.note_entry()
        cmd = [sys.executable, str(ROOT / 'tools/history_dualflow.py'),
               'verify', str(self.path), '--expected-head', '0'*64]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn('head differs from external pin', proc.stderr)

    def test_cli_verify_rejects_missing_ledger(self):
        cmd = [sys.executable, str(ROOT / 'tools/history_dualflow.py'), 'verify', str(self.path)]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn('history file is absent', proc.stderr)

    def test_cli_rejects_stale_expected_head(self):
        self.report_entry()
        p = Path(self.tmp.name) / 'note.json'
        p.write_text(json.dumps(self.note))
        proc = subprocess.run([sys.executable, str(ROOT / 'tools/history_dualflow.py'),
                               'append-note', str(self.path), str(p),
                               '--expected-head', 'GENESIS'], capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn('stale history head', proc.stderr)

    def test_symlink_history_rejected(self):
        target = Path(self.tmp.name) / 'target.jsonl'
        target.write_text('{}\n')
        self.path.symlink_to(target)
        with self.assertRaises(DesignError):
            append_event(self.path, 'REGRESSION_REPORT', self.report, GENESIS)

    def test_invalid_second_event_does_not_modify_prior_valid_history(self):
        s = self.report_entry()
        old = self.path.read_bytes()
        invalid = copy.deepcopy(self.note)
        invalid['candidate_sha256'] = 'f'*64
        with self.assertRaises(DesignError):
            append_event(self.path, 'REVIEW_NOTE', invalid, s['head_sha256'])
        self.assertEqual(self.path.read_bytes(), old)

    def test_result_input_not_modified(self):
        report = copy.deepcopy(self.report)
        before = copy.deepcopy(report)
        append_event(self.path, 'REGRESSION_REPORT', report, GENESIS)
        self.assertEqual(report, before)


if __name__ == '__main__':
    unittest.main()
