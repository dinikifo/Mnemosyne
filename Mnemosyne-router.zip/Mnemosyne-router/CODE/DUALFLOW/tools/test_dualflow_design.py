"""Offline WL-01/SF-01 design-contract tests; not runtime/integration tests."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import tempfile
import unittest

from check_dualflow_design import DesignError, check_design, load_design


EXAMPLE = (Path(__file__).resolve().parents[1]
           / "docs/dualflow/examples/evidence_review.json")


class DualFlowDesignChecks(unittest.TestCase):
    def setUp(self):
        self.doc = load_design(EXAMPLE)

    def invalid(self, edit):
        doc = copy.deepcopy(self.doc)
        edit(doc)
        with self.assertRaises(DesignError):
            check_design(doc)

    def test_example_is_valid_shape_only(self):
        result = check_design(self.doc)
        self.assertEqual(result["status"], "DESIGN_SHAPE_VALID_ONLY")
        self.assertFalse(result["execution_authorized"])
        self.assertFalse(result["knowledge_approved"])
        self.assertEqual(result["flows"], 3)

    def test_reject_unsupported_schema(self):
        self.invalid(lambda d: d.__setitem__("schema", "hwi.dualflow.v999"))

    def test_reject_self_claimed_approval_field(self):
        self.invalid(lambda d: d.__setitem__("approved", True))

    def test_reject_escalated_mode(self):
        self.invalid(lambda d: d.__setitem__("mode", "execute"))

    def test_reject_arbitrary_capability(self):
        self.invalid(lambda d: d["flows"][0].__setitem__("capability", "shell_exec"))

    def test_reject_unknown_stock(self):
        self.invalid(lambda d: d["flows"][0]["outputs"].append("work.nonexistent"))

    def test_reject_missing_failure_edge(self):
        self.invalid(lambda d: d["flows"][0].pop("on_failure"))

    def test_reject_nonterminal_unknown_edge(self):
        self.invalid(lambda d: d["flows"][0].__setitem__("on_unknown", "work.retrieved"))

    def test_reject_duplicate_stock_id(self):
        self.invalid(lambda d: d["stocks"].append(copy.deepcopy(d["stocks"][0])))

    def test_reject_unreachable_work_stock(self):
        self.invalid(lambda d: d["stocks"].append({"id":"work.orphan","kind":"work","initial":[]}))

    def test_reject_terminal_outgoing_flow(self):
        def edit(d):
            d["flows"][2]["inputs"] = ["work.reported", "knowledge.assessments"]
        self.invalid(edit)

    def test_reject_cycle(self):
        def edit(d):
            d["flows"][2]["outputs"] = ["work.pending"]
        self.invalid(edit)

    def test_reject_boolean_revision(self):
        self.invalid(lambda d: d.__setitem__("revision", True))

    def test_reject_missing_mandatory_invariant(self):
        self.invalid(lambda d: d["invariants"].remove("no_protected_writes"))

    def test_reject_duplicated_initial_artifact(self):
        self.invalid(lambda d: d["stocks"][1]["initial"].append("request:example"))

    def test_reject_duplicate_json_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "duplicate.json"
            p.write_text('{"schema":"a","schema":"b"}', encoding="utf-8")
            with self.assertRaises(DesignError):
                load_design(p)

    def test_reject_json_nan(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "nan.json"
            p.write_text('{"value":NaN}', encoding="utf-8")
            with self.assertRaises(DesignError):
                load_design(p)


if __name__ == "__main__":
    unittest.main()
