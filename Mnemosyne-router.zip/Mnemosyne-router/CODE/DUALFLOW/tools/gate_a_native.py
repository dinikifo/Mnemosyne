"""Gate A native verification: one command per target machine, one JSON report.

Run through RUN_GATE_A_NATIVE.command on each machine you will use (macOS, the
Linux PC, the Raspberry Pi). Every step uses temporary folders and throwaway
keys; it never reads or writes real notebooks, keys, policies or ~/.config/hwi.

Steps (each must pass for Gate A on this machine):
  1. archive      VERIFY_ARCHIVE.py (before anything else can create files)
  2. offline      RUN_ALL_OFFLINE.command (all suites)
  3. walkthrough  USER_MANUAL end to end through RUN_GOVERNANCE.command
  4. concurrency  8 gated submitters against a quota of 3
  5. install      INSTALL.sh in a temporary HOME: install, then idempotent re-run
Informational (never fail the gate): platform facts, Ollama reachability, and
whether the home folder sits on an SD card.

The report goes OUTSIDE the release folder (default ~/hwi-gate-a/), because the
release's integrity check refuses unexpected files.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request

LABEL = re.compile(r'^[a-z0-9][a-z0-9-]{0,31}$')
STEP_TIMEOUT = 1800


def _env(root: Path, **extra):
    env = dict(os.environ)
    env.update(PYTHONDONTWRITEBYTECODE='1',
               PYTHONPATH=os.pathsep.join(str(root / p) for p in
                                          ('CODE/DUALFLOW', 'CODE/APPROVED_WIKI_CORE',
                                           'CODE/APPROVED_AGENT_PROVIDER')))
    env.update(extra)
    return env


def _run(name, cmd, root, logs: Path, check, env=None, cwd=None):
    started = time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=cwd or root, env=env or _env(root), capture_output=True,
                              text=True, timeout=STEP_TIMEOUT, stdin=subprocess.DEVNULL)
        output, code = proc.stdout + proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = f'TIMEOUT after {STEP_TIMEOUT}s\n{exc.stdout or ""}{exc.stderr or ""}', -1
    log = logs / f'{name}.log'
    log.write_text(output, encoding='utf-8')
    log.chmod(0o600)
    passed, detail = check(code, output)
    return {'step':name, 'passed':passed, 'detail':detail, 'exit_code':code,
            'seconds':round(time.monotonic() - started, 1), 'log':log.name,
            'log_sha256':hashlib.sha256(output.encode('utf-8')).hexdigest()}


def _check_archive(code, out):
    m = re.search(r'VERIFIED (\d+)/(\d+)', out)
    return (code == 0 and m is not None and m.group(1) == m.group(2)), (m.group(0) if m else out.strip()[-200:])


def _check_offline(code, out):
    ran = [int(n) for n in re.findall(r'^Ran (\d+) tests?', out, re.M)]
    failed = re.findall(r'^FAILED.*$', out, re.M)
    return (code == 0 and len(ran) >= 4 and not failed), {'suites':ran, 'total':sum(ran), 'failed':failed}


def _check_walkthrough(code, out):
    ok = code == 0 and 'WALKTHROUGH COMPLETE' in out
    steps = len(re.findall(r'^OK ', out, re.M))
    return ok, {'ok_steps':steps, 'last_line':out.strip().splitlines()[-1] if out.strip() else ''}


def _check_json(code, out):
    try:
        data = json.loads(out.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return False, out.strip()[-200:]
    return (code == 0 and data.get('passed') is True), data


def _install_step(root: Path, logs: Path, label: str):
    started = time.monotonic()
    tmp = Path(tempfile.mkdtemp(prefix='hwi-gate-a-install.')).resolve()
    os.chmod(tmp, 0o700)
    env = _env(root, HOME=str(tmp), XDG_CONFIG_HOME=str(tmp / 'xdg'))
    cmd = ['sh', str(root / 'INSTALL.sh'), '--role', 'wiki-and-model', '--label', label,
           '--workspace', str(tmp / 'ws'), '--skip-ollama-check']
    outputs, statuses, codes = [], [], []
    try:
        for _ in range(2):
            proc = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=STEP_TIMEOUT,
                                  stdin=subprocess.DEVNULL)
            outputs.append(proc.stdout + proc.stderr)
            codes.append(proc.returncode)
            try:
                statuses.append(json.loads(proc.stdout)['status'])
            except (ValueError, KeyError):
                statuses.append(None)
        profile = tmp / 'xdg' / 'hwi' / 'host_profile.json'
        mode = oct(profile.stat().st_mode & 0o777) if profile.exists() else None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    output = '\n'.join(outputs)
    (logs / 'install.log').write_text(output, encoding='utf-8')
    (logs / 'install.log').chmod(0o600)
    passed = codes == [0, 0] and statuses == ['INSTALLED', 'ALREADY_INSTALLED'] and mode == '0o600'
    return {'step':'install', 'passed':passed,
            'detail':{'statuses':statuses, 'profile_mode':mode}, 'exit_code':codes,
            'seconds':round(time.monotonic() - started, 1), 'log':'install.log',
            'log_sha256':hashlib.sha256(output.encode('utf-8')).hexdigest()}


def _facts(root: Path):
    conn = sqlite3.connect(':memory:')
    try:
        fts5 = bool(conn.execute("SELECT sqlite_compileoption_used('ENABLE_FTS5')").fetchone()[0])
    finally:
        conn.close()
    try:
        with urllib.request.urlopen('http://127.0.0.1:11434/api/tags', timeout=3) as resp:
            models = [m.get('name') for m in json.loads(resp.read().decode('utf-8')).get('models', [])]
        ollama = {'reachable':True, 'models':models}
    except (OSError, ValueError):
        ollama = {'reachable':False, 'models':[]}
    home_sd = False
    if platform.system() == 'Linux':
        home_sd = os.major(Path.home().stat().st_dev) == 179
    try:
        import cryptography
        crypto = cryptography.__version__
    except ImportError:
        crypto = None
    return {'system':platform.system(), 'release':platform.release(), 'machine':platform.machine(),
            'python':platform.python_version(), 'sqlite':sqlite3.sqlite_version, 'sqlite_fts5':fts5,
            'cryptography':crypto, 'ollama':ollama, 'home_on_sd_card':home_sd,
            'manifest_sha256':hashlib.sha256((root / 'SHA256_MANIFEST.json').read_bytes()).hexdigest()}


def main(argv=None):
    parser = argparse.ArgumentParser(description='Gate A native verification for this machine')
    parser.add_argument('--label', help='Machine label, e.g. mac-m2, pc-cuda, pi5-cpu')
    parser.add_argument('--output-dir', help='Default: ~/hwi-gate-a/<label>-<UTC timestamp>/')
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[3]
    label = args.label or re.sub(r'[^a-z0-9-]', '-', platform.node().lower()).strip('-')[:32] or 'hwi-host'
    if not LABEL.fullmatch(label):
        print('Label: lowercase letters, digits and hyphens, at most 32 characters', file=sys.stderr)
        return 2
    stamp = _dt.datetime.now(_dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = Path(args.output_dir).expanduser() if args.output_dir else Path.home() / 'hwi-gate-a' / f'{label}-{stamp}'
    if out.resolve().is_relative_to(root):
        print('The report must be written outside the release folder', file=sys.stderr)
        return 2
    out.mkdir(mode=0o700, parents=True, exist_ok=False)
    logs = out
    py = sys.executable
    print(f'Gate A native check for {label}; report in {out}', flush=True)
    steps = []
    plan = [
        ('archive', [py, '-I', str(root / 'VERIFY_ARCHIVE.py')], _check_archive),
        ('offline', ['bash', str(root / 'RUN_ALL_OFFLINE.command')], _check_offline),
        ('walkthrough', [py, '-I', '-B', str(root / 'CODE/DUALFLOW/tools/gate_a_walkthrough.py'), str(root)],
         _check_walkthrough),
        ('concurrency', [py, '-I', '-B', str(root / 'CODE/DUALFLOW/tools/gate_a_concurrency.py'), str(root)],
         _check_json),
    ]
    for name, cmd, check in plan:
        print(f'  {name} ...', end=' ', flush=True)
        result = _run(name, cmd, root, logs, check, env=_env(root, HWI_PYTHON=py))
        steps.append(result)
        print('PASS' if result['passed'] else 'FAIL', f"({result['seconds']}s)", flush=True)
        if name == 'archive' and not result['passed']:
            break  # an unverified release makes every later result meaningless
    else:
        print('  install ...', end=' ', flush=True)
        result = _install_step(root, logs, label)
        steps.append(result)
        print('PASS' if result['passed'] else 'FAIL', f"({result['seconds']}s)", flush=True)
    passed = len(steps) == 5 and all(s['passed'] for s in steps)
    report = {'schema':'hwi.gate_a.native_report.v1', 'machine_label':label, 'generated_at':stamp,
              'gate_a_passed_on_this_machine':passed, 'steps':steps, 'facts':_facts(root),
              'note':'Temporary folders and throwaway keys only; no real notebook, key or policy was used.'}
    report_path = out / f'GATE_A_REPORT_{label}.json'
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    report_path.chmod(0o600)
    print(('GATE A PASSED on ' if passed else 'GATE A FAILED on ') + label)
    print(f'Report: {report_path}')
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
