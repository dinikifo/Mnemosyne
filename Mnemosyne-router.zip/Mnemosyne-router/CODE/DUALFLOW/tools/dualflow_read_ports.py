"""CMR-09: replaceable read-only reporting and pinned-workflow selection ports.

The default implementations retain approved caller behavior. The opt-in routed
implementations send ONLY identities through a separate bounded CMR-09 router
profile; they never let model text, wiki text or router effect intents act as
commands, approvals or tool-execution authorizations.
"""
from __future__ import annotations

from typing import Any, Protocol

from check_dualflow_design import check_design
from simulate_dualflow import canonical_digest, SCHEMA as SIMULATION_SCHEMA


class SimulationReader(Protocol):
    def replay(self, design: dict, scenario: dict) -> dict: ...


class PinnedWorkflowReader(Protocol):
    def select(self, *, broker: Any, reference: str,
               expected_source_revision_sha256: str,
               expected_design_sha256: str,
               expected_workflow_id: str,
               expected_revision: int) -> dict: ...


class DirectSimulationReader:
    def replay(self, design: dict, scenario: dict) -> dict:
        from simulate_dualflow import simulate
        return simulate(design, scenario)


class DirectPinnedWorkflowReader:
    def select(self, **kwargs: Any) -> dict:
        from read_dualflow_wiki import select_pinned_workflow
        return select_pinned_workflow(**kwargs)


def _router(context: dict[str, str]):
    """Bootstrap fresh bounded flow from reviewed local profile. No shared state."""
    from hwi_router.read_protocol import open_read_profile
    def guard(name, msg, _snapshot):
        p = msg.payload
        if name == 'review_context_pinned':
            return (msg.origin == 'dualflow_review' and
                    p['design_sha256'] == context.get('design_sha256') and
                    p['scenario_sha256'] == context.get('scenario_sha256'))
        if name == 'simulator_result_pinned':
            return (msg.origin == 'dualflow_simulator' and
                    p['design_sha256'] == context.get('design_sha256') and
                    p['trace_sha256'] == context.get('trace_sha256'))
        if name == 'agent_read_explicit_pin':
            return (msg.origin == 'agent_evaluation' and
                    all(p.get(k) == context.get(k) for k in (
                        'reference', 'source_revision_sha256', 'design_sha256')))
        if name == 'broker_selection_pinned':
            return (msg.origin == 'wiki_selection' and
                    all(p.get(k) == context.get(k) for k in (
                        'reference', 'source_revision_sha256', 'design_sha256',
                        'selection_sha256')))
        return False

    return open_read_profile('CMR-09', guard)


def _dispatch(router, flow, source, kind, payload, *, parent=None, effect=None):
    # Keep the former adapter-local entrypoint and lazy import for CLI compatibility.
    from hwi_router.read_protocol import dispatch_read_message
    transitions = {'dualflow.regression.request': 'R01',
                   'dualflow.regression.result': 'R02',
                   'agent.pinned_read.request': 'R03',
                   'agent.pinned_read.result': 'R04'}
    return dispatch_read_message(router, flow, source, kind, payload,
                                 parent=parent, effect=effect,
                                 transition=transitions.get(kind, 'UNKNOWN'))


class RoutedSimulationReader:
    """Opt-in simulation substitution; cannot produce or authorize live actions."""
    def __init__(self, delegate: SimulationReader | None = None):
        self.delegate = delegate if delegate is not None else DirectSimulationReader()

    def replay(self, design: dict, scenario: dict) -> dict:
        design_pin = canonical_digest(design)
        scenario_pin = canonical_digest(scenario)
        ctx = {'design_sha256': design_pin, 'scenario_sha256': scenario_pin}
        router, flow, sources = _router(ctx)
        request_id = _dispatch(router, flow, sources['dualflow_review'],
                               'dualflow.regression.request', dict(ctx),
                               effect='dualflow.simulation.read')
        # An expected DesignError must propagate unchanged for the existing
        # WL-04 intentional-rejection test cases. Do NOT silently retry.
        output = self.delegate.replay(design, scenario)
        if (type(output) is not dict or output.get('design_sha256') != design_pin or
                output.get('trace_sha256') != canonical_digest({
                    k: v for k, v in output.items() if k != 'trace_sha256'}) or
                any(output.get(flag) is not False for flag in (
                    'execution_authorized', 'knowledge_approved',
                    'observations_independently_verified'))):
            raise ValueError('unverified simulator read result')
        ctx['trace_sha256'] = output['trace_sha256']
        _dispatch(router, flow, sources['dualflow_simulator'],
                  'dualflow.regression.result',
                  {'design_sha256': design_pin, 'trace_sha256': ctx['trace_sha256']},
                  parent=request_id)
        return output


class RoutedPinnedWorkflowReader:
    """Opt-in exact-revision broker selection with digest-only message routing."""
    def __init__(self, delegate: PinnedWorkflowReader | None = None):
        self.delegate = delegate if delegate is not None else DirectPinnedWorkflowReader()

    def select(self, *, broker: Any, reference: str,
               expected_source_revision_sha256: str,
               expected_design_sha256: str,
               expected_workflow_id: str,
               expected_revision: int) -> dict:
        ctx = {'reference': reference,
               'source_revision_sha256': expected_source_revision_sha256,
               'design_sha256': expected_design_sha256}
        router, flow, sources = _router(ctx)
        request_id = _dispatch(router, flow, sources['agent_evaluation'],
                               'agent.pinned_read.request', dict(ctx),
                               effect='agent.pinned_read')
        result = self.delegate.select(
            broker=broker, reference=reference,
            expected_source_revision_sha256=expected_source_revision_sha256,
            expected_design_sha256=expected_design_sha256,
            expected_workflow_id=expected_workflow_id,
            expected_revision=expected_revision)
        if (type(result) is not dict or
                result.get('source_reference') != reference or
                result.get('source_revision_sha256') != expected_source_revision_sha256 or
                result.get('design_sha256') != expected_design_sha256 or
                result.get('selection_sha256') != canonical_digest({
                    k: v for k, v in result.items() if k != 'selection_sha256'}) or
                result.get('design_sha256') != canonical_digest(result.get('design')) or
                result.get('workflow_id') != expected_workflow_id or
                result.get('revision') != expected_revision or
                result.get('status') != 'PINNED_UNTRUSTED_WIKI_WORKFLOW' or
                result.get('source_class') != 'UNTRUSTED_WIKI_DATA' or
                any(result.get(flag) is not False for flag in (
                    'execution_authorized', 'knowledge_approved',
                    'wiki_source_authenticated', 'workflow_published',
                    'application_authorized', 'application_validated',
                    'knowledge_verified', 'workflow_owner_acceptance_verified'))):
            raise ValueError('unverified wiki read result')
        try:
            check_design(result['design'])
        except Exception as exc:
            raise ValueError('unverified wiki design shape') from exc
        ctx['selection_sha256'] = result['selection_sha256']
        _dispatch(router, flow, sources['wiki_selection'],
                  'agent.pinned_read.result', dict(ctx), parent=request_id)
        return result
