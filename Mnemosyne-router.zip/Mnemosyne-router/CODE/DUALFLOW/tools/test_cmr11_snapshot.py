"""Offline packaging safety and deterministic source-overlay tests."""
from __future__ import annotations
import io
from pathlib import Path
import subprocess
import tempfile
import unittest
import zipfile

from .build_cmr11_snapshot import _safe, _inventory, build


class SnapshotTests(unittest.TestCase):
    def test_reject_unsafe_archive_names(self):
        for name in ('../a', '/etc/passwd', 'x/../y', 'x\\y', 'x//y', './a', ''):
            with self.subTest(name=name), self.assertRaises(ValueError):
                _safe(name)

    def test_invalid_zip_root_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            z = root/'fake.zip'
            with zipfile.ZipFile(z, 'w') as out:
                out.writestr('different-root/file.txt', b'bad')
            with self.assertRaises(ValueError):
                _inventory(z, root, None)

    def test_approved_files_are_immutable_and_overlay_captured(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root/'repo'; repo.mkdir()
            subprocess.run(['git','init','-q',str(repo)], check=True)
            candidate = repo/'hwi_router'/'module.py'
            candidate.parent.mkdir(); candidate.write_text('PASS = True\n')
            subprocess.run(['git','-C',str(repo),'add','hwi_router/module.py'], check=True)
            baseline = root/'base.zip'
            with zipfile.ZipFile(baseline, 'w') as z:
                z.writestr('HWI_CODEBASE_CMR05/CODE/APPROVED_AGENT_PROVIDER/a.py', 'trusted')
                z.writestr('HWI_CODEBASE_CMR05/CODE/APPROVED_WIKI_CORE/b.py', 'wiki')
                z.writestr('HWI_CODEBASE_CMR05/CODE/DUALFLOW/old.txt', 'old')
                z.writestr('HWI_CODEBASE_CMR05/VERIFY_PACKAGE.py', 'historical')
            out = root/'snapshot.zip'
            info=build(baseline, repo, out)
            self.assertEqual(info['approved_source_files'], 2)
            with zipfile.ZipFile(out) as z:
                entries = {n.split('/', 1)[1]: z.read(n)
                           for n in z.namelist()}
                self.assertEqual(entries['CODE/APPROVED_AGENT_PROVIDER/a.py'], b'trusted')
                self.assertEqual(entries['CODE/APPROVED_WIKI_CORE/b.py'], b'wiki')
                self.assertEqual(entries['CODE/DUALFLOW/hwi_router/module.py'], b'PASS = True\n')
                self.assertIn('ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY/VERIFY_PACKAGE.py', entries)
                self.assertIn('MANIFEST.sha256', entries)
                self.assertIn('VERIFY_CONSOLIDATED.py', entries)
            with zipfile.ZipFile(out) as z:
                z.extractall(root/'extracted')
            pkg = root/'extracted'/'HWI_CODEBASE_CMR11'
            result=subprocess.run(['python','-B','VERIFY_CONSOLIDATED.py'], cwd=pkg,
                                  capture_output=True,text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            (pkg/'CODE/APPROVED_AGENT_PROVIDER/a.py').write_text('corrupted')
            result=subprocess.run(['python','-B','VERIFY_CONSOLIDATED.py'], cwd=pkg,
                                  capture_output=True,text=True)
            self.assertNotEqual(result.returncode, 0)


if __name__ == '__main__':
    unittest.main()
