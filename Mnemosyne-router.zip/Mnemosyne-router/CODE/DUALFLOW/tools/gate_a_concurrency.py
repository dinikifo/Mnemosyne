"""Gate A: concurrent gated submissions against one quota, through the real launcher.

Usage: python3 -I gate_a_concurrency.py <release folder> [submitters=8] [quota=3]
Prints a JSON result; exits 0 only when exactly `quota` submissions succeed, all
VERIFIED, and the SQLite gate store records exactly `quota` bound slots.
Temporary workspace and throwaway keys only.
"""
import json, subprocess, sys, unittest
from pathlib import Path

REL = Path(sys.argv[1]).resolve()
N = int(sys.argv[2]) if len(sys.argv) > 2 else 8
Q = int(sys.argv[3]) if len(sys.argv) > 3 else 3
for s in ('CODE/DUALFLOW', 'CODE/APPROVED_WIKI_CORE', 'CODE/APPROVED_AGENT_PROVIDER'):
    sys.path.insert(0, str(REL / s))
from hwi_governance import test_governance as T
from hwi_governance.gate_store import GateStore
from hwi_governance.review_queue import list_entries
from hwi_governance.task_fitness import assess

RESULT = {}


class Concurrency(T.ReviewQueueTests):
    def runTest(self):
        contract, results = T.example(max_proposals=Q)
        cmds = []
        for i in range(N):
            args, _ = self.gate_args(self.agent_spec(reason=f'concurrent {i}'),
                                     contract=contract, results=results, tag=f'c{i}')
            cmds.append(['bash', str(REL / 'RUN_GOVERNANCE.command'), *args])
        procs = [subprocess.Popen(c, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for c in cmds]
        codes = [p.wait() for p in procs]
        entries = list_entries(self.ws, 'primary')
        with GateStore(self.ws.root, 'primary', self.namespace()) as store:
            usage = store.usage(assess(contract, results)['assessment_sha256'])
        RESULT.update(submitters=N, quota=Q, exit_codes=sorted(codes),
                      statuses=sorted(e['fitness_gate']['status'] for e in entries), usage=usage)
        RESULT['passed'] = (codes.count(0) == Q and len(entries) == Q and
                            all(e['fitness_gate']['status'] == 'VERIFIED' for e in entries) and
                            usage == {'reserved': 0, 'bound': Q})


unittest.TextTestRunner(stream=open('/dev/null', 'w'), verbosity=0).run(Concurrency())
print(json.dumps(RESULT, sort_keys=True))
sys.exit(0 if RESULT.get('passed') else 1)
