#!/usr/bin/env python3
"""Offline CMR-11 release-layout source snapshot builder.

Overlays only Git-tracked candidate files onto the frozen CMR-05 release ZIP.
Approved agent/wiki trees and original supporting materials are preserved
byte-for-byte. This does NOT install, sign, execute or accept the candidate.
"""
from __future__ import annotations

import argparse
from hashlib import sha256
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile

PREFIX = 'HWI_CODEBASE_CMR11/'
BASE_PREFIX = 'HWI_CODEBASE_CMR05/'
APPROVED = ('CODE/APPROVED_AGENT_PROVIDER/', 'CODE/APPROVED_WIKI_CORE/')
RETIRED = {'PACKAGE_SHA256.json', 'VERIFY_PACKAGE.py'}

VERIFY_SCRIPT = '''#!/usr/bin/env python3
"""Check hashes AND exact file inventory in extracted CMR-11 snapshot."""
from hashlib import sha256
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
manifest = root / 'MANIFEST.sha256'
rows = manifest.read_text('utf-8').splitlines()
expected = {}
for row in rows:
    digest, marker, name = row.partition('  ')
    if not marker or len(digest) != 64 or name in expected:
        raise SystemExit('Invalid CMR-11 manifest')
    expected[name] = digest
actual = {str(p.relative_to(root).as_posix()) for p in root.rglob('*') if p.is_file()}
if actual != set(expected) | {'MANIFEST.sha256'}:
    missing = sorted(set(expected) - actual)
    extra = sorted(actual - set(expected) - {'MANIFEST.sha256'})
    raise SystemExit(f'CMR-11 inventory mismatch: missing={missing} extra={extra}')
for name, digest in expected.items():
    if sha256((root / name).read_bytes()).hexdigest() != digest:
        raise SystemExit(f'CMR-11 integrity failure: {name}')
print(f'CMR-11 verified {len(expected)} payload files')
'''

README = '''# HWI CMR-11 — Candidate source snapshot

This is an **experimental** consolidation snapshot, NOT an accepted release.
The approved agent provider and wiki-core sources are copied without changes.
The CMR-05 release scaffold has been preserved; its original integrity
metadata is under `ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY/` and does not
validate this candidate. Use `python3 VERIFY_CONSOLIDATED.py` for this ZIP.

Candidate source: `CODE/DUALFLOW/` (includes `hwi_router/`, Formation,
governance and tests). Original approved code: `CODE/APPROVED_AGENT_PROVIDER/`
and `CODE/APPROVED_WIKI_CORE/`.

Run offline tests from the extracted root with the existing release commands,
with Python dependencies installed as the original release specifies. To run
new router tests, set `PYTHONPATH` to include `CODE/DUALFLOW`,
`CODE/DUALFLOW/tools`, and both approved roots. Do not run any installer,
apply signed writes, or start live models merely to verify this archive.

The optional `GIT/HWI_CMR11_CONSOLIDATION.bundle` contains the checkpoint
branch. Restoring the prior CMR-10 commit is the documented rollback.
'''


def _safe(name: str) -> str:
    p = PurePosixPath(name)
    if (not name or name.startswith('/') or '\\' in name or
            any(part in ('', '.', '..') for part in name.split('/')) or
            p.is_absolute()):
        raise ValueError(f'unsafe archive path: {name!r}')
    return str(p)


def _tracked(repo: Path) -> list[str]:
    names = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '-z']).split(b'\0')
    return sorted(item.decode('utf-8') for item in names if item)


def _inventory(baseline_zip: Path, repo: Path, bundle: Path | None) -> dict[str, tuple[bytes, int]]:
    contents: dict[str, tuple[bytes, int]] = {}
    with zipfile.ZipFile(baseline_zip) as archive:
        if archive.testzip() is not None:
            raise ValueError('broken baseline ZIP')
        for entry in archive.infolist():
            if entry.is_dir():
                continue
            raw = _safe(entry.filename)
            if not raw.startswith(BASE_PREFIX):
                raise ValueError('unexpected baseline root')
            rel = _safe(raw[len(BASE_PREFIX):])
            if rel in RETIRED:
                # Keep original verification artifacts explicitly baseline-only.
                rel = 'ORIGINAL_RELEASE_INTEGRITY_BASELINE_ONLY/' + rel
            if rel in contents:
                raise ValueError('duplicate source ZIP path')
            mode = ((entry.external_attr >> 16) & 0o777) or 0o644
            contents[rel] = (archive.read(entry), mode)
    approved_before = {name: sha256(data).digest() for name, (data, _) in contents.items()
                       if name.startswith(APPROVED)}
    for rel in _tracked(repo):
        safe = _safe(rel)
        source = repo / safe
        if not source.is_file() or source.is_symlink():
            raise ValueError('unsafe Git-tracked source')
        dst = 'CODE/DUALFLOW/' + safe
        if dst.startswith(APPROVED):
            raise ValueError('attempted approved source overwrite')
        mode = 0o755 if source.stat().st_mode & stat.S_IXUSR else 0o644
        contents[dst] = (source.read_bytes(), mode)
    approved_after = {name: sha256(data).digest() for name, (data, _) in contents.items()
                      if name.startswith(APPROVED)}
    if approved_before != approved_after:
        raise ValueError('approved-source parity failure')
    if bundle is not None:
        if not bundle.is_file():
            raise ValueError('Git bundle missing')
        contents['GIT/HWI_CMR11_CONSOLIDATION.bundle'] = (bundle.read_bytes(), 0o644)
    contents['README_CMR11.md'] = (README.encode('utf-8'), 0o644)
    contents['VERIFY_CONSOLIDATED.py'] = (VERIFY_SCRIPT.encode('utf-8'), 0o755)
    lines = [sha256(data).hexdigest() + '  ' + name
             for name, (data, _) in sorted(contents.items())]
    contents['MANIFEST.sha256'] = (('\n'.join(lines) + '\n').encode('utf-8'), 0o644)
    return contents


def build(baseline_zip: Path, repo: Path, output: Path, bundle: Path | None = None) -> dict:
    if not baseline_zip.is_file() or not (repo / '.git').is_dir():
        raise ValueError('baseline ZIP and real Git checkout required')
    files = _inventory(baseline_zip, repo, bundle)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6,
                         allowZip64=True) as out:
        for name, (data, mode) in sorted(files.items()):
            info = zipfile.ZipInfo(PREFIX + name, date_time=(2026, 11, 14, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | mode) << 16
            out.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    return {'payload_files': len(files)-1, 'approved_source_files': sum(
            name.startswith(APPROVED) for name in files),
            'sha256': sha256(output.read_bytes()).hexdigest(), 'size': output.stat().st_size}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-zip', required=True, type=Path)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--bundle', type=Path)
    options = parser.parse_args()
    print(build(options.baseline_zip, options.repo, options.output, options.bundle))


if __name__ == '__main__':
    main()
