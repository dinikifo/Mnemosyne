"""HWI-I02 offline integration with the real approved Ollama HTTP provider.

The HTTP responder is a deterministic local test double, NOT an LLM.
"""
from __future__ import annotations
import contextlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import os
import subprocess
import sys
import tempfile
import threading
import unittest

from check_dualflow_design import DesignError
from evaluate_dualflow_model import evaluate_model_proposal
from patch_dualflow import load_patch
from run_dualflow_local import (
    evaluate_local_models, installed_models, load_inputs, parse_pins,
    save_report_exclusive, validate_loopback_endpoint,
)

ROOT=Path(__file__).resolve().parents[1]
DOCS=ROOT/'docs/dualflow/examples'
TEST_SHA='b'*64


class Handler(BaseHTTPRequestHandler):
    received=[]
    invalid_tags=False
    wrong_status=False
    redirect_tags=False
    patch_text='{}'

    def do_GET(self):
        if self.path != '/api/tags':
            self.send_error(404);return
        if type(self).redirect_tags:
            self.send_response(302);self.send_header('Location','https://example.invalid/api/tags');self.end_headers();return
        if type(self).wrong_status:
            self.send_error(500);return
        data={'models':[{'name':'local-a:1','digest':TEST_SHA},
                        {'name':'local-b:2','digest':'sha256:'+TEST_SHA}]}
        if type(self).invalid_tags:data={'models':[{'name':'local-a:1','digest':TEST_SHA}]*2}
        self._respond(data)

    def do_POST(self):
        if self.path != '/api/chat':self.send_error(404);return
        length=int(self.headers.get('content-length',0))
        if length > 100000:self.send_error(413);return
        payload=json.loads(self.rfile.read(length))
        type(self).received.append(payload)
        response={'model':payload['model'],'message':{'role':'assistant','content':type(self).patch_text},
                  'prompt_eval_count':100,'eval_count':70,'done':True}
        self._respond(response)

    def _respond(self,payload):
        b=json.dumps(payload).encode()
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(b)))
        self.end_headers();self.wfile.write(b)

    def log_message(self,*args): pass


@contextlib.contextmanager
def local_server():
    Handler.received=[];Handler.invalid_tags=False;Handler.wrong_status=False;Handler.redirect_tags=False
    Handler.patch_text=(DOCS/'evidence_review.patch.json').read_text()
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:yield f'http://127.0.0.1:{server.server_port}'
    finally:
        server.shutdown();thread.join(timeout=5);server.server_close()


def provider(endpoint):
    from autogpt_lite.llm.ollama import OllamaProvider
    result=OllamaProvider(base_url=validate_loopback_endpoint(endpoint))
    result._session.trust_env=False
    result._session.max_redirects=0
    return result


class LoopbackValidationTests(unittest.TestCase):
    def test_valid_defaults_and_ipv6(self):
        self.assertEqual(validate_loopback_endpoint('http://127.0.0.1:11434'),
                         'http://127.0.0.1:11434')
        self.assertEqual(validate_loopback_endpoint('http://[::1]:11434'),
                         'http://[::1]:11434')

    def test_refuse_non_loopback_and_tricks(self):
        for value in ['http://localhost:11434','https://127.0.0.1:11434',
                      'http://127.0.0.2:11434','http://evil.test:11434',
                      'http://user:pwd@127.0.0.1:11434',
                      'http://127.0.0.1:11434/api/tags',
                      'http://127.0.0.1:11434/?q=1',
                      'http://127.0.0.1:99999',
                      'http://127.0.0.1', 'file:///etc/passwd',
                      'http://127.0.0.1:11434#fragment']:
            with self.subTest(value=value),self.assertRaises(DesignError):
                validate_loopback_endpoint(value)

    def test_invalid_pins(self):
        for bad in ['','abc','local-a:1=bad','local-a:1='+'g'*64,
                    'local-a:1='+'b'*64+'=extra']:
            with self.subTest(bad=bad),self.assertRaises(DesignError):parse_pins([bad])
        with self.assertRaises(DesignError):parse_pins(['local-a:1='+TEST_SHA]*2)
        self.assertEqual(parse_pins(['local-a:1='+TEST_SHA]),{'local-a:1':TEST_SHA})


class LocalProtocolTests(unittest.TestCase):
    def setUp(self):
        self.base,self.task,self.patch,self.reg,self.app=load_inputs(
            design=DOCS/'evidence_review.json',
            task_file=DOCS/'evidence_review.model_task.txt',
            reference_patch=DOCS/'evidence_review.patch.json',
            regression=DOCS/'evidence_review.regression.json',
            application=DOCS/'evidence_review.application.json')

    def test_provider_real_http_path_with_pinned_inputs(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            models=installed_models(p)
            self.assertEqual([x['name'] for x in models],['local-a:1','local-b:2'])
            result=evaluate_local_models(
                provider=p,installed=models,model_names=['local-a:1','local-b:2'],
                base=self.base,task=self.task,reference_patch=self.patch,
                regression_suite=self.reg,application_suite=self.app,
                repeats=2,pin_digests={'local-a:1':TEST_SHA},endpoint=endpoint)
            self.assertEqual(result['all_outcomes'],{'MODEL_PATCH_MATCHES_PINNED_REFERENCE':4})
            self.assertFalse(result['execution_authorized'])
            self.assertTrue(result['locally_reported_identity_not_independently_attested'])
            self.assertEqual(len(Handler.received),4)
            for raw in Handler.received:
                self.assertIs(raw['stream'],False)
                self.assertEqual(raw['format'],'json')
                self.assertEqual(raw['options']['temperature'],0.0)
                self.assertIn('base_sha256',raw['messages'][1]['content'])
                self.assertIn(self.patch['base_sha256'],raw['messages'][1]['content'])
                self.assertNotIn('reference_patch',raw['messages'][1]['content'])
                self.assertEqual(raw['messages'][0]['role'],'system')

    def test_missing_model_rejected_before_chat(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            with self.assertRaises(DesignError):evaluate_local_models(
                provider=p,installed=installed_models(p),model_names=['missing:1'],
                base=self.base,task=self.task,reference_patch=None,
                regression_suite=None,application_suite=None,repeats=1,endpoint=endpoint)
            self.assertFalse(Handler.received)

    def test_model_digest_mismatch_rejected_before_chat(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            with self.assertRaises(DesignError):evaluate_local_models(
                provider=p,installed=installed_models(p),model_names=['local-a:1'],
                base=self.base,task=self.task,reference_patch=None,
                regression_suite=None,application_suite=None,repeats=1,
                pin_digests={'local-a:1':'c'*64},endpoint=endpoint)
            self.assertFalse(Handler.received)

    def test_bad_tags_rejected(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            Handler.invalid_tags=True
            with self.assertRaises(DesignError):installed_models(p)

    def test_redirect_does_not_follow_to_remote(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            Handler.redirect_tags=True
            with self.assertRaises(DesignError):installed_models(p)
            self.assertFalse(Handler.received)

    def test_invalid_model_output_reported_without_authority(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            Handler.patch_text='{"execution_authorized":true}'
            report=evaluate_local_models(
                provider=p,installed=installed_models(p),model_names=['local-a:1'],
                base=self.base,task=self.task,reference_patch=None,
                regression_suite=None,application_suite=None,repeats=1,endpoint=endpoint)
            self.assertEqual(report['all_outcomes'],{'MODEL_OUTPUT_REJECTED':1})
            self.assertFalse(report['human_acceptance_obtained'])

    def test_without_reference_stays_untested(self):
        with local_server() as endpoint:
            p=provider(endpoint)
            report=evaluate_local_models(
                provider=p,installed=installed_models(p),model_names=['local-a:1'],
                base=self.base,task=self.task,reference_patch=None,
                regression_suite=None,application_suite=None,repeats=1,endpoint=endpoint)
            self.assertEqual(report['all_outcomes'],{'VALID_CANDIDATE_UNTESTED':1})

    def test_private_exclusive_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'report.json'
            save_report_exclusive(path,{'example':'value'})
            self.assertEqual(path.stat().st_mode & 0o777,0o600)
            with self.assertRaises(FileExistsError):save_report_exclusive(path,{'example':'other'})
            self.assertEqual(json.loads(path.read_text()),{'example':'value'})

    def test_cli_end_to_end(self):
        with local_server() as endpoint,tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'trial.json'
            cli=[sys.executable,str(ROOT/'tools/run_dualflow_local.py'),
                 '--endpoint',endpoint,'--model','local-a:1','--repeats','1',
                 '--pin-model','local-a:1='+TEST_SHA,
                 '--design',str(DOCS/'evidence_review.json'),
                 '--task-file',str(DOCS/'evidence_review.model_task.txt'),
                 '--reference-patch',str(DOCS/'evidence_review.patch.json'),
                 '--regression',str(DOCS/'evidence_review.regression.json'),
                 '--application',str(DOCS/'evidence_review.application.json'),
                 '--output',str(out)]
            proc=subprocess.run(cli,text=True,capture_output=True,timeout=30)
            self.assertEqual(proc.returncode,0,proc.stderr)
            report=json.loads(out.read_text())
            self.assertEqual(report['all_outcomes'],{'MODEL_PATCH_MATCHES_PINNED_REFERENCE':1})
            self.assertEqual(report['models'][0]['local_reported_model_digest_sha256'],TEST_SHA)
            self.assertEqual(out.stat().st_mode & 0o777,0o600)

    def test_cli_list_models(self):
        with local_server() as endpoint:
            proc=subprocess.run([sys.executable,str(ROOT/'tools/run_dualflow_local.py'),
                 '--endpoint',endpoint,'--list-models'],capture_output=True,text=True,timeout=20)
            self.assertEqual(proc.returncode,0,proc.stderr)
            self.assertEqual(len(json.loads(proc.stdout)['installed_models']),2)

    def test_cli_no_service_reports_unavailable(self):
        # No fixed port assumption: start and close a server, then call its port.
        with local_server() as endpoint:pass
        proc=subprocess.run([sys.executable,str(ROOT/'tools/run_dualflow_local.py'),
               '--endpoint',endpoint,'--list-models'],capture_output=True,text=True,timeout=20)
        self.assertEqual(proc.returncode,3)
        self.assertNotIn('success',proc.stdout.lower())

    def test_cli_rejects_network_endpoint_without_contact(self):
        proc=subprocess.run([sys.executable,str(ROOT/'tools/run_dualflow_local.py'),
               '--endpoint','https://example.com','--list-models'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,2)


if __name__=='__main__':unittest.main()
