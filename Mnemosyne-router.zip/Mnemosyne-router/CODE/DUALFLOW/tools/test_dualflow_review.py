"""WL-04 tests: regression replay, exact pins and non-authorizing review notes."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError, load_design
from patch_dualflow import load_patch, propose_revision
from review_dualflow import (
    assess_revision, attach_review_note, load_review_note, load_suite,
)
from simulate_dualflow import canonical_digest

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "docs/dualflow/examples"


class RegressionReviewTests(unittest.TestCase):
    def setUp(self):
        self.base = load_design(EXAMPLES / "evidence_review.json")
        self.patch = load_patch(EXAMPLES / "evidence_review.patch.json")
        self.suite = load_suite(EXAMPLES / "evidence_review.regression.json")
        self.note = load_review_note(EXAMPLES / "evidence_review.review_note.json")

    def report(self):
        return assess_revision(self.base, self.patch, self.suite)

    def reject_suite(self, change):
        suite = copy.deepcopy(self.suite)
        change(suite)
        with self.assertRaises(DesignError):
            assess_revision(self.base, self.patch, suite)

    def test_all_declared_tests_are_actually_simulated(self):
        report = self.report()
        self.assertEqual(report["status"], "READY_FOR_OWNER_REVIEW")
        self.assertEqual(report["cases_passed"], 3)
        self.assertEqual(report["cases_total"], 3)
        self.assertEqual([x["outcome"] for x in report["results"]], ["MATCH"] * 3)
        self.assertEqual([x["observed"]["kind"] for x in report["results"]],
                         ["simulate", "simulate", "reject"])
        self.assertEqual(report["review_outcome"], "PENDING_OWNER_REVIEW")
        self.assertTrue(report["tests_executed_in_synthetic_simulator"])
        for k in ("expected_results_independently_verified",
                  "observations_independently_verified", "reviewer_identity_verified",
                  "owner_accepted", "workflow_published", "execution_authorized", "knowledge_approved"):
            self.assertIs(report[k], False)

    def test_report_hash_binds_all_results(self):
        report = self.report()
        digest = report.pop("evidence_sha256")
        self.assertEqual(digest, canonical_digest(report))
        self.assertEqual(report["candidate_sha256"],
                         propose_revision(self.base, self.patch)["candidate_sha256"])
        self.assertEqual(report["suite_sha256"], canonical_digest(self.suite))

    def test_repeatable_result(self):
        self.assertEqual(self.report(), self.report())

    def test_does_not_mutate_inputs(self):
        before = copy.deepcopy((self.base, self.patch, self.suite))
        self.report()
        self.assertEqual((self.base, self.patch, self.suite), before)

    def test_simulation_unknown_does_not_produce_new_knowledge(self):
        x = self.report()["results"][1]
        self.assertEqual(x["observed"]["flow_statuses"], ["SUCCESS", "SUCCESS", "UNKNOWN"])
        self.assertEqual(x["observed"]["terminal_stock"], "work.stopped")
        self.assertEqual(x["observed"]["knowledge_ids"], ["assessment:alpha", "source:alpha"])

    def test_original_revision_scenario_is_rejected(self):
        x = self.report()["results"][2]
        self.assertIn("revision mismatch", x["observed"]["error"])
        self.assertIsNone(x["trace_sha256"])

    def test_missing_case_is_not_accepted_as_coverage(self):
        self.reject_suite(lambda s: s["cases"].pop())

    def test_additional_undeclared_case_rejected(self):
        def mutate(s):
            new = copy.deepcopy(s["cases"][0])
            new["test_id"] = "unexpected_extra_case"
            s["cases"].append(new)
        self.reject_suite(mutate)

    def test_duplicate_case_id_rejected(self):
        self.reject_suite(lambda s: s["cases"][1].__setitem__("test_id", s["cases"][0]["test_id"]))

    def test_no_positive_simulation_case_rejected(self):
        def mutate(s):
            for case in s["cases"]:
                case["expected"] = {"kind": "reject", "error_contains": "missing input"}
        self.reject_suite(mutate)

    def test_suite_without_successful_terminal_path_rejected(self):
        def mutate(s):
            s["cases"][0]["expected"] = copy.deepcopy(s["cases"][1]["expected"])
        self.reject_suite(mutate)

    def test_wrong_base_digest_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("base_sha256", "0" * 64))

    def test_wrong_patch_digest_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("patch_sha256", "0" * 64))

    def test_wrong_candidate_digest_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("candidate_sha256", "0" * 64))

    def test_uppercase_digest_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("candidate_sha256", s["candidate_sha256"].upper()))

    def test_extra_authorization_claim_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("approved", True))

    def test_extra_case_authority_rejected(self):
        self.reject_suite(lambda s: s["cases"][0].__setitem__("approved", True))

    def test_wrong_suite_schema_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("schema", "hwi.dualflow.regression.v99"))

    def test_wrong_workflow_id_rejected(self):
        self.reject_suite(lambda s: s.__setitem__("workflow_id", "other"))

    def test_positive_case_cannot_pin_old_design(self):
        self.reject_suite(lambda s: s["cases"][0].__setitem__("scenario", copy.deepcopy(s["cases"][2]["scenario"])))

    def test_rejection_case_must_pin_real_design(self):
        self.reject_suite(lambda s: s["cases"][2]["scenario"].__setitem__("design_sha256", "0"*64))

    def test_boolean_revision_rejected(self):
        self.reject_suite(lambda s: s["cases"][0]["scenario"].__setitem__("revision", True))

    def test_malformed_expected_status_rejected(self):
        self.reject_suite(lambda s: s["cases"][0]["expected"].__setitem__("status", []))

    def test_invalid_terminal_rejected(self):
        self.reject_suite(lambda s: s["cases"][0]["expected"].__setitem__("terminal_stock", "work.pending"))

    def test_invalid_flow_status_rejected(self):
        self.reject_suite(lambda s: s["cases"][0]["expected"].__setitem__("flow_statuses", ["APPROVED"]))

    def test_mismatched_expected_outcomes_block_review(self):
        s = copy.deepcopy(self.suite)
        s["cases"][1]["expected"]["flow_statuses"] = ["SUCCESS", "SUCCESS", "FAILURE"]
        r = assess_revision(self.base, self.patch, s)
        self.assertEqual(r["status"], "REGRESSION_MISMATCH")
        self.assertEqual(r["cases_passed"], 2)
        self.assertEqual(r["results"][1]["outcome"], "MISMATCH")
        self.assertFalse(r["owner_accepted"])

    def test_scenario_design_error_is_mismatch_when_success_expected(self):
        s = copy.deepcopy(self.suite)
        s["cases"][0]["scenario"]["steps"][-1]["guards"].pop("conflicts_reviewed")
        r = assess_revision(self.base, self.patch, s)
        self.assertEqual(r["status"], "REGRESSION_MISMATCH")
        self.assertEqual(r["results"][0]["observed"]["kind"], "reject")

    def test_rejection_reason_must_match(self):
        s = copy.deepcopy(self.suite)
        s["cases"][2]["expected"]["error_contains"] = "undeclared resource"
        r = assess_revision(self.base, self.patch, s)
        self.assertEqual(r["status"], "REGRESSION_MISMATCH")

    def test_review_note_is_non_authorizing(self):
        report = self.report()
        annotation = attach_review_note(report, self.note)
        self.assertEqual(annotation["status"], "REVIEW_ANNOTATION_ONLY_NOT_AUTHORIZATION")
        self.assertEqual(annotation["report_sha256"], report["evidence_sha256"])
        for key in ("reviewer_identity_verified", "owner_accepted",
                    "workflow_published", "execution_authorized", "knowledge_approved"):
            self.assertIs(annotation[key], False)
        self.assertEqual(annotation["note"], self.note)

    def test_review_note_does_not_mutate_input(self):
        report, note = self.report(), copy.deepcopy(self.note)
        before = copy.deepcopy((report,note))
        attach_review_note(report,note)
        self.assertEqual((report,note), before)

    def test_review_note_rejects_stale_evidence(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["evidence_sha256"] = "0"*64
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_review_note_rejects_different_candidate(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["candidate_sha256"] = "0"*64
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_review_note_cannot_claim_approval(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["owner_accepted"] = True
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_invalid_review_note_disposition_rejected(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["disposition"] = "APPROVED"
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_review_note_nonexistent_case_id_rejected(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["reviewed_test_ids"] = ["nonexistent"]
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_recommendation_requires_all_cases_reviewed(self):
        report = self.report()
        note = copy.deepcopy(self.note)
        note["disposition"] = "RECOMMEND_FOR_OWNER_DECISION"
        note["reviewed_test_ids"] = ["contradictions_reported"]
        with self.assertRaises(DesignError): attach_review_note(report, note)
        note["reviewed_test_ids"] = list(self.patch["tests_to_run"])
        annotated = attach_review_note(report, note)
        self.assertFalse(annotated["owner_accepted"])

    def test_cannot_recommend_with_failed_regression(self):
        s = copy.deepcopy(self.suite)
        s["cases"][0]["expected"]["knowledge_ids"] = []
        report = assess_revision(self.base, self.patch, s)
        note = copy.deepcopy(self.note)
        note["evidence_sha256"] = report["evidence_sha256"]
        note["disposition"] = "RECOMMEND_FOR_OWNER_DECISION"
        with self.assertRaises(DesignError): attach_review_note(report, note)

    def test_forged_approved_report_rejected(self):
        report = self.report()
        report["owner_accepted"] = True
        report["evidence_sha256"] = canonical_digest(
            {k: v for k, v in report.items() if k != "evidence_sha256"})
        with self.assertRaises(DesignError): attach_review_note(report, self.note)

    def test_tampered_report_rejected(self):
        report = self.report()
        report["cases_passed"] = 100
        with self.assertRaises(DesignError): attach_review_note(report, self.note)

    def test_cli_success_with_note(self):
        cmd = [sys.executable, str(ROOT / "tools/review_dualflow.py"),
               str(EXAMPLES / "evidence_review.json"),
               str(EXAMPLES / "evidence_review.patch.json"),
               str(EXAMPLES / "evidence_review.regression.json"),
               "--review-note", str(EXAMPLES / "evidence_review.review_note.json")]
        proc = subprocess.run(cmd, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        obj = json.loads(proc.stdout)
        self.assertEqual(obj["evidence_report"]["cases_passed"], 3)
        self.assertFalse(obj["review_annotation"]["owner_accepted"])
        report = obj["evidence_report"]
        self.assertEqual(report["evidence_sha256"],
                         canonical_digest({k:v for k,v in report.items() if k!="evidence_sha256"}))

    def test_cli_mismatch_exit_code(self):
        suite = copy.deepcopy(self.suite)
        suite["cases"][0]["expected"]["knowledge_ids"] = []
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "fail.json"
            path.write_text(json.dumps(suite), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(ROOT/"tools/review_dualflow.py"),
                                   str(EXAMPLES/"evidence_review.json"),
                                   str(EXAMPLES/"evidence_review.patch.json"), str(path)],
                                  capture_output=True, text=True)
        self.assertEqual(proc.returncode, 1, proc.stderr)
        self.assertEqual(json.loads(proc.stdout)["status"], "REGRESSION_MISMATCH")

    def test_cli_invalid_input_exit_code(self):
        suite = copy.deepcopy(self.suite)
        suite["owner_accepted"] = True
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.json"
            path.write_text(json.dumps(suite), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(ROOT/"tools/review_dualflow.py"),
                                   str(EXAMPLES/"evidence_review.json"),
                                   str(EXAMPLES/"evidence_review.patch.json"), str(path)],
                                  capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)
        self.assertIn("REGRESSION_REJECTED", proc.stderr)

    def test_duplicate_json_keys_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "duplicate.json"
            f.write_text('{"schema": "a", "schema": "b"}', encoding="utf-8")
            with self.assertRaises(DesignError): load_suite(f)

    def test_nan_json_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "nan.json"
            f.write_text('{"x": NaN}', encoding="utf-8")
            with self.assertRaises(DesignError): load_suite(f)

    def test_large_suite_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "large.json"
            f.write_text(" " * 512001, encoding="utf-8")
            with self.assertRaises(DesignError): load_suite(f)


if __name__ == "__main__":
    unittest.main()
