"""WL-06: application-specific, bounded, synthetic-only validation tests."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError, load_design
from patch_dualflow import load_patch
from review_dualflow import assess_revision, load_suite
from simulate_dualflow import canonical_digest
from validate_dualflow_application import assess_application, load_application

ROOT = Path(__file__).resolve().parents[1]
EX = ROOT / 'docs/dualflow/examples'


class ApplicationValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = load_design(EX/'evidence_review.json')
        cls.patch = load_patch(EX/'evidence_review.patch.json')
        cls.baseline = load_suite(EX/'evidence_review.regression.json')
        cls.original = load_application(EX/'evidence_review.application.json')

    def setUp(self):
        self.application = copy.deepcopy(self.original)

    def assess(self, *, base=None, patch=None, baseline=None, application=None):
        return assess_application(self.base if base is None else base,
                                  self.patch if patch is None else patch,
                                  self.baseline if baseline is None else baseline,
                                  self.application if application is None else application)

    def invalid(self, mutate, fragment=None):
        mutate(self.application)
        with self.assertRaises(DesignError) as cm:
            self.assess()
        if fragment:
            self.assertIn(fragment, str(cm.exception))

    def test_example_ready_for_human_review_only(self):
        r=self.assess()
        self.assertEqual(r['status'], 'READY_FOR_HUMAN_APPLICATION_REVIEW')
        self.assertEqual((r['cases_matched'],r['cases_total']),(3,3))
        self.assertEqual([x['outcome'] for x in r['results']],['MATCH']*3)
        for flag in ('workflow_owner_acceptance_verified','expectations_independently_verified',
                     'observations_independently_verified','human_application_review_completed',
                     'application_authorized','application_executed','knowledge_approved',
                     'workflow_published'):
            self.assertIs(r[flag],False,flag)

    def test_unknown_case_is_safe_stop_without_knowledge(self):
        x=self.assess()['results'][1]
        self.assertEqual(x['observed']['terminal_stock'],'work.stopped')
        self.assertEqual(x['observed']['flow_statuses'],['UNKNOWN'])
        self.assertEqual(x['observed']['knowledge_ids'],[])

    def test_violation_case_is_safe_stop(self):
        x=self.assess()['results'][2]
        self.assertEqual(x['observed']['flow_statuses'],['SUCCESS','SUCCESS','FAILURE'])
        self.assertEqual(x['observed']['terminal_stock'],'work.stopped')

    def test_both_flows_remain_traceable(self):
        r=self.assess()
        self.assertEqual(r['results'][0]['observed']['knowledge_ids'],
                         ['assessment:case6','source:case6'])

    def test_report_identity_is_canonical(self):
        r=self.assess()
        self.assertEqual(r['report_sha256'],canonical_digest(
            {k:v for k,v in r.items() if k!='report_sha256'}))

    def test_no_input_mutation(self):
        original=copy.deepcopy((self.base,self.patch,self.baseline,self.application))
        self.assess()
        self.assertEqual((self.base,self.patch,self.baseline,self.application),original)

    def test_reproducible_output(self):
        self.assertEqual(self.assess(),self.assess())

    def test_expectation_mismatch_blocks_review(self):
        self.application['cases'][0]['expected']['knowledge_ids']=[]
        r=self.assess()
        self.assertEqual(r['status'],'APPLICATION_BLOCKED')
        self.assertEqual((r['cases_matched'],r['cases_total']),(2,3))
        self.assertFalse(r['application_authorized'])

    def test_invalid_scenario_is_recorded_mismatch(self):
        self.application['cases'][0]['scenario']['steps'][-1]['guards'].pop('conflicts_reviewed')
        r=self.assess()
        self.assertEqual(r['status'],'APPLICATION_BLOCKED')
        self.assertEqual(r['results'][0]['observed']['kind'],'reject')

    def test_stale_baseline_evidence_rejected(self):
        self.invalid(lambda a:a.__setitem__('baseline_evidence_sha256','0'*64),'stale baseline')

    def test_baseline_mismatch_blocks_selection(self):
        s=copy.deepcopy(self.baseline)
        s['cases'][0]['expected']['knowledge_ids']=[]
        with self.assertRaisesRegex(DesignError,'baseline regression'):
            self.assess(baseline=s)

    def test_stale_workflow_digest_rejected(self):
        self.invalid(lambda a:a['workflow'].__setitem__('design_sha256','0'*64),'stale or mismatched')

    def test_stale_workflow_revision_rejected(self):
        self.invalid(lambda a:a['workflow'].__setitem__('revision',1),'stale or mismatched')

    def test_bool_revision_rejected(self):
        self.invalid(lambda a:a['workflow'].__setitem__('revision',True),'stale or mismatched')

    def test_wrong_workflow_rejected(self):
        self.invalid(lambda a:a['workflow'].__setitem__('workflow_id','unknown'),'stale or mismatched')

    def test_forged_approval_flag_rejected(self):
        self.invalid(lambda a:a.__setitem__('owner_accepted',True),'application: expected exactly')

    def test_forged_execution_flag_rejected(self):
        self.invalid(lambda a:a['workflow'].__setitem__('execute',True),'workflow selection')

    def test_invalid_schema_rejected(self):
        self.invalid(lambda a:a.__setitem__('schema','hwi.dualflow.application.v99'),'unsupported application')

    def test_missing_task_rejected(self):
        self.invalid(lambda a:a.pop('task'),'application: expected exactly')

    def test_no_requirements_rejected(self):
        self.invalid(lambda a:a['task'].__setitem__('requirements',[]),'requirements')

    def test_duplicate_requirements_rejected(self):
        self.invalid(lambda a:a['task']['requirements'].append(
            copy.deepcopy(a['task']['requirements'][0])),'duplicate requirement')

    def test_empty_goal_rejected(self):
        self.invalid(lambda a:a['task'].__setitem__('goal','x'),'bounded explanatory')

    def test_extra_task_authority_claim_rejected(self):
        self.invalid(lambda a:a['task'].__setitem__('approved_by','owner'),'task: expected exactly')

    def test_undeclared_requirement_rejected(self):
        self.invalid(lambda a:a['cases'][0].__setitem__('requirement_ids',['not_declared']),
                     'undeclared task requirement')

    def test_uncovered_requirement_rejected(self):
        self.invalid(lambda a:a['task']['requirements'].append(
            {'id':'uncovered','description':'Never tested and therefore not covered by any case.'}),
                     'do not cover')

    def test_case_id_reuse_rejected(self):
        self.invalid(lambda a:a['cases'][0].__setitem__('case_id','contradictions_reported'),
                     'reused from baseline')

    def test_duplicate_case_id_rejected(self):
        self.invalid(lambda a:a['cases'][1].__setitem__('case_id',a['cases'][0]['case_id']),
                     'duplicate application test ID')

    def test_exact_baseline_scenario_reuse_rejected(self):
        self.invalid(lambda a:a['cases'][0].__setitem__('scenario',
                     copy.deepcopy(self.baseline['cases'][0]['scenario'])),
                     'scenario steps reused from baseline')

    def test_duplicate_scenario_steps_rejected(self):
        self.invalid(lambda a:a['cases'][2].__setitem__('scenario',
                     copy.deepcopy(a['cases'][1]['scenario'])),
                     'duplicate application scenario')

    def test_no_failure_case_rejected(self):
        self.invalid(lambda a:a.__setitem__('cases',[a['cases'][0]]),'2..16')

    def test_only_successful_expectations_rejected(self):
        def alter(a):
            a['cases'][1]['expected']=copy.deepcopy(a['cases'][0]['expected'])
            a['cases'][2]['expected']=copy.deepcopy(a['cases'][0]['expected'])
        self.invalid(alter,'failure or unknown terminal')

    def test_no_positive_case_rejected(self):
        def alter(a):
            a['cases'][0]['expected']=copy.deepcopy(a['cases'][1]['expected'])
        self.invalid(alter,'successful non-failure terminal')

    def test_stale_scenario_identity_rejected(self):
        self.invalid(lambda a:a['cases'][0]['scenario'].__setitem__('design_sha256','0'*64),
                     'exact selected revision')

    def test_stale_scenario_revision_rejected(self):
        self.invalid(lambda a:a['cases'][0]['scenario'].__setitem__('revision',1),
                     'exact selected revision')

    def test_rejection_expectation_not_allowed(self):
        self.invalid(lambda a:a['cases'][1].__setitem__('expected',
                     {'kind':'reject','error_contains':'invalid scenario'}),
                     'must expect simulations')

    def test_bogus_completion_not_allowed(self):
        self.invalid(lambda a:a['cases'][0]['expected'].__setitem__('status','COMMITTED'),
                     'invalid simulation status')

    def test_extra_case_authorization_rejected(self):
        self.invalid(lambda a:a['cases'][0].__setitem__('execution_authorized',True),
                     'case[0]: expected exactly')

    def test_text_bounded(self):
        self.invalid(lambda a:a['cases'][0].__setitem__('rationale','x'*500),
                     'bounded explanatory')

    def test_case_count_bounded(self):
        self.invalid(lambda a:a.__setitem__('cases',a['cases']*6),'2..16')

    def test_loader_rejects_duplicate_json_keys(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'d.json'
            path.write_text('{"schema":"a","schema":"b"}')
            with self.assertRaisesRegex(DesignError,'duplicate JSON key'):
                load_application(path)

    def test_loader_rejects_nan(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'d.json'
            path.write_text('{"bad":NaN}')
            with self.assertRaises(DesignError):load_application(path)

    def test_loader_rejects_oversize(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'d.json'
            path.write_bytes(b' '*512_001)
            with self.assertRaisesRegex(DesignError,'byte limit'):
                load_application(path)

    def test_cli_success_without_execution(self):
        args=[sys.executable,str(ROOT/'tools/validate_dualflow_application.py'),
              str(EX/'evidence_review.json'),str(EX/'evidence_review.patch.json'),
              str(EX/'evidence_review.regression.json'),
              str(EX/'evidence_review.application.json')]
        p=subprocess.run(args,capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        r=json.loads(p.stdout)
        self.assertFalse(r['application_executed'])
        self.assertFalse(r['application_authorized'])

    def test_cli_blocked_exit_code(self):
        self.application['cases'][0]['expected']['knowledge_ids']=[]
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'a.json';path.write_text(json.dumps(self.application))
            p=subprocess.run([sys.executable,str(ROOT/'tools/validate_dualflow_application.py'),
                              str(EX/'evidence_review.json'),str(EX/'evidence_review.patch.json'),
                              str(EX/'evidence_review.regression.json'),str(path)],
                             capture_output=True,text=True)
        self.assertEqual(p.returncode,1,p.stderr)
        self.assertEqual(json.loads(p.stdout)['status'],'APPLICATION_BLOCKED')

    def test_cli_invalid_exit_code(self):
        self.application['owner_accepted']=True
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'a.json';path.write_text(json.dumps(self.application))
            p=subprocess.run([sys.executable,str(ROOT/'tools/validate_dualflow_application.py'),
                              str(EX/'evidence_review.json'),str(EX/'evidence_review.patch.json'),
                              str(EX/'evidence_review.regression.json'),str(path)],
                             capture_output=True,text=True)
        self.assertEqual(p.returncode,2,p.stderr)
        self.assertIn('APPLICATION_REJECTED',p.stderr)


if __name__=='__main__':
    unittest.main()
