#!/usr/bin/env python3
"""HWI-I01: exact-revision, read-only PERSONAL.WIKI dual-flow bridge.

Requires the *separately approved* HWI-05 ReadOnlyKnowledgeBroker object. The
broker is constructed by a trusted caller with a named workspace. No search,
paths, historic-revision fallback, wiki writes, actions or approval interface.
All returned workflow content is untrusted even if its integrity pins match.
"""
from __future__ import annotations

import json
import re
from typing import Any

from check_dualflow_design import (
    DesignError, _need, _symbol, _unique_object, _reject_constant, check_design,
)
from simulate_dualflow import canonical_digest, simulate

SCHEMA = "hwi.dualflow.wiki_selection.v0"
REHEARSAL_SCHEMA = "hwi.dualflow.wiki_rehearsal.v0"
_REF = re.compile(r"hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*\Z")
_SHA = re.compile(r"[0-9a-f]{64}\Z")
MAX_WIKI_DESIGN_CHARS = 4096  # Actual HWI-05 broker read() maximum.


def _pin(value: Any, where: str) -> str:
    _need(type(value) is str and _SHA.fullmatch(value) is not None,
          f"{where}: exact lowercase SHA-256 digest required")
    return value


def _broker_type():
    # Import only when integrated with the approved wiki installation; no
    # duplicated connector API and no third-party import in offline tests.
    try:
        from hwi.knowledge_broker import ReadOnlyKnowledgeBroker
    except ImportError as exc:
        raise DesignError("approved HWI-05 broker is not installed") from exc
    return ReadOnlyKnowledgeBroker


def select_pinned_workflow(*, broker: Any, reference: str,
                           expected_source_revision_sha256: str,
                           expected_design_sha256: str,
                           expected_workflow_id: str,
                           expected_revision: int) -> dict[str, Any]:
    """Read only the caller-selected *current* revision; return no approval.

    The source revision is a local HWI-05 identity, not signed PVS provenance.
    The workflow's digest is canonical JSON identity, not semantic validity.
    """
    _need(type(broker) is _broker_type(),
          "approved HWI-05 ReadOnlyKnowledgeBroker instance required")
    _need(type(reference) is str and _REF.fullmatch(reference) is not None,
          "explicit current-revision hwi05:// reference required")
    _pin(expected_source_revision_sha256, "source revision")
    _pin(expected_design_sha256, "design")
    _symbol(expected_workflow_id, "workflow_id")
    _need(type(expected_revision) is int and 1 <= expected_revision <= 1_000_000,
          "valid exact integer workflow revision required")

    # read() enforces local notebook scope, freshness, PVS protection, catalog
    # integrity, and SQL read-only operation. Never call revision() as fallback.
    record = broker.read(reference, max_text_chars=MAX_WIKI_DESIGN_CHARS)
    _need(type(record) is dict and record.get("ref") == reference,
          "broker returned a different revision reference")
    _need(record.get("revision_sha256") == expected_source_revision_sha256,
          "source revision digest has changed")
    _need(record.get("event_id") == int(reference.rsplit("@", 1)[1]),
          "event identity mismatch")
    _need(record.get("title_truncated") is False and
          record.get("text_truncated") is False and
          record.get("fields_truncated") is False and
          record.get("tags_truncated") is False and
          record.get("historical_only") is not True,
          "truncated or historical wiki data cannot be selected")
    labels = record.get("labels")
    _need(type(labels) is dict and labels.get("content_class") == "untrusted_wiki_data" and
          all(labels.get(x) is False for x in (
              "evidence_authenticated", "actor_authenticated", "human_authorized",
              "pvs_approved", "execution_authorized")),
          "wiki record must retain the HWI-05 untrusted and unauthorized labels")
    tags = record.get("tags")
    _need(type(tags) is list and "pvs" not in tags,
          "protected wiki content is not eligible")
    raw = record.get("text")
    _need(type(raw) is str and 0 < len(raw) <= MAX_WIKI_DESIGN_CHARS,
          "bounded complete workflow text required")
    try:
        doc = json.loads(raw, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)
    except (ValueError, TypeError, RecursionError) as exc:
        raise DesignError("wiki workflow JSON is malformed") from exc
    check_design(doc)
    _need(doc["workflow_id"] == expected_workflow_id and
          doc["revision"] == expected_revision,
          "wiki workflow identity/revision mismatch")
    digest = canonical_digest(doc)
    _need(digest == expected_design_sha256,
          "canonical workflow design digest mismatch")
    selection = {
        "schema": SCHEMA,
        "status": "PINNED_UNTRUSTED_WIKI_WORKFLOW",
        "workflow_id": doc["workflow_id"],
        "revision": doc["revision"],
        "design_sha256": digest,
        "source_reference": reference,
        "source_revision_sha256": expected_source_revision_sha256,
        "source_namespace": reference.split("/")[2],
        "design": doc,
        "source_class": "UNTRUSTED_WIKI_DATA",
        "wiki_source_authenticated": False,
        "knowledge_verified": False,
        "workflow_owner_acceptance_verified": False,
        "application_validated": False,
        "application_authorized": False,
        "execution_authorized": False,
        "knowledge_approved": False,
        "workflow_published": False,
    }
    selection["selection_sha256"] = canonical_digest(selection)
    return selection


def rehearse_pinned_workflow(*, broker: Any, reference: str,
                             expected_source_revision_sha256: str,
                             expected_design_sha256: str,
                             expected_workflow_id: str,
                             expected_revision: int,
                             scenario: dict[str, Any]) -> dict[str, Any]:
    """Replay synthetic observations without reading actual external evidence."""
    selection = select_pinned_workflow(
        broker=broker, reference=reference,
        expected_source_revision_sha256=expected_source_revision_sha256,
        expected_design_sha256=expected_design_sha256,
        expected_workflow_id=expected_workflow_id,
        expected_revision=expected_revision,
    )
    trace = simulate(selection["design"], scenario)
    result = {
        "schema": REHEARSAL_SCHEMA,
        "status": "SYNTHETIC_REHEARSAL_ONLY",
        "source_reference": reference,
        "source_revision_sha256": selection["source_revision_sha256"],
        "design_sha256": selection["design_sha256"],
        "selection_sha256": selection["selection_sha256"],
        "trace": trace,
        "wiki_source_authenticated": False,
        "observations_independently_verified": False,
        "application_validated": False,
        "application_authorized": False,
        "execution_authorized": False,
        "knowledge_approved": False,
    }
    result["rehearsal_sha256"] = canonical_digest(result)
    return result
