"""HWI-I02: offline report/review integrity, accounting and fail-closed tests."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError
from assess_dualflow_trials import (
    assess_local_trials, review_template, verify_local_report, _read_json,
)
from run_dualflow_local import evaluate_local_models, installed_models, load_inputs
from simulate_dualflow import canonical_digest
from test_dualflow_local import Handler, local_server, provider, DOCS, TEST_SHA

ROOT=Path(__file__).resolve().parents[1]


def rehash_trial(data: dict, *, model=0, trial=0) -> None:
    t = data['models'][model]['trials'][trial]['report']
    t['trial_sha256']=canonical_digest({k:v for k,v in t.items() if k!='trial_sha256'})
    data['report_sha256']=canonical_digest({k:v for k,v in data.items() if k!='report_sha256'})


def rehash_report(data: dict) -> None:
    data['report_sha256']=canonical_digest({k:v for k,v in data.items() if k!='report_sha256'})


class LocalTrialReviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        base,task,patch,reg,app = load_inputs(
            design=DOCS/'evidence_review.json',
            task_file=DOCS/'evidence_review.model_task.txt',
            reference_patch=DOCS/'evidence_review.patch.json',
            regression=DOCS/'evidence_review.regression.json',
            application=DOCS/'evidence_review.application.json')
        with local_server() as endpoint:
            p=provider(endpoint)
            cls.example=evaluate_local_models(
                provider=p, installed=installed_models(p),
                model_names=['local-a:1','local-b:2'], base=base, task=task,
                reference_patch=patch, regression_suite=reg,
                application_suite=app, repeats=2,endpoint=endpoint,
                pin_digests={'local-a:1':TEST_SHA})

    def test_positive_report_and_counters(self):
        data=verify_local_report(self.example)
        self.assertEqual(data['total_trials'],4)
        self.assertEqual(data['models'],2)
        self.assertEqual(data['outcomes'],{'MODEL_PATCH_MATCHES_PINNED_REFERENCE':4})

    def test_prompt_versions_v0_and_v1_reviewable(self):
        self.assertEqual(self.example['models'][0]['trials'][0]['report']['prompt_version'],
                         'hwi.dualflow.model_prompt.v1')
        old = copy.deepcopy(self.example)
        for model_index, model in enumerate(old['models']):
            for trial_index, _ in enumerate(model['trials']):
                model['trials'][trial_index]['report']['prompt_version'] = (
                    'hwi.dualflow.model_prompt.v0')
                trial = model['trials'][trial_index]['report']
                trial['trial_sha256'] = canonical_digest({
                    k:v for k,v in trial.items() if k != 'trial_sha256'})
        rehash_report(old)
        self.assertEqual(verify_local_report(old)['total_trials'], 4)
        self.assertEqual(verify_local_report(self.example)['total_trials'], 4)

    def test_unknown_prompt_version_rejected_with_valid_digests(self):
        report = copy.deepcopy(self.example)
        report['models'][0]['trials'][0]['report']['prompt_version'] = (
            'hwi.dualflow.model_prompt.v99')
        rehash_trial(report)
        with self.assertRaisesRegex(DesignError, 'unknown prompt'):
            verify_local_report(report)

    def test_initial_review_is_incomplete_not_accepted(self):
        output=assess_local_trials(self.example)
        self.assertEqual(output['status'],'AWAITING_HUMAN_REVIEW')
        self.assertFalse(output['hwi_i02_acceptance_established'])
        self.assertEqual(output['metrics'][0]['pending_review'],2)
        self.assertFalse(output['truth_or_correctness_independently_established'])
        self.assertFalse(output['model_is_genuine_llm_independently_established'])

    def test_template_is_pinned_to_every_trial(self):
        review=review_template(self.example)
        self.assertEqual(len(review['judgments']),4)
        self.assertEqual({j['verdict'] for j in review['judgments']},{'PENDING'})
        self.assertFalse(review['approval_requested'])
        self.assertEqual(review['local_report_sha256'],self.example['report_sha256'])

    def test_partial_and_complete_review_counts(self):
        review=review_template(self.example)
        review['judgments'][0].update(verdict='SUPPORTED',evidence_note='Human compared the test output to the pinned source example.')
        review['judgments'][1].update(verdict='INCORRECT',evidence_note='The expected source qualification was not represented.')
        review['judgments'][2].update(verdict='UNCERTAIN',evidence_note='There is no independent evidential adjudication yet.')
        partial=assess_local_trials(self.example,review)
        self.assertEqual(partial['review_state'],'PARTIAL_REVIEW')
        self.assertEqual(partial['metrics'][0]['annotated_supported'],1)
        self.assertEqual(partial['metrics'][0]['annotated_incorrect'],1)
        self.assertEqual(partial['metrics'][1]['annotated_uncertain'],1)
        self.assertEqual(partial['metrics'][1]['pending_review'],1)
        review['judgments'][3].update(verdict='SUPPORTED',evidence_note='Confirmed supported against the separate expected record.')
        complete=assess_local_trials(self.example,review)
        self.assertEqual(complete['review_state'],'ALL_TRIALS_ANNOTATED')
        self.assertFalse(complete['human_review_authentication_established'])
        self.assertFalse(complete['hwi_i02_acceptance_established'])

    def test_reject_modified_top_level_without_digest(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['duration_seconds']=111
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_modified_trial_even_if_outer_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['model_requested']='local-other'
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_wrong_trial_hash_even_with_outer_rehash(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['status']='MODEL_CALL_FAILED'
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_forged_acceptance_even_with_rehashed_digests(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['workflow_owner_acceptance_verified']=True
        rehash_trial(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_forged_top_level_authority_even_if_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['execution_authorized']=True
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_wrong_counts_even_if_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['exact_reference_matches']=0
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_false_reference_replay_label_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['model_patch_regression_replayed']=False
        rehash_trial(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_wrong_reference_source_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['reference_outcome_basis']='INDEPENDENTLY_VERIFIED'
        rehash_trial(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_wrong_model_identity_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['report']['model_requested']='local-b:2'
        rehash_trial(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_duplicated_trial_numbers_rehashed(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][1]['index']=1
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_malformed_duration(self):
        obj=copy.deepcopy(self.example)
        obj['models'][0]['trials'][0]['duration_seconds']=-1
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_reject_review_for_another_report(self):
        worksheet=review_template(self.example)
        worksheet['local_report_sha256']='f'*64
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_incomplete_trial_worksheet(self):
        worksheet=review_template(self.example)
        worksheet['judgments'].pop()
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_duplicate_trial_review(self):
        worksheet=review_template(self.example)
        worksheet['judgments'][1]=worksheet['judgments'][0]
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_review_with_authorization_claim(self):
        worksheet=review_template(self.example)
        worksheet['approval_requested']=True
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_review_verdict_without_evidence(self):
        worksheet=review_template(self.example)
        worksheet['judgments'][0]['verdict']='SUPPORTED'
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_unknown_review_field(self):
        worksheet=review_template(self.example)
        worksheet['owner_accepted']=True
        with self.assertRaises(DesignError):assess_local_trials(self.example,worksheet)

    def test_reject_untrusted_report_extra_field(self):
        obj=copy.deepcopy(self.example)
        obj['claim']='the model was verified'
        rehash_report(obj)
        with self.assertRaises(DesignError):verify_local_report(obj)

    def test_cli_template_and_assessment(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'input.json'
            p.write_text(json.dumps(self.example))
            code=[sys.executable,str(ROOT/'tools/assess_dualflow_trials.py'),str(p)]
            plain=subprocess.run(code,text=True,capture_output=True,timeout=30)
            self.assertEqual(plain.returncode,0,plain.stderr)
            self.assertEqual(json.loads(plain.stdout)['status'],'AWAITING_HUMAN_REVIEW')
            templ=subprocess.run(code+['--make-review-template'],text=True,
                                 capture_output=True,timeout=30)
            self.assertEqual(templ.returncode,0,templ.stderr)
            template=json.loads(templ.stdout)
            path=Path(t)/'review.json'
            path.write_text(json.dumps(template))
            checked=subprocess.run(code+['--review',str(path)],text=True,
                                   capture_output=True,timeout=30)
            self.assertEqual(checked.returncode,0,checked.stderr)
            self.assertEqual(json.loads(checked.stdout)['review_state'],'PARTIAL_REVIEW')

    def test_cli_rejects_duplicate_keys(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'bad.json'
            p.write_text('{"schema":"A","schema":"B"}')
            with self.assertRaises(DesignError):_read_json(p)

    def test_cli_rejects_oversize_file(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'bad.json'
            with p.open('wb') as f:f.truncate(10_000_001)
            with self.assertRaises(DesignError):_read_json(p)


if __name__=='__main__':unittest.main()
