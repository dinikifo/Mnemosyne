#!/usr/bin/env python3
"""HWI-I02: offline review worksheet and integrity audit for local-model reports.

Neither a digest nor a self-reported reviewer judgment is independent attestation.
This module does not call a provider, validate knowledge truth, grant approval,
execute a workflow, or modify PERSONAL.WIKI/PVS.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
from typing import Any

from check_dualflow_design import DesignError, _need, _unique_object, _reject_constant
from evaluate_dualflow_model import SCHEMA as TRIAL_SCHEMA, TRUST_FLAGS, _model_id
from run_dualflow_local import SCHEMA as LOCAL_SCHEMA, validate_loopback_endpoint
from simulate_dualflow import canonical_digest

REVIEW_SCHEMA = 'hwi.dualflow.local_trial_review.v0'
ASSESSMENT_SCHEMA = 'hwi.dualflow.local_trial_assessment.v0'
MAX_BYTES = 10_000_000
STATUSES = frozenset({
    'MODEL_PATCH_MATCHES_PINNED_REFERENCE', 'VALID_CANDIDATE_UNTESTED',
    'CANDIDATE_MATCHES_DESIGN_DIFFERENT_PATCH_UNTESTED',
    'VALID_ALTERNATIVE_NOT_BENCHMARK_VERIFIED',
    'MODEL_OUTPUT_REJECTED', 'MODEL_CALL_FAILED',
})
VALID_PATCH_STATUSES = frozenset({
    'MODEL_PATCH_MATCHES_PINNED_REFERENCE', 'VALID_CANDIDATE_UNTESTED',
    'CANDIDATE_MATCHES_DESIGN_DIFFERENT_PATCH_UNTESTED',
    'VALID_ALTERNATIVE_NOT_BENCHMARK_VERIFIED',
})
VERDICTS = frozenset({'PENDING', 'SUPPORTED', 'INCORRECT', 'UNCERTAIN'})


def _keys(obj: Any, required: set[str], description: str) -> dict:
    _need(type(obj) is dict and set(obj) == required,
          f'{description}: fields missing or unexpected')
    return obj


def _sha(value: Any, label: str) -> str:
    _need(type(value) is str and len(value) == 64 and
          all(c in '0123456789abcdef' for c in value), f'{label}: expected lowercase SHA-256')
    return value


def _finite_duration(value: Any) -> bool:
    return type(value) in (int, float) and 0 <= value <= 86400


def _read_json(path: Path) -> dict:
    _need(path.is_file() and path.stat().st_size <= MAX_BYTES, 'input file too large or missing')
    with path.open(encoding='utf-8') as f:
        return json.load(f, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def _digest_check(obj: dict, digest_field: str, label: str) -> None:
    declared = _sha(obj[digest_field], label + '.sha256')
    actual = canonical_digest({k: v for k, v in obj.items() if k != digest_field})
    _need(actual == declared, label + ': digest mismatch')


def verify_local_report(report: Any) -> dict:
    """Checks local report consistency; does not attest model provenance."""
    _keys(report, {'schema', 'mode', 'endpoint', 'workstation', 'base_sha256',
                   'task_sha256', 'repeats_per_model', 'benchmark_kind', 'models',
                   'all_outcomes', 'locally_reported_identity_not_independently_attested',
                   'factual_correctness_not_independently_verified',
                   'human_acceptance_obtained', 'execution_authorized',
                   'protected_knowledge_write_authorized', 'note', 'report_sha256'},
          'local report')
    _need(report['schema'] == LOCAL_SCHEMA and report['mode'] == 'LOCAL_LOOPBACK_OLLAMA_PROTOCOL',
          'unsupported local report')
    validate_loopback_endpoint(report['endpoint'])
    _keys(report['workstation'], {'os', 'machine', 'python'}, 'workstation')
    for value in report['workstation'].values():
        _need(type(value) is str and len(value) <= 100, 'invalid workstation field')
    base_digest = _sha(report['base_sha256'], 'base_sha256')
    task_digest = _sha(report['task_sha256'], 'task_sha256')
    repeats = report['repeats_per_model']
    _need(type(repeats) is int and 1 <= repeats <= 12, 'invalid trial count')
    benchmark = report['benchmark_kind']
    _need(benchmark in ('STRUCTURAL_PROPOSALS_ONLY', 'PREDECLARED_SYNTHETIC_REFERENCE'),
          'invalid benchmark kind')
    for flag in ('human_acceptance_obtained', 'execution_authorized',
                 'protected_knowledge_write_authorized'):
        _need(report[flag] is False, 'authority claim in local report: ' + flag)
    for flag in ('locally_reported_identity_not_independently_attested',
                 'factual_correctness_not_independently_verified'):
        _need(report[flag] is True, 'missing uncertainty flag: ' + flag)
    _need(type(report['note']) is str and len(report['note']) <= 1000, 'bad note')
    _need(type(report['models']) is list and 1 <= len(report['models']) <= 8,
          'invalid models list')
    names = set()
    all_statuses = Counter()
    total = 0
    for model in report['models']:
        _keys(model, {'model','local_reported_model_digest_sha256','trials',
                      'outcome_counts','structurally_valid_proposals','structural_valid_percent',
                      'exact_reference_matches','reference_match_percent'}, 'model')
        name = _model_id(model['model'])
        _need(name not in names, 'duplicate model')
        names.add(name)
        digest = model['local_reported_model_digest_sha256']
        if digest is not None: _sha(digest, 'model reported digest')
        trials = model['trials']
        _need(type(trials) is list and len(trials) == repeats,
              'inconsistent trial count')
        counts = Counter()
        for i, trial in enumerate(trials, 1):
            _keys(trial, {'index', 'duration_seconds', 'report'}, 'trial')
            _need(type(trial['index']) is int and trial['index'] == i, 'invalid trial index')
            _need(_finite_duration(trial['duration_seconds']), 'invalid trial duration')
            item = trial['report']
            _need(type(item) is dict and item.get('schema') == TRIAL_SCHEMA,
                  'invalid trial report')
            _need(item.get('model_requested') == name and item.get('provider_kind') == 'LOCAL_OLLAMA',
                  'model/provider mismatch')
            _need(item.get('base_sha256') == base_digest and item.get('task_sha256') == task_digest,
                  'base/task identity mismatch')
            _need(item.get('status') in STATUSES, 'invalid status')
            for flag, expected in TRUST_FLAGS.items():
                _need(item.get(flag) is expected, 'trial claimed authority or verification: ' + flag)
            _need(type(item.get('prompt_version')) is str and
                  item['prompt_version'] in (
                      'hwi.dualflow.model_prompt.v0',
                      'hwi.dualflow.model_prompt.v1'), 'unknown prompt')
            _digest_check(item, 'trial_sha256', 'trial')
            if item['status'] in VALID_PATCH_STATUSES:
                _need(type(item.get('proposed_patch')) is dict and
                      type(item.get('candidate')) is dict and
                      item.get('failure_class') is None,
                      'valid status lacks candidate')
            else:
                _need(item.get('candidate') is None and item.get('proposed_patch') is None,
                      'failed status contains candidate')
            _need(item.get('model_patch_regression_replayed') is
                  (item['status'] == 'MODEL_PATCH_MATCHES_PINNED_REFERENCE'),
                  'inconsistent reference replay claim')
            if benchmark == 'STRUCTURAL_PROPOSALS_ONLY':
                _need(item['status'] != 'MODEL_PATCH_MATCHES_PINNED_REFERENCE' and
                      item.get('reference_candidate_sha256') is None and
                      item.get('reference_regression_sha256') is None and
                      item.get('reference_application_sha256') is None and
                      item.get('reference_outcome_basis') is None,
                      'reference evidence without reference suite')
            else:
                for reference_field in ('reference_candidate_sha256',
                                        'reference_regression_sha256',
                                        'reference_application_sha256'):
                    _sha(item.get(reference_field),reference_field)
                _need(item.get('reference_outcome_basis') ==
                      'PREDECLARED_SYNTHETIC_EXPECTATIONS_NOT_GROUND_TRUTH',
                      'incorrect benchmark evidence label')
            counts[item['status']] += 1
            all_statuses[item['status']] += 1
            total += 1
        good = sum(counts[x] for x in VALID_PATCH_STATUSES)
        matched = counts['MODEL_PATCH_MATCHES_PINNED_REFERENCE']
        _need(model['outcome_counts'] == dict(sorted(counts.items())), 'model outcomes mismatch')
        _need(type(model['structurally_valid_proposals']) is int and
              model['structurally_valid_proposals'] == good, 'model valid count mismatch')
        _need(type(model['exact_reference_matches']) is int and
              model['exact_reference_matches'] == matched, 'reference count mismatch')
        _need(type(model['structural_valid_percent']) in (int,float) and
              model['structural_valid_percent'] == round(100*good/repeats, 2),
              'model valid percent mismatch')
        _need(type(model['reference_match_percent']) in (int,float) and
              model['reference_match_percent'] == round(100*matched/repeats,2),
              'model reference percent mismatch')
    _need(report['all_outcomes'] == dict(sorted(all_statuses.items())),
          'aggregate statuses mismatch')
    _digest_check(report, 'report_sha256', 'local report')
    return {'total_trials': total, 'models': len(names),
            'outcomes': dict(sorted(all_statuses.items()))}


def review_template(report: dict) -> dict:
    verify_local_report(report)
    result = {'schema':REVIEW_SCHEMA,
              'local_report_sha256':report['report_sha256'],
              'reviewer_reference':'UNAUTHENTICATED_LOCAL_REVIEW',
              'judgments':[
                  {'model':m['model'],'trial_index':t['index'],
                   'trial_sha256':t['report']['trial_sha256'],
                   'verdict':'PENDING','evidence_note':''}
                  for m in report['models'] for t in m['trials']],
              'approval_requested':False,'knowledge_publication_requested':False}
    return result


def assess_local_trials(report: dict, reviews: dict | None = None) -> dict:
    verified = verify_local_report(report)
    template = review_template(report)
    observations: dict[str, Counter] = {m['model']:Counter() for m in report['models']}
    review_state = 'REVIEW_NOT_PROVIDED'
    if reviews is not None:
        _keys(reviews, {'schema','local_report_sha256','reviewer_reference',
                        'judgments','approval_requested','knowledge_publication_requested'},
              'review record')
        _need(reviews['schema'] == REVIEW_SCHEMA and
              reviews['local_report_sha256'] == report['report_sha256'],
              'review does not match exact local report')
        _need(type(reviews['reviewer_reference']) is str and
              1 <= len(reviews['reviewer_reference']) <= 128 and
              all(x.isprintable() for x in reviews['reviewer_reference']),
              'invalid reviewer reference')
        _need(reviews['approval_requested'] is False and
              reviews['knowledge_publication_requested'] is False,
              'review worksheet cannot request authority')
        _need(type(reviews['judgments']) is list and
              len(reviews['judgments']) == verified['total_trials'],
              'review must include every trial, including pending')
        expected = {(j['model'],j['trial_index'],j['trial_sha256']) for j in template['judgments']}
        seen = set()
        for j in reviews['judgments']:
            _keys(j, {'model','trial_index','trial_sha256','verdict','evidence_note'},
                  'judgment')
            ident=(j['model'],j['trial_index'],j['trial_sha256'])
            _need(ident in expected and ident not in seen,'missing/duplicate/wrong judgment pin')
            seen.add(ident)
            _need(j['verdict'] in VERDICTS,'invalid verdict')
            _need(type(j['evidence_note']) is str and len(j['evidence_note']) <= 1000 and
                  all(c.isprintable() or c == '\n' for c in j['evidence_note']),
                  'invalid evidence note')
            if j['verdict'] != 'PENDING':
                _need(len(j['evidence_note'].strip()) >= 10,
                      'human judgment requires specific supporting note')
            observations[j['model']][j['verdict']] += 1
        review_state = ('ALL_TRIALS_ANNOTATED' if all(x['PENDING'] == 0 for x in observations.values())
                        else 'PARTIAL_REVIEW')
    metrics=[]
    for model in report['models']:
        name=model['model']
        counts=observations[name]
        metrics.append({'model':name,
                        'trial_count':len(model['trials']),
                        'model_reported_structural_valid_percent':model['structural_valid_percent'],
                        'model_reported_exact_reference_match_percent':model['reference_match_percent'],
                        'annotated_supported':counts['SUPPORTED'],
                        'annotated_incorrect':counts['INCORRECT'],
                        'annotated_uncertain':counts['UNCERTAIN'],
                        'pending_review':len(model['trials'])-sum(counts.values())+counts['PENDING'],
                        'support_percent_of_all_trials':round(100*counts['SUPPORTED']/len(model['trials']),2)})
    assessment={'schema':ASSESSMENT_SCHEMA,
                'status': 'REVIEW_ANNOTATED_NOT_AUTHENTICATED' if reviews else 'AWAITING_HUMAN_REVIEW',
                'review_state':review_state,
                'local_report_sha256':report['report_sha256'],
                'review_template_sha256':canonical_digest(template),
                'review_record_sha256':canonical_digest(reviews) if reviews else None,
                'metrics':metrics,
                'model_identity_independently_attested':False,
                'model_is_genuine_llm_independently_established':False,
                'human_review_authentication_established':False,
                'truth_or_correctness_independently_established':False,
                'workflow_execution_authorized':False,
                'knowledge_publication_authorized':False,
                'hwi_i02_acceptance_established':False,
                'note':'Digest-consistent local reports and supplied review notes are not independent proof of LLM origin, ground truth, or owner approval.'}
    assessment['assessment_sha256']=canonical_digest(assessment)
    return assessment


def main(argv: list[str] | None = None) -> int:
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('local_trial_report',type=Path)
    cli.add_argument('--make-review-template',action='store_true',
                     help='produce a JSON worksheet with every trial pinned and PENDING')
    cli.add_argument('--review',type=Path,help='completed or partial JSON review worksheet')
    args=cli.parse_args(argv)
    try:
        _need(not (args.review and args.make_review_template),'choose assessment or worksheet')
        report=_read_json(args.local_trial_report)
        output=(review_template(report) if args.make_review_template else
                assess_local_trials(report,_read_json(args.review) if args.review else None))
        print(json.dumps(output,indent=2,sort_keys=True,ensure_ascii=True))
        return 0
    except (DesignError,ValueError,TypeError,OSError,UnicodeError,RecursionError,KeyError) as exc:
        print('TRIAL_REVIEW_REJECTED: '+type(exc).__name__,file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
