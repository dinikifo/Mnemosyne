"""WL-03 candidate patch tests: closed, immutable, non-authorizing revisions."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from check_dualflow_design import DesignError, check_design, load_design
from patch_dualflow import load_patch, propose_revision
from simulate_dualflow import canonical_digest, load_scenario, simulate

ROOT = Path(__file__).resolve().parents[1]
DESIGN = ROOT / "docs/dualflow/examples/evidence_review.json"
PATCH = ROOT / "docs/dualflow/examples/evidence_review.patch.json"
SCENARIO = ROOT / "docs/dualflow/examples/evidence_review.simulation.json"


class VersionedPatchTests(unittest.TestCase):
    def setUp(self):
        self.base = load_design(DESIGN)
        self.patch = load_patch(PATCH)

    def invalid(self, mutate, *, expect=DesignError):
        base, patch = copy.deepcopy(self.base), copy.deepcopy(self.patch)
        mutate(base, patch)
        with self.assertRaises(expect):
            propose_revision(base, patch)

    def test_successful_proposal(self):
        original_base, original_patch = copy.deepcopy(self.base), copy.deepcopy(self.patch)
        result = propose_revision(self.base, self.patch)
        self.assertEqual(result['status'], 'UNREVIEWED_CANDIDATE_SHAPE_VALID_ONLY')
        self.assertEqual(result['candidate_revision'], 2)
        self.assertEqual(result['base_revision'], 1)
        self.assertEqual(result['base_sha256'], canonical_digest(self.base))
        self.assertEqual(result['candidate_sha256'], canonical_digest(result['candidate_design']))
        self.assertEqual(result['candidate_design']['flows'][2]['guards'][-1], 'conflicts_reviewed')
        self.assertEqual(result['changes'][0]['before']['observations'],
                         self.base['flows'][2]['observations'])
        self.assertEqual(self.base, original_base)
        self.assertEqual(self.patch, original_patch)
        for key in ('owner_accepted', 'workflow_published', 'execution_authorized',
                    'knowledge_approved', 'observations_independently_verified'):
            self.assertIs(result[key], False)

    def test_deterministic_replay(self):
        self.assertEqual(propose_revision(self.base, self.patch),
                         propose_revision(self.base, self.patch))

    def test_stale_base_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('base_sha256', '0' * 64))

    def test_revision_mismatch_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('base_revision', 2))

    def test_boolean_revision_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('base_revision', True))

    def test_identity_mismatch_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('workflow_id', 'another'))

    def test_unknown_schema_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('schema', 'hwi.dualflow.patch.v999'))

    def test_extra_authority_flag_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('approved', True))

    def test_no_tests_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('tests_to_run', []))

    def test_duplicate_tests_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('tests_to_run', ['same', 'same']))

    def test_invalid_rationale_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('rationale', '\x1b[2J' + 'x' * 20))

    def test_no_ops_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', []))

    def test_too_many_ops_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', p['operations'] * 17))

    def test_patch_cannot_change_protected_mode(self):
        self.invalid(lambda b,p: p['operations'][0].__setitem__('mode', 'execution'))

    def test_patch_cannot_change_invariants(self):
        self.invalid(lambda b,p: p['operations'][0].__setitem__('invariants', []))

    def test_patch_cannot_change_capabilities(self):
        self.invalid(lambda b,p: p['operations'][0]['value'].__setitem__('capability', 'exec'))

    def test_patch_cannot_change_flow_identity(self):
        self.invalid(lambda b,p: p['operations'][0]['value'].__setitem__('id', 'new_name'))

    def test_replace_nonexistent_flow_rejected(self):
        self.invalid(lambda b,p: p['operations'][0].__setitem__('id', 'missing'))

    def test_duplicate_target_rejected(self):
        self.invalid(lambda b,p: p['operations'].append(copy.deepcopy(p['operations'][0])))

    def test_noop_rejected(self):
        self.invalid(lambda b,p: p['operations'][0].__setitem__('value', copy.deepcopy(b['flows'][2])))

    def test_removing_last_flow_rejected(self):
        def change(b,p):
            p['operations'] = [ {'op':'remove_flow', 'id':f['id']} for f in b['flows']]
        self.invalid(change)

    def test_remove_required_flow_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'remove_flow', 'id':'assess_sources'}]))

    def test_remove_initial_stock_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'remove_stock', 'id':'work.pending'}]))

    def test_remove_unknown_stock_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'remove_stock', 'id':'work.unknown'}]))

    def test_add_nonempty_stock_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'add_stock', 'value':{'id':'work.other', 'kind':'work', 'initial':['forged']}}]))

    def test_add_stock_without_connecting_flow_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'add_stock', 'value':{'id':'work.other', 'kind':'work', 'initial':[]}}]))

    def test_add_duplicate_stock_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'add_stock', 'value': b['stocks'][0]}]))

    def test_add_duplicate_flow_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'add_flow', 'value': b['flows'][0]}]))

    def test_set_invalid_resource_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'set_resource', 'name':'max_tools', 'value':1}]))

    def test_set_boolean_resource_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'set_resource', 'name':'max_steps', 'value':True}]))

    def test_set_resource_success(self):
        self.patch['operations'] = [{'op':'set_resource', 'name':'max_steps', 'value':15}]
        result = propose_revision(self.base, self.patch)
        self.assertEqual(result['candidate_design']['resources']['max_steps'],15)
        self.assertEqual(result['changes'][0]['before'],12)

    def test_set_resource_noop_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'set_resource', 'name':'max_steps', 'value':12}]))

    def test_terminal_refs_invalid_rejected(self):
        self.invalid(lambda b,p: p.__setitem__('operations', [{'op':'set_terminal_stocks', 'value':['work.nonexistent']}]))

    def test_failed_multiop_has_no_partial_mutation(self):
        base_original = copy.deepcopy(self.base)
        self.patch['operations'] = [
            {'op':'set_resource','name':'max_steps','value':15},
            {'op':'remove_stock','id':'work.pending'},
        ]
        with self.assertRaises(DesignError):
            propose_revision(self.base, self.patch)
        self.assertEqual(self.base, base_original)

    def test_candidate_does_not_satisfy_stale_simulation(self):
        result = propose_revision(self.base, self.patch)
        scenario = load_scenario(SCENARIO)
        with self.assertRaises(DesignError):
            simulate(result['candidate_design'], scenario)

    def test_candidate_requires_new_observation_in_rebased_simulation(self):
        result = propose_revision(self.base, self.patch)
        scenario = load_scenario(SCENARIO)
        scenario['revision'] = 2
        scenario['design_sha256'] = result['candidate_sha256']
        with self.assertRaises(DesignError):
            simulate(result['candidate_design'], scenario)
        scenario['steps'][-1]['guards']['conflicts_reviewed'] = 'VERIFIED'
        scenario['steps'][-1]['observations']['contradictions_reported'] = 'VERIFIED'
        out = simulate(result['candidate_design'], scenario)
        self.assertEqual(out['terminal_stock'], 'work.reported')
        self.assertFalse(out['observations_independently_verified'])

    def test_revised_candidate_rejects_same_patch(self):
        candidate = propose_revision(self.base, self.patch)['candidate_design']
        with self.assertRaises(DesignError):
            propose_revision(candidate, self.patch)

    def test_cli_stdout_review_only(self):
        run = subprocess.run([sys.executable, str(ROOT/'tools/patch_dualflow.py'),
                              str(DESIGN),str(PATCH)],capture_output=True,text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        x = json.loads(run.stdout)
        self.assertFalse(x['workflow_published'])
        self.assertEqual(x['candidate_revision'], 2)

    def test_cli_error_escapes_terminal_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.json'
            p.write_text('{"schema":"a", "schema":"b"}',encoding='utf8')
            run = subprocess.run([sys.executable,str(ROOT/'tools/patch_dualflow.py'),
                                  str(DESIGN), str(p)],capture_output=True,text=True)
            self.assertEqual(run.returncode, 2)
            self.assertNotIn('\x1b', run.stderr)

    def test_duplicate_json_keys_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'dup.json'
            p.write_text('{"schema":"a","schema":"b"}',encoding='utf8')
            with self.assertRaises(DesignError):
                load_patch(p)

    def test_nonstandard_number_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'nan.json'
            p.write_text('{"x":NaN}',encoding='utf8')
            with self.assertRaises(DesignError):
                load_patch(p)

    def test_excessive_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'oversized.json'
            p.write_bytes(b' ' * 128001)
            with self.assertRaises(DesignError):
                load_patch(p)

    def test_revision_range_rejected(self):
        def change(b,p):
            b['revision'] = 1_000_000
            p['base_revision'] = 1_000_000
            p['base_sha256'] = canonical_digest(b)
        self.invalid(change)

    def test_candidate_mutation_does_not_mutate_base_or_patch(self):
        result = propose_revision(self.base,self.patch)
        result['candidate_design']['flows'][2]['guards'].append('mutated')
        self.assertEqual(self.base['flows'][2]['guards'], ['report_inputs_available'])
        self.assertNotIn('mutated', self.patch['operations'][0]['value']['guards'])


    def _insert_review_step_patch(self):
        old = copy.deepcopy(self.base['flows'][2])
        old['inputs'] = ['work.reviewed', 'knowledge.assessments']
        return [
            {'op':'add_stock', 'value': {'id':'work.reviewed','kind':'work','initial':[]}},
            {'op':'add_flow', 'value': {
                'id':'peer_review', 'capability':'assess_evidence',
                'inputs':['work.assessed', 'knowledge.assessments'],
                'outputs':['work.reviewed'], 'guards':['claims_reviewable'],
                'observations':['peer_review_recorded'],
                'on_failure':'work.stopped', 'on_unknown':'work.stopped'}},
            {'op':'replace_flow', 'id':'report_assessment', 'value':old},
        ]

    def test_add_transition_and_stock_in_atomic_patch(self):
        self.patch['operations'] = self._insert_review_step_patch()
        candidate = propose_revision(self.base, self.patch)['candidate_design']
        self.assertEqual(candidate['revision'], 2)
        self.assertIn('work.reviewed', {s['id'] for s in candidate['stocks']})
        self.assertEqual(check_design(candidate)['status'], 'DESIGN_SHAPE_VALID_ONLY')

    def test_rebased_new_transition_requires_explicit_new_scenario_step(self):
        self.patch['operations'] = self._insert_review_step_patch()
        candidate = propose_revision(self.base, self.patch)['candidate_design']
        scenario = load_scenario(SCENARIO)
        scenario['revision'] = 2
        scenario['design_sha256'] = canonical_digest(candidate)
        # Old scenario cannot jump from assessed to reported under revised definition.
        with self.assertRaises(DesignError):
            simulate(candidate, scenario)
        scenario['steps'].insert(2, {
            'flow':'peer_review', 'work_artifact':'request:example',
            'guards': {'claims_reviewable':'VERIFIED'},
            'observations': {'peer_review_recorded':'VERIFIED'},
            'knowledge_produced': []
        })
        self.assertEqual(simulate(candidate, scenario)['terminal_stock'], 'work.reported')

    def test_new_revision_can_reverse_prior_specification_change(self):
        self.patch['operations'] = self._insert_review_step_patch()
        v2 = propose_revision(self.base, self.patch)['candidate_design']
        v3_patch = {
            'schema': 'hwi.dualflow.patch.v0',
            'workflow_id': v2['workflow_id'],
            'base_revision': 2,
            'base_sha256': canonical_digest(v2),
            'rationale': 'Remove experimental peer review step after validation and preserve prior tests.',
            'tests_to_run': ['verify_reversal', 'run_all_regressions'],
            'operations': [
                {'op': 'remove_flow', 'id':'peer_review'},
                {'op': 'replace_flow', 'id':'report_assessment', 'value':copy.deepcopy(self.base['flows'][2])},
                {'op': 'remove_stock', 'id':'work.reviewed'},
            ]
        }
        v3 = propose_revision(v2, v3_patch)['candidate_design']
        self.assertEqual(v3['revision'], 3)
        self.assertEqual(v3['flows'], self.base['flows'])
        self.assertEqual(v3['stocks'], self.base['stocks'])
        self.assertNotEqual(canonical_digest(v3), canonical_digest(self.base))  # revision identity


if __name__ == '__main__':
    unittest.main()
