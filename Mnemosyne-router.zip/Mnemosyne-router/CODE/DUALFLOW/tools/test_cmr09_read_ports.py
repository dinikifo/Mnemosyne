"""CMR-09 opt-in read-only ports, routing integrity and deterministic parity."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from check_dualflow_design import DesignError, load_design
from dualflow_read_ports import (
    DirectPinnedWorkflowReader, DirectSimulationReader, RoutedPinnedWorkflowReader,
    RoutedSimulationReader, _router,
)
from evaluate_dualflow_model import evaluate_pinned_wiki_model
from patch_dualflow import load_patch
from review_dualflow import assess_revision, load_suite
from simulate_dualflow import canonical_digest

try:
    from personal_wiki_core import NotebookWorkspace
    from hwi.knowledge_broker import ReadOnlyKnowledgeBroker, StaleKnowledgeReference
    HAVE_WIKI = True
except ImportError:
    HAVE_WIKI = False

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / 'docs' / 'dualflow' / 'examples'


class SimulationPortTests(unittest.TestCase):
    def setUp(self):
        self.design = load_design(EXAMPLES/'evidence_review.json')
        self.patch = load_patch(EXAMPLES/'evidence_review.patch.json')
        self.suite = load_suite(EXAMPLES/'evidence_review.regression.json')

    def test_report_byte_parity_with_routed_port(self):
        legacy = assess_revision(self.design, self.patch, self.suite)
        routed = assess_revision(self.design, self.patch, self.suite,
                                 simulation_reader=RoutedSimulationReader())
        self.assertEqual(legacy, routed)
        self.assertEqual(routed['cases_passed'], 3)
        self.assertFalse(routed['execution_authorized'])
        self.assertFalse(routed['knowledge_approved'])

    def test_direct_port_is_replaceable(self):
        class Spy:
            count = 0
            def replay(self, design, scenario):
                self.count += 1
                return DirectSimulationReader().replay(design, scenario)
        spy = Spy()
        assess_revision(self.design, self.patch, self.suite, simulation_reader=spy)
        self.assertEqual(spy.count, 3)  # including one expected DesignError

    def test_routed_port_is_replaceable_and_no_double_read(self):
        class Spy:
            count = 0
            def replay(self, design, scenario):
                self.count += 1
                return DirectSimulationReader().replay(design, scenario)
        spy = Spy()
        result = assess_revision(self.design, self.patch, self.suite,
                                 simulation_reader=RoutedSimulationReader(spy))
        self.assertEqual(result['cases_passed'], 3)
        self.assertEqual(spy.count, 3)

    def test_false_authority_from_simulator_is_rejected(self):
        class Forged:
            def replay(self, design, scenario):
                output = DirectSimulationReader().replay(design, scenario)
                output['execution_authorized'] = True
                output['trace_sha256'] = canonical_digest({
                    k:v for k,v in output.items() if k != 'trace_sha256'})
                return output
        with self.assertRaisesRegex(ValueError, 'unverified simulator'):
            RoutedSimulationReader(Forged()).replay(
                self.design, json.loads((EXAMPLES/'evidence_review.simulation.json').read_text()))

    def test_interrupted_simulator_is_not_retried(self):
        class Interrupted:
            count = 0
            def replay(self, *_):
                self.count += 1
                raise RuntimeError('simulate interrupted')
        obj = Interrupted()
        with self.assertRaises(RuntimeError):
            RoutedSimulationReader(obj).replay(self.design, {})
        self.assertEqual(obj.count, 1)

    def test_rejected_scenario_preserves_existing_designerror(self):
        from patch_dualflow import propose_revision
        candidate = propose_revision(self.design, self.patch)['candidate_design']
        bad = copy.deepcopy(self.suite['cases'][2]['scenario'])
        with self.assertRaises(DesignError):
            RoutedSimulationReader().replay(candidate, bad)


class ProfileTests(unittest.TestCase):
    def setUp(self):
        self.ctx = {'design_sha256':'a'*64,'scenario_sha256':'b'*64}
        self.router, self.flow, self.sources = _router(self.ctx)

    def packet(self):
        return self.router.issue_message(self.flow, self.sources['dualflow_review'],
            'dualflow.regression.request', self.ctx.copy())

    def test_request_result_correlation_and_replay(self):
        p = self.packet()
        v = self.router.dispatch(self.flow, self.sources['dualflow_review'], p)
        self.assertTrue(v.accepted)
        self.assertEqual(tuple(e.kind for e in v.effects), ('dualflow.simulation.read',))
        self.assertTrue(self.router.dispatch(self.flow, self.sources['dualflow_review'], p).replayed)
        bad = copy.deepcopy(p)
        bad['payload']['design_sha256'] = 'b'*64
        self.assertEqual(self.router.dispatch(self.flow, self.sources['dualflow_review'], bad).code, 'F10')
        self.ctx['trace_sha256'] = 'c'*64
        q = self.router.issue_message(self.flow, self.sources['dualflow_simulator'],
             'dualflow.regression.result', {'design_sha256':'a'*64,'trace_sha256':'c'*64},
             parent=p['message_id'])
        self.assertTrue(self.router.dispatch(self.flow, self.sources['dualflow_simulator'], q).accepted)
        self.assertEqual(self.router.snapshot(self.flow).phase, 'SIM_REPORTED')

    def test_forged_origin_and_approval_claim_rejected(self):
        p = self.packet()
        p['origin'] = 'agent_evaluation'
        self.assertFalse(self.router.dispatch(self.flow, self.sources['dualflow_review'], p).accepted)
        p = self.packet(); p['payload']['approved'] = True
        self.assertEqual(self.router.dispatch(self.flow, self.sources['dualflow_review'], p).code, 'F01')
        p = self.packet(); p['kind'] = 'formation.practice.request'
        self.assertEqual(self.router.dispatch(self.flow, self.sources['dualflow_review'], p).code, 'F01')

    def test_wrong_parent_and_result_before_request_rejected(self):
        q = self.router.issue_message(self.flow, self.sources['dualflow_simulator'],
            'dualflow.regression.result', {'design_sha256':'a'*64,'trace_sha256':'c'*64}, parent='f'*32)
        self.assertEqual(self.router.dispatch(self.flow,self.sources['dualflow_simulator'],q).code,'F03')
        p=self.packet()
        self.assertTrue(self.router.dispatch(self.flow,self.sources['dualflow_review'],p).accepted)
        self.ctx['trace_sha256']='c'*64
        q=self.router.issue_message(self.flow,self.sources['dualflow_simulator'],
            'dualflow.regression.result', {'design_sha256':'a'*64,'trace_sha256':'c'*64},parent='f'*32)
        self.assertEqual(self.router.dispatch(self.flow,self.sources['dualflow_simulator'],q).code,'F02')

    def test_no_unlisted_executor(self):
        self.assertEqual(set(self.router._effects), {'dualflow.simulation.read', 'agent.pinned_read'})
        self.assertNotIn('wiki.write', self.router._effects)
        self.assertNotIn('agent.execute', self.router._effects)


@unittest.skipUnless(HAVE_WIKI, 'approved wiki dependencies unavailable')
class PinnedPortTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name).resolve(strict=True)
        self.ws = NotebookWorkspace(self.path/'private',create=True)
        self.ws.create_notebook('primary')
        self.design = load_design(EXAMPLES/'evidence_review.json')
        with self.ws.open_notebook('primary',readonly=False) as wiki:
            wiki.save_tiddler('Example Workflow',json.dumps(self.design,sort_keys=True),
                              ['workflow'],reason='synthetic fixture')
            wiki.knowledge_catalog().initialize()
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            self.record = broker.search('Example Workflow',mode='Title')[0]
        self.kw = dict(reference=self.record['ref'],
                       expected_source_revision_sha256=self.record['revision_sha256'],
                       expected_design_sha256=canonical_digest(self.design),
                       expected_workflow_id=self.design['workflow_id'],
                       expected_revision=self.design['revision'])

    def tearDown(self):
        self.temp.cleanup()

    def inventory(self):
        import hashlib
        return {str(p.relative_to(self.path)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.path.rglob('*') if p.is_file()}

    def test_actual_broker_parity_and_no_write(self):
        before=self.inventory()
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            legacy=DirectPinnedWorkflowReader().select(broker=broker,**self.kw)
            routed=RoutedPinnedWorkflowReader().select(broker=broker,**self.kw)
        self.assertEqual(legacy,routed)
        self.assertFalse(routed['execution_authorized'])
        self.assertEqual(before,self.inventory())

    def test_agent_model_report_parity_on_pinned_read(self):
        from test_dualflow_model import FakeProvider, Response, TASK
        patch = load_patch(EXAMPLES/'evidence_review.patch.json')
        # No model is started: the provider is a deterministic trusted stub.
        def evaluate(reader):
            with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
                return evaluate_pinned_wiki_model(
                    broker=broker, **self.kw,
                    provider=FakeProvider(Response(json.dumps(patch))),
                    model='fixture:1',task=TASK,pinned_reader=reader)
        legacy = evaluate(DirectPinnedWorkflowReader())
        routed = evaluate(RoutedPinnedWorkflowReader())
        self.assertEqual(legacy,routed)
        self.assertEqual(legacy['source_reference'],self.kw['reference'])
        self.assertFalse(routed['execution_authorized'])
        self.assertFalse(routed['knowledge_approved'])

    def test_no_double_broker_read(self):
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            with patch.object(broker,'read',wraps=broker.read) as observed:
                RoutedPinnedWorkflowReader().select(broker=broker,**self.kw)
                self.assertEqual(observed.call_count,1)

    def test_invalid_reference_blocks_before_delegate(self):
        class Count:
            calls=0
            def select(self, **kw):
                self.calls+=1
                return {}
        reader=Count()
        kw=dict(self.kw,reference='wiki://not-pinned')
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            with self.assertRaisesRegex(ValueError,'typed read contract'):
                RoutedPinnedWorkflowReader(reader).select(broker=broker,**kw)
        self.assertEqual(reader.calls,0)

    def test_injected_malicious_authority_flag_rejected(self):
        class Forged:
            def select(self,**kw):
                r=DirectPinnedWorkflowReader().select(**kw)
                r['execution_authorized']=True
                r['selection_sha256']=canonical_digest({k:v for k,v in r.items() if k!='selection_sha256'})
                return r
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            with self.assertRaisesRegex(ValueError,'unverified wiki'):
                RoutedPinnedWorkflowReader(Forged()).select(broker=broker,**self.kw)

    def test_failed_read_never_calls_model(self):
        from test_dualflow_model import FakeProvider, Response, TASK
        class Forged:
            def select(self, **kw):
                result = DirectPinnedWorkflowReader().select(**kw)
                result['knowledge_approved'] = True
                result['selection_sha256'] = canonical_digest({
                    k:v for k,v in result.items() if k!='selection_sha256'})
                return result
        model = FakeProvider(Response('{}'))
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            with self.assertRaisesRegex(ValueError,'unverified wiki'):
                evaluate_pinned_wiki_model(
                    broker=broker, **self.kw, provider=model,
                    model='fixture:1', task=TASK,
                    pinned_reader=RoutedPinnedWorkflowReader(Forged()))
        self.assertEqual(model.calls, [])

    def test_stale_revision_is_rejected(self):
        with self.ws.open_notebook('primary',readonly=False) as wiki:
            wiki.update_tiddler('Example Workflow','Example Workflow',
                                json.dumps(self.design,sort_keys=True)+' ',['workflow'],
                                reason='fixture update')
        with ReadOnlyKnowledgeBroker(self.ws,'primary') as broker:
            with self.assertRaises(StaleKnowledgeReference):
                RoutedPinnedWorkflowReader().select(broker=broker,**self.kw)


if __name__=='__main__':
    unittest.main()
