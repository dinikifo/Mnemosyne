"""HWI-I02 bounded real-provider interface and isolated fake-provider tests.

All generated responses are fixtures. These cases do NOT constitute a genuine
Ollama test or independent assessment of underlying factual correctness.
"""
from __future__ import annotations

import copy
import hashlib
from dataclasses import dataclass
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch as mock_patch

from check_dualflow_design import DesignError, load_design
from simulate_dualflow import canonical_digest
from patch_dualflow import load_patch
from review_dualflow import load_suite
from validate_dualflow_application import load_application
from evaluate_dualflow_model import (evaluate_model_proposal, evaluate_pinned_wiki_model,
                                     evaluate_model_batch)

try:
    from personal_wiki_core import NotebookWorkspace
    from hwi.knowledge_broker import ReadOnlyKnowledgeBroker
    HAVE_WIKI = True
except ImportError:
    HAVE_WIKI = False

try:
    from autogpt_lite.llm.ollama import OllamaProvider
    HAVE_APPROVED_OLLAMA = True
except ImportError:
    HAVE_APPROVED_OLLAMA = False

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT/'docs/dualflow/examples'
TASK = 'Add explicit contradiction checks to prevent a report from omitting disputed historical evidence.'


@dataclass
class Response:
    content: str
    model: str = 'fixture:1'
    prompt_tokens: int = 88
    completion_tokens: int = 32


class FakeProvider:
    def __init__(self, response, error=None):
        self.response = response
        self.error = error
        self.calls = []

    def chat(self, *, messages, model, temperature, max_tokens, json_mode):
        self.calls.append((messages, model, temperature, max_tokens, json_mode))
        if self.error:
            raise self.error
        return self.response


class ModelTrialTests(unittest.TestCase):
    def setUp(self):
        self.base = load_design(EXAMPLES/'evidence_review.json')
        self.patch = load_patch(EXAMPLES/'evidence_review.patch.json')
        self.regression = load_suite(EXAMPLES/'evidence_review.regression.json')
        self.application = load_application(EXAMPLES/'evidence_review.application.json')
        self.provider = FakeProvider(Response(json.dumps(self.patch)))

    def run_trial(self, **kwargs):
        return evaluate_model_proposal(
            provider=kwargs.pop('provider', self.provider),
            model=kwargs.pop('model', 'fixture:1'),
            task=kwargs.pop('task', TASK),
            base=kwargs.pop('base', self.base),
            reference_patch=kwargs.pop('reference_patch', self.patch),
            regression_suite=kwargs.pop('regression_suite', self.regression),
            application_suite=kwargs.pop('application_suite', self.application),
            **kwargs)

    def test_valid_model_patch_matches_pinned_reference(self):
        out = self.run_trial()
        self.assertEqual(out['status'], 'MODEL_PATCH_MATCHES_PINNED_REFERENCE')
        self.assertEqual(out['reference_candidate_sha256'], out['candidate']['candidate_sha256'])
        self.assertTrue(out['model_patch_regression_replayed'])
        self.assertFalse(out['real_model_behavior_demonstrated'])
        self.assertFalse(out['execution_authorized'])
        self.assertFalse(out['workflow_owner_acceptance_verified'])
        self.assertEqual(out['reported_tokens']['prompt'], 88)
        self.assertEqual(len(self.provider.calls), 1)
        messages, name, temp, budget, json_mode = self.provider.calls[0]
        self.assertEqual([m.role for m in messages], ['system','user'])
        self.assertEqual(temp, 0)
        self.assertEqual(budget, 2048)
        self.assertTrue(json_mode)
        self.assertEqual(name, 'fixture:1')
        self.assertNotIn(self.patch['operations'][0]['value']['guards'][-1], messages[1].content)

    def test_prompt_v1_specifies_exact_operation_field_sets(self):
        result = self.run_trial()
        self.assertEqual(result['prompt_version'], 'hwi.dualflow.model_prompt.v1')
        messages = self.provider.calls[-1][0]
        guide = messages[0].content
        self.assertIn('replace_flow: exactly op,id,value', guide)
        self.assertIn('set_terminal_stocks: exactly op,value', guide)
        self.assertIn('set_resource: exactly op,name,value', guide)
        self.assertIn('prefer exactly ONE replace_flow', guide)
        self.assertIn('id,capability,inputs,outputs,guards,observations,on_failure,on_unknown', guide)
        self.assertNotIn('contradictions_reported', guide)
        self.assertNotIn('contradictions_reported', messages[1].content)

    def test_incorrect_third_operation_with_extra_key_still_rejected(self):
        invalid = copy.deepcopy(self.patch)
        invalid['operations'].extend([
            {'op': 'set_resource', 'name': 'max_steps', 'value': 13},
            {'op': 'set_terminal_stocks', 'id': 'work.reported',
             'value': ['work.reported', 'work.stopped']},
        ])
        self.provider.response = Response(json.dumps(invalid))
        result = self.run_trial()
        self.assertEqual(result['status'], 'MODEL_OUTPUT_REJECTED')
        self.assertEqual(result['failure_class'], 'DesignError')
        self.assertIsNone(result['candidate'])
        self.assertIsNone(result['proposed_patch'])
        self.assertFalse(result['execution_authorized'])

    def test_batch_exact_match_metric_is_explicitly_fixture_only(self):
        batch = evaluate_model_batch(
            repeats=3, provider=self.provider, model='fixture:1', task=TASK,
            base=self.base, reference_patch=self.patch,
            regression_suite=self.regression, application_suite=self.application)
        self.assertEqual(batch['trials'], 3)
        self.assertEqual(batch['reference_match_count'], 3)
        self.assertEqual(batch['reference_match_percent'], 100)
        self.assertFalse(batch['real_model_identity_attested'])
        self.assertFalse(batch['execution_authorized'])
        self.assertEqual(len(self.provider.calls), 3)

    def test_batch_mixed_failure_count(self):
        class AlternatingProvider(FakeProvider):
            def chat(self, **kwargs):
                self.calls.append(kwargs)
                if len(self.calls) == 2:
                    return Response('not a json response')
                return Response(json.dumps(self_response))
        self_response = self.patch
        provider = AlternatingProvider(None)
        batch = evaluate_model_batch(
            repeats=3, provider=provider, model='fixture:1', task=TASK,
            base=self.base, reference_patch=self.patch,
            regression_suite=self.regression, application_suite=self.application)
        self.assertEqual(batch['reference_match_count'], 2)
        self.assertEqual(batch['outcome_counts']['MODEL_OUTPUT_REJECTED'], 1)

    def test_batch_rejects_invalid_attempt_count_before_call(self):
        with self.assertRaises(DesignError):
            evaluate_model_batch(repeats=0, provider=self.provider,
                model='fixture:1',task=TASK,base=self.base,reference_patch=self.patch,
                regression_suite=self.regression,application_suite=self.application)
        self.assertEqual(len(self.provider.calls),0)

    def test_batch_rejects_boolean_attempt_count(self):
        with self.assertRaises(DesignError):
            evaluate_model_batch(repeats=True, provider=self.provider,
                model='fixture:1',task=TASK,base=self.base,reference_patch=self.patch,
                regression_suite=self.regression,application_suite=self.application)

    def test_repeatability(self):
        self.assertEqual(self.run_trial(), self.run_trial())

    def test_invalid_json_fails_closed(self):
        self.provider.response = Response('{')
        out = self.run_trial()
        self.assertEqual(out['status'], 'MODEL_OUTPUT_REJECTED')
        self.assertIsNone(out['candidate'])
        self.assertIsNone(out['proposed_patch'])

    def test_markdown_fenced_json_fails(self):
        self.provider.response = Response('```json\n' + json.dumps(self.patch) + '\n```')
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_duplicate_json_keys_rejected(self):
        self.provider.response = Response('{"schema":"a", "schema":"b"}')
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_nan_rejected(self):
        self.provider.response = Response('{"schema":NaN}')
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_authorization_claim_rejected(self):
        forged = dict(self.patch, execution_authorized=True)
        self.provider.response = Response(json.dumps(forged))
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_protected_mode_mutation_rejected(self):
        forged = copy.deepcopy(self.patch)
        forged['operations'][0]['value']['capability'] = 'execute_python'
        self.provider.response = Response(json.dumps(forged))
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_wrong_base_rejected(self):
        forged = copy.deepcopy(self.patch)
        forged['base_sha256'] = '0'*64
        self.provider.response = Response(json.dumps(forged))
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_response_model_mismatch_rejected(self):
        self.provider.response = Response(json.dumps(self.patch), model='other')
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_provider_exception_fails_closed_without_leaking_message(self):
        err = RuntimeError('secret token 123456')
        out = self.run_trial(provider=FakeProvider(None, error=err))
        self.assertEqual(out['status'], 'MODEL_CALL_FAILED')
        self.assertEqual(out['failure_class'], 'RuntimeError')
        self.assertNotIn('secret', json.dumps(out))

    def test_response_size_limit(self):
        self.provider.response = Response('X'*128001)
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_wrong_json_shape_rejected(self):
        self.provider.response = Response('[]')
        self.assertEqual(self.run_trial()['status'], 'MODEL_OUTPUT_REJECTED')

    def test_candidate_matches_design_only(self):
        altered = copy.deepcopy(self.patch)
        altered['rationale'] = 'Another explanatory reason satisfying all bounded text checks.'
        self.provider.response = Response(json.dumps(altered))
        out = self.run_trial()
        self.assertEqual(out['status'], 'CANDIDATE_MATCHES_DESIGN_DIFFERENT_PATCH_UNTESTED')
        self.assertFalse(out['model_patch_regression_replayed'])

    def test_valid_alternative_does_not_inherit_reference_tests(self):
        altered = copy.deepcopy(self.patch)
        altered['operations'] = [{'op':'set_resource', 'name':'max_steps', 'value':13}]
        self.provider.response = Response(json.dumps(altered))
        out = self.run_trial()
        self.assertEqual(out['status'], 'VALID_ALTERNATIVE_NOT_BENCHMARK_VERIFIED')
        self.assertFalse(out['model_patch_regression_replayed'])

    def test_without_reference_stays_untested(self):
        out = self.run_trial(reference_patch=None, regression_suite=None, application_suite=None)
        self.assertEqual(out['status'], 'VALID_CANDIDATE_UNTESTED')
        self.assertIsNone(out['reference_candidate_sha256'])

    def test_incomplete_benchmark_rejected_before_call(self):
        with self.assertRaises(DesignError):
            self.run_trial(regression_suite=None)
        self.assertEqual(len(self.provider.calls), 0)

    def test_invalid_declared_benchmark_rejected_before_call(self):
        suite = copy.deepcopy(self.regression)
        suite['cases'] = []
        with self.assertRaises(DesignError):
            self.run_trial(regression_suite=suite)
        self.assertEqual(len(self.provider.calls), 0)

    def test_bad_task_rejected_before_call(self):
        with self.assertRaises(DesignError):
            self.run_trial(task='run')
        self.assertEqual(len(self.provider.calls), 0)

    def test_control_character_task_rejected(self):
        with self.assertRaises(DesignError):
            self.run_trial(task='Task with control \x1b[2J injected')

    def test_oversized_task_rejected(self):
        with self.assertRaises(DesignError):
            self.run_trial(task='a'*1201)

    def test_provider_kind_not_attested(self):
        out = self.run_trial(provider_kind='LOCAL_OLLAMA')
        self.assertEqual(out['provider_kind'], 'LOCAL_OLLAMA')
        self.assertFalse(out['real_model_behavior_demonstrated'])

    def test_provider_kind_invalid(self):
        with self.assertRaises(DesignError):
            self.run_trial(provider_kind='REMOTE_EXECUTOR')

    def test_referenced_wiki_metadata_is_not_authorization(self):
        out = self.run_trial(source_reference='hwi05://'+'a'*64+'/'+'b'*32+'@1',
                             source_revision_sha256='c'*64)
        self.assertFalse(out['wiki_source_authenticated'])
        self.assertFalse(out['knowledge_approved'])

    def test_source_metadata_partial_rejected(self):
        with self.assertRaises(DesignError):
            self.run_trial(source_reference='hwi05://abc')

    def test_inputs_immutable(self):
        original = copy.deepcopy((self.base, self.patch, self.regression, self.application))
        self.run_trial()
        self.assertEqual((self.base, self.patch, self.regression, self.application), original)

    def test_no_provider_call_when_benchmark_hash_stale(self):
        app = copy.deepcopy(self.application)
        app['workflow']['design_sha256'] = 'f'*64
        with self.assertRaises(DesignError):
            self.run_trial(application_suite=app)
        self.assertEqual(len(self.provider.calls),0)


@unittest.skipUnless(HAVE_WIKI, 'approved wiki wheel not on PYTHONPATH')
class PinnedWikiModelTests(unittest.TestCase):
    def setUp(self):
        self.base = load_design(EXAMPLES/'evidence_review.json')
        self.patch = load_patch(EXAMPLES/'evidence_review.patch.json')
        self.regression = load_suite(EXAMPLES/'evidence_review.regression.json')
        self.application = load_application(EXAMPLES/'evidence_review.application.json')
        self.provider = FakeProvider(Response(json.dumps(self.patch)))
        self.temp = tempfile.TemporaryDirectory()
        # Resolve first: on macOS the temp folder sits behind the /var ->
        # /private/var symlink, and the wiki core refuses symlinked workspaces.
        self.root = Path(self.temp.name).resolve(strict=True)
        self.ws = NotebookWorkspace(self.root/'private', create=True)
        self.ws.create_notebook('primary')
        raw = json.dumps(self.base, sort_keys=True, separators=(',', ':'))
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            wiki.save_tiddler('Pinned Workflow', raw, ['workflow'], fields={}, reason='synthetic')
            wiki.knowledge_catalog().initialize()
        with ReadOnlyKnowledgeBroker(self.ws, 'primary') as broker:
            self.original = broker.search('Pinned Workflow', mode='Title')[0]

    def tearDown(self):
        self.temp.cleanup()

    def test_model_proposal_does_not_modify_notebook(self):
        def inventory(root):
            return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in root.rglob('*') if p.is_file()}
        before = inventory(self.ws.path) if hasattr(self.ws, 'path') else inventory(self.root)
        with ReadOnlyKnowledgeBroker(self.ws, 'primary') as broker:
            evaluate_pinned_wiki_model(
                broker=broker, reference=self.original['ref'],
                expected_source_revision_sha256=self.original['revision_sha256'],
                expected_design_sha256=canonical_digest(self.base),
                expected_workflow_id=self.base['workflow_id'],
                expected_revision=self.base['revision'],
                provider=self.provider, model='fixture:1', task=TASK,
                reference_patch=self.patch, regression_suite=self.regression,
                application_suite=self.application)
        after = inventory(self.ws.path) if hasattr(self.ws, 'path') else inventory(self.root)
        self.assertEqual(before, after)

    def test_end_to_end_wiki_model_patch_fixture(self):
        with ReadOnlyKnowledgeBroker(self.ws, 'primary') as broker:
            out = evaluate_pinned_wiki_model(
                broker=broker, reference=self.original['ref'],
                expected_source_revision_sha256=self.original['revision_sha256'],
                expected_design_sha256=canonical_digest(self.base),
                expected_workflow_id=self.base['workflow_id'],
                expected_revision=self.base['revision'],
                provider=self.provider, model='fixture:1', task=TASK,
                reference_patch=self.patch, regression_suite=self.regression,
                application_suite=self.application)
        self.assertEqual(out['status'], 'MODEL_PATCH_MATCHES_PINNED_REFERENCE')
        self.assertEqual(out['source_reference'], self.original['ref'])
        self.assertFalse(out['workflow_published'])

    def test_stale_revision_rejected_before_model(self):
        with self.ws.open_notebook('primary', readonly=False) as wiki:
            wiki.save_tiddler('Pinned Workflow', 'updated', ['workflow'],fields={}, reason='fixture edit')
        with ReadOnlyKnowledgeBroker(self.ws, 'primary') as broker:
            with self.assertRaises(Exception):
                evaluate_pinned_wiki_model(
                    broker=broker, reference=self.original['ref'],
                    expected_source_revision_sha256=self.original['revision_sha256'],
                    expected_design_sha256=canonical_digest(self.base),
                    expected_workflow_id=self.base['workflow_id'],
                    expected_revision=self.base['revision'],
                    provider=self.provider, model='fixture:1', task=TASK)
        self.assertEqual(len(self.provider.calls), 0)

    def test_wrong_source_pin_rejected_before_model(self):
        with ReadOnlyKnowledgeBroker(self.ws, 'primary') as broker:
            with self.assertRaises(Exception):
                evaluate_pinned_wiki_model(
                    broker=broker, reference=self.original['ref'],
                    expected_source_revision_sha256='a'*64,
                    expected_design_sha256=canonical_digest(self.base),
                    expected_workflow_id=self.base['workflow_id'],
                    expected_revision=self.base['revision'],
                    provider=self.provider, model='fixture:1', task=TASK)
        self.assertEqual(len(self.provider.calls), 0)


@unittest.skipUnless(HAVE_APPROVED_OLLAMA, 'approved CR03 agent provider not on PYTHONPATH')
class ExistingOllamaProviderContractTests(unittest.TestCase):
    def test_existing_provider_http_chat_contract_mocked_no_network(self):
        class ResponseStub:
            status_code = 200
            def raise_for_status(self):
                pass
            def json(self):
                return {'message': {'content': json.dumps(load_patch(
                    EXAMPLES/'evidence_review.patch.json'))},
                    'prompt_eval_count': 42, 'eval_count': 51}

        p = OllamaProvider(base_url='http://127.0.0.1:11434')
        with mock_patch.object(p._session, 'post', return_value=ResponseStub()) as send:
            out = evaluate_model_proposal(
                provider=p, model='fixture:1', task=TASK,
                base=load_design(EXAMPLES/'evidence_review.json'),
                reference_patch=load_patch(EXAMPLES/'evidence_review.patch.json'),
                regression_suite=load_suite(EXAMPLES/'evidence_review.regression.json'),
                application_suite=load_application(EXAMPLES/'evidence_review.application.json'),
                provider_kind='LOCAL_OLLAMA')
        self.assertEqual(out['status'], 'MODEL_PATCH_MATCHES_PINNED_REFERENCE')
        self.assertFalse(out['real_model_behavior_demonstrated'])
        self.assertEqual(out['reported_tokens'], {'prompt':42, 'completion':51})
        kwargs = send.call_args.kwargs
        self.assertEqual(kwargs['json']['format'], 'json')
        self.assertEqual(kwargs['json']['options']['temperature'], 0.0)
        self.assertEqual(kwargs['json']['stream'], False)
        self.assertEqual(kwargs['json']['model'], 'fixture:1')
        self.assertEqual(send.call_args.args[0], 'http://127.0.0.1:11434/api/chat')
        self.assertNotIn('tools', kwargs['json'])

    def test_existing_provider_unavailable_preflight_mocked(self):
        import requests
        p = OllamaProvider(base_url='http://127.0.0.1:11434')
        with mock_patch.object(p._session, 'get', side_effect=requests.ConnectionError('no service')):
            self.assertIs(p.validate(), False)



if __name__ == '__main__':
    unittest.main()
