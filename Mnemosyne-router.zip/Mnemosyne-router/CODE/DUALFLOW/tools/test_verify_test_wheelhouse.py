"""Offline-only unit checks for RC-05 wheelhouse preflight."""
import importlib.util
import tempfile
from pathlib import Path
import unittest
from zipfile import ZipFile

SCRIPT = Path(__file__).with_name('verify_test_wheelhouse.py')
SPEC = importlib.util.spec_from_file_location('verify_test_wheelhouse', SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def make_wheel(root, name, version, *, metadata_name=None, metadata_version=None):
    filename = f'{name}-{version}-py3-none-any.whl'
    path = root / filename
    with ZipFile(path,'w') as z:
        z.writestr(f'{name}-{version}.dist-info/METADATA',
                   f'Metadata-Version: 2.1\nName: {metadata_name or name}\nVersion: {metadata_version or version}\n')
        z.writestr(f'{name}-{version}.dist-info/WHEEL', 'Wheel-Version: 1.0\nGenerator: rc05-test\nRoot-Is-Purelib: true\nTag: py3-none-any\n')
    return path


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.requirements = self.root / 'requirements-test.txt'
        self.wheels = self.root / 'wheels'
        self.wheels.mkdir()

    def test_requires_exact_pins(self):
        self.requirements.write_text('pytest>=9\n')
        with self.assertRaisesRegex(ValueError,'Non-exact'):
            MODULE.parse_requirements(self.requirements)

    def test_duplicate_names_rejected(self):
        self.requirements.write_text('Foo_Bar==1.0\nfoo-bar==1.1\n')
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            MODULE.parse_requirements(self.requirements)

    def test_missing_wheelhouse_is_blocked(self):
        self.requirements.write_text('pytest==9.1.1\n')
        result = MODULE.inspect(self.root / 'absent', self.requirements)
        self.assertEqual(result['status'],'BLOCKED_NO_WHEELHOUSE')

    def test_missing_direct_pin_is_blocked(self):
        self.requirements.write_text('pytest==9.1.1\n')
        result = MODULE.inspect(self.wheels, self.requirements)
        self.assertEqual(result['status'],'BLOCKED_MISSING_DIRECT_WHEELS')
        self.assertEqual(result['missing_direct_pins'],['pytest==9.1.1'])

    def test_valid_direct_wheel_not_misreported_as_full_resolution(self):
        self.requirements.write_text('fake-package==1.0\n')
        make_wheel(self.wheels, 'fake_package', '1.0')
        result = MODULE.inspect(self.wheels, self.requirements, resolve=False)
        self.assertEqual(result['status'],'DIRECT_PINS_PRESENT_TRANSITIVES_UNCHECKED')
        self.assertEqual(len(result['wheels'][0]['sha256']),64)

    def test_resolver_accepts_isolated_synthetic_fixture_only(self):
        self.requirements.write_text('fake-package==1.0\n')
        make_wheel(self.wheels, 'fake_package', '1.0')
        result = MODULE.inspect(self.wheels, self.requirements, resolve=True)
        self.assertEqual(result['status'], 'READY_FOR_ISOLATED_INSTALL_NOT_TESTED')

    def test_tampered_metadata_rejected(self):
        self.requirements.write_text('fake-package==1.0\n')
        make_wheel(self.wheels, 'fake_package', '1.0',metadata_version='2.0')
        result = MODULE.inspect(self.wheels, self.requirements, resolve=False)
        self.assertEqual(result['status'],'BLOCKED_INVALID_WHEELS')

    def test_corrupt_wheel_rejected(self):
        self.requirements.write_text('fake-package==1.0\n')
        (self.wheels / 'fake_package-1.0-py3-none-any.whl').write_bytes(b'garbage')
        result = MODULE.inspect(self.wheels, self.requirements, resolve=False)
        self.assertEqual(result['status'],'BLOCKED_INVALID_WHEELS')


if __name__=='__main__':
    unittest.main()
