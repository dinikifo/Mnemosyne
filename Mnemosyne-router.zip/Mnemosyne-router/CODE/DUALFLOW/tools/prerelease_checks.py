"""Pre-release checks for conditions a single build machine does not show by itself.

Run from the release folder:  python3 -I CODE/DUALFLOW/tools/prerelease_checks.py .

1. symlinked_tmp: all offline suites with TMPDIR reached through a symlink
   (macOS keeps temporary folders behind /var -> /private/var).
2. ollama_listening: all offline suites while a recording fake Ollama listens on
   127.0.0.1:11434 (a developer machine usually runs one). No test may send it a
   chat request, and every suite must still pass. SKIPPED if the port is in use.

Prints a JSON summary; exit 0 only if every check that ran passed.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


def run_offline(release: Path, env: dict) -> dict:
    p = subprocess.run(['bash', str(release / 'RUN_ALL_OFFLINE.command')], cwd=release,
                       capture_output=True, text=True, env=env, timeout=1800)
    out = p.stdout + p.stderr
    ran = [int(line.split()[1]) for line in out.splitlines() if line.startswith('Ran ')]
    bad = [line for line in out.splitlines() if line.startswith(('FAIL:', 'ERROR:'))]
    return {'exit_code': p.returncode, 'suites': ran, 'total': sum(ran), 'failures': bad[:10]}


def check_symlinked_tmp(release: Path) -> dict:
    with tempfile.TemporaryDirectory() as real:
        link = Path(real).parent / (Path(real).name + '-link')
        os.symlink(real, link)
        try:
            result = run_offline(release, {**os.environ, 'TMPDIR': str(link)})
        finally:
            link.unlink()
    result['passed'] = result['exit_code'] == 0 and not result['failures']
    return result


def check_ollama_listening(release: Path) -> dict:
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _reply(self, obj):
            body = json.dumps(obj).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            requests.append(('GET', self.path))
            self._reply({'models': [{'name': 'llama3.1:8b'}]})

        def do_POST(self):
            length = int(self.headers.get('Content-Length', 0))
            self.rfile.read(length)
            requests.append(('POST', self.path))
            self._reply({'message': {'role': 'assistant', 'content': 'Which notes?'}, 'done': True})

    try:
        server = ThreadingHTTPServer(('127.0.0.1', 11434), Handler)
    except OSError:
        return {'passed': None, 'status': 'SKIPPED', 'reason': 'port 11434 in use (a real Ollama?)'}
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        result = run_offline(release, dict(os.environ))
    finally:
        server.shutdown()
    chats = [r for r in requests if r[0] == 'POST']
    result.update(chat_requests=len(chats), requests=requests[:10])
    result['passed'] = result['exit_code'] == 0 and not result['failures'] and not chats
    return result


def main() -> int:
    release = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve(strict=True)
    if not (release / 'RUN_ALL_OFFLINE.command').is_file():
        print('usage: prerelease_checks.py <release folder>', file=sys.stderr)
        return 2
    report = {'schema': 'hwi.prerelease_checks.v1',
              'symlinked_tmp': check_symlinked_tmp(release),
              'ollama_listening': check_ollama_listening(release)}
    ran = [v['passed'] for v in report.values() if isinstance(v, dict) and v.get('passed') is not None]
    report['passed'] = bool(ran) and all(ran)
    print(json.dumps(report, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
