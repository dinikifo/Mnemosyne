#!/usr/bin/env python3
"""Validate and report refactor checkpoint goal counts; never grants acceptance."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def validate(data, root):
    errors, cp_counts, seen = [], [], set()
    if data.get('schema') != 'hwi.refactor.checkpoints.v1':
        errors.append('unknown schema')
    cps = data.get('checkpoints', [])
    if not isinstance(cps, list) or len(cps) != 6:
        errors.append('expected six checkpoints')
        return errors, {}
    for idx, cp in enumerate(cps):
        cid = cp.get('id')
        deps = cp.get('depends_on', [])
        if cid != f'RC-{idx:02d}': errors.append(f'checkpoint order: {cid}')
        if deps != ([] if idx == 0 else [cps[idx-1].get('id')]): errors.append(f'{cid} dependency sequence')
        if cp.get('acceptance') not in ('PENDING_OWNER_REVIEW', 'ACCEPTED', 'REJECTED'):
            errors.append(f'{cid} unknown acceptance')
        goals=cp.get('goals', [])
        if len(goals) != (3 if idx==0 else (4 if idx==5 else 5)):
            errors.append(f'{cid} goal count changed without denominator review')
        done=0
        for g in goals:
            gid=g.get('id')
            if not isinstance(gid,str) or not gid.startswith(cid+'.') or gid in seen:
                errors.append(f'{cid} invalid or duplicate goal {gid}')
            seen.add(gid)
            status=g.get('status')
            if status not in ('pending','complete'):
                errors.append(f'{gid} invalid status {status}')
            if status == 'complete':
                done+=1
                if idx>0 and any(pending for prev in cps[:idx] for pending in prev.get('goals',[]) if pending.get('status')!='complete'):
                    errors.append(f'{gid} prior checkpoint not complete')
                evidence=g.get('evidence', [])
                if not isinstance(evidence,list) or not evidence:
                    errors.append(f'{gid} complete without evidence')
                else:
                    for item in evidence:
                        if not isinstance(item,str) or not item or Path(item).is_absolute() or '..' in Path(item).parts or not (root/item).is_file():
                            errors.append(f'{gid} invalid/missing evidence: {item!r}')
            elif g.get('evidence'):
                for item in g['evidence']:
                    if not isinstance(item, str) or '..' in Path(item).parts:
                        errors.append(f'{gid} unsafe evidence')
        cp_counts.append({'id':cid, 'title':cp.get('title'), 'complete':done, 'total':len(goals), 'percent':round(100*done/len(goals),1) if goals else 0,'acceptance':cp.get('acceptance')})
    completed=sum(x['complete'] for x in cp_counts)
    total=sum(x['total'] for x in cp_counts)
    if total != 27: errors.append(f'unapproved denominator: {total} != 27')
    impl_completed=sum(x['complete'] for x in cp_counts[1:])
    out={'complete':completed,'total':total,'percent':round(100*completed/total,1) if total else 0,
         'implementation_complete':impl_completed,'implementation_total':total-len(cps[0].get('goals',[])),
         'implementation_percent':round(100*impl_completed/(total-len(cps[0].get('goals',[]))),1) if total>len(cps[0].get('goals',[])) else 0,
         'checkpoints':cp_counts}
    return errors,out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--json',action='store_true')
    ap.add_argument('--markdown',action='store_true')
    args=ap.parse_args()
    data=json.loads((ROOT/'refactor/GOALS.json').read_text())
    errors,report=validate(data,ROOT)
    if errors:
        for msg in errors: print('FAIL',msg)
        raise SystemExit(1)
    if args.json:print(json.dumps(report,sort_keys=True))
    elif args.markdown:
        print('| Checkpoint | Completed / total | Progress | Owner acceptance |')
        print('|---|---:|---:|---|')
        for cp in report['checkpoints']:
            print(f"| {cp['id']} — {cp['title']} | {cp['complete']}/{cp['total']} | {cp['percent']:.1f}% | {cp['acceptance']} |")
        print(f"Overall: **{report['complete']}/{report['total']} ({report['percent']:.1f}%)**; "
              f"implementation-only **{report['implementation_complete']}/{report['implementation_total']} ({report['implementation_percent']:.1f}%)**")
    else:print(f"REFRACTOR_GOALS_VALID {report['complete']}/{report['total']} {report['percent']:.1f}% ")

if __name__=='__main__':main()
