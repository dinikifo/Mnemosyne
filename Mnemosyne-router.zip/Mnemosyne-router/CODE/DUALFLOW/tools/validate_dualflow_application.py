#!/usr/bin/env python3
"""WL-06 offline, per-request *simulation* gate; never workflow execution.

A supplied, version-pinned workflow and newly declared task-specific synthetic
cases are compared against expected results. Neither the input cases nor the
baseline's passing report prove factual correctness, owner acceptance, or
permission to run an actual workflow.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import sys
from typing import Any

from check_dualflow_design import (
    DesignError, _items, _need, _object, _symbol, _unique_object,
    _reject_constant, load_design,
)
from patch_dualflow import load_patch, propose_revision
from review_dualflow import assess_revision, load_suite, _expected, _sha
from simulate_dualflow import canonical_digest, simulate, SCHEMA as SIMULATION_SCHEMA

SCHEMA = "hwi.dualflow.application_suite.v0"
REPORT_SCHEMA = "hwi.dualflow.application_report.v0"
MAX_BYTES = 512_000
MAX_CASES = 16
MAX_REQUIREMENTS = 12


def load_application(path: str | Path) -> dict:
    p = Path(path)
    _need(p.stat().st_size <= MAX_BYTES, "application suite exceeds byte limit")
    with p.open(encoding="utf-8") as f:
        return json.load(f, object_pairs_hook=_unique_object,
                         parse_constant=_reject_constant)


def _bounded_text(value: Any, where: str, limit: int = 400) -> str:
    _need(type(value) is str and 12 <= len(value) <= limit and
          value.isprintable(), f"{where}: invalid bounded explanatory text")
    return value


def _validate_application(application: Any, base: dict, proposal: dict,
                          baseline_report: dict, baseline_suite: dict) -> list[dict]:
    design = proposal["candidate_design"]
    _object(application, {"schema", "application_id", "task", "workflow",
                          "baseline_evidence_sha256", "cases"}, "application")
    _need(application["schema"] == SCHEMA, "unsupported application schema")
    _symbol(application["application_id"], "application_id")
    workflow = _object(application["workflow"], {"workflow_id", "revision",
                                                  "design_sha256"}, "workflow selection")
    _need(workflow["workflow_id"] == design["workflow_id"] and
          type(workflow["revision"]) is int and workflow["revision"] == design["revision"] and
          _sha(workflow["design_sha256"], "workflow.design_sha256") ==
          proposal["candidate_sha256"], "stale or mismatched workflow selection")
    _need(_sha(application["baseline_evidence_sha256"], "baseline_evidence_sha256") ==
          baseline_report["evidence_sha256"], "stale baseline evidence identity")

    task = _object(application["task"], {"goal", "requirements"}, "task")
    _bounded_text(task["goal"], "task.goal", 800)
    reqs = task["requirements"]
    _need(type(reqs) is list and 1 <= len(reqs) <= MAX_REQUIREMENTS,
          "task.requirements: expected 1..12 requirements")
    req_ids: list[str] = []
    for idx, raw in enumerate(reqs):
        req = _object(raw, {"id", "description"}, f"requirement[{idx}]")
        req_ids.append(_symbol(req["id"], "requirement.id"))
        _bounded_text(req["description"], "requirement.description")
    _need(len(req_ids) == len(set(req_ids)), "duplicate requirement id")

    cases = application["cases"]
    _need(type(cases) is list and 2 <= len(cases) <= MAX_CASES,
          "application requires 2..16 new task-specific cases")
    old_ids = {case["test_id"] for case in baseline_suite["cases"]}
    old_scenarios = {canonical_digest(case["scenario"]["steps"])
                     for case in baseline_suite["cases"]}
    case_ids: set[str] = set()
    scenario_ids: set[str] = set()
    covered: set[str] = set()
    positive = negative = False
    failure_stocks = {flow[key] for flow in design["flows"]
                      for key in ("on_failure", "on_unknown")}
    for i, raw in enumerate(cases):
        case = _object(raw, {"case_id", "requirement_ids", "rationale",
                             "scenario", "expected"}, f"case[{i}]")
        cid = _symbol(case["case_id"], f"case[{i}].case_id")
        _need(cid not in old_ids, "application test ID reused from baseline regression")
        _need(cid not in case_ids, "duplicate application test ID")
        case_ids.add(cid)
        _bounded_text(case["rationale"], f"case[{i}].rationale")
        covered.update(_items(case["requirement_ids"], f"case[{i}].requirement_ids",
                              minimum=1, maximum=MAX_REQUIREMENTS))
        _need(set(case["requirement_ids"]) <= set(req_ids),
              f"case[{i}]: undeclared task requirement")
        scenario = case["scenario"]
        _need(type(scenario) is dict and scenario.get("schema") == SIMULATION_SCHEMA and
              scenario.get("workflow_id") == design["workflow_id"] and
              type(scenario.get("revision")) is int and
              scenario["revision"] == design["revision"] and
              scenario.get("design_sha256") == proposal["candidate_sha256"],
              f"case[{i}]: scenario must pin exact selected revision")
        # This checks byte-level novelty relative to the regression suite, not
        # semantic novelty or independence of generated test expectations.
        steps = scenario.get("steps")
        _need(type(steps) is list, f"case[{i}]: invalid scenario steps")
        sid = canonical_digest(steps)
        _need(sid not in old_scenarios, f"case[{i}]: scenario steps reused from baseline")
        _need(sid not in scenario_ids, "duplicate application scenario steps")
        scenario_ids.add(sid)
        expected = _expected(case["expected"], design, f"case[{i}].expected")
        _need(expected["kind"] == "simulate", "application cases must expect simulations")
        if (expected["status"] == "SIMULATED_TERMINAL" and
                all(s == "SUCCESS" for s in expected["flow_statuses"]) and
                expected["terminal_stock"] not in failure_stocks):
            positive = True
        if (expected["status"] == "SIMULATED_TERMINAL" and
                any(s in ("FAILURE", "UNKNOWN") for s in expected["flow_statuses"]) and
                expected["terminal_stock"] in failure_stocks):
            negative = True
    _need(covered == set(req_ids), "application cases do not cover all declared requirements")
    _need(positive, "application suite requires a successful non-failure terminal case")
    _need(negative, "application suite requires a failure or unknown terminal case")
    return cases


def assess_application(base: Any, patch: Any, baseline_suite: Any,
                       application: Any) -> dict[str, Any]:
    """Replay declared, new per-use synthetic cases without executing operations.

    Baseline and application expectations remain untrusted assertions. Output is
    solely an unapproved proposal for *human* application review.
    """
    proposal = propose_revision(base, patch)
    baseline_report = assess_revision(base, patch, baseline_suite)
    _need(baseline_report["status"] == "READY_FOR_OWNER_REVIEW",
          "baseline regression is not ready for review")
    cases = _validate_application(application, base, proposal,
                                  baseline_report, baseline_suite)
    selected = proposal["candidate_design"]
    results: list[dict] = []
    for case in cases:
        expected = case["expected"]
        try:
            trace = simulate(selected, case["scenario"])
        except DesignError as exc:
            observed = {"kind": "reject", "error": str(exc)[:240]}
            trace_hash = None
            matched = False
        else:
            generated = sorted(a for a, info in trace["lineage"].items()
                               if info["origin"] != "initial")
            observed = {"kind": "simulate", "status": trace["status"],
                        "terminal_stock": trace["terminal_stock"],
                        "flow_statuses": [step["status"] for step in trace["trace"]],
                        "knowledge_ids": generated}
            trace_hash = trace["trace_sha256"]
            matched = observed == expected
        results.append({"case_id": case["case_id"],
                        "requirement_ids": copy.deepcopy(case["requirement_ids"]),
                        "scenario_sha256": canonical_digest(case["scenario"]),
                        "outcome": "MATCH" if matched else "MISMATCH",
                        "expected": copy.deepcopy(expected), "observed": observed,
                        "trace_sha256": trace_hash})

    passes = sum(x["outcome"] == "MATCH" for x in results)
    report = {"schema": REPORT_SCHEMA,
              "status": ("READY_FOR_HUMAN_APPLICATION_REVIEW" if passes == len(results)
                         else "APPLICATION_BLOCKED"),
              "application_id": application["application_id"],
              "workflow_id": selected["workflow_id"],
              "revision": selected["revision"],
              "design_sha256": proposal["candidate_sha256"],
              "baseline_evidence_sha256": baseline_report["evidence_sha256"],
              "application_suite_sha256": canonical_digest(application),
              "task_sha256": canonical_digest(application["task"]),
              "cases_matched": passes,
              "cases_total": len(results),
              "results": results,
              "coverage_basis": "DECLARED_REQUIREMENT_IDS_NOT_SEMANTICALLY_VERIFIED",
              "novelty_basis": "SCENARIO_STEP_DIGEST_NOT_IN_BASELINE_NOT_SEMANTIC_NOVELTY",
              "workflow_owner_acceptance_verified": False,
              "expectations_independently_verified": False,
              "observations_independently_verified": False,
              "human_application_review_completed": False,
              "application_authorized": False,
              "application_executed": False,
              "knowledge_approved": False,
              "workflow_published": False}
    report["report_sha256"] = canonical_digest(report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base_design", type=Path)
    parser.add_argument("patch", type=Path)
    parser.add_argument("baseline_suite", type=Path)
    parser.add_argument("application_suite", type=Path)
    args = parser.parse_args(argv)
    try:
        report = assess_application(load_design(args.base_design),
                                    load_patch(args.patch),
                                    load_suite(args.baseline_suite),
                                    load_application(args.application_suite))
    except (DesignError, OSError, ValueError, UnicodeError, RecursionError) as exc:
        print(f"APPLICATION_REJECTED: {ascii(str(exc))}", file=sys.stderr)
        return 2
    print(json.dumps(report, sort_keys=True, ensure_ascii=True))
    return 0 if report["status"] == "READY_FOR_HUMAN_APPLICATION_REVIEW" else 1


if __name__ == "__main__":
    raise SystemExit(main())
