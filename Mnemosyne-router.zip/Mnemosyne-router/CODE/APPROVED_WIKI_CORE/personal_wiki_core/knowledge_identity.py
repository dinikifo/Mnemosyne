"""HWI-04 optional knowledge identity and provenance, using existing history IDs.

No LLM tool access, governance promotion, authentication, or independent authority
is implemented here. A metadata annotation is a *claim*, not an attestation.
All links refer to immutable history events and retain meaning after renames.
The catalog must be explicitly initialized; opening a notebook does not migrate it.
"""
from __future__ import annotations

import hashlib
import json
import re


_ACTORS = frozenset({'human', 'agent', 'tool', 'import', 'unknown'})
_SOURCES = frozenset({'journal', 'human_statement', 'tool_result', 'external', 'agent_inference', 'other'})
_RELATIONS = frozenset({'supports', 'contradicts', 'depends_on', 'supersedes', 'derived_from', 'references'})
_ID = re.compile(r'^[0-9a-f]{32}$')
_DIGEST = re.compile(r'^[0-9a-f]{64}$')

_SCHEMA = '''
CREATE TABLE hist.hwi_catalog_info (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE hist.hwi_origins (
    post_id TEXT NOT NULL REFERENCES posts(post_id),
    event_id INTEGER NOT NULL REFERENCES events(event_id),
    event_sha256 TEXT NOT NULL,
    actor_claim TEXT NOT NULL CHECK(actor_claim IN ('human','agent','tool','import','unknown')),
    source_kind TEXT NOT NULL CHECK(source_kind IN
        ('journal','human_statement','tool_result','external','agent_inference','other')),
    source_ref TEXT NOT NULL CHECK(length(trim(source_ref)) > 0),
    source_sha256 TEXT,
    reason TEXT NOT NULL CHECK(length(trim(reason)) > 0),
    PRIMARY KEY(post_id,event_id)
);
CREATE TABLE hist.hwi_links (
    link_id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_post TEXT NOT NULL REFERENCES posts(post_id),
    from_event INTEGER NOT NULL REFERENCES events(event_id),
    from_sha256 TEXT NOT NULL,
    to_post TEXT NOT NULL REFERENCES posts(post_id),
    to_event INTEGER NOT NULL REFERENCES events(event_id),
    to_sha256 TEXT NOT NULL,
    relation TEXT NOT NULL CHECK(relation IN
        ('supports','contradicts','depends_on','supersedes','derived_from','references','restored_from')),
    reason TEXT NOT NULL CHECK(length(trim(reason)) > 0),
    UNIQUE(from_post,from_event,to_post,to_event,relation)
);
CREATE INDEX hist.hwi_links_from ON hwi_links(from_post);
CREATE INDEX hist.hwi_links_to ON hwi_links(to_post);
'''


class CatalogError(ValueError):
    """Invalid or stale knowledge metadata operation."""


class StaleKnowledgeRevision(CatalogError):
    """The caller did not specify the currently observed revision."""


def _require(value, allowed, name):
    if value not in allowed:
        raise CatalogError(f'Invalid {name}: {value!r}')
    return value


def _reason(value):
    if not isinstance(value, str) or not value.strip():
        raise CatalogError('A non-empty reason is required')
    return value.strip()


def _id(value):
    if not isinstance(value, str) or _ID.fullmatch(value) is None:
        raise CatalogError('Invalid stable history post ID')
    return value


def _digest(value):
    if value is not None and (not isinstance(value, str) or _DIGEST.fullmatch(value) is None):
        raise CatalogError('Expected a lowercase SHA-256 digest')
    return value


class KnowledgeCatalog:
    """Optional revision-bound metadata for one open WikiCore notebook.

    The active notebook uses the same stable post IDs as its historical audit.
    Metadata is stored in the existing attached history SQLite database so
    pair backups include it. It is *not* signed or externally anchored.
    """

    def __init__(self, wiki):
        self.wiki = wiki
        self.db = wiki._db
        self.conn = self.db.conn

    def enabled(self) -> bool:
        return self.conn.execute("SELECT 1 FROM hist.sqlite_master WHERE type='table' "
                                 "AND name='hwi_catalog_info'").fetchone() is not None

    def _require_enabled(self):
        if not self.enabled():
            raise CatalogError('HWI catalog not initialized; explicit initialization required')
        row = self.conn.execute("SELECT value FROM hist.hwi_catalog_info WHERE key='version'").fetchone()
        if row is None or row[0] != '1':
            raise CatalogError('Unsupported HWI catalog version')

    def initialize(self):
        """Explicit, idempotent schema extension; no default migration on open."""
        if self.wiki.readonly:
            raise PermissionError('Read-only wiki cannot initialize a catalog')
        with self.conn:
            if not self.enabled():
                # sqlite3 executescript would commit before the DDL; run statements
                # individually inside the current history/content transaction.
                for statement in _SCHEMA.split(';'):
                    if statement.strip():
                        self.conn.execute(statement)
                self.conn.execute('INSERT INTO hist.hwi_catalog_info(key,value) VALUES(?,?)',
                                  ('version','1'))
            self._require_enabled()
        return {'enabled': True, 'version': 1}

    def _event(self, post_id, event_id):
        row = self.conn.execute('SELECT post_id,event_id,after_sha256,before_sha256,title,after_json '
                                'FROM hist.events WHERE post_id=? AND event_id=?',
                                (_id(post_id), event_id)).fetchone()
        if row is None:
            raise CatalogError('Event does not belong to the specified knowledge ID')
        return row

    def resolve(self, post_id: str, event_id: int | None = None) -> dict:
        """Resolve stable ID regardless of rename; deleted records stay resolvable."""
        post = self.conn.execute('SELECT post_id,current_title,last_title,current_sha256,deleted '
                                 'FROM hist.posts WHERE post_id=?', (_id(post_id),)).fetchone()
        if post is None:
            raise CatalogError('Unknown knowledge ID')
        latest = self.conn.execute('SELECT event_id,after_sha256,before_sha256,title '
                                   'FROM hist.events WHERE post_id=? ORDER BY event_id DESC LIMIT 1',
                                   (post_id,)).fetchone()
        if latest is None:
            raise CatalogError('Post has no history')
        record = {'knowledge_id': post_id, 'current_title': post['current_title'],
                  'last_title': post['last_title'], 'deleted': bool(post['deleted']),
                  'latest_event_id': latest['event_id'], 'current_sha256': post['current_sha256']}
        if event_id is not None:
            event = self._event(post_id, event_id)
            record['selected_event_id'] = event['event_id']
            record['selected_sha256'] = event['after_sha256'] or event['before_sha256']
            record['selected_title'] = event['title']
        return record

    def by_title(self, title: str) -> dict | None:
        """Only active title lookup; a reused title has a new knowledge ID."""
        row = self.conn.execute('SELECT post_id FROM hist.posts WHERE current_title=? '
                                'AND deleted=0', (title,)).fetchone()
        return self.resolve(row[0]) if row is not None else None

    def _current_event(self, post_id, expected_event):
        state = self.resolve(post_id)
        if state['deleted']:
            raise CatalogError('Deleted knowledge cannot be annotated as current')
        if type(expected_event) is not int or state['latest_event_id'] != expected_event:
            raise StaleKnowledgeRevision('Expected revision is no longer current')
        if self.db.is_protected(state['current_title']):
            raise PermissionError('Protected PVS record cannot receive HWI annotations')
        event = self._event(post_id, expected_event)
        if event['after_sha256'] != state['current_sha256']:
            raise CatalogError('Current history digest mismatch')
        return event

    def record_origin(self, post_id: str, *, expected_event_id: int, actor_claim: str,
                      source_kind: str, source_ref: str, reason: str,
                      source_sha256: str | None = None) -> dict:
        """Annotate one exact revision. The actor is an unverified claim."""
        if self.wiki.readonly:
            raise PermissionError('Read-only wiki')
        self._require_enabled()
        _require(actor_claim, _ACTORS, 'actor claim')
        _require(source_kind, _SOURCES, 'source kind')
        _reason(reason); _digest(source_sha256)
        if not isinstance(source_ref, str) or not source_ref.strip() or len(source_ref) > 2048:
            raise CatalogError('Non-empty bounded source reference required')
        with self.conn:
            # Lock the writer BEFORE checking the expected head revision.
            # Merely entering `with conn` does not begin a SQLite transaction.
            self.conn.execute('BEGIN IMMEDIATE')
            ev = self._current_event(post_id, expected_event_id)
            self.conn.execute('INSERT INTO hist.hwi_origins '
                '(post_id,event_id,event_sha256,actor_claim,source_kind,source_ref,source_sha256,reason) '
                'VALUES(?,?,?,?,?,?,?,?)',
                (post_id,expected_event_id,ev['after_sha256'],actor_claim,source_kind,
                 source_ref.strip(),source_sha256,_reason(reason)))
        return {'knowledge_id': post_id, 'event_id': expected_event_id,
                'actor_claim': actor_claim, 'verified_actor': False}

    def link(self, from_id: str, to_id: str, relation: str, *,
             expected_from_event: int, expected_to_event: int, reason: str) -> dict:
        """Append an immutable revision-scoped relation, never an authorization."""
        if self.wiki.readonly:
            raise PermissionError('Read-only wiki')
        self._require_enabled()
        _require(relation, _RELATIONS, 'relation')
        note = _reason(reason)
        with self.conn:
            self.conn.execute('BEGIN IMMEDIATE')
            src = self._current_event(from_id, expected_from_event)
            dst = self._current_event(to_id, expected_to_event)
            cur = self.conn.execute('INSERT INTO hist.hwi_links '
                '(from_post,from_event,from_sha256,to_post,to_event,to_sha256,relation,reason) '
                'VALUES (?,?,?,?,?,?,?,?)',
                (from_id,expected_from_event,src['after_sha256'],to_id,expected_to_event,
                 dst['after_sha256'],relation,note))
        return {'link_id': cur.lastrowid, 'relation': relation,
                'from_knowledge_id': from_id, 'to_knowledge_id': to_id,
                'authorizes_action': False}

    def origins(self, post_id: str) -> list[dict]:
        self._require_enabled()
        _id(post_id)
        return [dict(r) for r in self.conn.execute(
            'SELECT * FROM hist.hwi_origins WHERE post_id=? ORDER BY event_id', (post_id,))]

    def links(self, post_id: str) -> list[dict]:
        self._require_enabled()
        _id(post_id)
        return [dict(r) for r in self.conn.execute(
            'SELECT * FROM hist.hwi_links WHERE from_post=? OR to_post=? ORDER BY link_id',
            (post_id,post_id))]

    def plan_reorganization(self, kind: str, source_ids: list[str], target_titles: list[str]) -> dict:
        """Pure split/merge proposal. Does not write or confer authority."""
        _require(kind, {'split', 'merge'}, 'reorganization type')
        if not isinstance(source_ids, list) or any(not isinstance(x,str) for x in source_ids) or len(source_ids) != len(set(source_ids)):
            raise CatalogError('Unique knowledge source IDs required')
        if not isinstance(target_titles, list) or any(not isinstance(x,str) for x in target_titles) or len(target_titles) != len(set(target_titles)):
            raise CatalogError('Unique target titles required')
        if kind == 'split' and (len(source_ids) != 1 or len(target_titles) < 2):
            raise CatalogError('Split needs one source and at least two targets')
        if kind == 'merge' and (len(source_ids) < 2 or len(target_titles) != 1):
            raise CatalogError('Merge needs two sources and one target')
        sources = [self.resolve(pid) for pid in source_ids]
        if any(s['deleted'] for s in sources):
            raise CatalogError('Cannot reorganize a deleted source')
        for title in target_titles:
            if not isinstance(title,str) or not title.strip() or self.by_title(title):
                raise CatalogError('Empty or already occupied target title')
        document = {'kind':kind, 'sources':[
            {'knowledge_id':s['knowledge_id'], 'expected_event_id':s['latest_event_id'],
             'sha256':s['current_sha256']} for s in sources],
            'target_titles':target_titles, 'write_permitted':False,
            'authorization':None}
        digest = hashlib.sha256(json.dumps(document, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        return {**document, 'plan_sha256': digest}

    def verify(self) -> dict:
        """Check metadata vs history, not authentic human identity or truth."""
        self._require_enabled()
        problems = []
        for row in self.conn.execute('SELECT * FROM hist.hwi_origins'):
            try:
                event = self._event(row['post_id'], row['event_id'])
                if event['after_sha256'] != row['event_sha256']:
                    problems.append(f"Origin {row['post_id']}:{row['event_id']} digest mismatch")
            except CatalogError:
                problems.append('Origin with broken event association')
        for row in self.conn.execute('SELECT * FROM hist.hwi_links'):
            for side in ('from','to'):
                try:
                    event = self._event(row[side+'_post'], row[side+'_event'])
                    expected = event['after_sha256'] or event['before_sha256']
                    if expected != row[side+'_sha256']:
                        problems.append(f"Link {row['link_id']} {side} digest mismatch")
                except CatalogError:
                    problems.append(f"Link {row['link_id']} {side} event mismatch")
        return {'verified': not problems, 'problems': problems,
                'origins': self.conn.execute('SELECT COUNT(*) FROM hist.hwi_origins').fetchone()[0],
                'links': self.conn.execute('SELECT COUNT(*) FROM hist.hwi_links').fetchone()[0],
                'proves_human_identity': False, 'authorizes_actions': False}
