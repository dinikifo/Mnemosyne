"""Reusable Qt-free PERSONAL.WIKI core.

Import ``WikiCore`` from ``personal_wiki_core.wiki_core`` or directly
from ``personal_wiki_core`` when installed with this distribution.
The original ``app/`` entrypoints remain compatible with flat imports.
"""
from .wiki_core import WikiCore, ContractAcknowledgementRequired, SchemaError
from .workspace import NotebookWorkspace, WorkspaceError

__all__ = ("WikiCore", "ContractAcknowledgementRequired", "SchemaError", "NotebookWorkspace", "WorkspaceError", "KnowledgeCatalog", "CatalogError", "StaleKnowledgeRevision")

from .knowledge_identity import KnowledgeCatalog, CatalogError, StaleKnowledgeRevision
