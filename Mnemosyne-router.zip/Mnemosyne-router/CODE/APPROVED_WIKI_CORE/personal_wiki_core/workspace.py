"""HWI-03 opt-in named notebook sandbox; not a change to the desktop UI.

This is a path-resolution boundary, not an OS user sandbox. The workspace
must be owned by its operator; another process running as that same user can
still race a SQLite filename and requires OS isolation for stronger guarantees.
"""
from __future__ import annotations

import os
from pathlib import Path
import re
import stat

if __package__:
    from .wiki_core import WikiCore
else:  # Standalone source-tree compatibility, like other core modules.
    from wiki_core import WikiCore

_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")


class WorkspaceError(RuntimeError):
    """A workspace path or notebook identity cannot be trusted."""


def _name(value: str) -> str:
    if not isinstance(value, str) or _NAME.fullmatch(value) is None:
        raise WorkspaceError("Names must be 1–64 ASCII letters, digits, _ or -, starting with a letter")
    return value


def _verify_directory(path: Path) -> None:
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise WorkspaceError("Symlinked workspace path is forbidden")
    if not path.is_dir():
        raise WorkspaceError("Workspace directory does not exist")
    if os.name == 'posix' and (path.stat().st_mode & 0o077):
        raise WorkspaceError("Workspace directory must be private (permissions 0700)")


def _verify_file(path: Path) -> None:
    if path.is_symlink():
        raise WorkspaceError(f"Symlinked notebook or backup file is forbidden: {path.name}")
    try:
        info = path.stat(follow_symlinks=False)
    except FileNotFoundError:
        return
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise WorkspaceError(f"Unexpected notebook or backup file: {path.name}")


class NotebookWorkspace:
    """Resolve *names*, never caller-provided paths, under a private root.

    - content/history stay together in `notebooks/`
    - exported and restored bundles come only from `backups/`
    - no delete/recursive cleanup operation is exposed
    """

    def __init__(self, root: str | Path, *, create: bool = False):
        self.root = Path(os.path.abspath(root))
        for part in (self.root, *self.root.parents):
            if part.is_symlink():
                raise WorkspaceError("Symlinked workspace path is forbidden")
        if create:
            self.root.mkdir(mode=0o700, parents=False, exist_ok=True)
        _verify_directory(self.root)
        self.notebooks = self.root / "notebooks"
        self.backups = self.root / "backups"
        for folder in (self.notebooks, self.backups):
            if create:
                folder.mkdir(mode=0o700, exist_ok=True)
            _verify_directory(folder)

    def _assert_unchanged(self) -> None:
        for directory in (self.root, self.notebooks, self.backups):
            _verify_directory(directory)

    def notebook_path(self, name: str) -> Path:
        """Resolve a valid name to a path (never an arbitrary filename)."""
        self._assert_unchanged()
        path = self.notebooks / (_name(name) + '.db')
        history = WikiCore.history_file(path)
        for candidate in (path, history):
            # SQLite may use transient journal files beside either database.
            for suffix in ('', '-journal', '-wal', '-shm'):
                _verify_file(Path(str(candidate) + suffix))
        return path

    def bundle_path(self, name: str) -> Path:
        self._assert_unchanged()
        path = self.backups / (_name(name) + '.pwbundle')
        _verify_file(path)
        return path

    def create_notebook(self, name: str) -> Path:
        path = self.notebook_path(name)
        WikiCore.create_database(path)
        return path

    def open_notebook(self, name: str, *, readonly: bool = True) -> WikiCore:
        path = self.notebook_path(name)
        if not path.is_file() or not WikiCore.has_history(path):
            raise WorkspaceError("Notebook content/history pair is incomplete")
        return WikiCore(path, readonly=readonly)

    def export_backup(self, notebook_name: str, bundle_name: str) -> dict:
        source = self.notebook_path(notebook_name)
        backup = self.bundle_path(bundle_name)
        if backup.exists():
            raise WorkspaceError("Existing backup cannot be overwritten")
        with self.open_notebook(notebook_name, readonly=False) as wiki:
            return wiki.export_bundle(backup)

    def restore_backup(self, bundle_name: str, new_notebook_name: str) -> dict:
        backup = self.bundle_path(bundle_name)
        destination = self.notebook_path(new_notebook_name)
        if not backup.is_file():
            raise WorkspaceError("Backup does not exist")
        if destination.exists() or WikiCore.history_file(destination).exists():
            raise WorkspaceError("Existing notebook cannot be overwritten")
        return WikiCore.restore_bundle(backup, destination)
