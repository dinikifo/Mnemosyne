"""C6 operator-provisioned C5 evidence guard for the existing M5 prompt provider.

This is a read-only cross-store check, not a provider, permission or approval.
The trust boundary is the externally provisioned selector, evidence bundle and
operator pins; model text and notebook content cannot construct this safely.
"""
from __future__ import annotations
import hashlib


def _snapshot_operator_inputs(value):
    """Copy nested builtin containers without cloning trusted service objects.

    PVS workspace, journal and ledger objects must retain their identities for
    C5's exact-instance checks; dict/list containers must not alias an operator's
    mutable configuration after a successful preflight.
    """
    if type(value) is dict:
        return {key: _snapshot_operator_inputs(item) for key, item in value.items()}
    if type(value) is list:
        return [_snapshot_operator_inputs(item) for item in value]
    if type(value) is tuple:
        return tuple(_snapshot_operator_inputs(item) for item in value)
    return value


class HwiRuntimeGuardError(ValueError):
    """An HWI cross-store memory binding could not be reverified."""


class HwiProtectedSelectionGuard:
    """Bind a C5 inspection to exactly one independently pinned M5 selector."""

    def __init__(self, *, selector, selection_kwargs: dict):
        from research_memory.pvs_memory_selector import GovernedMemorySelector
        if type(selector) is not GovernedMemorySelector or selector.credential_registry is None:
            raise HwiRuntimeGuardError('Exact credential-enforced M5 selector required')
        if type(selection_kwargs) is not dict or 'selector' in selection_kwargs:
            raise HwiRuntimeGuardError('Invalid independently provisioned C5 context')
        # Inputs belong to the trusted provisioning caller, never a prompt.
        self.selector = selector
        self._kwargs = _snapshot_operator_inputs(selection_kwargs)

    @staticmethod
    def _match(selection: dict, report: dict) -> bool:
        if selection.get('status') == 'NO_APPROVED_MEMORY':
            return (report.get('status') == 'NO_APPROVED_MEMORY'
                    and report.get('pvs_approved_for_memory') is False
                    and report.get('llm_prompt_attached') is False
                    and report.get('execution_authorized') is False)
        if selection.get('status') != 'SIGNED_CREDENTIAL_REVIEW_CURRENT':
            return False
        text = selection.get('memory_text')
        return (type(text) is str and report.get('status') == 'CURRENT_PVS_APPROVAL_MATCHED'
                and report.get('pvs_approved_for_memory') is True
                and report.get('llm_prompt_attached') is False
                and report.get('execution_authorized') is False
                and report.get('memory_text_sha256') == hashlib.sha256(text.encode('utf-8')).hexdigest()
                and report.get('pvs_review_fingerprint') == selection.get('memory_review_fingerprint')
                and selection.get('credential_revocation_enforced') is True)

    def verify(self, selection: dict) -> dict:
        """Recheck C5 and M5 without caching a memory grant across calls."""
        try:
            from hwi.pvs_review_gate import inspect_independent_pvs_selection
            report = inspect_independent_pvs_selection(
                selector=self.selector, **_snapshot_operator_inputs(self._kwargs))
            if not self._match(selection, report):
                raise HwiRuntimeGuardError('C5 result disagrees with M5 memory selection')
            # Re-select after cross-store inspection; these are not one atomic
            # transaction, but a changed pinned head must prevent prompt use.
            final = self.selector.select()
            if final != selection:
                raise HwiRuntimeGuardError('M5 selection changed during C5 guard')
            return report
        except HwiRuntimeGuardError:
            raise
        except Exception as exc:
            raise HwiRuntimeGuardError('C5 cross-store evidence check failed') from exc
