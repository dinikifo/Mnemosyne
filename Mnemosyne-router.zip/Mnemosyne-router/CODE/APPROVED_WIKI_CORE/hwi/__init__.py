"""Opt-in HWI integration adapters. No LLM registration or write tools."""
from .knowledge_broker import (ReadOnlyKnowledgeBroker, BrokerError,
    StaleKnowledgeReference, NotebookScopeError)
__all__ = ("ReadOnlyKnowledgeBroker", "BrokerError", "StaleKnowledgeReference", "NotebookScopeError")

from .proposals import KnowledgeProposalLedger, ProposalError, DuplicateProposal, ProposalLedgerError
__all__ += ("KnowledgeProposalLedger", "ProposalError", "DuplicateProposal", "ProposalLedgerError")

from .reviewed_writes import (review_message, apply_signed_review, ReviewWriteError,
                              StaleReview, AlreadyApplied)
__all__ += ('review_message', 'apply_signed_review', 'ReviewWriteError',
            'StaleReview', 'AlreadyApplied')

from .recovery_inspection import inspect_application, read_retained_review_evidence, RecoveryInspectionError
__all__ += ('inspect_application', 'read_retained_review_evidence', 'RecoveryInspectionError')

from .pvs_handoff import (prepare_pvs_candidate, select_protected_wiki_memory,
                          signed_review_artifact, PvsHandoffError)
__all__ += ('prepare_pvs_candidate', 'select_protected_wiki_memory',
            'signed_review_artifact', 'PvsHandoffError')

from .symbolic_rules import infer, infer_from_broker, SymbolicRuleError
__all__ += ('infer', 'infer_from_broker', 'SymbolicRuleError')

from .procedures import assess_procedure, assess_procedure_from_broker, ProcedureError
__all__ += ('assess_procedure', 'assess_procedure_from_broker', 'ProcedureError')

from .defect_dataset import (assess_defect, plan_dataset, release_review_message,
                             export_reviewed_dataset, DefectDatasetError)
__all__ += ('assess_defect', 'plan_dataset', 'release_review_message',
            'export_reviewed_dataset', 'DefectDatasetError')

from .journal_grounding import (prepare_journal_grounded_candidate, verify_unreviewed_pvs_draft, JournalGroundingError)
__all__ += ('prepare_journal_grounded_candidate', 'verify_unreviewed_pvs_draft', 'JournalGroundingError')

from .semantic_review import (prepare_semantic_review_packet, semantic_review_message,
                              verify_signed_semantic_review, SemanticReviewError)
__all__ += ('prepare_semantic_review_packet', 'semantic_review_message',
            'verify_signed_semantic_review', 'SemanticReviewError')

from .pvs_admission import (prepare_admission_plan, admission_operator_message,
                            submit_signed_unreviewed_admission, AdmissionError,
                            AdmissionCommitUncertain)
__all__ += ('prepare_admission_plan', 'admission_operator_message',
            'submit_signed_unreviewed_admission', 'AdmissionError',
            'AdmissionCommitUncertain')

from .pvs_review_gate import (prepare_independent_pvs_review,
                              inspect_independent_pvs_selection, PvsReviewGateError)
__all__ += ('prepare_independent_pvs_review', 'inspect_independent_pvs_selection',
            'PvsReviewGateError')

from .provenance_gate import (build_lineage_manifest, audit_admission_lineage,
    provenance_operator_message, verify_signed_admission_lineage, ProvenanceGateError)
__all__ += ('build_lineage_manifest', 'audit_admission_lineage',
    'provenance_operator_message', 'verify_signed_admission_lineage',
    'ProvenanceGateError')
