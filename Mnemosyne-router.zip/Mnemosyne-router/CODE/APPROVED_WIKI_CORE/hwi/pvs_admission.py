"""C4: explicit, independently signed operator admission to UNREVIEWED PVS storage.

Semantic opinions are *not* authorization. This module only prepares and, after a
separate signed operator instruction, submits an existing valid M1 memory draft
through the original M3 PVS writer. No PVS review, prompt eligibility, or tool
execution authority is produced. Unknown commit outcomes require manual recovery.
"""
from __future__ import annotations

import hashlib
import json
import re
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .proposals import _canon
from .journal_grounding import (prepare_journal_grounded_candidate,
                                verify_unreviewed_pvs_draft)
from .semantic_review import (prepare_semantic_review_packet,
                              verify_signed_semantic_review)

_SHA = re.compile(r'^[0-9a-f]{64}$')
_PLAN_SCHEMA = 'hwi.pvs.admission.plan.v1'
_DOMAIN = b'HWI-C4-STORE-UNREVIEWED-PVS-DRAFT-V1\n'
_CONFIRMATION = 'STORE_EXACT_UNREVIEWED_DRAFT_ONLY'
_PVS_KEYS = frozenset({'workspace','journal','actor','versioner_id',
    'source_target_id','source_project_id','proposal_target_id',
    'proposal_project_id','expected_source_head','expected_versioner_pin',
    'expected_source_target_pin','expected_proposal_target_pin'})


class AdmissionError(ValueError):
    """Reject stale, unapproved, malformed or inconsistent admission evidence."""


class AdmissionCommitUncertain(AdmissionError):
    """PVS may have written; reconcile; never automatically retry."""


def _hash(body):
    return hashlib.sha256(_canon(body).encode('utf-8')).hexdigest()


def _sha(value):
    if type(value) is not str or not _SHA.fullmatch(value):
        raise AdmissionError('Exact lowercase SHA-256 required')
    return value


def _preflight(*, source_kwargs, expected_witness_sha256, packet, decision,
               semantic_signature_hex, semantic_reviewer_public_key,
               expected_semantic_reviewer_key_sha256, expected_packet_sha256,
               pvs_context, draft):
    # Do not broaden the PVS writer's argument vocabulary or allow callers to
    # swap the journal/source identity between witness and proposal target.
    if type(source_kwargs) is not dict or type(pvs_context) is not dict or set(pvs_context) != _PVS_KEYS:
        raise AdmissionError('Exact source and PVS proposal context required')
    if (pvs_context['workspace'] is not source_kwargs.get('pvs_workspace')
            or pvs_context['journal'] is not source_kwargs.get('journal')
            or pvs_context['actor'] != source_kwargs.get('source_actor')
            or pvs_context['versioner_id'] != source_kwargs.get('source_versioner_id')
            or pvs_context['source_target_id'] != source_kwargs.get('source_target_id')
            or pvs_context['source_project_id'] != source_kwargs.get('source_project_id')
            or pvs_context['expected_source_head'] != source_kwargs.get('expected_source_head')
            or pvs_context['expected_versioner_pin'] != source_kwargs.get('expected_source_versioner_pin')
            or pvs_context['expected_source_target_pin'] != source_kwargs.get('expected_source_target_pin')):
        raise AdmissionError('PVS proposal target does not match the witnessed source history')
    _sha(expected_witness_sha256)
    _sha(expected_packet_sha256)
    _sha(expected_semantic_reviewer_key_sha256)
    # Verify the exact signed semantic review, *then* independently refresh the
    # source packet. A signature only authenticates an opinion on an old packet.
    opinion = verify_signed_semantic_review(packet, decision,
        signature_hex=semantic_signature_hex,
        reviewer_public_key=semantic_reviewer_public_key,
        expected_reviewer_key_sha256=expected_semantic_reviewer_key_sha256,
        expected_packet_sha256=expected_packet_sha256,
        expected_witness_sha256=expected_witness_sha256)
    if opinion['reviewer_asserted_verdict'] != 'SUPPORTED':
        raise AdmissionError('Semantic reviewer did not support the candidate')
    current_packet = prepare_semantic_review_packet(
        source_kwargs=source_kwargs,
        expected_witness_sha256=expected_witness_sha256)
    if current_packet != packet:
        raise AdmissionError('Semantic packet or source is stale or substituted')
    witness = prepare_journal_grounded_candidate(**source_kwargs)
    if witness['witness_sha256'] != expected_witness_sha256:
        raise AdmissionError('Fresh journal-grounding witness changed')
    binding = verify_unreviewed_pvs_draft(witness, draft,
        journal=pvs_context['journal'],
        expected_source_head=pvs_context['expected_source_head'],
        expected_witness_sha256=expected_witness_sha256)
    if binding['draft_sha256'] != draft['content_sha256']:
        raise AdmissionError('PVS draft integrity mismatch')
    # The original PVS implementation is optional to the wiki package.
    from research_memory.pvs_memory_proposals import verify_proposals
    snapshot = verify_proposals(**pvs_context)
    previous = snapshot['latest_draft']
    if draft['identity']['revision'] != snapshot['proposal_count'] + 1:
        raise AdmissionError('PVS draft is not the next revision')
    if (previous is None and draft['parent_revision_sha256'] is not None) or (
            previous is not None and draft['parent_revision_sha256'] != previous['content_sha256']):
        raise AdmissionError('PVS proposal parent lineage mismatch')
    if packet['wiki']['memory_text_sha256'] != witness['wiki']['memory_text_sha256']:
        raise AdmissionError('Wiki review does not match selected PVS text')
    return opinion, binding, snapshot


def prepare_admission_plan(*, source_kwargs: dict, expected_witness_sha256: str,
                           packet: dict, decision: dict,
                           semantic_signature_hex: str,
                           semantic_reviewer_public_key: bytes,
                           expected_semantic_reviewer_key_sha256: str,
                           expected_packet_sha256: str,
                           pvs_context: dict, draft: dict) -> dict:
    """Read-only, signed-opinion-aware PVS preflight; never grants write rights."""
    try:
        opinion, binding, snapshot = _preflight(
            source_kwargs=source_kwargs, expected_witness_sha256=expected_witness_sha256,
            packet=packet, decision=decision,
            semantic_signature_hex=semantic_signature_hex,
            semantic_reviewer_public_key=semantic_reviewer_public_key,
            expected_semantic_reviewer_key_sha256=expected_semantic_reviewer_key_sha256,
            expected_packet_sha256=expected_packet_sha256,
            pvs_context=pvs_context, draft=draft)
        body = {
            'schema': _PLAN_SCHEMA,
            'status': 'VERIFIED_PREFLIGHT_NOT_AUTHORIZED',
            'operation': _CONFIRMATION,
            'witness_sha256': expected_witness_sha256,
            'packet_sha256': expected_packet_sha256,
            'semantic_opinion_sha256': _hash(opinion),
            'semantic_reviewer_key_sha256': expected_semantic_reviewer_key_sha256,
            'draft_sha256': draft['content_sha256'],
            'candidate_text_sha256': packet['wiki']['memory_text_sha256'],
            'pvs_source_head_sha256': pvs_context['expected_source_head'],
            'pvs_agent_id': pvs_context['journal'].agent_id,
            'pvs_actor': pvs_context['actor'],
            'pvs_versioner_id': pvs_context['versioner_id'],
            'pvs_source_project_id': pvs_context['source_project_id'],
            'pvs_source_target_id': pvs_context['source_target_id'],
            'pvs_proposal_target_id': pvs_context['proposal_target_id'],
            'pvs_proposal_project_id': pvs_context['proposal_project_id'],
            'pvs_pins_sha256': _hash({name:pvs_context[name] for name in (
                'expected_versioner_pin','expected_source_target_pin',
                'expected_proposal_target_pin')}),
            'pvs_proposal_count_before': snapshot['proposal_count'],
            'write_authorized': False,
            'pvs_approved': False,
            'prompt_eligible': False,
            'execution_authorized': False,
            'human_identity_established': False,
            'cross_store_atomicity_established': False,
        }
        return {**body, 'plan_sha256': _hash(body)}
    except AdmissionError:
        raise
    except Exception as exc:
        raise AdmissionError('PVS admission preflight rejected missing or stale evidence') from exc


def admission_operator_message(plan: dict, *, expected_plan_sha256: str) -> bytes:
    """Exact domain-separated instruction for a distinct operator signing key."""
    _sha(expected_plan_sha256)
    if type(plan) is not dict or set(plan) != {
            'schema','status','operation','witness_sha256','packet_sha256',
            'semantic_opinion_sha256','semantic_reviewer_key_sha256','draft_sha256',
            'candidate_text_sha256','pvs_source_head_sha256','pvs_agent_id',
            'pvs_actor','pvs_versioner_id','pvs_source_project_id',
            'pvs_source_target_id','pvs_proposal_target_id','pvs_proposal_project_id',
            'pvs_pins_sha256','pvs_proposal_count_before','write_authorized',
            'pvs_approved','prompt_eligible','execution_authorized',
            'human_identity_established','cross_store_atomicity_established',
            'plan_sha256'}:
        raise AdmissionError('Unexpected admission plan schema')
    for name in ('witness_sha256','packet_sha256','semantic_opinion_sha256',
                 'semantic_reviewer_key_sha256','draft_sha256',
                 'candidate_text_sha256','pvs_source_head_sha256',
                 'pvs_pins_sha256'):
        _sha(plan[name])
    if (type(plan['pvs_proposal_count_before']) is not int
            or plan['pvs_proposal_count_before'] < 0):
        raise AdmissionError('Invalid PVS prior proposal count')
    if (plan['schema'] != _PLAN_SCHEMA
            or plan['status'] != 'VERIFIED_PREFLIGHT_NOT_AUTHORIZED'
            or plan['operation'] != _CONFIRMATION
            or plan['plan_sha256'] != expected_plan_sha256
            or _hash({k:v for k,v in plan.items() if k!='plan_sha256'}) != expected_plan_sha256
            or any(plan[k] is not False for k in (
                'write_authorized','pvs_approved','prompt_eligible',
                'execution_authorized','human_identity_established',
                'cross_store_atomicity_established'))):
        raise AdmissionError('Admission plan claims authority or fails digest check')
    return _DOMAIN + _canon(plan).encode('utf-8')


def submit_signed_unreviewed_admission(*, plan: dict, expected_plan_sha256: str,
                                       operator_signature_hex: str,
                                       operator_public_key: bytes,
                                       expected_operator_key_sha256: str,
                                       source_kwargs: dict, expected_witness_sha256: str,
                                       packet: dict, decision: dict,
                                       semantic_signature_hex: str,
                                       semantic_reviewer_public_key: bytes,
                                       expected_semantic_reviewer_key_sha256: str,
                                       expected_packet_sha256: str,
                                       pvs_context: dict, draft: dict,
                                       provenance_manifest: dict,
                                       expected_provenance_sha256: str,
                                       provenance_signature_hex: str,
                                       externally_pinned_origins: dict) -> dict:
    """One explicit PVS storage-only request. COMMIT_UNCERTAIN prohibits retry."""
    _sha(expected_operator_key_sha256)
    if (type(operator_public_key) is not bytes or len(operator_public_key) != 32
            or hashlib.sha256(operator_public_key).hexdigest() != expected_operator_key_sha256
            or expected_operator_key_sha256 == expected_semantic_reviewer_key_sha256):
        raise AdmissionError('Separate externally pinned operator signing key required')
    if type(operator_signature_hex) is not str or len(operator_signature_hex) != 128:
        raise AdmissionError('Operator Ed25519 signature required')
    # All caller-owned signed documents are snapshotted before they are used.
    # In particular, PVS must store the SAME draft that matched the signed
    # plan; a later caller mutation must not change a receipt or write payload.
    try:
        frozen_plan = json.loads(_canon(plan))
        frozen_packet = json.loads(_canon(packet))
        frozen_decision = json.loads(_canon(decision))
        frozen_draft = json.loads(_canon(draft))
        frozen_manifest = json.loads(_canon(provenance_manifest))
        frozen_origins = json.loads(_canon(externally_pinned_origins))
    except (TypeError, ValueError) as exc:
        raise AdmissionError('Canonical signed-admission snapshots required') from exc
    msg = admission_operator_message(frozen_plan, expected_plan_sha256=expected_plan_sha256)
    try:
        Ed25519PublicKey.from_public_bytes(operator_public_key).verify(
            bytes.fromhex(operator_signature_hex), msg)
    except (InvalidSignature, ValueError) as exc:
        raise AdmissionError('Operator signature missing, malformed or invalid') from exc
    # C13 adds a NEW domain-separated operator signature; C4's signed bytes
    # remain unchanged. Missing provenance fails before any PVS write. Older
    # C4-only clients MUST migrate rather than silently bypass the lineage gate.
    from .provenance_gate import verify_signed_admission_lineage, ProvenanceGateError
    # C13 verification and the returned C14 receipt use the same snapshots.
    try:
        witness = prepare_journal_grounded_candidate(**source_kwargs)
        # C2 validates journal references but permits additional signed wiki
        # references. Those could point to derived wiki material and bypass the
        # declared lineage; C13 conservatively rejects them until an
        # independently verified versioned ancestry format covers them too.
        signed_refs = source_kwargs['ledger'].get(source_kwargs['proposal_id'])['record']['source_refs']
        exact_journal_refs = [
            f'journal:{witness["journal"]["agent_id"]}:{row["seq"]:012d}:{row["entry_sha256"]}'
            for row in witness['journal']['selected_source_refs']]
        if (type(signed_refs) is not list or len(signed_refs) != len(exact_journal_refs)
                or sorted(signed_refs) != sorted(exact_journal_refs)):
            raise AdmissionError('Unresolved non-journal signed source ancestry')
        verify_signed_admission_lineage(
            manifest=frozen_manifest,
            expected_lineage_sha256=expected_provenance_sha256,
            plan=frozen_plan, witness=witness,
            externally_pinned_origins=frozen_origins,
            signature_hex=provenance_signature_hex,
            operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256)
    except Exception as exc:
        raise AdmissionError('C13 signed source-lineage verification required') from exc
    fresh = prepare_admission_plan(
        source_kwargs=source_kwargs, expected_witness_sha256=expected_witness_sha256,
        packet=frozen_packet, decision=frozen_decision,
        semantic_signature_hex=semantic_signature_hex,
        semantic_reviewer_public_key=semantic_reviewer_public_key,
        expected_semantic_reviewer_key_sha256=expected_semantic_reviewer_key_sha256,
        expected_packet_sha256=expected_packet_sha256,
        pvs_context=pvs_context, draft=frozen_draft)
    if fresh != frozen_plan:
        raise AdmissionError('Signed operator plan is stale or has changed')
    # The original M3 writer checks source/proposal PVS pins again before the
    # write and performs its own post-commit verification. Failure after call
    # entry is uncertain: do not assume rollback or automatically retry.
    from research_memory.pvs_memory_proposals import submit_proposal
    try:
        stored = submit_proposal(**pvs_context, draft=frozen_draft)
        after = prepare_semantic_review_packet(
            source_kwargs=source_kwargs,
            expected_witness_sha256=expected_witness_sha256)
        if after != frozen_packet:
            raise RuntimeError('Source or wiki moved across PVS admission')
        if (stored['proposal_count'] != frozen_plan['pvs_proposal_count_before'] + 1
                or stored['proposal_sha256'][-1] is None
                or stored['prompt_eligible'] is not False
                or stored['human_approved'] is not False):
            raise RuntimeError('Unexpected PVS proposal postcondition')
        # C14: retain the independently signed C13 lineage with the storage
        # receipt. This does not establish external custody: callers must still
        # independently pin the receipt and the external-origin map. A v1 C4
        # receipt cannot authenticate C13 lineage and must not be promoted.
        lineage_origins_sha256 = _hash(frozen_origins)
        receipt_body = {
            'schema':'hwi.pvs.admission.receipt.v2',
            'status':'STORED_UNREVIEWED_NO_MEMORY_APPROVAL',
            'plan_sha256': expected_plan_sha256,
            'operator_key_sha256': expected_operator_key_sha256,
            'operator_signature_hex': operator_signature_hex,
            'draft_sha256': frozen_draft['content_sha256'],
            'pvs_proposal_target_id': pvs_context['proposal_target_id'],
            'pvs_proposal_count': stored['proposal_count'],
            'pvs_proposal_target_pin': stored['proposal_target_pin'],
            'source_witness_sha256': expected_witness_sha256,
            'lineage_manifest': frozen_manifest,
            'lineage_signature_hex': provenance_signature_hex,
            'lineage_origins_sha256': lineage_origins_sha256,
            'pvs_approved': False, 'prompt_eligible': False,
            'execution_authorized': False,
            'receipt_stored_in_pvs': False,
            'external_custody_established': False,
        }
        return {**receipt_body,'receipt_sha256':_hash(receipt_body)}
    except Exception as exc:
        raise AdmissionCommitUncertain(
            'COMMIT_UNCERTAIN: inspect exact PVS proposal history and retain the '
            'signed command; no automatic retry or inferred memory approval') from exc
