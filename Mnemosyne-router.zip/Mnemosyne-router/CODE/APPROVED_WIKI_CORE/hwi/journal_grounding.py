"""C2: read-only, journal-grounded wiki candidate witnesses for operator review.

This bridges *two* provenance chains. It neither proves semantic alignment nor
constructs/commits PVS memory proposals. PVS and the agent remain separate.
Source journal events are captured actions, NOT verified real-world observations.
"""
from __future__ import annotations

import hashlib
import json
import re

from .proposals import _canon
from .pvs_handoff import prepare_pvs_candidate

_SHA = re.compile(r"^[a-f0-9]{64}$")
_FIELDS = frozenset(("summary", "result.status", "result.reason",
                     "result.outputs", "result.feedback"))
_MAX_REFS = 12
_MAX_WITNESS_BYTES = 24576


class JournalGroundingError(RuntimeError):
    """Independently required provenance or local consistency was not established."""


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value).encode("utf-8")).hexdigest()


def _refs(journal, events, declarations, anchors):
    if type(anchors) is not list or not 1 <= len(anchors) <= _MAX_REFS:
        raise ValueError('1 to 12 explicit journal source anchors are required')
    if type(declarations) is not list or not all(type(r) is str for r in declarations):
        raise ValueError('Malformed immutable proposal source references')
    claimed_journal = {r for r in declarations if r.startswith('journal:')}
    if len(claimed_journal) != sum(r.startswith('journal:') for r in declarations):
        raise ValueError('Duplicate declared journal references')
    verified = []
    names = set()
    for row in anchors:
        if type(row) is not dict or set(row) != {
                'seq', 'entry_sha256', 'episode_sha256', 'field', 'value_sha256'}:
            raise ValueError('Source anchor has unexpected fields')
        seq = row['seq']
        if type(seq) is not int or not 1 <= seq <= len(events):
            raise ValueError('Source sequence out of bounds')
        event = events[seq - 1]
        if (row['entry_sha256'] != event.entry_sha256
                or row['episode_sha256'] != event.episode_sha256):
            raise ValueError('Source entry or episode digest mismatch')
        field = row['field']
        if type(field) is not str or field not in _FIELDS:
            raise ValueError('Source field is unsupported')
        # One selected source field per independently referenced episode.
        # Multiple excerpts from one signed reference must be separately reviewed.
        ident = seq
        if ident in names:
            raise ValueError('Repeated source anchor')
        names.add(ident)
        ep = event.episode
        if field == 'summary':
            value = ep.summary
        else:
            value = getattr(ep.result, field.split('.')[1])
            if field == 'result.status':
                value = value.value  # enum value in the actual captured episode
        if value is None or value == '' or value == {} or value == []:
            raise ValueError('Selected source excerpt is empty')
        if _digest(value) != row['value_sha256']:
            raise ValueError('Source-field value digest mismatch')
        verified.append(dict(row))
    expected = {f'journal:{journal.agent_id}:{r["seq"]:012d}:{r["entry_sha256"]}'
                for r in verified}
    # The source bindings must be present in the *original signed wiki proposal*.
    # Attaching unrelated entries after a signature would launder evidence.
    if claimed_journal != expected:
        raise ValueError('Journal sources differ from immutable signed wiki proposal')
    return sorted(verified, key=lambda r:(r['seq'], r['field']))


def _history(*, journal, expected_source_head, pvs_workspace, source_actor,
             source_versioner_id, source_target_id, source_project_id,
             expected_source_versioner_pin, expected_source_target_pin):
    # Import the original, unmodified PVS module lazily: the independently
    # installed wiki package must work without the optional agent backend.
    from autogpt_lite.persistence.episode_journal import EpisodeJournal
    from research_memory.pvs_journal_bridge import verify_history
    if type(journal) is not EpisodeJournal:
        raise ValueError('Original EpisodeJournal type required')
    if type(expected_source_head) is not str or not _SHA.fullmatch(expected_source_head):
        raise ValueError('Independently retained journal head required')
    report = verify_history(
        workspace=pvs_workspace, journal=journal,
        actor=source_actor, versioner_id=source_versioner_id,
        target_id=source_target_id, project_id=source_project_id,
        expected_source_head=expected_source_head,
        expected_versioner_pin=expected_source_versioner_pin,
        expected_target_pin=expected_source_target_pin)
    if report['status'] != 'HISTORY_VERIFIED_NO_MEMORY_APPROVAL' or report['source_current'] is not True:
        raise ValueError('Current independently pinned PVS source history required')
    events = journal.replay(expected_head=expected_source_head)
    if not events or events[-1].entry_sha256 != expected_source_head:
        raise ValueError('Missing journal head')
    return report, events


def prepare_journal_grounded_candidate(*, workspace, notebook_name, ledger, proposal_id,
                                        review_signature_hex, reviewer_public_key,
                                        expected_review_artifact_sha256,
                                        journal, expected_agent_id, expected_source_head,
                                        anchors, pvs_workspace, source_actor,
                                        source_versioner_id, source_target_id,
                                        source_project_id, expected_source_versioner_pin,
                                        expected_source_target_pin) -> dict:
    """Read-only source witness; requires original signed wiki refs and PVS pins.

    A witness binds verified *bytes and identities* only. It makes no claim that
    a journal entry entails the wiki note, and never approves a PVS memory.
    """
    try:
        if type(expected_agent_id) is not str or journal.agent_id != expected_agent_id:
            raise ValueError('Expected agent identity differs from source journal')
        args = dict(journal=journal, expected_source_head=expected_source_head,
                    pvs_workspace=pvs_workspace, source_actor=source_actor,
                    source_versioner_id=source_versioner_id,
                    source_target_id=source_target_id, source_project_id=source_project_id,
                    expected_source_versioner_pin=expected_source_versioner_pin,
                    expected_source_target_pin=expected_source_target_pin)
        report, events = _history(**args)
        wiki_args = dict(workspace=workspace, notebook_name=notebook_name,
                         ledger=ledger, proposal_id=proposal_id,
                         review_signature_hex=review_signature_hex,
                         reviewer_public_key=reviewer_public_key,
                         expected_review_artifact_sha256=expected_review_artifact_sha256)
        wiki = prepare_pvs_candidate(**wiki_args)
        entry = ledger.get(proposal_id)
        sources = _refs(journal, events, entry['record']['source_refs'], anchors)
        witness_body = {
            'schema':'hwi.pvs.journal.grounding.v1',
            'status':'REFERENCES_VERIFIED_SEMANTIC_ALIGNMENT_UNPROVEN',
            'wiki':{'proposal_id':proposal_id,
                    'notebook_scope':wiki['notebook_scope'],
                    'revision_reference':wiki['source_reference'],
                    'revision_sha256':wiki['source_revision_sha256'],
                    'memory_text_sha256':wiki['memory_text_sha256'],
                    'review_evidence_sha256':wiki['review_evidence_sha256']},
            'journal':{'agent_id':journal.agent_id,
                       'head_sha256':expected_source_head,
                       'event_count':len(events),
                       'source_scope':events[0].source_scope,
                       'legacy_gap':events[0].source_scope == 'LEGACY_CHECKPOINT_GAP',
                       'selected_source_refs':sources},
            'pvs_source':{'versioner_id':source_versioner_id,
                          'target_id':source_target_id,
                          'project_id':source_project_id,
                          'versioner_pin':expected_source_versioner_pin,
                          'target_pin':expected_source_target_pin,
                          'history_revisions':report['pvs_revision_count'],
                          'current':True},
            'claims':{'source_bytes_verified':True,
                      'semantic_alignment_verified':False,
                      'pvs_proposal_submitted':False,
                      'pvs_approved':False,
                      'execution_authorized':False,
                      'human_identity_established':False,
                      'independent_custody_established':False}}
        if len(_canon(witness_body).encode('utf-8')) > _MAX_WITNESS_BYTES:
            raise ValueError('Source witness exceeds size bound')
        # Existing wiki and source may change while crossing three stores.
        # Reject any movement observed during re-verification, but make no
        # claim to a global cross-store atomic snapshot.
        new_report, new_events = _history(**args)
        if len(new_events) != len(events) or new_report != report:
            raise ValueError('Source moved during witness preparation')
        if prepare_pvs_candidate(**wiki_args) != wiki:
            raise ValueError('Wiki moved during witness preparation')
        return {**witness_body, 'witness_sha256':_digest(witness_body)}
    except Exception as exc:
        raise JournalGroundingError('Journal-grounded wiki source witness unavailable or stale') from exc


def verify_unreviewed_pvs_draft(witness: dict, draft: dict, *, journal,
                                expected_source_head: str,
                                expected_witness_sha256: str) -> dict:
    """Validate a PVS/AM04 draft's journal interval and exact wiki memory text.

    This requires a separately constructed AM04 draft. It cannot establish
    whether that text is actually supported by its journal source, and never
    writes to PVS or signs a review.
    """
    try:
        from research_memory.pvs_memory_contract import verify_memory_draft
        if type(witness) is not dict or set(witness) != {
                'schema','status','wiki','journal','pvs_source','claims','witness_sha256'}:
            raise ValueError('Unexpected witness fields')
        if (type(expected_witness_sha256) is not str
                or _SHA.fullmatch(expected_witness_sha256) is None
                or witness['witness_sha256'] != expected_witness_sha256):
            raise ValueError('Independently retained witness digest mismatch')
        if witness['witness_sha256'] != _digest({k:v for k,v in witness.items()
                                                if k != 'witness_sha256'}):
            raise ValueError('Witness digest mismatch')
        if (witness['schema'] != 'hwi.pvs.journal.grounding.v1'
                or witness['journal']['head_sha256'] != expected_source_head
                or witness['journal']['agent_id'] != journal.agent_id
                or witness['status'] != 'REFERENCES_VERIFIED_SEMANTIC_ALIGNMENT_UNPROVEN'
                or witness['claims'] != {'source_bytes_verified':True,
                      'semantic_alignment_verified':False,
                      'pvs_proposal_submitted':False,
                      'pvs_approved':False,
                      'execution_authorized':False,
                      'human_identity_established':False,
                      'independent_custody_established':False}):
            raise ValueError('Journal witness identity/authority mismatch')
        result = verify_memory_draft(draft, journal=journal, expected_head=expected_source_head)
        candidate = draft['candidate']
        text = candidate['candidate_text']
        if (result['status'] != 'VERIFIED_DRAFT_NOT_APPROVED'
                or hashlib.sha256(text.encode('utf-8')).hexdigest()
                   != witness['wiki']['memory_text_sha256']):
            raise ValueError('PVS draft text differs from pinned wiki candidate')
        low, high = candidate['source']['interval_inclusive']
        if any(not low <= entry['seq'] <= high
               for entry in witness['journal']['selected_source_refs']):
            raise ValueError('PVS draft source window omits bound source entries')
        return {'status':'PVS_DRAFT_SOURCE_AND_TEXT_BOUND_ALIGNMENT_UNPROVEN',
                'draft_sha256':draft['content_sha256'],
                'witness_sha256':witness['witness_sha256'],
                'pvs_approved':False, 'execution_authorized':False,
                'semantic_alignment_verified':False}
    except Exception as exc:
        raise JournalGroundingError('PVS draft does not match source witness') from exc
