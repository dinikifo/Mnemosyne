"""C12: bounded, read-only detection of circular support and stalled deliberation.

This checks the *shape of supplied claims*, never whether evidence is true,
independent, current, signed, or human-approved. It accepts no agent actions,
PVS approvals, SQL handles, or executable callback. A positive audit is not a
permission to continue, promote memory, or execute tools.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Mapping


class ReasoningCycleError(ValueError):
    """Reject malformed/ambiguous reasoning graphs and progress traces."""


_ATOM = re.compile(r"^[a-z][a-z0-9_.:-]{0,79}$")
_SHA = re.compile(r"^[0-9a-f]{64}$")
_REF = re.compile(r"^(?:journal|evidence|external|human|run|fixture):[A-Za-z0-9._:/-]{1,160}$")
_MAX_NODES = 128
_MAX_EDGES = 512
_MAX_STEPS = 32


def _name(value: Any) -> str:
    if type(value) is not str or _ATOM.fullmatch(value) is None:
        raise ReasoningCycleError('Expected bounded lowercase claim identifier')
    return value


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode('ascii')).hexdigest()


def detect_reachable_cycle(dependencies: Mapping[str, list[str]], goal: str) -> list[str]:
    """Return deterministic reachable cycle A->...->A, or empty list.

    All dependency identifiers must exist. Used also by HWI-11's symbolic engine.
    No recursive traversal: step/edge bounds and an explicit stack avoid overflow.
    """
    _name(goal)
    if type(dependencies) is not dict or len(dependencies) > _MAX_NODES or goal not in dependencies:
        raise ReasoningCycleError('Bounded graph must contain the goal')
    edges = 0
    for node, children in dependencies.items():
        _name(node)
        if type(children) is not list or len(children) > 16:
            raise ReasoningCycleError('Each claim needs bounded dependencies')
        for child in children:
            _name(child)
        if len(children) != len(set(children)):
            raise ReasoningCycleError('Duplicate dependency')
        edges += len(children)
        for child in children:
            if child not in dependencies:
                raise ReasoningCycleError('Unresolved dependency; cannot audit incomplete graph')
    if edges > _MAX_EDGES:
        raise ReasoningCycleError('Too many dependency edges')
    # Three-color DFS; the active path is the diagnostic witness.
    color: dict[str, int] = {}
    path: list[str] = []
    positions: dict[str, int] = {}
    frames: list[tuple[str, Any]] = [(goal, iter(sorted(dependencies[goal])))]
    color[goal] = 1
    positions[goal] = 0
    path.append(goal)
    while frames:
        node, children = frames[-1]
        child = next(children, None)
        if child is None:
            frames.pop()
            color[node] = 2
            positions.pop(node)
            path.pop()
            continue
        if color.get(child) == 1:
            return path[positions[child]:] + [child]
        if color.get(child) != 2:
            color[child] = 1
            positions[child] = len(path)
            path.append(child)
            frames.append((child, iter(sorted(dependencies[child]))))
    return []


def audit_support_graph(nodes: list[dict], *, goal: str) -> dict:
    """Audit self-support cycles in one bounded, caller-supplied proof graph.

    Observation nodes are *claims about sources*, not authenticated evidence.
    Acyclic with observations means only that the argument isn't self-supporting.
    """
    _name(goal)
    if type(nodes) is not list or not 1 <= len(nodes) <= _MAX_NODES:
        raise ReasoningCycleError('Expected 1–128 typed claim nodes')
    dependencies: dict[str, list[str]] = {}
    observations: dict[str, tuple[str, str]] = {}
    for item in nodes:
        if type(item) is not dict or item.get('kind') not in ('observation', 'inference'):
            raise ReasoningCycleError('Unknown claim node kind')
        name = _name(item.get('id'))
        if name in dependencies:
            raise ReasoningCycleError('Duplicate claim identity')
        if item['kind'] == 'observation':
            if set(item) != {'id', 'kind', 'source_ref', 'source_sha256'}:
                raise ReasoningCycleError('Observation requires a bounded source and digest')
            ref, sha = item['source_ref'], item['source_sha256']
            if type(ref) is not str or _REF.fullmatch(ref) is None or type(sha) is not str or _SHA.fullmatch(sha) is None:
                raise ReasoningCycleError('Malformed claimed observation pin')
            dependencies[name] = []
            observations[name] = (ref, sha)
        else:
            if set(item) != {'id', 'kind', 'depends_on'}:
                raise ReasoningCycleError('Inference requires explicit dependencies')
            children = item['depends_on']
            if type(children) is not list or not 1 <= len(children) <= 16:
                raise ReasoningCycleError('Inference must name 1–16 premises')
            dependencies[name] = children
    cycle = detect_reachable_cycle(dependencies, goal)
    # Collect all reachable source *claims* without treating them as proof.
    seen: set[str] = set()
    pending = [goal]
    while pending:
        node = pending.pop()
        if node in seen:
            continue
        seen.add(node)
        pending.extend(dependencies[node])
    sources = sorted({observations[n] for n in seen if n in observations})
    status = ('CIRCULAR_SUPPORT' if cycle else
              'NO_OBSERVATION_ANCHOR' if not sources else 'ACYCLIC_SOURCE_CLAIMS')
    body = {'schema': 'hwi.reasoning.graph.v1', 'goal': goal,
            'status': status, 'cycle_path': cycle,
            'reachable_claim_count': len(seen), 'claimed_observation_pins': [
                {'source_ref': ref, 'source_sha256': sha} for ref, sha in sources],
            'claimed_unique_observation_count': len(sources),
            'source_authenticity_verified': False,
            'independence_of_sources_verified': False,
            'confidence_increase_authorized': False,
            'human_authorized': False, 'pvs_approved': False,
            'execution_authorized': False}
    return {**body, 'audit_sha256': _digest(body)}


def audit_reasoning_trace(trace: list[dict], *, allowed_source_pins: list[str],
                          max_steps_without_new_source: int = 4) -> dict:
    """Bounded anti-stagnation diagnostic for a trusted journal's ordered trace.

    Every step has a claim ID and an *accumulated* list of SHA-256 source pins.
    Pins must belong to an explicit caller-held allowlist; no arbitrary new
    hash may reset the progress budget. The caller is responsible for verifying
    that the allowed pins correspond to real, externally observed evidence.
    A repeated claim with the same pins is a loop, regardless of intervening
    claims. Even an allowlisted new pin is not proof of independent evidence.
    """
    if type(max_steps_without_new_source) is not int or not 2 <= max_steps_without_new_source <= 16:
        raise ReasoningCycleError('Invalid no-progress budget')
    if type(trace) is not list or not 1 <= len(trace) <= _MAX_STEPS:
        raise ReasoningCycleError('Expected 1–32 ordered reasoning steps')
    if (type(allowed_source_pins) is not list or len(allowed_source_pins) > 64
            or any(type(p) is not str or _SHA.fullmatch(p) is None
                   for p in allowed_source_pins)
            or len(set(allowed_source_pins)) != len(allowed_source_pins)):
        raise ReasoningCycleError('Distinct caller-pinned source digests required')
    allowed = set(allowed_source_pins)
    # Fully validate all rows *before* reporting a loop, including trailing
    # entries that would otherwise hide malformed or substituted trace data.
    validated: list[tuple[str, set[str]]] = []
    previous: set[str] = set()
    for entry in trace:
        if type(entry) is not dict or set(entry) != {'claim_id', 'source_pins'}:
            raise ReasoningCycleError('Exact claim_id/source_pins trace row required')
        claim = _name(entry['claim_id'])
        pins = entry['source_pins']
        if (type(pins) is not list or len(pins) > 64
                or any(type(p) is not str or _SHA.fullmatch(p) is None for p in pins)
                or len(set(pins)) != len(pins)):
            raise ReasoningCycleError('Invalid or duplicate cumulative source pins')
        now = set(pins)
        if not now.issubset(allowed):
            raise ReasoningCycleError('Unknown source digest cannot claim new progress')
        if not previous.issubset(now):
            raise ReasoningCycleError('Nonmonotonic source history; require independent reinspection')
        validated.append((claim, now))
        previous = now
    history: dict[tuple[str, tuple[str, ...]], int] = {}
    previous = set()
    stagnant = 0
    status = 'WITHIN_BUDGET_UNVERIFIED'
    first_repeated_at: int | None = None
    last = None
    for idx, (claim, now) in enumerate(validated):
        stagnant = 0 if now - previous else stagnant + 1
        state = (claim, tuple(sorted(now)))
        if state in history:
            status = 'STOP_REPEATED_REASONING_STATE'
            first_repeated_at = history[state]
            last = idx
            break
        history[state] = idx
        previous = now
        last = idx
        if stagnant >= max_steps_without_new_source:
            status = 'STOP_NO_NEW_SOURCE'
            break
    result = {'schema': 'hwi.reasoning.trace.v1', 'status': status,
              'steps_examined': len(trace) if status == 'WITHIN_BUDGET_UNVERIFIED' else last + 1,
              'first_repeated_step': first_repeated_at,
              'new_pins_are_independent_evidence': False,
              'suitable_for_autonomous_confidence_gain': False,
              'human_authorized': False, 'pvs_approved': False,
              'execution_authorized': False}
    return {**result, 'audit_sha256': _digest(result)}
