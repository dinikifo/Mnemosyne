"""HWI-08 candidate: signed, one-use, revision-checked wiki changes.

Signatures are evidence that the enrolled private key authorized an exact proposal,
not proof of reviewer identity or informed consent. No signer/private key is exposed
here. This is offline, opt-in and is NOT a PVS approval or SEC-02 execution right.
"""
from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime, timezone
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from personal_wiki_core import NotebookWorkspace
from personal_wiki_core.history_db import _append, _utc_stamp, encode_tags, is_managed
from .proposals import KnowledgeProposalLedger, ProposalError, _canon, _sha
from .knowledge_broker import ReadOnlyKnowledgeBroker


class ReviewWriteError(ValueError):
    pass


class StaleReview(ReviewWriteError):
    pass


class AlreadyApplied(ReviewWriteError):
    pass


def review_message(entry: dict) -> bytes:
    """Exact bytes to present to an OFFLINE human reviewer for signing."""
    if entry['state'] != 'SUBMITTED':
        raise ReviewWriteError('Only open proposals can be reviewed')
    return _canon({'purpose':'HWI08 wiki change, not PVS or execution authorization',
                   'schema':'hwi.review.v1', 'proposal_id':entry['proposal_id'],
                   'proposal_digest':entry['content_digest'],
                   'notebook_scope':entry['record']['notebook_scope']}).encode('utf-8')


def _verify_signature(entry, signature_hex, public_key_bytes):
    if type(public_key_bytes) is not bytes or len(public_key_bytes) != 32:
        raise ReviewWriteError('Pinned 32-byte reviewer public key required')
    if type(signature_hex) is not str or len(signature_hex) != 128:
        raise ReviewWriteError('64-byte Ed25519 signature required')
    try:
        signature = bytes.fromhex(signature_hex)
        Ed25519PublicKey.from_public_bytes(public_key_bytes).verify(signature, review_message(entry))
    except (ValueError, InvalidSignature) as exc:
        raise ReviewWriteError('Invalid reviewer signature') from exc
    return hashlib.sha256(public_key_bytes).hexdigest()


def review_custody_artifact(entry: dict, signature_hex: str, reviewer_public_key: bytes) -> dict:
    """Public, exact signing evidence; not a claim of human identity or PVS approval.

    Called only *after* the ordinary application signature/pin validation. The
    stored artifact can be independently checked, provided its digest and
    reviewer key enrollment were independently retained by an operator.
    """
    message = review_message(entry)
    return {'schema':'hwi.review.custody.v1',
            'proposal_id':entry['proposal_id'],
            'proposal_digest':entry['content_digest'],
            'signed_message_json':message.decode('ascii'),
            'signed_message_sha256':hashlib.sha256(message).hexdigest(),
            'signature_hex':signature_hex.lower(),
            'reviewer_public_key_hex':reviewer_public_key.hex(),
            'reviewer_key_sha256':hashlib.sha256(reviewer_public_key).hexdigest()}


def _verify_operator_pin(workspace, notebook_name, scope, public_key_bytes):
    """Read operator-provisioned pin; this module has NO pin creation API."""
    path = workspace.root / 'review_policy' / (notebook_name + '.json')
    folder = path.parent
    if folder.is_symlink() or not folder.is_dir():
        raise ReviewWriteError('Operator policy directory missing or unsafe')
    if os.name == 'posix' and folder.stat().st_mode & 0o077:
        raise ReviewWriteError('Operator policy directory not private')
    if path.is_symlink() or not path.is_file():
        raise ReviewWriteError('Operator-pinned review policy is missing')
    st = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
        raise ReviewWriteError('Operator policy must be a single-link regular file')
    if os.name == 'posix' and st.st_mode & 0o077:
        raise ReviewWriteError('Operator policy file must have mode 0600')
    if st.st_size > 2048:
        raise ReviewWriteError('Oversized operator policy')
    try:
        policy = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, UnicodeError) as exc:
        raise ReviewWriteError('Invalid operator review policy') from exc
    if type(policy) is not dict or set(policy) != {'schema','notebook_scope','reviewer_key_sha256'}:
        raise ReviewWriteError('Unexpected operator policy fields')
    fingerprint = hashlib.sha256(public_key_bytes).hexdigest()
    if policy != {'schema':'hwi.review.policy.v1','notebook_scope':scope,
                  'reviewer_key_sha256':fingerprint}:
        raise ReviewWriteError('Review key or notebook does not match operator pin')


def _ensure_unmanaged(db, title):
    raw = db._get_raw(title)
    if db.is_protected(title) or (raw is not None and is_managed(raw)):
        raise ReviewWriteError('Protected or PVS-managed record denied')
    return raw


def _apply_locked(workspace: NotebookWorkspace, notebook_name: str,
                        ledger: KnowledgeProposalLedger, proposal_id: str, *,
                        signature_hex: str, reviewer_public_key: bytes, entry: dict) -> dict:
    """Apply one exact signed proposal in a single SQLite content/history txn.

    For a create/revise/link/retire the currently observed state is rechecked AFTER
    BEGIN IMMEDIATE, under SQLite's writer lock. The independent proposal ledger
    is never mutated. HWI-09 handles receipt reconciliation across stores.
    """
    if not isinstance(workspace, NotebookWorkspace) or not isinstance(ledger, KnowledgeProposalLedger):
        raise ReviewWriteError('Trusted workspace and proposal ledger required')
    if ledger.notebook_name != notebook_name:
        raise ReviewWriteError('Proposal ledger notebook mismatch')
    if entry['state'] != 'SUBMITTED':
        raise ReviewWriteError('Closed proposal cannot be applied')
    rec = entry['record']
    if rec['schema_version'] != 'hwi.contract.v0.1' or rec['notebook_scope'] != ledger.namespace:
        raise ReviewWriteError('Unsupported proposal schema or namespace')
    if _sha('HWI07-proposal-v1\x00' + _canon(rec)) != entry['content_digest']:
        raise ReviewWriteError('Proposal content does not match committed digest')
    if rec.get('labels') != {'human_authorized':False,'actor_authenticated':False,
                              'pvs_approved':False,'execution_authorized':False,
                              'evidence_authenticated':False}:
        raise ReviewWriteError('Invalid proposal authority labels')
    with ReadOnlyKnowledgeBroker(workspace, notebook_name) as broker:
        if broker.namespace != ledger.namespace:
            raise ReviewWriteError('Notebook namespace changed')
    _verify_operator_pin(workspace, notebook_name, ledger.namespace, reviewer_public_key)
    fingerprint = _verify_signature(entry, signature_hex, reviewer_public_key)
    custody = review_custody_artifact(entry, signature_hex, reviewer_public_key)
    custody_json = _canon(custody)
    custody_sha256 = hashlib.sha256(custody_json.encode('ascii')).hexdigest()
    with workspace.open_notebook(notebook_name, readonly=False) as wiki:
        db = wiki._db
        conn = db.conn
        if not wiki.knowledge_catalog().enabled():
            raise ReviewWriteError('Knowledge catalog not initialized')
        conn.execute('BEGIN IMMEDIATE')
        try:
            # Per-notebook replay receipts are committed ATOMICALLY with the wiki edit.
            conn.execute('CREATE TABLE IF NOT EXISTS hist.hwi08_receipts ('
                         'proposal_id TEXT PRIMARY KEY, proposal_digest TEXT NOT NULL, '
                         'reviewer_key_sha256 TEXT NOT NULL, operation TEXT NOT NULL, '
                         'result_json TEXT NOT NULL, applied_at TEXT NOT NULL)')
            conn.execute('CREATE TABLE IF NOT EXISTS hist.hwi08_review_evidence ('
                         'proposal_id TEXT PRIMARY KEY, evidence_json TEXT NOT NULL, '
                         'evidence_sha256 TEXT NOT NULL)')
            if conn.execute('SELECT 1 FROM hist.hwi08_receipts WHERE proposal_id=?',
                            (proposal_id,)).fetchone():
                raise AlreadyApplied('Proposal already applied in this notebook')
            op = rec['operation']
            catalog = wiki.knowledge_catalog()
            if op not in ('create','revise','retire','link'):
                raise ReviewWriteError('Unsupported operation')
            target_id = rec['target_knowledge_id']
            if op == 'create':
                if rec['target_ref'] is not None or rec['expected_revision_sha256'] is not None:
                    raise ReviewWriteError('Invalid create baseline')
                after = rec['after']
                title = after['title']
                if _ensure_unmanaged(db,title) is not None:
                    raise StaleReview('Destination title already exists')
                item = {'title':title,'text':after['text'],'tags':list(after['tags']),
                        'created':_utc_stamp(),'modified':_utc_stamp(),**after['fields']}
                db._store(item)
                db._typing_gate(None,item,False)
                _append(conn,before=None,after=item,change_type='first_version',
                        reason='HWI08 signed proposal '+proposal_id+': '+rec['reason'])
                result = {'title':title}
            else:
                state = catalog.resolve(target_id)
                if state['deleted'] or state['current_sha256'] != rec['expected_revision_sha256']:
                    raise StaleReview('Target revision changed after proposal submission')
                title = state['current_title']
                raw = _ensure_unmanaged(db,title)
                if raw is None:
                    raise StaleReview('Current content missing')
                if op in ('revise','retire'):
                    before = rec['before']
                    actual = {'title':raw['title'],'text':raw.get('text',''),
                              'tags':list(raw.get('tags',[])) if isinstance(raw.get('tags',[]),list)
                              else raw.get('tags','').split(),
                              'fields':{k:v for k,v in raw.items()
                                        if k not in ('title','text','tags','created','modified')}}
                    if actual != before:
                        raise StaleReview('Current content differs from reviewed before-image')
                if op == 'revise':
                    after = rec['after']
                    _ensure_unmanaged(db,after['title'])
                    replacement = {'title':after['title'],'text':after['text'],
                                   'tags':list(after['tags']),**after['fields']}
                    db._replace(raw,replacement,'HWI08 signed proposal '+proposal_id+': '+rec['reason'],False)
                    result = {'title':after['title']}
                elif op == 'retire':
                    db.conn.execute('DELETE FROM tiddlers WHERE title=?',(title,))
                    db._typing_gate(raw,None,False)
                    _append(conn,before=raw,after=None,change_type='delete',
                            reason='HWI08 signed proposal '+proposal_id+': '+rec['reason'])
                    result = {'retired_id':target_id}
                else:
                    link = rec['after']
                    other = catalog.resolve(link['to_knowledge_id'])
                    if other['deleted'] or other['current_sha256'] != link['to_revision_sha256']:
                        raise StaleReview('Link destination changed')
                    _ensure_unmanaged(db,other['current_title'])
                    src_event = conn.execute('SELECT event_id FROM hist.events WHERE post_id=? '
                        'ORDER BY event_id DESC LIMIT 1',(target_id,)).fetchone()[0]
                    dst_event = conn.execute('SELECT event_id FROM hist.events WHERE post_id=? '
                        'ORDER BY event_id DESC LIMIT 1',(link['to_knowledge_id'],)).fetchone()[0]
                    conn.execute('INSERT INTO hist.hwi_links '
                        '(from_post,from_event,from_sha256,to_post,to_event,to_sha256,relation,reason) '
                        'VALUES(?,?,?,?,?,?,?,?)',
                        (target_id,src_event,state['current_sha256'],link['to_knowledge_id'],
                         dst_event,other['current_sha256'],link['relation'],
                         'HWI08 signed proposal '+proposal_id+': '+rec['reason']))
                    result = {'linked_ids':[target_id,link['to_knowledge_id']]}
            applied_at = datetime.now(timezone.utc).isoformat()
            receipt = {'proposal_id':proposal_id,'proposal_digest':entry['content_digest'],
                       'reviewer_key_sha256':fingerprint,'operation':op,
                       'result':result,'applied_at':applied_at,
                       'pvs_approved':False,'execution_authorized':False}
            conn.execute('INSERT INTO hist.hwi08_receipts VALUES (?,?,?,?,?,?)',
                (proposal_id,entry['content_digest'],fingerprint,op,_canon(receipt),applied_at))
            conn.execute('INSERT INTO hist.hwi08_review_evidence VALUES (?,?,?)',
                         (proposal_id, custody_json, custody_sha256))
            conn.execute('COMMIT')
            return receipt
        except BaseException:
            conn.execute('ROLLBACK')
            raise


def apply_signed_review(workspace: NotebookWorkspace, notebook_name: str,
                        ledger: KnowledgeProposalLedger, proposal_id: str, *,
                        signature_hex: str, reviewer_public_key: bytes) -> dict:
    """Signed review application serialized against proposal withdrawal.

    A ledger writer transaction remains open through the wiki commit. It
    prevents a concurrent reject/withdraw from committing *before* this
    application, but does not create a cross-database atomic transaction.
    After an uncertain outcome, inspect via HWI-09; never auto-retry.
    """
    if not isinstance(ledger, KnowledgeProposalLedger):
        raise ReviewWriteError('Trusted proposal ledger required')
    if not isinstance(workspace, NotebookWorkspace) or ledger.notebook_name != notebook_name:
        raise ReviewWriteError('Trusted matching workspace/notebook required')
    try:
        with ledger._hold_submitted_for_application(proposal_id) as entry:
            return _apply_locked(workspace, notebook_name, ledger, proposal_id,
                                 signature_hex=signature_hex,
                                 reviewer_public_key=reviewer_public_key,
                                 entry=entry)
    except ProposalError as exc:
        raise ReviewWriteError('Proposal is closed or invalid at application time') from exc
