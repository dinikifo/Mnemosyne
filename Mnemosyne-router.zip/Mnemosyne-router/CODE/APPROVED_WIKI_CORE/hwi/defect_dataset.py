"""HWI-13: deterministic defect-case assessment and human-reviewed dataset export.

This module DOES NOT execute a model, run an untrusted test, verify factual truth,
modify the notebook/agent/PVS, or authorize fine-tuning or tool use. Assertions of
independence, privacy clearance, and licensing require real external review.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class DefectDatasetError(ValueError):
    """Invalid case, split, review, or signing evidence; nothing exported."""


_ID = re.compile(r'^[a-z][a-z0-9_.:-]{0,79}$')
_REF = re.compile(r'^(?:journal:[A-Za-z0-9._:-]{1,100}|hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*)$')
_HEX64 = re.compile(r'^[0-9a-f]{64}$')
_HEX128 = re.compile(r'^[0-9a-f]{128}$')
_MAX_CASES = 30
_MAX_DATASET_CHARS = 180_000


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise DefectDatasetError(message)


def _keys(obj: Any, required: set[str], optional: set[str] = frozenset()) -> None:
    _require(type(obj) is dict and required.issubset(obj) and not set(obj) - required - optional,
             'Missing, malformed, or unexpected fields')


def _text(value: Any, maximum: int, label: str, *, empty: bool = False) -> str:
    _require(type(value) is str and len(value) <= maximum and (empty or bool(value.strip())),
             f'Invalid {label}')
    return value


def _name(value: Any, label: str) -> str:
    _require(type(value) is str and _ID.fullmatch(value) is not None, f'Invalid {label}')
    return value


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=True, allow_nan=False).encode('ascii')
    except (TypeError, ValueError, OverflowError) as exc:
        raise DefectDatasetError('Object is not canonical JSON') from exc


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict:
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('Duplicate JSON object member')
        obj[key] = value
    return obj


def _parse_json(value: str) -> bytes | None:
    try:
        obj = json.loads(value, object_pairs_hook=_unique_pairs,
                         parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid JSON constant')))
        return _canonical(obj)
    except (ValueError, TypeError, DefectDatasetError, RecursionError):
        return None


def _case(raw: Any) -> dict:
    _keys(raw, {'schema', 'case_id', 'leakage_group', 'instruction', 'expected_output',
                'observed_before', 'observed_after', 'oracle_kind', 'expected_origin_claim',
                'evidence_refs'})
    _require(raw['schema'] == 'hwi.defect.case.v1', 'Unsupported defect-case schema')
    _name(raw['case_id'], 'case ID')
    _name(raw['leakage_group'], 'leakage group')
    for field in ('instruction', 'expected_output'):
        _text(raw[field], 3000, field)
    for field in ('observed_before', 'observed_after'):
        _text(raw[field], 3000, field, empty=True)
    _require(raw['oracle_kind'] in ('exact_text', 'canonical_json'), 'Unsupported deterministic oracle')
    _require(type(raw['expected_origin_claim']) is str and raw['expected_origin_claim'] in
             ('human_specification', 'external_test', 'agent_suggestion'), 'Invalid expected-origin claim')
    refs = raw['evidence_refs']
    _require(type(refs) is list and 1 <= len(refs) <= 8 and
             all(type(r) is str and _REF.fullmatch(r) is not None for r in refs) and
             len(set(refs)) == len(refs), 'Missing, duplicate, or malformed claimed evidence refs')
    if raw['oracle_kind'] == 'canonical_json':
        _require(_parse_json(raw['expected_output']) is not None, 'Expected output is not valid canonical-comparable JSON')
    return json.loads(_canonical(raw))


def assess_defect(case: dict) -> dict:
    """Compare recorded outputs against a caller-supplied expected answer.

    A local oracle match is NOT independent confirmation of a corrected defect.
    """
    source = _case(case)
    if source['oracle_kind'] == 'exact_text':
        before_match = source['observed_before'] == source['expected_output']
        after_match = source['observed_after'] == source['expected_output']
    else:
        expected = _parse_json(source['expected_output'])
        before_match = _parse_json(source['observed_before']) == expected
        after_match = _parse_json(source['observed_after']) == expected
    status = ('LOCAL_CORRECTION_MATCH' if not before_match and after_match else
              'BASELINE_ALREADY_MATCHED' if before_match else 'LOCAL_CORRECTION_NOT_OBSERVED')
    return {'schema': 'hwi.defect.assessment.v1', 'case_id': source['case_id'],
            'case_sha256': _sha(_canonical(source)), 'oracle_kind': source['oracle_kind'],
            'before_matches_expected': before_match, 'after_matches_expected': after_match,
            'status': status, 'expected_origin_claim': source['expected_origin_claim'],
            'evidence_refs_claimed': sorted(source['evidence_refs']),
            'truth_independently_verified': False, 'root_cause_established': False,
            'model_improvement_proven': False, 'training_authorized': False,
            'pvs_approved': False, 'execution_authorized': False}


def _prompt_key(prompt: str) -> str:
    return ' '.join(prompt.casefold().split())


def plan_dataset(cases: list[dict], assignments: list[dict]) -> dict:
    """Build deterministic, unsigned train/eval candidate plan; no file writes."""
    _require(type(cases) is list and 2 <= len(cases) <= _MAX_CASES, 'Expected 2-30 distinct cases')
    _require(type(assignments) is list and len(assignments) == len(cases), 'Expected one assignment per case')
    normalized = [_case(case) for case in cases]
    ids = [case['case_id'] for case in normalized]
    _require(len(set(ids)) == len(ids), 'Duplicate case IDs')
    reviewed = [assess_defect(case) for case in normalized]
    _require(all(r['status'] == 'LOCAL_CORRECTION_MATCH' for r in reviewed),
             'Only locally reproduced defect/fix pairs may enter dataset planning')
    _require(all(case['expected_origin_claim'] != 'agent_suggestion' for case in normalized),
             'Unreviewed model-suggested expected outputs must not become dataset labels')
    mapping: dict[str, str] = {}
    for item in assignments:
        _keys(item, {'case_id', 'split'})
        _require(type(item['case_id']) is str and item['case_id'] in ids and
                 item['case_id'] not in mapping and item['split'] in ('train', 'eval'),
                 'Invalid or duplicate split assignment')
        mapping[item['case_id']] = item['split']
    _require(set(mapping) == set(ids) and set(mapping.values()) == {'train', 'eval'},
             'Both train and eval splits are required')
    groups: dict[str, str] = {}
    prompts: dict[str, str] = {}
    for case in normalized:
        split = mapping[case['case_id']]
        for registry, key in ((groups, case['leakage_group']),
                              (prompts, _prompt_key(case['instruction']))):
            _require(key not in registry or registry[key] == split,
                     'Likely train/eval leakage across group or duplicated prompt')
            registry[key] = split
    plan = {'schema': 'hwi.dataset.plan.v1',
            'cases': sorted(normalized, key=lambda item: item['case_id']),
            'assignments': [{'case_id': k, 'split': v} for k, v in sorted(mapping.items())],
            'assessments': sorted(reviewed, key=lambda item: item['case_id'])}
    _require(len(_canonical(plan)) <= _MAX_DATASET_CHARS, 'Dataset candidate plan too large')
    return plan


def _validate_plan(raw: Any) -> dict:
    _keys(raw, {'schema', 'cases', 'assignments', 'assessments'})
    _require(raw['schema'] == 'hwi.dataset.plan.v1', 'Unsupported dataset plan')
    expected = plan_dataset(raw['cases'], raw['assignments'])
    _require(_canonical(raw) == _canonical(expected), 'Plan differs from recomputed evidence checks')
    return expected


def _review(raw: Any) -> dict:
    _keys(raw, {'reviewer_session', 'reason', 'ground_truth_reviewed', 'privacy_reviewed',
                'licensing_reviewed', 'evidence_custody_reviewed', 'split_separation_reviewed'})
    _name(raw['reviewer_session'], 'reviewer session')
    _text(raw['reason'], 1000, 'review reason')
    for name in ('ground_truth_reviewed', 'privacy_reviewed', 'licensing_reviewed',
                 'evidence_custody_reviewed', 'split_separation_reviewed'):
        _require(raw[name] is True, f'Release requires explicit {name} attestation')
    return json.loads(_canonical(raw))


def release_review_message(plan: dict, review: dict) -> bytes:
    """Exact message an independently provisioned reviewer must sign externally."""
    p = _validate_plan(plan)
    r = _review(review)
    return _canonical({'schema': 'hwi.dataset.release.review.v1',
                       'plan_sha256': _sha(_canonical(p)), 'review': r})


def export_reviewed_dataset(plan: dict, review: dict, *, signature_hex: str,
                            reviewer_public_key_hex: str, pinned_key_sha256: str) -> dict:
    """Verify explicitly pinned signed release and return dataset bytes, no IO.

    Does not validate identity/independence, licensing rights, data privacy, or
    the ground-truth oracle itself. This is authorization to export only.
    """
    message = release_review_message(plan, review)
    _require(type(signature_hex) is str and _HEX128.fullmatch(signature_hex) is not None,
             'Invalid Ed25519 signature encoding')
    _require(type(reviewer_public_key_hex) is str and _HEX64.fullmatch(reviewer_public_key_hex) is not None,
             'Invalid Ed25519 public key')
    _require(type(pinned_key_sha256) is str and _HEX64.fullmatch(pinned_key_sha256) is not None,
             'Invalid independently pinned key digest')
    key_bytes = bytes.fromhex(reviewer_public_key_hex)
    _require(_sha(key_bytes) == pinned_key_sha256, 'Reviewer key does not match independent pin')
    try:
        Ed25519PublicKey.from_public_bytes(key_bytes).verify(bytes.fromhex(signature_hex), message)
    except (InvalidSignature, ValueError) as exc:
        raise DefectDatasetError('Invalid reviewer signature') from exc
    p = _validate_plan(plan)
    assignments = {a['case_id']: a['split'] for a in p['assignments']}
    emitted: dict[str, list[bytes]] = {'train': [], 'eval': []}
    for case in p['cases']:
        row = {'schema': 'hwi.dataset.example.v1', 'case_id': case['case_id'],
               'leakage_group': case['leakage_group'], 'instruction': case['instruction'],
               'completion': case['expected_output'], 'oracle_kind': case['oracle_kind'],
               'case_sha256': _sha(_canonical(case)),
               'expected_origin_claim': case['expected_origin_claim'],
               'evidence_refs_claimed': sorted(case['evidence_refs']),
               'labels_independently_verified': False}
        emitted[assignments[case['case_id']]].append(_canonical(row) + b'\n')
    train = b''.join(emitted['train'])
    evaluation = b''.join(emitted['eval'])
    manifest = {'schema': 'hwi.dataset.release.manifest.v1',
                'plan_sha256': _sha(_canonical(p)),
                'signed_review_sha256': _sha(message),
                'reviewer_key_sha256': pinned_key_sha256,
                'signature_hex': signature_hex,
                'reviewer_session_claim': review['reviewer_session'],
                'train_sha256': _sha(train), 'eval_sha256': _sha(evaluation),
                'train_rows': len(emitted['train']), 'eval_rows': len(emitted['eval']),
                'export_reviewed': True, 'human_identity_independently_verified': False,
                'labels_independently_verified': False, 'privacy_independently_verified': False,
                'licensing_independently_verified': False, 'fine_tuning_authorized': False,
                'publishing_authorized': False, 'pvs_approved': False,
                'execution_authorized': False}
    return {'train_jsonl': train, 'eval_jsonl': evaluation, 'manifest': manifest}
