"""HWI-11: bounded, deterministic inference on *untrusted assertions*.

VERIFIED means a logical condition follows from supplied assertions, not that
any assertion is true, authenticated, human-approved or PVS-governed. The
module never writes to SQLite, invokes a model, or authorizes an action.
"""
from __future__ import annotations

from datetime import date
import json
import re
from typing import Any

from .knowledge_broker import ReadOnlyKnowledgeBroker
from .reasoning_cycles import detect_reachable_cycle


class SymbolicRuleError(ValueError):
    """Malformed or excessive symbolic input; no partial result is returned."""


_ATOM = re.compile(r"^[a-z][a-z0-9_.:-]{0,79}$")
_REF = re.compile(r"^(?:hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*|journal:[A-Za-z0-9._:-]{1,100})$")
_STATUS = frozenset({"VERIFIED", "VIOLATED", "UNKNOWN"})
_MAX_FACTS = 64
_MAX_RULES = 64
_MAX_DEPTH = 12


def _strict_keys(obj: Any, required: set[str], optional: set[str] = frozenset()) -> None:
    if type(obj) is not dict or not required.issubset(obj) or set(obj) - required - optional:
        raise SymbolicRuleError(f"Expected exactly required keys {sorted(required)} and optional keys {sorted(optional)}")


def _atom(value: Any) -> str:
    if type(value) is not str or not _ATOM.fullmatch(value):
        raise SymbolicRuleError("Expected bounded, lowercase symbolic atom")
    return value


def _ref(value: Any) -> str:
    if type(value) is not str or not _REF.fullmatch(value):
        raise SymbolicRuleError("Expected revision-bound wiki reference or named journal reference")
    return value


def _day(value: Any) -> date:
    if type(value) is not str or len(value) != 10 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise SymbolicRuleError("Expected YYYY-MM-DD")
    try:
        parsed = date.fromisoformat(value)
    except ValueError as e:
        raise SymbolicRuleError("Invalid calendar date") from e
    if parsed.isoformat() != value:
        raise SymbolicRuleError("Noncanonical calendar date")
    return parsed


def _window(obj: dict) -> tuple[date | None, date | None]:
    a = _day(obj["valid_from"]) if "valid_from" in obj else None
    b = _day(obj["valid_until"]) if "valid_until" in obj else None
    if a and b and a >= b:
        raise SymbolicRuleError("Expected nonempty [valid_from, valid_until) window")
    return a, b


def _unique(items: list[str]) -> list[str]:
    return sorted(set(items))


def _result(status: str, reason: str, *, supporting: list[str] | tuple = (),
            opposing: list[str] | tuple = (), missing: list[str] | tuple = (),
            rule_refs: list[str] | tuple = ()) -> dict:
    assert status in _STATUS
    return {"status": status, "reason": reason,
            "supporting_refs": _unique(list(supporting)),
            "opposing_refs": _unique(list(opposing)), "rule_refs": _unique(list(rule_refs)),
            "missing_atoms": sorted(set(missing)),
            "assertions_authenticated": False, "human_authorized": False,
            "pvs_approved": False, "execution_authorized": False,
            "verification_scope": "logical_consistency_of_untrusted_assertions"}


def infer(facts: list[dict], rules: list[dict], *, goal: str, at: str) -> dict:
    """Evaluate a single named atom/rule deterministically at one explicit date.

    Supported rules:
      requires: target depends on all prerequisite atoms (logical conjunction)
      dependency: target depends on one prerequisite atom
      contradiction: target means two atoms are NOT both true
      temporal: target is applicable on [valid_from, valid_until), optionally
                also requiring an atom to be true in that window.

    Explicit positive and negative assertions of the same atom yield UNKNOWN.
    Missing and cyclic dependencies yield UNKNOWN, never implicit falsehood.
    The result describes the formal relationship of supplied claims only.
    """
    goal = _atom(goal)
    on = _day(at)
    if type(facts) is not list or len(facts) > _MAX_FACTS:
        raise SymbolicRuleError("Expected up to 64 fact assertions")
    if type(rules) is not list or len(rules) > _MAX_RULES:
        raise SymbolicRuleError("Expected up to 64 rules")

    by_atom: dict[str, list[dict]] = {}
    normalized_rules: dict[str, dict] = {}
    for fact in facts:
        _strict_keys(fact, {"atom", "value", "source_ref"}, {"valid_from", "valid_until"})
        atom = _atom(fact["atom"])
        if type(fact["value"]) is not bool:
            raise SymbolicRuleError("Fact value must be a Boolean (not number or string)")
        source = _ref(fact["source_ref"])
        start, end = _window(fact)
        by_atom.setdefault(atom, []).append({"value": fact["value"],
            "ref": source, "from": start, "until": end})

    for rule in rules:
        _strict_keys(rule, {"kind", "target", "source_ref"},
                     {"requires", "depends_on", "left", "right", "valid_from", "valid_until", "basis"})
        kind = rule["kind"]
        if type(kind) is not str or kind not in ("requires", "dependency", "contradiction", "temporal"):
            raise SymbolicRuleError("Unknown symbolic rule kind")
        target = _atom(rule["target"])
        _ref(rule["source_ref"])
        if target in normalized_rules:
            raise SymbolicRuleError("Duplicate rules for one target are ambiguous")
        mandatory = {"kind", "target", "source_ref"}
        if kind == "requires":
            mandatory.add("requires")
            req = rule.get("requires")
            if type(req) is not list or not 1 <= len(req) <= 16 or any(type(x) is not str for x in req):
                raise SymbolicRuleError("Requires rule needs 1–16 named atoms")
            if len(set(req)) != len(req):
                raise SymbolicRuleError("Duplicate prerequisites")
            for x in req: _atom(x)
        elif kind == "dependency":
            mandatory.add("depends_on")
            _atom(rule.get("depends_on"))
        elif kind == "contradiction":
            mandatory |= {"left", "right"}
            _atom(rule.get("left")); _atom(rule.get("right"))
            if rule["left"] == rule["right"]:
                raise SymbolicRuleError("Contradiction pair must have different atoms")
        else:
            mandatory |= {"valid_from", "valid_until"}
            if "basis" in rule: _atom(rule["basis"])
            start, end = _window(rule)
            if start is None or end is None:
                raise SymbolicRuleError("Temporal window needs start and end")
        optional = {"basis"} if kind == "temporal" else set()
        _strict_keys(rule, mandatory, optional)
        if target in by_atom:
            raise SymbolicRuleError("Explicit facts cannot override a derived rule target")
        normalized_rules[target] = rule

    # A complete graph is audited independently of recursive inference. A
    # negative premise must not hide an otherwise reachable justification loop.
    graph: dict[str, list[str]] = {}
    for atom, rule in normalized_rules.items():
        if rule['kind'] == 'requires':
            graph[atom] = list(rule['requires'])
        elif rule['kind'] == 'dependency':
            graph[atom] = [rule['depends_on']]
        elif rule['kind'] == 'contradiction':
            graph[atom] = [rule['left'], rule['right']]
        else:
            graph[atom] = [rule['basis']] if 'basis' in rule else []
    for deps in list(graph.values()):
        for dep in deps:
            graph.setdefault(dep, [])
    graph.setdefault(goal, [])
    cycle_path = detect_reachable_cycle(graph, goal)

    memo: dict[str, dict] = {}

    def check(atom: str, trail: frozenset[str], depth: int) -> dict:
        if atom in trail or depth > _MAX_DEPTH:
            return _result("UNKNOWN", "cyclic_or_excessive_dependency", missing=[atom])
        if atom in memo:
            return memo[atom]
        if atom not in normalized_rules:
            active = [f for f in by_atom.get(atom, [])
                      if (f["from"] is None or f["from"] <= on)
                      and (f["until"] is None or on < f["until"])]
            yes = _unique([f["ref"] for f in active if f["value"]])
            no = _unique([f["ref"] for f in active if not f["value"]])
            if yes and no:
                answer = _result("UNKNOWN", "conflicting_assertions", supporting=yes, opposing=no)
            elif yes:
                answer = _result("VERIFIED", "positive_assertion", supporting=yes)
            elif no:
                answer = _result("VIOLATED", "negative_assertion", opposing=no)
            else:
                answer = _result("UNKNOWN", "no_applicable_assertion", missing=[atom])
            memo[atom] = answer
            return answer

        rule = normalized_rules[atom]
        ref = rule["source_ref"]
        new_trail = trail | {atom}
        kind = rule["kind"]
        if kind == "temporal":
            start, end = _window(rule)
            if not start <= on < end:
                answer = _result("VIOLATED", "outside_declared_window", rule_refs=[ref])
            elif "basis" in rule:
                result = check(rule["basis"], new_trail, depth + 1)
                answer = _result(result["status"], "temporal_basis_" + result["reason"],
                    supporting=result["supporting_refs"],
                    opposing=result["opposing_refs"], missing=result["missing_atoms"],
                    rule_refs=[ref, *result["rule_refs"]])
            else:
                answer = _result("VERIFIED", "inside_declared_window", rule_refs=[ref])
        elif kind == "contradiction":
            left = check(rule["left"], new_trail, depth + 1)
            right = check(rule["right"], new_trail, depth + 1)
            if left["status"] == right["status"] == "VERIFIED":
                answer = _result("VIOLATED", "mutual_exclusion_violated",
                    supporting=[*left["supporting_refs"], *right["supporting_refs"]],
                    rule_refs=[ref, *left["rule_refs"], *right["rule_refs"]])
            elif "VIOLATED" in (left["status"], right["status"]):
                answer = _result("VERIFIED", "mutual_exclusion_satisfied_by_negative_assertion",
                    opposing=[*left["opposing_refs"], *right["opposing_refs"]],
                    rule_refs=[ref, *left["rule_refs"], *right["rule_refs"]])
            else:
                answer = _result("UNKNOWN", "mutual_exclusion_not_determined",
                    supporting=[*left["supporting_refs"], *right["supporting_refs"]],
                    opposing=[*left["opposing_refs"], *right["opposing_refs"]],
                    missing=[*left["missing_atoms"], *right["missing_atoms"]],
                    rule_refs=[ref, *left["rule_refs"], *right["rule_refs"]])
        else:
            prerequisites = rule["requires"] if kind == "requires" else [rule["depends_on"]]
            results = [check(item, new_trail, depth + 1) for item in prerequisites]
            statuses = [r["status"] for r in results]
            common_support = [s for r in results for s in r["supporting_refs"]]
            common_oppose = [s for r in results for s in r["opposing_refs"]]
            common_missing = [m for r in results for m in r["missing_atoms"]]
            rule_refs = [ref, *(src for r in results for src in r["rule_refs"])]
            if "VIOLATED" in statuses:
                answer = _result("VIOLATED", "prerequisite_violated", supporting=common_support,
                    opposing=common_oppose, missing=common_missing, rule_refs=rule_refs)
            elif all(s == "VERIFIED" for s in statuses):
                answer = _result("VERIFIED", "prerequisites_verified",
                                 supporting=common_support, rule_refs=rule_refs)
            else:
                answer = _result("UNKNOWN", "prerequisites_undetermined", supporting=common_support,
                    opposing=common_oppose, missing=common_missing, rule_refs=rule_refs)
        # Cyclic intermediate conclusions must not be cached as if globally valid;
        # all derived assertions are recomputed for each traversal path.
        return answer

    outcome = check(goal, frozenset(), 0)
    if cycle_path and outcome['status'] != 'UNKNOWN':
        # A circular premise cannot certify a positive or negative conclusion.
        outcome = {**outcome, 'status': 'UNKNOWN',
                   'reason': 'circular_dependency_overrides_inference'}
    return {"circular_dependency_detected": bool(cycle_path),
            "cycle_path": cycle_path,
            "suitable_as_independent_evidence": False,
            "schema": "hwi.symbolic.result.v1", "goal": goal, "evaluated_at": at,
            "facts_considered": len(facts), "rules_considered": len(rules), **outcome}


def _no_duplicate_fields(items: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("Duplicate symbolic JSON key")
        result[key] = value
    return result


def infer_from_broker(broker: ReadOnlyKnowledgeBroker, references: list[str], *, goal: str, at: str) -> dict:
    """Read typed claims from exact current wiki revisions; never use note prose as rules.

    Each referenced note supplies either `hwi11_kind=fact` or `hwi11_kind=rule`
    and a string `hwi11_payload` containing canonical JSON. The source_ref
    is *always* the broker's actual revision reference, never one claimed in
    the note. Any malformed/truncated/restricted/stale record rejects the
    entire batch. The user's application chooses references, not the model.
    """
    if not isinstance(broker, ReadOnlyKnowledgeBroker):
        raise SymbolicRuleError("ReadOnlyKnowledgeBroker required")
    if type(references) is not list or not 1 <= len(references) <= 20 or any(type(r) is not str for r in references) or len(set(references)) != len(references):
        raise SymbolicRuleError("Expected 1–20 distinct revision-bound references")
    facts: list[dict] = []
    rules: list[dict] = []
    for reference in references:
        record = broker.read(reference)
        if record["ref"] != reference or record["fields_truncated"]:
            raise SymbolicRuleError("Truncated or mismatched wiki record")
        labels = record["labels"]
        if labels.get("content_class") != "untrusted_wiki_data" or labels.get("pvs_approved") is not False:
            raise SymbolicRuleError("Not an untrusted wiki data record")
        fields = record["fields"]
        if type(fields) is not dict or type(fields.get("hwi11_kind")) is not str or type(fields.get("hwi11_payload")) is not str:
            raise SymbolicRuleError("Missing explicit typed symbolic fields")
        raw = fields["hwi11_payload"]
        if len(raw) > 1200:
            raise SymbolicRuleError("Oversized typed symbolic payload")
        try:
            obj = json.loads(raw, object_pairs_hook=_no_duplicate_fields,
                             parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        except (ValueError, TypeError, RecursionError) as e:
            raise SymbolicRuleError("Invalid symbolic JSON payload") from e
        if type(obj) is not dict or "source_ref" in obj:
            raise SymbolicRuleError("Knowledge object cannot claim its own source_ref")
        enriched = {**obj, "source_ref": reference}
        if fields["hwi11_kind"] == "fact":
            facts.append(enriched)
        elif fields["hwi11_kind"] == "rule":
            rules.append(enriched)
        else:
            raise SymbolicRuleError("Unsupported symbolic record kind")
    result = infer(facts, rules, goal=goal, at=at)
    return {**result, "source_namespace": broker.namespace,
            "input_refs": sorted(references), "source_claims_are_untrusted": True,
            "suitable_for_governed_prompt": False}
