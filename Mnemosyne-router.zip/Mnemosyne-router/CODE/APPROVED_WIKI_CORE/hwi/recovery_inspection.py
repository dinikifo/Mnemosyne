"""HWI-09: read-only, local cross-store inspection after an uncertain HWI-08 write.

No reconciliation *action* is performed: no retry, no ledger status change, no
approval, no PVS/SEC-02 operation. New receipts can reconstruct and check
public Ed25519 signatures; this is NOT independently witnessed human identity
or independent custody of the retained public key or evidence digest.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import json
import re

from personal_wiki_core import NotebookWorkspace
from personal_wiki_core.history_db import custom_fields, parse_tags

from .knowledge_broker import ReadOnlyKnowledgeBroker
from .proposals import KnowledgeProposalLedger, _canon, _sha
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature


_PROPOSAL_ID = re.compile(r'^proposal:[0-9a-f]{32}$')
_HEX256 = re.compile(r'^[0-9a-f]{64}$')
_OPERATIONS = frozenset({'create', 'revise', 'link', 'retire'})


class RecoveryInspectionError(RuntimeError):
    """Required inspection evidence cannot be safely loaded or attributed."""


def _document(raw):
    if raw is None:
        return None
    if type(raw) is not dict:
        raise ValueError('History record is not an object')
    return {'title': raw['title'], 'text': raw.get('text', ''),
            'tags': parse_tags(raw.get('tags', [])),
            'fields': custom_fields(raw)}


def _table_exists(conn, table):
    return conn.execute("SELECT 1 FROM hist.sqlite_master WHERE type='table' AND name=?",
                        (table,)).fetchone() is not None


def _wiki_heads(conn):
    """Short-lived structural heads; change detection, not a cryptographic anchor."""
    events = conn.execute('SELECT COUNT(*), MAX(event_id) FROM hist.events').fetchone()
    links = (conn.execute('SELECT COUNT(*), MAX(link_id) FROM hist.hwi_links').fetchone()
             if _table_exists(conn, 'hwi_links') else (0, None))
    receipts = (conn.execute('SELECT COUNT(*), MAX(rowid) FROM hist.hwi08_receipts').fetchone()
                if _table_exists(conn, 'hwi08_receipts') else (0, None))
    evidence = (conn.execute('SELECT COUNT(*), MAX(rowid) FROM hist.hwi08_review_evidence').fetchone()
                if _table_exists(conn, 'hwi08_review_evidence') else (0, None))
    return [[events[0], events[1]], [links[0], links[1]],
            [receipts[0], receipts[1]], [evidence[0], evidence[1]]]


def _footprint(conn, proposal_id, reason, operation):
    expected = 'HWI08 signed proposal ' + proposal_id + ': ' + reason
    if operation == 'link':
        if not _table_exists(conn, 'hwi_links'):
            return []
        return conn.execute('SELECT * FROM hist.hwi_links WHERE reason=?', (expected,)).fetchall()
    return conn.execute('SELECT * FROM hist.events WHERE reason=? ORDER BY event_id',
                        (expected,)).fetchall()


def _event_evidence_valid(event, rec, result):
    op = rec['operation']
    try:
        before = json.loads(event['before_json']) if event['before_json'] is not None else None
        after = json.loads(event['after_json']) if event['after_json'] is not None else None
        if op == 'create':
            return (event['change_type'] == 'first_version' and before is None
                    and _document(after) == rec['after']
                    and result == {'title':rec['after']['title']})
        if op == 'revise':
            return (event['post_id'] == rec['target_knowledge_id']
                    and event['change_type'] in ('edit', 'rename')
                    and _document(before) == rec['before']
                    and _document(after) == rec['after']
                    and result == {'title':rec['after']['title']})
        if op == 'retire':
            return (event['post_id'] == rec['target_knowledge_id']
                    and event['change_type'] == 'delete' and after is None
                    and _document(before) == rec['before']
                    and result == {'retired_id':rec['target_knowledge_id']})
    except (TypeError, ValueError, KeyError, json.JSONDecodeError):
        return False
    return False


def _link_evidence_valid(link, rec, result):
    after = rec['after']
    return (link['from_post'] == rec['target_knowledge_id']
            and link['from_sha256'] == rec['expected_revision_sha256']
            and link['to_post'] == after['to_knowledge_id']
            and link['to_sha256'] == after['to_revision_sha256']
            and link['relation'] == after['relation']
            and result == {'linked_ids':[rec['target_knowledge_id'],
                                         after['to_knowledge_id']]})


def _receipt_valid(row, entry, matches):
    rec = entry['record']
    try:
        if row['proposal_digest'] != entry['content_digest'] or row['operation'] != rec['operation']:
            return False
        key = row['reviewer_key_sha256']
        if type(key) is not str or _HEX256.fullmatch(key) is None:
            return False
        applied_at = datetime.fromisoformat(row['applied_at'])
        if applied_at.tzinfo is None or applied_at.utcoffset() is None:
            return False
        receipt = json.loads(row['result_json'])
        if _canon(receipt) != row['result_json']:
            return False
        if set(receipt) != {'proposal_id', 'proposal_digest', 'reviewer_key_sha256',
                            'operation', 'result', 'applied_at', 'pvs_approved',
                            'execution_authorized'}:
            return False
        if (receipt['proposal_id'] != entry['proposal_id']
                or receipt['proposal_digest'] != entry['content_digest']
                or receipt['reviewer_key_sha256'] != key
                or receipt['operation'] != rec['operation']
                or receipt['applied_at'] != row['applied_at']
                or receipt['pvs_approved'] is not False
                or receipt['execution_authorized'] is not False):
            return False
        if len(matches) != 1:
            return False
        if rec['operation'] == 'link':
            return _link_evidence_valid(matches[0], rec, receipt['result'])
        return _event_evidence_valid(matches[0], rec, receipt['result'])
    except (TypeError, ValueError, KeyError, json.JSONDecodeError, OverflowError):
        return False



def _review_signature_evidence_valid(row, receipt_row, entry):
    """Reconstruct the exact signed request without trusting the stored message.

    Verification establishes *cryptographic consistency* only. The reviewer
    public key is not independently enrolled just because it is stored here.
    """
    try:
        if row is None or receipt_row is None:
            return False
        artifact = json.loads(row['evidence_json'])
        if type(artifact) is not dict or set(artifact) != {
                'schema','proposal_id','proposal_digest','signed_message_json',
                'signed_message_sha256','signature_hex','reviewer_public_key_hex',
                'reviewer_key_sha256'}:
            return False
        if (_canon(artifact) != row['evidence_json']
                or hashlib.sha256(row['evidence_json'].encode('ascii')).hexdigest()
                   != row['evidence_sha256']
                or artifact['schema'] != 'hwi.review.custody.v1'
                or row['proposal_id'] != entry['proposal_id']
                or artifact['proposal_id'] != entry['proposal_id']
                or artifact['proposal_digest'] != entry['content_digest']):
            return False
        pub = bytes.fromhex(artifact['reviewer_public_key_hex'])
        sig = bytes.fromhex(artifact['signature_hex'])
        if len(pub) != 32 or len(sig) != 64:
            return False
        fingerprint = hashlib.sha256(pub).hexdigest()
        if fingerprint != receipt_row['reviewer_key_sha256'] or fingerprint != artifact['reviewer_key_sha256']:
            return False
        expected = _canon({'purpose':'HWI08 wiki change, not PVS or execution authorization',
                           'schema':'hwi.review.v1','proposal_id':entry['proposal_id'],
                           'proposal_digest':entry['content_digest'],
                           'notebook_scope':entry['record']['notebook_scope']}).encode('ascii')
        if (artifact['signed_message_json'].encode('ascii') != expected
                or artifact['signed_message_sha256'] != hashlib.sha256(expected).hexdigest()):
            return False
        Ed25519PublicKey.from_public_bytes(pub).verify(sig, expected)
        return True
    except (TypeError, KeyError, ValueError, UnicodeError, InvalidSignature, OverflowError):
        return False


def _baseline_unchanged(wiki, rec):
    """Only a current-state observation; NOT proof that no earlier write occurred."""
    catalog = wiki.knowledge_catalog()
    op = rec['operation']
    try:
        if op == 'create':
            return wiki.get_tiddler(rec['after']['title']) is None
        state = catalog.resolve(rec['target_knowledge_id'])
        if state['deleted'] or state['current_sha256'] != rec['expected_revision_sha256']:
            return False
        if op in ('revise', 'retire'):
            return _document(wiki._db._get_raw(state['current_title'])) == rec['before']
        dest = catalog.resolve(rec['after']['to_knowledge_id'])
        return (not dest['deleted']
                and dest['current_sha256'] == rec['after']['to_revision_sha256'])
    except (ValueError, KeyError, TypeError, RuntimeError):
        return False


def inspect_application(workspace: NotebookWorkspace, notebook_name: str,
                        ledger: KnowledgeProposalLedger, proposal_id: str) -> dict:
    """Inspect a given proposal against wiki receipts and independently stored ledger.

    The caller provides an *already opened* ledger; this function performs no
    writes to either store, does not open a writable SQLite connection, and
    never permits retry even if no receipt is visible. The ledger can be open
    read/write by the operator; only its read methods are called here.
    """
    if (not isinstance(workspace, NotebookWorkspace)
            or not isinstance(ledger, KnowledgeProposalLedger)
            or type(notebook_name) is not str
            or ledger.notebook_name != notebook_name
            or type(proposal_id) is not str or _PROPOSAL_ID.fullmatch(proposal_id) is None):
        raise RecoveryInspectionError('Trusted workspace, matching ledger and valid proposal ID required')

    try:
        ledger_start = ledger.verify()
        entry = ledger.get(proposal_id)
        rec = entry['record']
        if (rec.get('schema_version') != 'hwi.contract.v0.1'
                or rec.get('record_type') != 'Proposal'
                or rec.get('operation') not in _OPERATIONS
                or rec.get('notebook_scope') != ledger.namespace
                or _sha('HWI07-proposal-v1\x00' + _canon(rec)) != entry['content_digest']):
            raise RecoveryInspectionError('Unsupported or inconsistent proposal evidence')
        with ReadOnlyKnowledgeBroker(workspace, notebook_name) as broker:
            if broker.namespace != ledger.namespace:
                raise RecoveryInspectionError('Wiki namespace differs from proposal ledger')
            with workspace.open_notebook(notebook_name, readonly=True) as wiki:
                conn = wiki._db.conn
                conn.execute('PRAGMA query_only=ON')
                conn.execute('BEGIN')
                if (not wiki.verify_history().get('verified')
                        or not wiki.knowledge_catalog().verify().get('verified')):
                    raise RecoveryInspectionError('Wiki history/catalog verification failed')
                heads_start = _wiki_heads(conn)
                matches = _footprint(conn, proposal_id, rec['reason'], rec['operation'])
                receipt_row = None
                if _table_exists(conn, 'hwi08_receipts'):
                    receipt_row = conn.execute('SELECT * FROM hist.hwi08_receipts WHERE proposal_id=?',
                                               (proposal_id,)).fetchone()
                custody_row = None
                if _table_exists(conn, 'hwi08_review_evidence'):
                    custody_row = conn.execute(
                        'SELECT * FROM hist.hwi08_review_evidence WHERE proposal_id=?',
                        (proposal_id,)).fetchone()
                custody_snapshot = tuple(custody_row) if custody_row is not None else None
                no_receipt_baseline = _baseline_unchanged(wiki, rec) if receipt_row is None else None
                signature_valid = False
                if receipt_row is not None:
                    consistent = _receipt_valid(receipt_row, entry, matches)
                    if not consistent:
                        status = 'RECEIPT_INCONSISTENT'
                    elif custody_row is None:
                        status = 'REVIEW_EVIDENCE_MISSING'
                    elif not _review_signature_evidence_valid(custody_row, receipt_row, entry):
                        status = 'REVIEW_EVIDENCE_INCONSISTENT'
                    else:
                        signature_valid = True
                        status = ('APPLIED_LOCALLY_LEDGER_OPEN' if entry['state'] == 'SUBMITTED'
                                  else 'APPLIED_LOCALLY_LEDGER_CLOSED')
                elif matches:
                    consistent = False
                    status = 'UNRECEIPTED_WIKI_FOOTPRINT'
                else:
                    consistent = None
                    status = ('NO_RECEIPT_BASELINE_UNCHANGED' if no_receipt_baseline
                              else 'NO_RECEIPT_BASELINE_CHANGED')
                observed = {
                    'schema':'hwi.recovery.inspection.v1',
                    'status': status,
                    'proposal_id':proposal_id,
                    'proposal_digest':entry['content_digest'],
                    'operation':rec['operation'],
                    'notebook_scope':ledger.namespace,
                    'ledger_state':entry['state'],
                    'wiki_receipt_observed':receipt_row is not None,
                    'wiki_receipt_consistent':consistent,
                    'matching_wiki_footprints':len(matches),
                    'baseline_currently_unchanged':no_receipt_baseline,
                    'ledger_last_event_sha256':ledger_start['last_event_sha256'],
                    'automatic_retry_permitted':False,
                    'automatic_reconciliation_permitted':False,
                    'memory_approved':False,
                    'execution_authorized':False,
                    'human_authorized':False,
                    'review_signature_reverified':signature_valid,
                    'review_evidence_present':custody_row is not None,
                    'review_evidence_sha256':custody_row['evidence_sha256'] if signature_valid else None,
                    'external_custody_verified':False,
                    'manual_reconciliation_required':True,
                    'interpretation':'Local structural observation only, not authorization or proof of no previous write.'
                }
        ledger_end = ledger.verify()
        with workspace.open_notebook(notebook_name, readonly=True) as again:
            again._db.conn.execute('PRAGMA query_only=ON')
            again._db.conn.execute('BEGIN')
            heads_end = _wiki_heads(again._db.conn)
            custody_now = (again._db.conn.execute(
                'SELECT * FROM hist.hwi08_review_evidence WHERE proposal_id=?',
                (proposal_id,)).fetchone() if _table_exists(again._db.conn, 'hwi08_review_evidence')
                           else None)
            custody_end = tuple(custody_now) if custody_now is not None else None
        if heads_start != heads_end or custody_snapshot != custody_end:
            observed['status'] = 'WIKI_CHANGED_DURING_INSPECTION'
            observed['wiki_receipt_consistent'] = None
            observed['review_signature_reverified'] = False
            observed['review_evidence_sha256'] = None
            observed['baseline_currently_unchanged'] = None
        if ledger_start != ledger_end or ledger.get(proposal_id)['state'] != entry['state']:
            observed['status'] = 'LEDGER_CHANGED_DURING_INSPECTION'
            observed['wiki_receipt_consistent'] = None
            observed['review_signature_reverified'] = False
            observed['review_evidence_sha256'] = None
            observed['baseline_currently_unchanged'] = None
        return observed
    except RecoveryInspectionError:
        raise
    except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
        raise RecoveryInspectionError('Required local evidence cannot be verified; manual inspection only') from exc


def read_retained_review_evidence(workspace: NotebookWorkspace, notebook_name: str,
                                  ledger: KnowledgeProposalLedger, proposal_id: str) -> dict:
    """Read-only export for independent retention. This does not *create* custody.

    The operator must store the digest, public-key enrollment evidence, and
    reviewer ceremony records in a genuinely independent location. Returning a
    locally retained signature is not proof of a real person's participation.
    """
    report = inspect_application(workspace, notebook_name, ledger, proposal_id)
    if (report['status'] != 'APPLIED_LOCALLY_LEDGER_OPEN'
            or report['review_signature_reverified'] is not True):
        raise RecoveryInspectionError('No current verifiable review evidence to export')
    try:
        with workspace.open_notebook(notebook_name, readonly=True) as wiki:
            conn = wiki._db.conn
            conn.execute('PRAGMA query_only=ON')
            row = conn.execute('SELECT evidence_json,evidence_sha256 '
                               'FROM hist.hwi08_review_evidence WHERE proposal_id=?',
                               (proposal_id,)).fetchone()
            if row is None or hashlib.sha256(row['evidence_json'].encode('ascii')).hexdigest() != row['evidence_sha256']:
                raise RecoveryInspectionError('Custody evidence changed during export')
            artifact = json.loads(row['evidence_json'])
            if report['review_evidence_sha256'] != row['evidence_sha256']:
                raise RecoveryInspectionError('Custody evidence differs from inspected revision')
        return {'schema':'hwi.review.custody.export.v1',
                'artifact':artifact, 'artifact_sha256':row['evidence_sha256'],
                'signature_verified_locally':True,
                'human_identity_established':False,
                'external_custody_established':False,
                'pvs_approved':False, 'execution_authorized':False}
    except RecoveryInspectionError:
        raise
    except (TypeError, ValueError, KeyError, OSError, RuntimeError) as exc:
        raise RecoveryInspectionError('Review custody cannot be exported safely') from exc
