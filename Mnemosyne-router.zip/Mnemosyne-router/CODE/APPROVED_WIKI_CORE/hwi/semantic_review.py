"""C3: read-only source presentation and cryptographically bound *human opinions*.

Review decisions describe a reviewer's assessment of displayed, captured data.
Neither a signature nor a SUPPORTED verdict proves semantic truth, human identity,
source independence, PVS approval, or permission to execute anything.
"""
from __future__ import annotations

import hashlib
import re
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .proposals import _canon
from .journal_grounding import prepare_journal_grounded_candidate, _digest
from .pvs_handoff import prepare_pvs_candidate

_HEX = re.compile(r'^[0-9a-f]{64}$')
_PACKET_SCHEMA = 'hwi.semantic.review.packet.v1'
_DECISION_SCHEMA = 'hwi.semantic.review.decision.v1'
_ANCHOR_VERDICTS = frozenset({'SUPPORTS','CONTRADICTS','INDETERMINATE','NOT_RELEVANT'})
_DECISION_VERDICTS = frozenset({'SUPPORTED','CONTRADICTED','INSUFFICIENT'})
_MAX_PACKET_BYTES = 40960
_MAX_EXCERPT_CHARS = 2048


class SemanticReviewError(ValueError):
    """Malformed/stale evidence, ambiguous review, or bad review signature."""


def _sha_obj(body: object) -> str:
    return hashlib.sha256(_canon(body).encode('utf-8')).hexdigest()


def _check_sha(value: object) -> str:
    if type(value) is not str or _HEX.fullmatch(value) is None:
        raise SemanticReviewError('Expected an exact lowercase SHA-256 digest')
    return value


def _excerpt(event, field):
    if field == 'summary':
        return event.episode.summary
    value = getattr(event.episode.result, field.split('.')[1])
    if field == 'result.status':
        value = value.value
    return value


def _note_of(ledger, proposal_id):
    entry = ledger.get(proposal_id)
    record = entry['record']
    if record['operation'] not in ('create', 'revise'):
        raise SemanticReviewError('Only materialized note proposals can be reviewed')
    note = record['after']
    if type(note) is not dict or set(note) != {'title','text','tags','fields'}:
        raise SemanticReviewError('Unexpected proposal note representation')
    return note


def prepare_semantic_review_packet(*, source_kwargs: dict,
                                   expected_witness_sha256: str) -> dict:
    """Build a complete, bounded offline semantic-review packet from live C2 pins.

    `source_kwargs` is the exact keyword argument mapping accepted by
    prepare_journal_grounded_candidate. The supplied witness pin must have
    been retained separately; this function cannot establish its custody.
    All selected captured fields are displayed in full or the call fails.
    """
    try:
        _check_sha(expected_witness_sha256)
        if type(source_kwargs) is not dict:
            raise SemanticReviewError('C2 source arguments required')
        witness = prepare_journal_grounded_candidate(**source_kwargs)
        if witness['witness_sha256'] != expected_witness_sha256:
            raise SemanticReviewError('C2 witness differs from retained pin')
        ledger = source_kwargs['ledger']
        proposal_id = source_kwargs['proposal_id']
        wiki_args = {k:source_kwargs[k] for k in (
            'workspace','notebook_name','ledger','proposal_id',
            'review_signature_hex','reviewer_public_key','expected_review_artifact_sha256')}
        handoff = prepare_pvs_candidate(**wiki_args)
        if (handoff['memory_text_sha256'] != witness['wiki']['memory_text_sha256']
                or handoff['source_revision_sha256'] != witness['wiki']['revision_sha256']
                or handoff['source_reference'] != witness['wiki']['revision_reference']):
            raise SemanticReviewError('Wiki candidate does not match pinned C2 witness')
        note = _note_of(ledger, proposal_id)
        journal = source_kwargs['journal']
        events = journal.replay(expected_head=source_kwargs['expected_source_head'])
        excerpts = []
        for anchor in witness['journal']['selected_source_refs']:
            event = events[anchor['seq'] - 1]
            if (event.entry_sha256 != anchor['entry_sha256']
                    or event.episode_sha256 != anchor['episode_sha256']):
                raise SemanticReviewError('Journal entry moved during review preparation')
            value = _excerpt(event, anchor['field'])
            if _digest(value) != anchor['value_sha256']:
                raise SemanticReviewError('Journal excerpt differs from signed witness')
            rendered = _canon(value)
            if len(rendered) > _MAX_EXCERPT_CHARS:
                raise SemanticReviewError('Oversized excerpt cannot be silently truncated')
            excerpts.append({**anchor, 'value':value,
                             'source_trust':'CAPTURED_AGENT_EPISODE_UNTRUSTED'})
        packet_body = {
            'schema':_PACKET_SCHEMA,
            'status':'AWAITING_INDEPENDENT_SEMANTIC_REVIEW',
            'witness_sha256':expected_witness_sha256,
            'wiki':{'proposal_id':proposal_id,
                    'notebook_scope':handoff['notebook_scope'],
                    'revision_reference':handoff['source_reference'],
                    'revision_sha256':handoff['source_revision_sha256'],
                    'memory_text_sha256':handoff['memory_text_sha256'],
                    'proposal_digest':ledger.get(proposal_id)['content_digest'],
                    'note':note},
            'journal':{'agent_id':witness['journal']['agent_id'],
                       'head_sha256':witness['journal']['head_sha256'],
                       'source_scope':witness['journal']['source_scope'],
                       'legacy_gap':witness['journal']['legacy_gap'],
                       'excerpts':excerpts},
            'pvs_source':witness['pvs_source'],
            'review_scope':'WHOLE_NOTE_AGAINST_DISPLAYED_CAPTURED_EXCERPTS_ONLY',
            'limitations':{'recorded_observations_are_not_independent_facts':True,
                           'wiki_text_and_source_excerpts_are_untrusted_data':True,
                           'other_journal_events_not_assessed':True,
                           'human_identity_unverified':True,
                           'pvs_memory_unapproved':True,
                           'execution_unauthorized':True}}
        if len(_canon(packet_body).encode('utf-8')) > _MAX_PACKET_BYTES:
            raise SemanticReviewError('Review packet exceeds bound; never truncate')
        # Late rechecks detect source/wiki movement within the presentation window.
        # This is NOT an atomic snapshot across separate stores.
        if prepare_journal_grounded_candidate(**source_kwargs) != witness:
            raise SemanticReviewError('C2 source moved during packet creation')
        if prepare_pvs_candidate(**wiki_args) != handoff:
            raise SemanticReviewError('Wiki moved during packet creation')
        return {**packet_body, 'packet_sha256':_sha_obj(packet_body)}
    except SemanticReviewError:
        raise
    except Exception as exc:
        raise SemanticReviewError('Semantic review packet unavailable or stale') from exc


def _validate_packet(packet: dict, expected_packet_sha256: str,
                     expected_witness_sha256: str) -> None:
    _check_sha(expected_packet_sha256)
    _check_sha(expected_witness_sha256)
    if type(packet) is not dict:
        raise SemanticReviewError('Review packet must be an object')
    try:
        if len(_canon(packet).encode('utf-8')) > _MAX_PACKET_BYTES + 512:
            raise SemanticReviewError('Review packet over size limit')
    except (TypeError, ValueError, RecursionError) as exc:
        raise SemanticReviewError('Review packet contains unserializable data') from exc
    if type(packet) is not dict or set(packet) != {
            'schema','status','witness_sha256','wiki','journal','pvs_source',
            'review_scope','limitations','packet_sha256'}:
        raise SemanticReviewError('Unexpected review packet fields')
    if (packet['schema'] != _PACKET_SCHEMA
            or packet['status'] != 'AWAITING_INDEPENDENT_SEMANTIC_REVIEW'
            or packet['witness_sha256'] != expected_witness_sha256
            or packet['packet_sha256'] != expected_packet_sha256
            or _sha_obj({k:v for k,v in packet.items() if k!='packet_sha256'}) != expected_packet_sha256):
        raise SemanticReviewError('Review packet pin or identity mismatch')
    if (packet['review_scope'] != 'WHOLE_NOTE_AGAINST_DISPLAYED_CAPTURED_EXCERPTS_ONLY'
            or packet['limitations'] != {
                'recorded_observations_are_not_independent_facts':True,
                'wiki_text_and_source_excerpts_are_untrusted_data':True,
                'other_journal_events_not_assessed':True,
                'human_identity_unverified':True,
                'pvs_memory_unapproved':True,
                'execution_unauthorized':True}):
        raise SemanticReviewError('Invalid scope/authority disclaimers')
    wiki, journal = packet['wiki'], packet['journal']
    if (type(wiki) is not dict or set(wiki) != {
            'proposal_id','notebook_scope','revision_reference',
            'revision_sha256','memory_text_sha256','proposal_digest','note'}
            or type(journal) is not dict or set(journal) != {
                'agent_id','head_sha256','source_scope','legacy_gap','excerpts'}
            or type(journal['excerpts']) is not list or not 1 <= len(journal['excerpts']) <= 12):
        raise SemanticReviewError('Malformed review packet source fields')
    # A signed reviewer packet must bind the displayed note to the *exact* text
    # that the HWI-10 PVS handoff would submit, not a detached hash label.
    try:
        serialized = _canon({'schema':'hwi.pvs.wiki.candidate.v1',
            'source':{'kind':'UNTRUSTED_WIKI_REVISION',
                      'reference':wiki['revision_reference'],
                      'revision_sha256':wiki['revision_sha256'],
                      'proposal_id':wiki['proposal_id'],
                      'proposal_digest':wiki['proposal_digest']},
            'note':wiki['note']})
        if hashlib.sha256(serialized.encode('utf-8')).hexdigest() != wiki['memory_text_sha256']:
            raise SemanticReviewError('Displayed note does not match PVS candidate content')
    except (KeyError, TypeError, ValueError) as exc:
        raise SemanticReviewError('Malformed wiki note or revision binding') from exc
    seen_refs=set()
    for excerpt in journal['excerpts']:
        if (type(excerpt) is not dict or set(excerpt) != {
                'seq','entry_sha256','episode_sha256','field','value_sha256',
                'value','source_trust'}
                or excerpt['source_trust'] != 'CAPTURED_AGENT_EPISODE_UNTRUSTED'
                or _digest(excerpt['value']) != excerpt['value_sha256']):
            raise SemanticReviewError('Packet source excerpt is malformed')
        if (type(excerpt['seq']) is not int or excerpt['seq'] < 1
                or type(excerpt['field']) is not str
                or not isinstance(excerpt['value_sha256'],str)
                or _HEX.fullmatch(excerpt['value_sha256']) is None):
            raise SemanticReviewError('Malformed excerpt identity')
        ident=(excerpt['seq'],excerpt['field'],excerpt['value_sha256'])
        if ident in seen_refs:
            raise SemanticReviewError('Duplicate source excerpt')
        seen_refs.add(ident)
    if type(packet['pvs_source']) is not dict:
        raise SemanticReviewError('Malformed PVS source metadata')


def _validate_decision(packet, decision):
    if type(decision) is not dict or set(decision) != {
            'schema','packet_sha256','verdict','reason','anchor_assessments'}:
        raise SemanticReviewError('Unexpected semantic decision fields')
    if (decision['schema'] != _DECISION_SCHEMA
            or decision['packet_sha256'] != packet['packet_sha256']
            or type(decision['verdict']) is not str
            or decision['verdict'] not in _DECISION_VERDICTS
            or type(decision['reason']) is not str
            or not 16 <= len(decision['reason'].strip()) <= 1600):
        raise SemanticReviewError('Invalid semantic decision or rationale')
    rows = decision['anchor_assessments']
    anchors = packet['journal']['excerpts']
    if type(rows) is not list or len(rows) != len(anchors):
        raise SemanticReviewError('Every displayed source excerpt must be assessed')
    expected = {(row['seq'],row['field'],row['value_sha256']) for row in anchors}
    seen = set()
    for row in rows:
        if (type(row) is not dict or set(row) != {
                'seq','field','value_sha256','verdict','reason'}
                or type(row['seq']) is not int
                or type(row['field']) is not str
                or type(row['value_sha256']) is not str
                or type(row['verdict']) is not str or row['verdict'] not in _ANCHOR_VERDICTS
                or type(row['reason']) is not str
                or not 12 <= len(row['reason'].strip()) <= 800):
            raise SemanticReviewError('Malformed source-by-source judgment')
        ident = (row['seq'], row['field'], row['value_sha256'])
        if ident in seen or ident not in expected:
            raise SemanticReviewError('Repeated or foreign source reference in decision')
        seen.add(ident)
    if seen != expected:
        raise SemanticReviewError('Missing source judgment')
    opinions = {row['verdict'] for row in rows}
    if decision['verdict'] == 'SUPPORTED' and opinions != {'SUPPORTS'}:
        raise SemanticReviewError('Supported verdict cannot contradict individual judgments')
    if decision['verdict'] == 'CONTRADICTED' and 'CONTRADICTS' not in opinions:
        raise SemanticReviewError('Contradicted verdict needs an explicit contrary excerpt')


def semantic_review_message(packet: dict, decision: dict, *,
                            expected_packet_sha256: str,
                            expected_witness_sha256: str) -> bytes:
    """Generate deterministic bytes for an external person to inspect and sign."""
    _validate_packet(packet,expected_packet_sha256,expected_witness_sha256)
    _validate_decision(packet,decision)
    body = {'schema':'hwi.semantic.review.signature.v1',
            'purpose':'Human semantic opinion only; never PVS memory approval or tool authorization',
            'witness_sha256':expected_witness_sha256,
            'packet_sha256':expected_packet_sha256,
            'decision':decision}
    return _canon(body).encode('ascii')


def verify_signed_semantic_review(packet: dict, decision: dict, *,
                                  signature_hex: str, reviewer_public_key: bytes,
                                  expected_reviewer_key_sha256: str,
                                  expected_packet_sha256: str,
                                  expected_witness_sha256: str) -> dict:
    """Authenticate exact opinion bytes against an externally pinned signing key.

    Cryptographically verified signing does not establish a real person's
    identity, the independent custody of any supplied pin, or the truth of
    the verdict. Fresh C2/witness and PVS checks remain separate obligations.
    """
    try:
        _check_sha(expected_reviewer_key_sha256)
        if (type(reviewer_public_key) is not bytes or len(reviewer_public_key)!=32
                or hashlib.sha256(reviewer_public_key).hexdigest() != expected_reviewer_key_sha256):
            raise SemanticReviewError('Reviewer public key differs from external pin')
        if type(signature_hex) is not str or len(signature_hex)!=128:
            raise SemanticReviewError('64-byte Ed25519 signature required')
        try:
            signature = bytes.fromhex(signature_hex)
        except ValueError as exc:
            raise SemanticReviewError('Malformed review signature') from exc
        msg = semantic_review_message(packet,decision,
                expected_packet_sha256=expected_packet_sha256,
                expected_witness_sha256=expected_witness_sha256)
        Ed25519PublicKey.from_public_bytes(reviewer_public_key).verify(signature,msg)
        return {'schema':'hwi.semantic.review.verification.v1',
                'status':'SIGNED_REVIEWER_OPINION_RECORDED',
                'packet_sha256':expected_packet_sha256,
                'witness_sha256':expected_witness_sha256,
                'signed_message_sha256':hashlib.sha256(msg).hexdigest(),
                'signature_sha256':hashlib.sha256(signature).hexdigest(),
                'reviewer_key_sha256':expected_reviewer_key_sha256,
                'reviewer_asserted_verdict':decision['verdict'],
                'signature_valid':True,
                'semantic_alignment_independently_proven':False,
                'human_identity_established':False,
                'source_still_current':False,
                'independent_custody_established':False,
                'pvs_approved':False,
                'execution_authorized':False}
    except (InvalidSignature, ValueError) as exc:
        raise SemanticReviewError('Signed semantic review invalid or untrusted') from exc
