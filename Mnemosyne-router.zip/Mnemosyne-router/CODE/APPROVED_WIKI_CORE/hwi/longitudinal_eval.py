"""HWI-14: reproducible, isolated, longitudinal evidence and model-swap evaluation.

The synthetic comparator is NOT the agent's real file-memory provider. No live
agent, PVS promotion, authorizations, dataset release, or notebook tool is exposed.
The fixture writer is isolated to a temporary study notebook; the evaluated
knowledge-broker and symbolic-procedure paths are strictly read-only.
"""
from __future__ import annotations

from importlib.resources import files
import hashlib
import json
from pathlib import Path
import re
import tempfile
from typing import Mapping

from personal_wiki_core import NotebookWorkspace
from .knowledge_broker import ReadOnlyKnowledgeBroker, StaleKnowledgeReference
from .procedures import assess_procedure_from_broker
from .retrieval_eval import (
    ModelReply, LocalOllamaAnswerOnly, _seed, _file_search, _wiki_search,
    _context, _inventory, _norm,
)


class LongitudinalError(ValueError):
    """Study fixture, model, or evidence boundary violation."""


_STUDY_ID = 'HWI14-LONGITUDINAL-V1'
_SHA = re.compile(r'^[0-9a-f]{64}$')
_ID = re.compile(r'^D\d{2}$')
_SESSION = re.compile(r'^S\d{2}$')
_ATOM = re.compile(r'^[a-z][a-z0-9_.:-]{0,79}$')
_MAX_CONTEXT = 16000


def _canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def _unique_pairs(pairs):
    out = {}
    for key, val in pairs:
        if key in out:
            raise LongitudinalError('Duplicate fixture JSON field')
        out[key] = val
    return out


def fixture_bytes() -> bytes:
    return files('hwi').joinpath('fixtures/hwi14_longitudinal_v1.json').read_bytes()


def _keys(obj, required, optional=frozenset()):
    if type(obj) is not dict or not set(required).issubset(obj) or set(obj) - set(required) - set(optional):
        raise LongitudinalError('Invalid or unexpected fixture fields')


def _short(value, bound=1000):
    return type(value) is str and 0 < len(value.strip()) <= bound


def load_fixture(raw: bytes | None = None) -> tuple[dict, str]:
    raw = fixture_bytes() if raw is None else raw
    if type(raw) is not bytes or len(raw) > 100_000:
        raise LongitudinalError('Fixture must be bounded UTF-8 bytes')
    try:
        obj = json.loads(raw, object_pairs_hook=_unique_pairs,
                         parse_constant=lambda value: (_ for _ in ()).throw(LongitudinalError(value)))
    except (ValueError, TypeError, UnicodeError, RecursionError) as e:
        raise LongitudinalError('Invalid study JSON') from e
    _keys(obj, {'study_id','documents','sessions','procedure','parameters'})
    if obj['study_id'] != _STUDY_ID:
        raise LongitudinalError('Unsupported study ID')
    documents = obj['documents']
    sessions = obj['sessions']
    if type(documents) is not list or not 1 <= len(documents) <= 20 or type(sessions) is not list or not 2 <= len(sessions) <= 12:
        raise LongitudinalError('Invalid experiment size')
    seen_docs = set()
    seen_titles = set()
    for d in documents:
        _keys(d, {'id','title','text','tags'})
        if (type(d['id']) is not str or not _ID.fullmatch(d['id']) or d['id'] in seen_docs or
            not _short(d['title'],120) or d['title'] in seen_titles or
            not _short(d['text'],3000) or type(d['tags']) is not list or
            not 1 <= len(d['tags']) <= 8 or any(type(t) is not str or not re.fullmatch(r'[a-z-]{1,30}',t) for t in d['tags']) or
            'pvs' in d['tags']):
            raise LongitudinalError('Invalid synthetic source document')
        seen_docs.add(d['id']); seen_titles.add(d['title'])
    params = obj['parameters']
    _keys(params, {'top_k','context_max_chars','max_text_chars'})
    if (type(params['top_k']) is not int or not 1 <= params['top_k'] <= 10 or
        type(params['context_max_chars']) is not int or not 512 <= params['context_max_chars'] <= _MAX_CONTEXT or
        type(params['max_text_chars']) is not int or not 1 <= params['max_text_chars'] <= 3000):
        raise LongitudinalError('Invalid shared context budget')
    if type(obj['procedure']) is not dict:
        raise LongitudinalError('Invalid procedure')
    # Reuse HWI-12's strict procedure grammar before writing any study object.
    from .procedures import _validate
    try:
        _validate(obj['procedure'])
    except ValueError as e:
        raise LongitudinalError('Invalid procedure contract') from e
    seen_sessions = set()
    last_session_id = ''
    has_a = has_b = False
    last_slot = 'A'
    known_titles = {d['id']: d['title'] for d in documents}
    for stage in sessions:
        _keys(stage, {'id','model_slot','query','question','gold_doc_ids','expected_answer',
                      'expected_procedure_status','facts','changes'}, {'stale_phrases','injection_marker'})
        slot = stage['model_slot']
        if (type(stage['id']) is not str or not _SESSION.fullmatch(stage['id']) or stage['id'] in seen_sessions or
            slot not in ('A','B') or (last_slot == 'B' and slot != 'B') or
            not _short(stage['query'],120) or not _short(stage['question'],400) or
            not _short(stage['expected_answer'],400)):
            raise LongitudinalError('Invalid session or model-swap order')
        if stage['id'] <= last_session_id:
            raise LongitudinalError('Session IDs must be increasing')
        last_session_id = stage['id']
        last_slot = slot; has_a |= slot == 'A'; has_b |= slot == 'B'; seen_sessions.add(stage['id'])
        gold = stage['gold_doc_ids']
        if (type(gold) is not list or not gold or any(type(x) is not str for x in gold) or
            len(gold) != len(set(gold)) or not set(gold) <= seen_docs):
            raise LongitudinalError('Invalid gold document identities')
        if stage['expected_procedure_status'] not in ('CONDITIONALLY_APPLICABLE','NOT_APPLICABLE','UNRESOLVED'):
            raise LongitudinalError('Unknown procedure status')
        for field in ('stale_phrases',):
            values = stage.get(field,[])
            if type(values) is not list or len(values)>10 or any(not _short(x,200) for x in values):
                raise LongitudinalError('Invalid stale phrase list')
        if 'injection_marker' in stage and not _short(stage['injection_marker'],80):
            raise LongitudinalError('Invalid injected-text marker')
        facts = stage['facts']
        if type(facts) is not list or not 1 <= len(facts) <= 20:
            raise LongitudinalError('Invalid stage facts')
        for f in facts:
            _keys(f, {'atom','value'})
            if type(f['atom']) is not str or not _ATOM.fullmatch(f['atom']) or type(f['value']) is not bool:
                raise LongitudinalError('Malformed typed premise')
        changes = stage['changes']
        if type(changes) is not list or len(changes) > len(documents):
            raise LongitudinalError('Invalid staged changes')
        used=set()
        for ch in changes:
            _keys(ch, {'doc_id','text','reason'}, {'title'})
            did=ch['doc_id']
            if did not in seen_docs or did in used or not _short(ch['text'],3000) or not _short(ch['reason'],200):
                raise LongitudinalError('Invalid revision change')
            used.add(did)
            if 'title' in ch:
                if not _short(ch['title'],120) or (ch['title'] in known_titles.values() and ch['title'] != known_titles[did]):
                    raise LongitudinalError('Title collision')
                known_titles[did]=ch['title']
    if not has_a or not has_b:
        raise LongitudinalError('Frozen experiment must include an A-to-B model transition')
    return obj, hashlib.sha256(raw).hexdigest()


def _ref(broker, state):
    # Derive references solely through the public read-only broker contract.
    title = state['current_title']
    matches = [x['ref'] for x in broker.search(title, mode='Title', limit=20) if x['title'] == title]
    if len(matches) != 1:
        raise LongitudinalError('Knowledge revision is missing or ambiguous in broker catalog')
    return matches[0]


def run_longitudinal(models: Mapping[str, object] | None = None, *, raw_fixture: bytes | None = None) -> dict:
    """Run staged source changes, independent read-only retrieval, and procedure checks.

    Optional models are stateless answer-only callbacks; no agent tools are given.
    A real-model claim requires two distinct, digest-pinned local adapters.
    """
    obj, digest = load_fixture(raw_fixture)
    if models is not None and (not isinstance(models, Mapping) or set(models) != {'A','B'} or
                               any(not callable(m) for m in models.values())):
        raise LongitudinalError('Provide exactly two answer-only model callbacks, A and B')
    pinned = False
    identities = {}
    if models is not None:
        for slot in ('A','B'):
            model=models[slot]
            # Callback evaluation is allowed, but is not attested real-model evidence.
            if callable(getattr(model, 'verify_digest', None)) and _SHA.fullmatch(getattr(model,'digest','')):
                model.verify_digest()
                identities[slot]={'name':getattr(model,'model',''), 'digest':model.digest}
        pinned = (len(identities)==2 and identities['A']['digest'] != identities['B']['digest'] and
                  all(isinstance(models[x], LocalOllamaAnswerOnly) for x in ('A','B')))
    params=obj['parameters']
    results=[]
    with tempfile.TemporaryDirectory(prefix='hwi14-offline-') as temp:
        root=Path(temp)
        # Reuse HWI-06's transparent flat-file comparator and matched wiki seed.
        flat, workspace = _seed(root, {'documents':obj['documents']})
        current={d['id']:dict(d) for d in obj['documents']}
        former_refs={}
        initial_ids={}
        with workspace.open_notebook('study', readonly=False) as w:
            w.save_tiddler('Migration Runbook','Advisory synthetic migration procedure', ['runbook'],
                           fields={'hwi12_kind':'procedure','hwi12_payload':_canonical(obj['procedure'])},
                           reason='HWI14 synthetic runbook')
        for stage in obj['sessions']:
            with workspace.open_notebook('study', readonly=False) as w:
                cat=w.knowledge_catalog()
                for change in stage['changes']:
                    did=change['doc_id']; before=current[did]; after=dict(before)
                    after['text']=change['text']; after['title']=change.get('title',before['title'])
                    w.update_tiddler(before['title'],after['title'],after['text'],after['tags'],
                                     fields={'study_doc_id':did},reason=change['reason'])
                    current[did]=after
                    (flat/(did+'.json')).write_text(_canonical(after), encoding='utf-8')
                    state=cat.by_title(after['title'])
                    cat.record_origin(state['knowledge_id'],expected_event_id=state['latest_event_id'],
                                      actor_claim='import',source_kind='external',
                                      source_ref='fixture:'+did,
                                      reason='unverified synthetic revision')
                for idx, f in enumerate(stage['facts']):
                    w.save_tiddler(f"Premise {stage['id']} {idx:02d}",
                                   f"Synthetic assertion {f['atom']}",['premise'],
                                   fields={'hwi11_kind':'fact','hwi11_payload':_canonical(f)},
                                   reason='HWI14 synthetic scenario premise')
            before_read=_inventory(root)
            with ReadOnlyKnowledgeBroker(workspace,'study') as broker:
                with workspace.open_notebook('study', readonly=True) as w:
                    catalog=w.knowledge_catalog()
                    state=catalog.by_title('Migration Runbook')
                    proc_ref=_ref(broker,state)
                    fact_refs=[]
                    for idx in range(len(stage['facts'])):
                        name=f"Premise {stage['id']} {idx:02d}"
                        fact_refs.append(_ref(broker,catalog.by_title(name)))
                    current_states={d:catalog.by_title(row['title']) for d,row in current.items()}
                ids={did:s['knowledge_id'] for did,s in current_states.items()}
                if initial_ids and any(ids[did]!=initial_ids[did] for did in ids):
                    raise LongitudinalError('Knowledge identity lost across rename or revision')
                if not initial_ids:initial_ids=ids
                rejected=[]
                for did,prior in former_refs.items():
                    if prior == _ref(broker, current_states[did]):
                        continue  # Unchanged revisions remain valid.
                    try:
                        broker.read(prior)
                    except StaleKnowledgeReference:
                        rejected.append(did)
                    else:
                        raise LongitudinalError('Earlier revision became active without warning')
                for did,state in current_states.items():
                    former_refs[did]=_ref(broker,state)
                assessment=assess_procedure_from_broker(broker,proc_ref,fact_refs,at='2026-11-09')
                arms={}
                for arm in ('flat_file','wiki_broker'):
                    rows=(_file_search(flat,stage['query'],params['top_k']) if arm=='flat_file'
                          else _wiki_search(broker,stage['query'],params['top_k']))
                    context, selected, omitted=_context(sorted(rows,key=lambda row:row['doc_id']),
                                                         params['context_max_chars'],params['max_text_chars'])
                    selected_set=set(selected)
                    gold=set(stage['gold_doc_ids'])
                    metric={'retrieved_ids':[r['doc_id'] for r in rows], 'included_ids':selected,
                            'recall_at_k':len(gold & {r['doc_id'] for r in rows})/len(gold),
                            'context_recall':len(gold & selected_set)/len(gold),
                            'context_chars':len(context),'omitted_by_budget':omitted,
                            'revision_pins_available':sum(bool(r.get('revision_ref')) for r in rows),
                            'stale_text_exposed':any(_norm(p) in _norm(context) for p in stage.get('stale_phrases',[])),
                            'injection_text_exposed':bool(stage.get('injection_marker') and stage['injection_marker'] in context),
                            'source_claims_authenticated':False, 'untrusted_context':True}
                    if models is not None:
                        model=models[stage['model_slot']]
                        if callable(getattr(model,'verify_digest',None)):model.verify_digest()
                        reply=model(stage['question'],context)
                        if (not isinstance(reply,ModelReply) or type(reply.answer) is not str or
                            type(reply.citations) is not tuple or any(type(x) is not str for x in reply.citations)):
                            raise LongitudinalError('Model callback must return ModelReply')
                        if callable(getattr(model,'verify_digest',None)):model.verify_digest()
                        metric['model']={'answer':reply.answer[:400], 'citations':list(reply.citations[:12]),
                                         'exact_answer_match':_norm(reply.answer)==_norm(stage['expected_answer']),
                                         'citations_valid':set(reply.citations).issubset(selected_set),
                                         'gold_evidence_cited':bool(set(reply.citations)&gold),
                                         'injection_marker_obeyed':bool(stage.get('injection_marker') and stage['injection_marker'] in reply.answer),
                                         'prompt_tokens':reply.prompt_tokens,'generated_tokens':reply.generated_tokens}
                    arms[arm]=metric
                results.append({'session_id':stage['id'],'model_slot':stage['model_slot'],
                                'procedure_status':assessment['status'],
                                'procedure_expected':stage['expected_procedure_status'],
                                'procedure_matches_expected':assessment['status']==stage['expected_procedure_status'],
                                'procedure_authority_granted':assessment['execution_authorized'] or assessment['pvs_approved'],
                                'revision_identities_stable':True,
                                'prior_refs_rejected':sorted(rejected),
                                'arms':arms})
            after_read=_inventory(root)
            if before_read!=after_read:
                raise LongitudinalError('Read-only evaluation modified a study database or corpus')
    summary={}
    for arm in ('flat_file','wiki_broker'):
        rows=[s['arms'][arm] for s in results]
        summary[arm]={'mean_recall_at_k':round(sum(s['recall_at_k'] for s in rows)/len(rows),4),
                      'mean_context_recall':round(sum(s['context_recall'] for s in rows)/len(rows),4),
                      'stale_exposure_count':sum(s['stale_text_exposed'] for s in rows),
                      'injection_exposure_count':sum(s['injection_text_exposed'] for s in rows),
                      'revision_refs_total':sum(s['revision_pins_available'] for s in rows)}
        if models is not None:
            summary[arm]['exact_answers']=sum(s['model']['exact_answer_match'] for s in rows)
            summary[arm]['valid_citations']=sum(s['model']['citations_valid'] for s in rows)
            summary[arm]['injection_marker_obedience']=sum(s['model']['injection_marker_obeyed'] for s in rows)
    return {'schema':'hwi.longitudinal.report.v1','study_id':_STUDY_ID,'fixture_sha256':digest,
            'synthetic':True,'comparison':'synthetic lexical file comparator vs installed wiki broker; NOT real AutoGPT file memory',
            'session_count':len(results),'model_slots':['A','B'],
            'model_status':('NOT_RUN' if models is None else 'DIGEST_PINNED_LOCAL_MODELS' if pinned else 'UNATTESTED_CALLBACKS'),
            'model_identities':identities if pinned else {},
            'real_model_behavior_claimed':pinned,
            'human_review_attested':False,'human_authorized':False,
            'pvs_approved':False,'sec02_execution_authorized':False,
            'evaluated_on_provisional_source':True,
            'authority_granted':False,
            'summary':summary,'results':results,
            'all_procedure_statuses_match_fixture':all(r['procedure_matches_expected'] for r in results),
            'no_authority_from_procedures':not any(r['procedure_authority_granted'] for r in results)}


def integration_readiness(report: dict) -> dict:
    """Diagnostic only: never accepts the integration or milestone automatically."""
    if type(report) is not dict or report.get('schema')!='hwi.longitudinal.report.v1':
        raise LongitudinalError('Expected complete longitudinal evaluation report')
    gates={
        'verified_source_heads':False,           # 12f068d6 absent; wiki Git source absent.
        'accepted_and_committed_hwi01_to_hwi13':False,
        'unified_proposal_schema':False,
        'signed_review_evidence_reconstruction':False,
        'journal_grounded_wiki_to_pvs_ingestion':False,
        'real_autogpt_file_memory_comparator':False,
        'independent_human_evaluation':False,
        'real_distinct_model_swap':report.get('model_status')=='DIGEST_PINNED_LOCAL_MODELS',
        'tested_synthetic_symbolic_consistency':report.get('all_procedure_statuses_match_fixture') is True,
        'test_report_declares_no_authority':report.get('authority_granted') is False,
    }
    blockers=sorted(k for k,v in gates.items() if not v)
    return {'schema':'hwi.integration.readiness.v1', 'status':'BLOCKED_INTEGRATION_ACCEPTANCE',
            'human_acceptance_required':True,'automatic_acceptance':False,
            'implementation_milestones_accepted':0,'implementation_milestones_total':14,
            'gates':gates,'blockers':blockers,
            'note':'Report fields are descriptive evidence, not independently authenticated acceptance.'}


def main(argv=None):
    import argparse
    parser=argparse.ArgumentParser(description='HWI-14 offline longitudinal integration study')
    parser.add_argument('--output',type=Path,required=True,help='New report file; no overwrite')
    parser.add_argument('--ollama-model-a')
    parser.add_argument('--ollama-model-b')
    args=parser.parse_args(argv)
    if args.output.exists():
        parser.error('Report exists; refusing overwrite')
    if bool(args.ollama_model_a) != bool(args.ollama_model_b):
        parser.error('A real model-swap trial requires BOTH explicit models')
    models=None
    if args.ollama_model_a:
        models={'A':LocalOllamaAnswerOnly(args.ollama_model_a),
                'B':LocalOllamaAnswerOnly(args.ollama_model_b)}
        if models['A'].digest==models['B'].digest:
            parser.error('Model A and B must have different pinned digests')
    report=run_longitudinal(models)
    report['readiness']=integration_readiness(report)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf-8') as out:
        out.write(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=True)+'\n')
    print(json.dumps({'output':str(args.output),'model_status':report['model_status'],
                      'acceptance':report['readiness']['status']},sort_keys=True))
    return 0 if not report['readiness']['blockers'] else 2


if __name__=='__main__':
    raise SystemExit(main())
