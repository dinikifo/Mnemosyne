"""HWI-10: offline wiki-to-PVS candidate and exact-match protected selection.

No PVS writes, signing keys, automatic approvals, live agent component,
model calls or SEC-02 dispatch are implemented. Every protected selection
revalidates HWI-08 signed evidence, the wiki head and the existing PVS
GovernedMemorySelector's independent source/proposal/review pins.
"""
from __future__ import annotations

import hashlib
import json

from personal_wiki_core import NotebookWorkspace
from .knowledge_broker import ReadOnlyKnowledgeBroker
from .proposals import KnowledgeProposalLedger, _canon
from .reviewed_writes import review_message, _verify_signature, _verify_operator_pin
from .recovery_inspection import inspect_application


class PvsHandoffError(RuntimeError):
    """Missing/stale evidence or unverified PVS approval; never a grant."""


def _hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def signed_review_artifact(entry: dict, signature_hex: str, reviewer_public_key: bytes) -> dict:
    """Canonical public review evidence for OUT-OF-BAND digest pinning.

    This function computes a digest, not an approval. The expected digest
    must be retained independently of the agent-generated candidate.
    """
    if type(reviewer_public_key) is not bytes or len(reviewer_public_key) != 32:
        raise PvsHandoffError('Raw 32-byte reviewer public key required')
    if type(signature_hex) is not str or len(signature_hex) != 128:
        raise PvsHandoffError('64-byte signature in hex required')
    try:
        sig = bytes.fromhex(signature_hex)
        if len(sig) != 64:
            raise ValueError('wrong length')
    except ValueError as exc:
        raise PvsHandoffError('Malformed Ed25519 signature') from exc
    return {'schema': 'hwi.review.evidence.v1',
            'proposal_id': entry['proposal_id'],
            'proposal_digest': entry['content_digest'],
            'review_message_sha256': _hash(review_message(entry)),
            'signature_hex': signature_hex,
            'reviewer_key_sha256': _hash(reviewer_public_key)}


def prepare_pvs_candidate(workspace: NotebookWorkspace, notebook_name: str,
                          ledger: KnowledgeProposalLedger, proposal_id: str, *,
                          review_signature_hex: str, reviewer_public_key: bytes,
                          expected_review_artifact_sha256: str) -> dict:
    """Read-only candidate export, never a memory approval or PVS submission.

    Requires an independently retained hash of the original signed HWI-08
    review evidence because independent custody cannot be inferred from HWI-08 local storage.
    """
    try:
        if not isinstance(workspace, NotebookWorkspace) or not isinstance(ledger, KnowledgeProposalLedger):
            raise ValueError('Trusted workspace and ledger required')
        if type(notebook_name) is not str or ledger.notebook_name != notebook_name:
            raise ValueError('Notebook name/ledger mismatch')
        if (type(expected_review_artifact_sha256) is not str
                or len(expected_review_artifact_sha256) != 64
                or any(c not in '0123456789abcdef' for c in expected_review_artifact_sha256)):
            raise ValueError('Independently retained review-evidence SHA-256 pin required')
        report = inspect_application(workspace, notebook_name, ledger, proposal_id)
        if (report['status'] != 'APPLIED_LOCALLY_LEDGER_OPEN'
                or report['wiki_receipt_consistent'] is not True):
            raise ValueError('Current, consistent local application required')
        entry = ledger.get(proposal_id)
        rec = entry['record']
        if rec['operation'] not in ('create', 'revise'):
            raise ValueError('Only materialized create/revise notes may be memory candidates')
        if rec['notebook_scope'] != ledger.namespace:
            raise ValueError('Notebook scope mismatch')
        artifact = signed_review_artifact(entry, review_signature_hex, reviewer_public_key)
        if _hash(_canon(artifact).encode('ascii')) != expected_review_artifact_sha256:
            raise ValueError('Review artifact differs from independently retained digest')
        _verify_operator_pin(workspace, notebook_name, ledger.namespace, reviewer_public_key)
        signer_sha = _verify_signature(entry, review_signature_hex, reviewer_public_key)
        reason = 'HWI08 signed proposal ' + proposal_id + ': ' + rec['reason']
        with ReadOnlyKnowledgeBroker(workspace, notebook_name) as broker:
            if broker.namespace != ledger.namespace:
                raise ValueError('Wiki instance changed')
            with workspace.open_notebook(notebook_name, readonly=True) as wiki:
                wiki._db.conn.execute('PRAGMA query_only=ON')
                wiki._db.conn.execute('BEGIN')
                conn = wiki._db.conn
                footprints = conn.execute(
                    'SELECT event_id,post_id FROM hist.events WHERE reason=?', (reason,)).fetchall()
                receipts = conn.execute('SELECT reviewer_key_sha256 FROM hist.hwi08_receipts '
                                        'WHERE proposal_id=?', (proposal_id,)).fetchall()
                if len(footprints) != 1 or len(receipts) != 1 or receipts[0]['reviewer_key_sha256'] != signer_sha:
                    raise ValueError('Review signature does not bind the observed wiki receipt')
                event_id, post_id = footprints[0]['event_id'], footprints[0]['post_id']
            reference = broker._ref(post_id, event_id)
            note = broker.read(reference, max_text_chars=4096)
            if (note['text_truncated'] or note['fields_truncated'] or note['tags_truncated']
                    or note['title_truncated'] or note['event_id'] != event_id
                    or note['knowledge_id'] != post_id):
                raise ValueError('Candidate cannot be sourced from truncated/stale knowledge')
            if {k:note[k] for k in ('title','text','tags','fields')} != rec['after']:
                raise ValueError('Current note differs from exact signed proposal')
            body = {'schema':'hwi.pvs.wiki.candidate.v1',
                    'source':{'kind':'UNTRUSTED_WIKI_REVISION',
                              'reference':reference,
                              'revision_sha256':note['revision_sha256'],
                              'proposal_id':proposal_id,
                              'proposal_digest':entry['content_digest']},
                    'note':rec['after']}
            memory_text = _canon(body)
            if (not memory_text.strip() or len(memory_text) > 6000
                    or any((ord(c) < 32 and c not in '\n\t') or ord(c) == 127
                           for c in memory_text)):
                raise ValueError('Candidate cannot fit the existing PVS memory text contract')
        # Do not claim the external digest has independent custody; the API
        # can compare pins, not establish who retained them.
        return {'schema':'hwi.pvs.handoff.v1',
                'status':'CANDIDATE_NOT_PVS_APPROVED',
                'notebook_scope':ledger.namespace,
                'proposal_id':proposal_id,
                'source_reference':reference,
                'source_revision_sha256':note['revision_sha256'],
                'review_evidence_sha256':expected_review_artifact_sha256,
                'memory_text':memory_text,
                'memory_text_sha256':_hash(memory_text.encode('utf-8')),
                'hwi08_key_signature_verified':True,
                'pvs_approved':False, 'execution_authorized':False,
                'human_identity_established':False, 'external_custody_established':False}
    except PvsHandoffError:
        raise
    except Exception as exc:
        raise PvsHandoffError('Wiki/PVS handoff evidence missing, stale, or untrusted') from exc


def select_protected_wiki_memory(workspace: NotebookWorkspace, notebook_name: str,
                                 ledger: KnowledgeProposalLedger, proposal_id: str, *,
                                 review_signature_hex: str, reviewer_public_key: bytes,
                                 expected_review_artifact_sha256: str,
                                 expected_memory_text_sha256: str,
                                 selector: object) -> dict:
    """Offline proof of an *exact* current PVS approval for one wiki revision.

    Not registered as an agent MessageProvider. Runtime integration would
    require a separate SEC-02-reviewed path. Never treats a wiki signature
    or a PVS receipt alone as authorization.
    """
    try:
        # Optional agent/PVS source; packaged wiki must import without it.
        from research_memory.pvs_memory_selector import GovernedMemorySelector
        if type(selector) is not GovernedMemorySelector:
            raise ValueError('Trusted PVS selector class required')
        if selector.credential_registry is None:
            raise ValueError('Credential revocation enforcement is mandatory in HWI-10')
        if (type(expected_memory_text_sha256) is not str
                or len(expected_memory_text_sha256) != 64
                or any(c not in '0123456789abcdef' for c in expected_memory_text_sha256)):
            raise ValueError('Independent candidate content pin required')
        def recheck():
            return prepare_pvs_candidate(
                workspace, notebook_name, ledger, proposal_id,
                review_signature_hex=review_signature_hex,
                reviewer_public_key=reviewer_public_key,
                expected_review_artifact_sha256=expected_review_artifact_sha256)
        before = recheck()
        if before['memory_text_sha256'] != expected_memory_text_sha256:
            raise ValueError('Candidate differs from independently retained pin')
        current = selector.select()  # independent PVS/journal/reviewer/credential verification
        if (type(current) is not dict
                or current.get('status') != 'SIGNED_CREDENTIAL_REVIEW_CURRENT'
                or current.get('credential_revocation_enforced') is not True
                or current.get('memory_text') != before['memory_text']):
            raise ValueError('No exact current PVS approval for this wiki revision')
        after = recheck()
        if after != before:
            raise ValueError('Wiki evidence moved during protected selection')
        return {'schema':'hwi.pvs.selection.v1',
                'status':'CURRENT_PVS_APPROVAL_MATCHED',
                'source_reference':before['source_reference'],
                'source_revision_sha256':before['source_revision_sha256'],
                'memory_text':before['memory_text'],
                'memory_text_sha256':before['memory_text_sha256'],
                'pvs_candidate_sha256':current['candidate_sha256'],
                'pvs_source_head_sha256':current['source_head_sha256'],
                'pvs_review_fingerprint':current['memory_review_fingerprint'],
                'pvs_approved_for_memory':True,
                'credential_revocation_enforced':True,
                'llm_prompt_attached':False,
                'execution_authorized':False,
                'human_identity_established':False}
    except PvsHandoffError:
        raise
    except Exception as exc:
        raise PvsHandoffError('Protected PVS/wiki selection refused: manual inspection required') from exc
