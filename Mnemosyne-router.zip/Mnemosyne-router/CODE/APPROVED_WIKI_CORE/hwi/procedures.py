"""HWI-12: read-only, advisory evaluation of untrusted reusable procedures.

A conditionally applicable procedure is NOT validated competence, approval,
permission to execute, or proof that a recorded failure catalogue is complete.
"""
from __future__ import annotations

from datetime import date
import json
import re
from typing import Any

from .knowledge_broker import ReadOnlyKnowledgeBroker
from .symbolic_rules import SymbolicRuleError, infer


class ProcedureError(ValueError):
    """Invalid procedure or unsupported evidence input; no partial approval."""


_NAME = re.compile(r"^[a-z][a-z0-9_.:-]{0,79}$")
_REF = re.compile(r"^(?:hwi05://[0-9a-f]{64}/[0-9a-f]{32}@[1-9][0-9]*|journal:[A-Za-z0-9._:-]{1,100})$")
_MAX_CASES = 12
_MAX_STEPS = 16


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ProcedureError(reason)


def _keys(obj: Any, required: set[str], optional: set[str] = frozenset()) -> None:
    _require(type(obj) is dict and required.issubset(obj) and not set(obj) - required - optional,
             'Invalid or unknown procedure fields')


def _name(value: Any) -> str:
    _require(type(value) is str and _NAME.fullmatch(value) is not None, 'Invalid symbolic identifier')
    return value


def _text(value: Any, maximum: int, label: str) -> str:
    _require(type(value) is str and 0 < len(value.strip()) <= maximum and len(value) <= maximum,
             f'Invalid {label}')
    return value


def _ref(value: Any) -> str:
    _require(type(value) is str and _REF.fullmatch(value) is not None,
             'Invalid claimed journal or revision reference')
    return value


def _day(value: Any) -> date:
    _require(type(value) is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}', value) is not None,
             'Expected canonical YYYY-MM-DD')
    try:
        result = date.fromisoformat(value)
    except ValueError as e:
        raise ProcedureError('Invalid calendar date') from e
    _require(result.isoformat() == value, 'Noncanonical date')
    return result


def _window(obj: dict, *, required: bool) -> tuple[date | None, date | None]:
    start = _day(obj['valid_from']) if 'valid_from' in obj else None
    end = _day(obj['valid_until']) if 'valid_until' in obj else None
    if required:
        _require(start is not None and end is not None, 'Failure conditions need a bounded period')
    _require(start is None or end is None or start < end, 'Invalid validity window')
    return start, end


def _atoms(values: Any, maximum: int, *, nonempty: bool = True) -> list[str]:
    _require(type(values) is list and (1 if nonempty else 0) <= len(values) <= maximum,
             'Invalid atom list length')
    result = [_name(v) for v in values]
    _require(len(set(result)) == len(result), 'Duplicate atoms')
    return result


def _validate(procedure: Any) -> dict:
    _keys(procedure, {'schema', 'procedure_id', 'title', 'preconditions', 'steps', 'failure_cases'},
          {'postconditions', 'valid_from', 'valid_until'})
    _require(procedure['schema'] == 'hwi.procedure.v1', 'Unsupported procedure schema')
    _name(procedure['procedure_id'])
    _text(procedure['title'], 160, 'title')
    _atoms(procedure['preconditions'], 16)
    _atoms(procedure.get('postconditions', []), 16, nonempty=False)
    _window(procedure, required=False)
    steps = procedure['steps']
    _require(type(steps) is list and 1 <= len(steps) <= _MAX_STEPS, 'Invalid step list')
    seen_steps: set[str] = set()
    for step in steps:
        _keys(step, {'step_id', 'description'}, {'expected_observation'})
        step_id = _name(step['step_id'])
        _require(step_id not in seen_steps, 'Duplicate step IDs')
        seen_steps.add(step_id)
        _text(step['description'], 400, 'step description')
        if 'expected_observation' in step:
            _text(step['expected_observation'], 300, 'expected observation')
    cases = procedure['failure_cases']
    _require(type(cases) is list and len(cases) <= _MAX_CASES, 'Too many failure cases')
    seen: set[str] = set()
    for case in cases:
        _keys(case, {'case_id', 'when_all', 'valid_from', 'valid_until', 'observation', 'evidence_refs'})
        name = _name(case['case_id'])
        _require(name not in seen, 'Duplicate failure case IDs')
        seen.add(name)
        _atoms(case['when_all'], 16)
        _window(case, required=True)
        _text(case['observation'], 400, 'failure observation')
        refs = case['evidence_refs']
        _require(type(refs) is list and 1 <= len(refs) <= 8, 'Failure case needs bounded evidence claims')
        for ref in refs:
            _ref(ref)
        _require(len(set(refs)) == len(refs), 'Duplicate failure evidence references')
    # Canonical copy: callers mutating the input afterwards cannot alter a result's source snapshot.
    return json.loads(json.dumps(procedure, sort_keys=True, ensure_ascii=True, allow_nan=False))


def _aggregate(checks: list[dict]) -> dict:
    return {'supporting_refs': sorted({x for c in checks for x in c['supporting_refs']}),
            'opposing_refs': sorted({x for c in checks for x in c['opposing_refs']}),
            'rule_refs': sorted({x for c in checks for x in c['rule_refs']}),
            'missing_atoms': sorted({x for c in checks for x in c['missing_atoms']})}


def assess_procedure(procedure: dict, facts: list[dict], rules: list[dict], *, at: str) -> dict:
    """Assess declared applicability and *conditional* negative knowledge.

    Statuses: CONDITIONALLY_APPLICABLE, NOT_APPLICABLE, UNRESOLVED.
    Even CONDITIONALLY_APPLICABLE does not mean that steps are safe or authorized.
    """
    source = _validate(procedure)
    on = _day(at)
    _require(type(facts) is list and type(rules) is list, 'Facts/rules must be lists')
    # HWI-11 validates the asserted facts and rules; no facts are invented here.
    try:
        prerequisites = [{"atom": atom, **infer(facts, rules, goal=atom, at=at)}
                         for atom in source['preconditions']]
        failure_checks = []
        for case in source['failure_cases']:
            start, end = _window(case, required=True)
            if not start <= on < end:
                expired = on >= end
                failure_checks.append({'case_id':case['case_id'],
                    'status':'EXPIRED_NEEDS_REVALIDATION' if expired else 'NOT_YET_ACTIVE',
                    'reason':'historical_failure_requires_revalidation' if expired else 'failure_window_not_started',
                    'evidence_refs_claimed':case['evidence_refs'], 'atom_checks':[]})
                continue
            evaluations = [{'atom':atom, **infer(facts,rules,goal=atom,at=at)}
                           for atom in case['when_all']]
            statuses = [x['status'] for x in evaluations]
            status = ('NOT_TRIGGERED' if 'VIOLATED' in statuses else
                      'TRIGGERED' if all(s == 'VERIFIED' for s in statuses) else 'UNRESOLVED')
            failure_checks.append({'case_id':case['case_id'], 'status':status,
                'reason':'conditional_failure_' + status.lower(),
                'evidence_refs_claimed':case['evidence_refs'], 'atom_checks':evaluations})
    except SymbolicRuleError as e:
        raise ProcedureError('Invalid symbolic evidence or rule input') from e
    active_from, active_until = _window(source, required=False)
    active = ((active_from is None or active_from <= on) and
              (active_until is None or on < active_until))
    violated = any(x['status'] == 'VIOLATED' for x in prerequisites)
    triggered = any(x['status'] == 'TRIGGERED' for x in failure_checks)
    unresolved = (any(x['status'] == 'UNKNOWN' for x in prerequisites) or
                  any(x['status'] in ('UNRESOLVED', 'EXPIRED_NEEDS_REVALIDATION')
                      for x in failure_checks))
    if not active:
        status, reason = 'NOT_APPLICABLE', 'outside_procedure_window'
    elif violated:
        status, reason = 'NOT_APPLICABLE', 'prerequisite_violation'
    elif triggered:
        status, reason = 'NOT_APPLICABLE', 'known_failure_condition_triggered'
    elif unresolved:
        status, reason = 'UNRESOLVED', 'incomplete_or_conflicting_evidence'
    else:
        status, reason = 'CONDITIONALLY_APPLICABLE', 'declared_conditions_satisfied'
    all_checks = prerequisites + [x for case in failure_checks for x in case['atom_checks']]
    return {'schema':'hwi.procedure.assessment.v1', 'procedure_id':source['procedure_id'],
            'evaluated_at':at, 'status':status, 'reason':reason,
            'prerequisite_checks':prerequisites, 'failure_checks':failure_checks,
            'postconditions_unverified':source.get('postconditions', []),
            'steps_are_untrusted_guidance':True, 'steps_count':len(source['steps']),
            'known_failure_catalog_complete':False, 'premises_authenticated':False,
            'human_authorized':False, 'procedure_reviewed':False,
            'pvs_approved':False, 'execution_authorized':False,
            'suitable_for_governed_prompt':False, **_aggregate(all_checks)}


def _unique_object_pairs(items: list[tuple[str, Any]]) -> dict:
    obj = {}
    for key, value in items:
        if key in obj:
            raise ValueError('Duplicate JSON keys')
        obj[key] = value
    return obj


def assess_procedure_from_broker(broker: ReadOnlyKnowledgeBroker, procedure_ref: str,
                                 assertion_refs: list[str], *, at: str) -> dict:
    """Read a procedure from a current, untrusted wiki revision and check typed evidence.

    Never follows instructions in wiki prose. Broker and HWI-11 enforce the
    current-revision, scope, and restricted-PVS boundaries.
    """
    if not isinstance(broker, ReadOnlyKnowledgeBroker):
        raise ProcedureError('A read-only knowledge broker is required')
    _require(type(procedure_ref) is str, 'Revision-bound procedure reference required')
    _require(type(assertion_refs) is list and 1 <= len(assertion_refs) <= 20 and
             all(type(x) is str for x in assertion_refs) and len(set(assertion_refs)) == len(assertion_refs)
             and procedure_ref not in assertion_refs, 'Expected distinct evidence revision references')
    record = broker.read(procedure_ref)
    _require(record['ref'] == procedure_ref and record['fields_truncated'] is False,
             'Truncated or mismatched procedure revision')
    labels = record['labels']
    _require(labels.get('content_class') == 'untrusted_wiki_data' and labels.get('pvs_approved') is False,
             'Restricted or incorrectly labeled record')
    fields = record['fields']
    _require(type(fields) is dict and fields.get('hwi12_kind') == 'procedure' and
             type(fields.get('hwi12_payload')) is str, 'Missing typed procedure fields')
    raw = fields['hwi12_payload']
    _require(len(raw) <= 5800, 'Oversized procedure payload')
    try:
        procedure = json.loads(raw, object_pairs_hook=_unique_object_pairs,
            parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    except (ValueError, TypeError, RecursionError) as e:
        raise ProcedureError('Malformed procedure JSON') from e
    # Reuse HWI-11's source-ref derivation, strict assertion parser, and notebook protection.
    from .symbolic_rules import _no_duplicate_fields
    facts = []
    rules = []
    for reference in assertion_refs:
        item = broker.read(reference)
        _require(item['ref'] == reference and not item['fields_truncated'] and
                 item['labels'].get('content_class') == 'untrusted_wiki_data' and
                 item['labels'].get('pvs_approved') is False, 'Untrusted typed record required')
        fs = item['fields']
        _require(type(fs) is dict and type(fs.get('hwi11_payload')) is str and
                 len(fs['hwi11_payload']) <= 1200, 'Malformed symbolic record')
        try:
            value = json.loads(fs['hwi11_payload'], object_pairs_hook=_no_duplicate_fields,
                               parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        except (ValueError, TypeError, RecursionError) as e:
            raise ProcedureError('Malformed symbolic record JSON') from e
        _require(type(value) is dict and 'source_ref' not in value,
                 'Source reference must be derived from broker revision')
        value = {**value, 'source_ref':reference}
        if fs.get('hwi11_kind') == 'fact':
            facts.append(value)
        elif fs.get('hwi11_kind') == 'rule':
            rules.append(value)
        else:
            raise ProcedureError('Unsupported symbolic record kind')
    result = assess_procedure(procedure, facts, rules, at=at)
    return {**result, 'procedure_ref':procedure_ref,
            'input_refs':sorted(assertion_refs), 'source_namespace':broker.namespace,
            'source_claims_are_untrusted':True}
