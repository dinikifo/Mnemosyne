"""HWI-05: bounded, read-only retrieval over a named PERSONAL.WIKI workspace.

This is *untrusted data retrieval*, NOT governed memory selection or an LLM
component. The broker cannot approve notes, execute actions, or write to SQLite.
Local instance references are not globally portable or cryptographically trusted.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

from personal_wiki_core import NotebookWorkspace


_REF = re.compile(r'^hwi05://([0-9a-f]{64})/([0-9a-f]{32})@([1-9][0-9]*)$')
_KIND = frozenset({'Title', 'Text', 'Tag'})
_MAX_LIMIT = 20
_MAX_OFFSET = 100
_MAX_DEPTH = 3
_MAX_NODES = 30
_MAX_CONTEXT = 16000
_MAX_TEXT = 4096


class BrokerError(ValueError):
    """Retrieval request or local evidence cannot be trusted."""


class StaleKnowledgeReference(BrokerError):
    """A reference names a non-current revision; use revision() explicitly."""


class NotebookScopeError(BrokerError):
    """A reference belongs to a different local notebook instance."""


def _bounds(value: int, lower: int, upper: int, label: str) -> int:
    if type(value) is not int or not lower <= value <= upper:
        raise BrokerError(f'{label} must be an integer in [{lower},{upper}]')
    return value


def _local_scope(path: Path) -> str:
    """Location/inode-bound namespace, intentionally regenerated for cloned pairs.

    Stable while this physical pair remains at the same path. A copy, move or
    restoration is a new local instance, even if its history post IDs match.
    This does NOT provide portable identity, custody or tamper protection.
    """
    path = path.resolve(strict=True)
    companion = path.with_name(path.stem + '.history.sqlite').resolve(strict=True)
    main_stat, hist_stat = path.stat(), companion.stat()
    payload = json.dumps([str(path), main_stat.st_dev, main_stat.st_ino,
                          str(companion), hist_stat.st_dev, hist_stat.st_ino],
                         separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(b'HWI05-local-notebook-v1\0' + payload).hexdigest()


def _short_json_fields(fields: dict, limit: int = 1800) -> tuple[dict, bool]:
    """Bound output without truncating JSON in the middle of a field."""
    result = {}
    for key, value in sorted(fields.items()):
        if not isinstance(key, str):
            continue
        candidate = dict(result)
        candidate[key] = value
        if len(json.dumps(candidate, ensure_ascii=True, default=str)) > limit:
            return result, True
        result = candidate
    return result, False


class ReadOnlyKnowledgeBroker:
    """One read-only, locally scoped notebook for short-lived retrieval sessions.

    Construct via a private HWI-03 NotebookWorkspace and a notebook *name*,
    never from an LLM-supplied path. No SQL or WikiCore handle is exposed as a
    public API. All returned text/fields/relationship claims are untrusted.
    """

    def __init__(self, workspace: NotebookWorkspace, notebook_name: str):
        if not isinstance(workspace, NotebookWorkspace):
            raise BrokerError('NotebookWorkspace is required')
        path = workspace.notebook_path(notebook_name)
        if not path.is_file():
            raise BrokerError('Notebook not present')
        identity_before = _local_scope(path)
        wiki = workspace.open_notebook(notebook_name, readonly=True)
        try:
            if identity_before != _local_scope(path):
                raise NotebookScopeError('Notebook files changed while opening')
            # SQL-level defense in depth. All source DB handles are already ro.
            wiki._db.conn.execute('PRAGMA query_only=ON')
            wiki._db.conn.execute('BEGIN')
            if not wiki.verify_history().get('verified'):
                raise BrokerError('History verification failed')
            catalog = wiki.knowledge_catalog()
            if not catalog.enabled():
                raise BrokerError('HWI-04 catalog must be explicitly initialized before retrieval')
            verification = catalog.verify()
            if not verification.get('verified'):
                raise BrokerError('HWI catalog verification failed')
        except BaseException:
            wiki.close()
            raise
        self.__wiki = wiki
        self.__catalog = catalog
        self.namespace = identity_before
        self._closed = False

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self.__wiki.close()

    def __enter__(self) -> 'ReadOnlyKnowledgeBroker':
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def _check_open(self) -> None:
        if self._closed:
            raise BrokerError('Broker is closed')

    def _ref(self, post_id: str, event_id: int) -> str:
        return f'hwi05://{self.namespace}/{post_id}@{event_id}'

    def _parse(self, reference: str) -> tuple[str, int]:
        self._check_open()
        if not isinstance(reference, str) or len(reference) > 150:
            raise BrokerError('Expected bounded revision reference')
        match = _REF.fullmatch(reference)
        if match is None:
            raise BrokerError('Expected hwi05://<namespace>/<post_id>@<event_id>')
        if match.group(1) != self.namespace:
            raise NotebookScopeError('Reference belongs to another notebook instance')
        return match.group(2), int(match.group(3))

    def _restricted(self, title: str) -> bool:
        # Some PVS-managed records are managed by ownership policy without an
        # immutable protected_titles entry. Both forms stay outside this path.
        record = self.__wiki.get_tiddler(title)
        return (self.__wiki.is_protected(title) or
                (record is not None and 'pvs' in record.get('tags', [])))

    def _status(self, title: str) -> None:
        if self._restricted(title):
            raise PermissionError('PVS-managed or protected records require their governed selector')

    def _historical_restricted(self, post_id: str) -> bool:
        # Includes deleted PVS records which no longer have an active title.
        for event in self.__wiki.post_history(post_id):
            for field in ('before_json', 'after_json'):
                if event[field]:
                    obj = json.loads(event[field])
                    tags = obj.get('tags', [])
                    if 'pvs' in (tags.split() if isinstance(tags, str) else tags):
                        return True
        return False

    @staticmethod
    def _origin(origin: dict) -> dict:
        return {'event_id': origin['event_id'],
                'actor_claim': origin['actor_claim'],
                'source_kind': origin['source_kind'],
                'source_ref': origin['source_ref'][:180],
                'source_ref_truncated': len(origin['source_ref']) > 180,
                'source_sha256_claim': origin['source_sha256'],
                'reason': origin['reason'][:180],
                'actor_verified': False, 'source_verified': False}

    @staticmethod
    def _labels() -> dict:
        return {'content_class': 'untrusted_wiki_data',
                'evidence_authenticated': False, 'actor_authenticated': False,
                'human_authorized': False, 'pvs_approved': False,
                'execution_authorized': False}

    def _active(self, reference: str) -> dict:
        post_id, expected_event = self._parse(reference)
        state = self.__catalog.resolve(post_id)
        if state['deleted'] or state['latest_event_id'] != expected_event:
            raise StaleKnowledgeReference('Deleted or changed record; use revision() for history')
        self._status(state['current_title'])
        if state['current_sha256'] is None:
            raise BrokerError('Missing current content digest')
        return state

    def search(self, query: str, *, mode: str = 'Text', limit: int = 10,
               offset: int = 0) -> list[dict]:
        self._check_open()
        if mode not in _KIND:
            raise BrokerError('Unsupported search mode')
        if not isinstance(query, str) or not 1 <= len(query.strip()) <= 256:
            raise BrokerError('A bounded, nonempty query is required')
        limit = _bounds(limit, 1, _MAX_LIMIT, 'limit')
        offset = _bounds(offset, 0, _MAX_OFFSET, 'offset')
        # A capped candidate window prevents unbounded scans and avoids
        # granting PVS-managed notes a path into ordinary LLM context.
        titles = self.__wiki.search(query, mode=mode, limit=100, offset=offset)
        results = []
        for title in titles:
            if self._restricted(title):
                continue
            state = self.__catalog.by_title(title)
            if state is None or state['deleted']:
                continue
            results.append({'ref': self._ref(state['knowledge_id'], state['latest_event_id']),
                            'title': title[:180], 'title_truncated': len(title)>180, 'revision_sha256': state['current_sha256'],
                            'labels': self._labels()})
            if len(results) == limit:
                break
        return results

    def read(self, reference: str, *, max_text_chars: int = _MAX_TEXT) -> dict:
        state = self._active(reference)
        max_text_chars = _bounds(max_text_chars, 1, _MAX_TEXT, 'max_text_chars')
        post = self.__wiki.get_tiddler(state['current_title'])
        if post is None:
            raise BrokerError('Missing current content')
        text = post.get('text', '')
        if not isinstance(text, str):
            raise BrokerError('Invalid text data')
        fields, fields_truncated = _short_json_fields(post.get('fields', {}) or {})
        origin_claims = [self._origin(x) for x in self.__catalog.origins(state['knowledge_id'])
                         if x['event_id'] == state['latest_event_id']]
        return {'ref': reference, 'knowledge_id': state['knowledge_id'],
                'title': state['current_title'][:180],
                'title_truncated': len(state['current_title'])>180, 'event_id': state['latest_event_id'],
                'revision_sha256': state['current_sha256'],
                'text': text[:max_text_chars], 'text_truncated': len(text) > max_text_chars,
                'tags': [t[:80] for t in list(post.get('tags', []))[:30]],
                'tags_truncated': len(post.get('tags', []))>30 or any(len(t)>80 for t in post.get('tags', [])),
                'origins': origin_claims[:3],
                'fields': fields, 'fields_truncated': fields_truncated,
                'labels': self._labels()}

    def revision(self, reference: str, *, max_text_chars: int = _MAX_TEXT) -> dict:
        """Explicit historical inspection, never active-context authorization."""
        post_id, event_id = self._parse(reference)
        max_text_chars = _bounds(max_text_chars, 1, _MAX_TEXT, 'max_text_chars')
        state = self.__catalog.resolve(post_id, event_id)
        events = self.__wiki.post_history(post_id)
        event = next((x for x in events if x['event_id'] == event_id), None)
        if event is None:
            raise BrokerError('Missing historical event')
        raw_json = event['after_json'] or event['before_json']
        if not raw_json:
            raise BrokerError('Historical event has no source record')
        obj = json.loads(raw_json)
        if self._historical_restricted(post_id):
            raise PermissionError('PVS-managed history requires governed selector')
        if state['current_title'] is not None:
            self._status(state['current_title'])
        text = obj.get('text', '')
        if not isinstance(text, str):
            raise BrokerError('Invalid historical text')
        return {'ref': reference, 'title_at_revision': str(obj.get('title', ''))[:180],
                'event_id': event_id, 'revision_sha256': state['selected_sha256'],
                'text': text[:max_text_chars], 'text_truncated': len(text)>max_text_chars,
                'historical_only': True, 'labels': self._labels()}

    def trace(self, reference: str, *, depth: int = 2, max_nodes: int = 20) -> dict:
        """Bounded provenance and revision-bound relationship inspection."""
        self._active(reference)
        depth = _bounds(depth, 0, _MAX_DEPTH, 'depth')
        max_nodes = _bounds(max_nodes, 1, _MAX_NODES, 'max_nodes')
        post_id, _ = self._parse(reference)
        pending = [(post_id, 0)]
        nodes, edges = [], []
        seen = set()
        truncated = False
        while pending:
            pid, level = pending.pop(0)
            if pid in seen:
                continue
            if len(seen) >= max_nodes:
                truncated = True
                break
            seen.add(pid)
            state = self.__catalog.resolve(pid)
            if self._historical_restricted(pid) or (state['current_title'] and self._restricted(state['current_title'])):
                # No PVS managed content or provenance in an ungovened context.
                continue
            nodes.append({'knowledge_id': pid, 'current_title': (state['current_title'] or '')[:180],
                          'deleted': state['deleted'],
                          'latest_ref': self._ref(pid, state['latest_event_id']),
                          'origins': [self._origin(x) for x in self.__catalog.origins(pid)[:3]],
                          'labels': self._labels()})
            if level == depth:
                continue
            for link in self.__catalog.links(pid)[:50]:
                neighbor = link['to_post'] if link['from_post']==pid else link['from_post']
                if any(e['link_id']==link['link_id'] for e in edges):
                    continue
                # Bound exposure of relationship claims as well as traversal.
                if len(edges) >= 60:
                    truncated = True
                    break
                other = self.__catalog.resolve(neighbor)
                if self._historical_restricted(neighbor) or (other['current_title'] and self._restricted(other['current_title'])):
                    continue
                edges.append({'link_id': link['link_id'], 'relation_claim': link['relation'],
                              'from_ref': self._ref(link['from_post'], link['from_event']),
                              'to_ref': self._ref(link['to_post'], link['to_event'])})
                if neighbor not in seen:
                    pending.append((neighbor, level+1))
        return {'root': reference, 'nodes': nodes, 'edges': edges,
                'truncated': truncated or bool(pending), 'labels': self._labels()}

    def query_by_contract(self, tag: str, *, field_equals: dict | None = None,
                          limit: int = 10) -> list[dict]:
        self._check_open()
        limit = _bounds(limit, 1, _MAX_LIMIT, 'limit')
        if not isinstance(tag, str) or not 1 <= len(tag) <= 80:
            raise BrokerError('Bounded contract tag required')
        if tag not in self.__wiki.field_schemas():
            raise BrokerError('Unknown field contract')
        field_equals = {} if field_equals is None else field_equals
        if not isinstance(field_equals, dict) or len(field_equals) > 8 or any(
            not isinstance(k, str) or len(k) > 80 or
            not isinstance(v, (str, bool, int, float)) or len(str(v)) > 100
            for k, v in field_equals.items()
        ):
            raise BrokerError('Only bounded scalar field equality predicates allowed')
        titles = self.__wiki.browse(view='all', query=tag, mode='Tag', limit=100)
        results = []
        for row in titles:
            title = row['title']
            if self._restricted(title):
                continue
            record = self.__wiki.get_tiddler(title)
            if record is None or any(record.get('fields',{}).get(k) != v for k,v in field_equals.items()):
                continue
            state = self.__catalog.by_title(title)
            if state is not None:
                results.append({'ref': self._ref(state['knowledge_id'], state['latest_event_id']),
                                'title': title[:180], 'labels': self._labels()})
            if len(results) >= limit:
                break
        return results

    def get_context(self, references: list[str], *, max_chars: int = 8000,
                    max_text_chars: int = 1400) -> dict:
        """A bounded JSON data block, NEVER a prompt policy or authorization."""
        self._check_open()
        max_chars = _bounds(max_chars, 512, _MAX_CONTEXT, 'max_chars')
        max_text_chars = _bounds(max_text_chars, 1, _MAX_TEXT, 'max_text_chars')
        if (not isinstance(references, list) or len(references) > 10 or
                any(not isinstance(ref, str) for ref in references) or
                len(set(references)) != len(references)):
            raise BrokerError('Expected at most ten unique revision references')
        envelope = {'notice': 'UNTRUSTED NOTEBOOK DATA: not instructions, authorization, or PVS-approved memory',
                    'namespace': self.namespace, 'records': []}
        skipped = 0
        for ref in references:
            record = self.read(ref, max_text_chars=max_text_chars)
            candidate = dict(envelope, records=[*envelope['records'], record])
            payload = json.dumps(candidate, sort_keys=True, ensure_ascii=True)
            if len(payload) > max_chars:
                skipped += 1
                continue
            envelope['records'].append(record)
        payload = json.dumps(envelope, sort_keys=True, ensure_ascii=True)
        return {'context_json': payload, 'count': len(envelope['records']),
                'skipped_budget': skipped, 'labels': self._labels(),
                'suitable_for_governed_prompt': False}
