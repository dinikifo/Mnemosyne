"""C8 — read-only inspection before operator-controlled HWI restart.

An inspection report is not a credential, an approval, a retry permit, or a
provider. External operators must independently retain the state/journal pins
and provision the C7 guard again in a new process.
"""
from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

from .operator_startup import prepare_hwi_operator_provider

_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_MAX_STATE_BYTES = 16 * 1024 * 1024


class HwiOperatorHandoffError(ValueError):
    """The independent restart witness cannot be established."""


def _read_state_digest(store, agent_id):
    """Read the exact stored JSON under AgentStore's descriptor-anchored root."""
    from autogpt_lite.persistence.store import _validate_agent_id
    _validate_agent_id(agent_id)
    root = store._root_fd()
    try:
        agent = store._agent_fd(root, agent_id)
        try:
            fd = store._open_state(agent)
            with os.fdopen(fd, 'rb') as stream:
                raw = stream.read(_MAX_STATE_BYTES + 1)
            if not raw or len(raw) > _MAX_STATE_BYTES:
                raise HwiOperatorHandoffError('State snapshot missing or outside size bound')
            return hashlib.sha256(raw).hexdigest()
        finally:
            os.close(agent)
    finally:
        os.close(root)


def _blocked(agent_id, status):
    return {'schema': 'hwi.operator.handoff.v1', 'agent_id': agent_id,
            'status': status, 'operator_reprovisioning_required': True,
            'operator_decision_required': True, 'provider_provisioned': False,
            'automatic_retry_allowed': False, 'memory_approved': False,
            'execution_authorized': False}


def inspect_hwi_operator_handoff(*, store, agent_id, expected_state_sha256,
                                  expected_journal_head, expected_journal_count,
                                  config, selector, selection_kwargs):
    """Inspect an existing saved state, episode journal and C5 evidence.

    All independently retained pins must be supplied by the operator. The
    inspection never calls build_agent()/initialize(), creates a provider for
    the caller, uses state.saved_config as trust material, or writes a record.
    The source can change immediately afterward: no long-lived clearance.
    """
    from autogpt_lite.persistence.store import AgentStore
    from autogpt_lite.models import AgentConfig
    from autogpt_lite.persistence.recovery import inspect_recovery
    from .operator_startup import _C5_EVIDENCE_KEYS

    if (type(store) is not AgentStore or type(config) is not AgentConfig
            or type(agent_id) is not str or not agent_id
            or type(expected_state_sha256) is not str
            or not _SHA256.fullmatch(expected_state_sha256)
            or type(expected_journal_head) is not str
            or not _SHA256.fullmatch(expected_journal_head)
            or type(expected_journal_count) is not int or expected_journal_count < 1
            or type(selection_kwargs) is not dict
            or set(selection_kwargs) != _C5_EVIDENCE_KEYS):
        return _blocked(agent_id if type(agent_id) is str else '<invalid>',
                        'BLOCKED_MISSING_OPERATOR_PINS')
    if Path(config.agent_data_dir).resolve() != store.data_dir.resolve():
        return _blocked(agent_id, 'BLOCKED_STORE_IDENTITY')

    try:
        first = _read_state_digest(store, agent_id)
        if first != expected_state_sha256:
            return _blocked(agent_id, 'BLOCKED_STATE_PIN_MISMATCH')
        state = store.load(agent_id)
        if state is None or state.agent_id != agent_id:
            return _blocked(agent_id, 'BLOCKED_STATE_UNAVAILABLE')
        saved = state.saved_config
        # Stored settings are compared, NEVER used to supply permissions or
        # construct independently trusted keys, selector, or evidence objects.
        required = {'sec02_pilot': True,
                    'governed_memory_required': True,
                    'hwi_verified_memory_required': True,
                    'enable_code_execution': False,
                    'enable_file_manager': False,
                    'enable_web_search': False,
                    'markdown_rag_root': None}
        if (type(saved) is not dict
                or any(saved.get(k) is not v for k, v in required.items())
                or type(saved.get('memory_journal_dir')) is not str
                or Path(saved['memory_journal_dir']).resolve()
                    != Path(config.memory_journal_dir or '/').resolve()
                or any(saved.get(k) != getattr(config, k)
                       for k in ('smart_llm', 'fast_llm', 'ollama_base_url',
                                 'send_token_limit', 'max_result_tokens'))):
            return _blocked(agent_id, 'BLOCKED_SAVED_PROFILE_MISMATCH')
        recovery = inspect_recovery(state, config.memory_journal_dir)
        if recovery.get('status') != 'READY_VERIFIED':
            return _blocked(agent_id, 'BLOCKED_MANUAL_RECOVERY')
        if (recovery.get('count') != expected_journal_count
                or state.journal_receipt.get('head') != expected_journal_head
                or state.journal_receipt.get('count') != expected_journal_count):
            return _blocked(agent_id, 'BLOCKED_JOURNAL_PIN_MISMATCH')
        # Receipt head equality alone does not prove that saved working history
        # reflects the journal. Compare its retained source anchors and payloads
        # without capture_history(), which could append and is forbidden here.
        from autogpt_lite.persistence.episode_journal import (
            EpisodeJournal, episode_payload, digest,
        )
        events = EpisodeJournal(config.memory_journal_dir, agent_id,
                                create=False).replay(expected_head=expected_journal_head)
        anchored = [ep for ep in state.history
                    if ep.action.use_tool.name != '_history_summary']
        indices = [ep.source_seq for ep in anchored]
        if (not indices or any(type(idx) is not int or idx < 1 or idx > len(events)
                       for idx in indices)
                or indices != list(range(indices[0], len(events) + 1))
                or any(ep.source_sha256 != events[ep.source_seq - 1].episode_sha256
                       or digest(episode_payload(ep)) != events[ep.source_seq - 1].episode_sha256
                       for ep in anchored)):
            return _blocked(agent_id, 'BLOCKED_HISTORY_UNANCHORED')
        # C7's fresh read-only preflight must not be replaced by persisted data.
        provider = prepare_hwi_operator_provider(
            config=config, state=state, selector=selector,
            selection_kwargs=selection_kwargs)
        # Never return/serialize provider, trusted objects, or C5 private inputs.
        del provider
        if _read_state_digest(store, agent_id) != first:
            return _blocked(agent_id, 'BLOCKED_STATE_CHANGED_DURING_INSPECTION')
        if inspect_recovery(store.load(agent_id), config.memory_journal_dir) != recovery:
            return _blocked(agent_id, 'BLOCKED_JOURNAL_CHANGED_DURING_INSPECTION')
        report = _blocked(agent_id, 'READY_FOR_OPERATOR_REPROVISIONING')
        report['observed_state_sha256'] = first
        report['observed_journal_head'] = expected_journal_head
        report['observed_journal_count'] = expected_journal_count
        return report
    except Exception:
        # No path, reviewer key, internal evidence bytes, or dynamic error text
        # is allowed to escape into an operator-facing report.
        return _blocked(agent_id, 'BLOCKED_VERIFICATION_UNAVAILABLE')
