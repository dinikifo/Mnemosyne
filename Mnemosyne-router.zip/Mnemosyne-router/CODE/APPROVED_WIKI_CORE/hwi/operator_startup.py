"""C7 operator-only, fail-closed preflight for existing C6 HWI runtime.

This module neither creates reviewer trust material nor runs the model. Only
operator-constructed exact PVS selector and C5 evidence objects are accepted.
The existing AutoGPT Lite build_agent() receives the returned, already-bound
GovernedMemoryComponent; the normal CLI is deliberately unchanged.
"""
from __future__ import annotations

from pathlib import Path

from .runtime_guard import HwiProtectedSelectionGuard


class HwiOperatorStartupError(ValueError):
    """Unprovisioned, inconsistent or downgraded HWI startup was refused."""


_C5_EVIDENCE_KEYS = frozenset({
    'admission_receipt', 'expected_admission_receipt_sha256',
    'admission_plan', 'operator_public_key', 'expected_operator_key_sha256',
    'draft', 'source_kwargs', 'packet', 'pvs_context', 'review_context',
    'reviewer_public_key', 'externally_pinned_origins',
})


def prepare_hwi_operator_provider(*, config, state, selector, selection_kwargs):
    """Read-only preflight and return the *original* governed memory component.

    The operator retains custody of selector construction, evidence, keys and
    independently pinned roots. No JSON/environment loader or dynamic plugin
    discovery is involved. Callers must explicitly pass the result to the
    existing build_agent() and then initialize; neither is done here.

    Valid NO_APPROVED_MEMORY is allowed, but malformed credentials or evidence
    raise HwiOperatorStartupError and do not return a provider.
    """
    from autogpt_lite.models import AgentConfig, AgentState
    from research_memory.pvs_memory_selector import (
        GovernedMemorySelector, GovernedMemoryComponent,
    )
    try:
        if type(config) is not AgentConfig or type(state) is not AgentState:
            raise HwiOperatorStartupError('Exact agent configuration and state required')
        if (not config.sec02_pilot or not config.governed_memory_required
                or not config.hwi_verified_memory_required
                or config.enable_code_execution or config.enable_web_search
                or config.enable_file_manager or config.markdown_rag_root):
            raise HwiOperatorStartupError('Closed SEC-02 HWI configuration required')
        if (state.evidence_failure or state.current_episode is not None
                or state.context or state.directives.constraints
                or state.directives.resources or state.directives.best_practices):
            raise HwiOperatorStartupError('Saved state requires separate recovery or cleanup')
        if (type(selector) is not GovernedMemorySelector
                or selector.credential_registry is None
                or selector.journal.agent_id != state.agent_id
                or not config.memory_journal_dir
                or Path(config.memory_journal_dir).resolve()
                   != selector.journal.root.resolve()):
            raise HwiOperatorStartupError('Trusted PVS selector/journal identity required')
        if (type(selection_kwargs) is not dict
                or set(selection_kwargs) != _C5_EVIDENCE_KEYS):
            raise HwiOperatorStartupError('Complete exact C5 operator evidence required')
        # A successful C5 assessment is an integrity check, never authority.
        # Verify before allocating or initializing an agent; this function does
        # not write to a wiki, journal, proposal ledger or saved agent state.
        guard = HwiProtectedSelectionGuard(
            selector=selector, selection_kwargs=selection_kwargs)
        selected = selector.select()
        guard.verify(selected)
        return GovernedMemoryComponent(selector, hwi_guard=guard)
    except HwiOperatorStartupError:
        raise
    except Exception as exc:
        # Avoid exposing private evidence bytes or key material in an exception.
        raise HwiOperatorStartupError('HWI operator preflight refused; inspect pinned evidence') from exc
