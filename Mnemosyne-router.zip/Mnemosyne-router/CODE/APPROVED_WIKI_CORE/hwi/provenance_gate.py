"""C13: signed, bounded cross-store derivation-lineage check for C4 admission.

Requires a separately signed and externally pinned *claimed* complete ancestry.
Acyclic lineage is necessary for admission, not proof of source authenticity,
origin independence, semantic correctness, human identity or permission to act.
"""
from __future__ import annotations

import hashlib
import re
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .proposals import _canon
from .reasoning_cycles import detect_reachable_cycle, ReasoningCycleError

_SCHEMA = 'hwi.provenance.lineage.v1'
_DOMAIN = b'HWI-C13-OPERATOR-LINEAGE-ATTESTATION-V1\n'
_SHA = re.compile(r'^[0-9a-f]{64}$')
_REF = re.compile(r'^(?:external|human|tool):[A-Za-z0-9._:/-]{1,160}$')
_ID = re.compile(r'^[a-z][a-z0-9_]{0,63}$')
_KINDS = {'pvs_draft', 'wiki_revision', 'journal_event',
          'pvs_memory', 'derived_claim', 'external_origin'}
_MAX_NODES = 128
_MAX_BYTES = 65536


class ProvenanceGateError(ValueError):
    """Reject unsafe, unauthenticated or incomplete provenance claims."""


def _sha(data):
    if type(data) is not str or not _SHA.fullmatch(data):
        raise ProvenanceGateError('Lowercase SHA-256 required')
    return data


def _digest(data):
    return hashlib.sha256(_canon(data).encode('utf-8')).hexdigest()


def _fields(obj, names):
    if type(obj) is not dict or set(obj) != set(names):
        raise ProvenanceGateError('Exact provenance fields required')


def build_lineage_manifest(*, plan, witness, nodes):
    """Pure packaging of operator-supplied ancestry; does NOT certify it."""
    if type(plan) is not dict or type(witness) is not dict or type(nodes) is not list:
        raise ProvenanceGateError('Exact C4/C2 objects and explicit nodes required')
    body = dict(schema=_SCHEMA, plan_sha256=plan.get('plan_sha256'),
                witness_sha256=witness.get('witness_sha256'),
                packet_sha256=plan.get('packet_sha256'),
                draft_sha256=plan.get('draft_sha256'),
                wiki_revision_sha256=witness.get('wiki', {}).get('revision_sha256'),
                journal_head_sha256=witness.get('journal', {}).get('head_sha256'),
                goal='draft', nodes=nodes)
    return {**body, 'lineage_sha256': _digest(body)}


def audit_admission_lineage(*, manifest, expected_lineage_sha256,
                            plan, witness, externally_pinned_origins) -> dict:
    """Audit *fully disclosed* lineage against C4 plan + current C2 witness.

    External origin pins MUST come from a separately provisioned operator source.
    The function cannot independently determine whether a claimed lineage is
    complete or whether an origin is independent of earlier model output.
    """
    try:
        _sha(expected_lineage_sha256)
        _fields(manifest, ('schema','plan_sha256','witness_sha256',
            'packet_sha256','draft_sha256','wiki_revision_sha256',
            'journal_head_sha256','goal','nodes','lineage_sha256'))
        if (len(_canon(manifest).encode('utf-8')) > _MAX_BYTES
                or manifest['schema'] != _SCHEMA
                or manifest['goal'] != 'draft'
                or manifest['lineage_sha256'] != expected_lineage_sha256
                or _digest({k:v for k,v in manifest.items() if k != 'lineage_sha256'}) != expected_lineage_sha256):
            raise ProvenanceGateError('Lineage format, size or pin mismatch')
        for name in ('plan_sha256','witness_sha256','packet_sha256',
                     'draft_sha256','wiki_revision_sha256','journal_head_sha256'):
            _sha(manifest[name])
        if type(plan) is not dict:
            raise ProvenanceGateError('C4 operator plan required')
        if (manifest['plan_sha256'] != plan['plan_sha256']
                or manifest['packet_sha256'] != plan['packet_sha256']
                or manifest['draft_sha256'] != plan['draft_sha256']
                or manifest['witness_sha256'] != plan['witness_sha256']
                or manifest['witness_sha256'] != witness['witness_sha256']
                or manifest['wiki_revision_sha256'] != witness['wiki']['revision_sha256']
                or manifest['journal_head_sha256'] != witness['journal']['head_sha256']
                or manifest['journal_head_sha256'] != plan['pvs_source_head_sha256']
                or plan['candidate_text_sha256'] != witness['wiki']['memory_text_sha256']
                or _digest({k:v for k,v in witness.items() if k != 'witness_sha256'}) != witness['witness_sha256']):
            raise ProvenanceGateError('C2 witness or C4 plan identity mismatch')
        if (type(externally_pinned_origins) is not dict
                or not 1 <= len(externally_pinned_origins) <= 32):
            raise ProvenanceGateError('Externally provided origin pin map required')
        for ref, digest in externally_pinned_origins.items():
            if type(ref) is not str or _REF.fullmatch(ref) is None:
                raise ProvenanceGateError('Invalid independent origin reference')
            _sha(digest)
        nodes = manifest['nodes']
        if type(nodes) is not list or not 3 <= len(nodes) <= _MAX_NODES:
            raise ProvenanceGateError('Bounded complete provenance graph required')
        graph, kinds, journal = {}, {}, {}
        origins = set()
        content_identities = set()
        for node in nodes:
            if type(node) is not dict or node.get('kind') not in _KINDS:
                raise ProvenanceGateError('Invalid provenance node kind')
            name = node.get('id')
            if type(name) is not str or not _ID.fullmatch(name) or name in graph:
                raise ProvenanceGateError('Duplicate or invalid lineage identity')
            kind = node['kind']
            required = {'id','kind','sha256','depends_on'}
            if kind == 'journal_event':
                required |= {'seq','value_sha256'}
            if kind == 'external_origin':
                required |= {'source_ref'}
            _fields(node, required)
            sha = _sha(node['sha256'])
            deps = node['depends_on']
            if (type(deps) is not list or len(deps) > 16
                    or any(type(n) is not str or not _ID.fullmatch(n) for n in deps)
                    or len(set(deps)) != len(deps)):
                raise ProvenanceGateError('Invalid lineage dependencies')
            if kind == 'external_origin':
                ref = node['source_ref']
                if (type(ref) is not str or not _REF.fullmatch(ref)
                        or externally_pinned_origins.get(ref) != sha or deps):
                    raise ProvenanceGateError('External origin lacks an independent pin or is derived')
                if (ref, sha) in origins:
                    raise ProvenanceGateError('Duplicate origin cannot count twice')
                origins.add((ref, sha))
            elif not deps:
                raise ProvenanceGateError('Derived or journal node cannot masquerade as a root')
            if kind == 'journal_event':
                seq = node['seq']
                if type(seq) is not int or seq in journal or seq <= 0:
                    raise ProvenanceGateError('Invalid or duplicate source sequence')
                _sha(node['value_sha256'])
                journal[seq] = node
            if kind not in ('external_origin','journal_event'):
                identity = (kind, sha)
                if identity in content_identities:
                    raise ProvenanceGateError('Duplicated content under different claim IDs')
                content_identities.add(identity)
            graph[name], kinds[name] = deps, kind
        # Caller allowlist is exact: extra undisclosed external pins cannot be
        # used later to manufacture progress or an additional proof branch.
        if set(externally_pinned_origins) != {ref for ref, _ in origins}:
            raise ProvenanceGateError('External origin list does not match declared lineage')
        # Draft and current wiki identities are fixed, not arbitrary aliases.
        if (kinds.get('draft') != 'pvs_draft'
                or kinds.get('wiki') != 'wiki_revision'
                or next(n for n in nodes if n['id'] == 'draft')['sha256'] != plan['draft_sha256']
                or next(n for n in nodes if n['id'] == 'wiki')['sha256'] != witness['wiki']['revision_sha256']
                or graph['draft'] != ['wiki']):
            raise ProvenanceGateError('Current draft/wiki source route differs from C4')
        exact_anchors = witness['journal']['selected_source_refs']
        if (type(exact_anchors) is not list or not exact_anchors
                or len(journal) != len(exact_anchors)
                or graph['wiki'] != [f'journal_{r["seq"]:012d}' for r in exact_anchors]):
            raise ProvenanceGateError('Every and only the signed journal anchor must be disclosed')
        # Exact byte identity is a separate, hard evidence-laundering check:
        # the candidate's own text cannot be treated as an independent source
        # excerpt, even when a supplied parent graph falsely calls it external.
        if any(r['value_sha256'] == plan['candidate_text_sha256']
               for r in exact_anchors):
            raise ProvenanceGateError('Candidate text recycled as journal evidence')
        for anchor in exact_anchors:
            seq = anchor['seq']
            node = journal.get(seq)
            if (node is None or node['id'] != f'journal_{seq:012d}'
                    or node['sha256'] != anchor['entry_sha256']
                    or node['value_sha256'] != anchor['value_sha256']):
                raise ProvenanceGateError('Signed source excerpt not bound to provenance')
        for node in nodes:
            if node['kind'] == 'pvs_memory' and node['sha256'] == plan['candidate_text_sha256']:
                raise ProvenanceGateError('Identical PVS memory cannot corroborate its own candidate')
            if node['kind'] == 'journal_event' and node['id'] not in graph['wiki']:
                raise ProvenanceGateError('Unbound journal event')
        # Require complete reachable ancestry; no unrelated nodes can conceal a
        # different loop or be selectively activated by a later consumer.
        seen, pending = set(), ['draft']
        while pending:
            name = pending.pop()
            if name in seen:
                continue
            if name not in graph:
                raise ProvenanceGateError('Unresolved ancestor; lineage incomplete')
            seen.add(name)
            pending.extend(graph[name])
        if seen != set(graph):
            raise ProvenanceGateError('Orphan lineage nodes are not permitted')
        cycle = detect_reachable_cycle(graph, 'draft')
        status = 'CIRCULAR_DERIVATION' if cycle else (
            'ACYCLIC_CLAIMED_LINEAGE' if origins else 'NO_INDEPENDENT_ORIGIN_CLAIM')
        report = dict(schema='hwi.provenance.audit.v1', status=status,
                      plan_sha256=plan['plan_sha256'],
                      lineage_sha256=expected_lineage_sha256,
                      cycle_path=cycle, nodes_checked=len(graph),
                      externally_pinned_origin_claims=len(origins),
                      complete_parentage_independently_verified=False,
                      source_independence_proven=False,
                      semantic_truth_proven=False, pvs_approved=False,
                      execution_authorized=False)
        return {**report, 'audit_sha256': _digest(report)}
    except (KeyError, TypeError, ValueError, StopIteration, ReasoningCycleError) as exc:
        raise ProvenanceGateError('Lineage cannot be independently matched to the candidate') from exc


def provenance_operator_message(*, manifest, expected_lineage_sha256, plan,
                                witness, externally_pinned_origins) -> bytes:
    """Build exact separate C13 signing request; refuses detected cycles."""
    result = audit_admission_lineage(
        manifest=manifest, expected_lineage_sha256=expected_lineage_sha256,
        plan=plan, witness=witness,
        externally_pinned_origins=externally_pinned_origins)
    if result['status'] != 'ACYCLIC_CLAIMED_LINEAGE':
        raise ProvenanceGateError('Circular/unanchored lineage cannot be signed for admission')
    return _DOMAIN + _canon(manifest).encode('utf-8')


def verify_signed_admission_lineage(*, manifest, expected_lineage_sha256,
                                    plan, witness, externally_pinned_origins,
                                    signature_hex, operator_public_key,
                                    expected_operator_key_sha256) -> dict:
    msg = provenance_operator_message(manifest=manifest,
        expected_lineage_sha256=expected_lineage_sha256, plan=plan,
        witness=witness, externally_pinned_origins=externally_pinned_origins)
    _sha(expected_operator_key_sha256)
    if (type(operator_public_key) is not bytes or len(operator_public_key) != 32
            or hashlib.sha256(operator_public_key).hexdigest() != expected_operator_key_sha256
            or type(signature_hex) is not str or len(signature_hex) != 128):
        raise ProvenanceGateError('Externally pinned operator signature required')
    try:
        Ed25519PublicKey.from_public_bytes(operator_public_key).verify(
            bytes.fromhex(signature_hex), msg)
    except (InvalidSignature, ValueError) as exc:
        raise ProvenanceGateError('Operator provenance signature invalid') from exc
    return {'schema':'hwi.provenance.signature.verification.v1',
            'status':'SIGNED_ACYCLIC_LINEAGE_CLAIM_NOT_INDEPENDENTLY_PROVEN',
            'plan_sha256':plan['plan_sha256'],
            'lineage_sha256':expected_lineage_sha256,
            'operator_key_sha256':expected_operator_key_sha256,
            'source_independence_proven':False,
            'pvs_approved':False, 'execution_authorized':False}
