"""HWI-07: isolated, append-only *proposal* ledger, never a wiki writer.

This ledger holds untrusted agent/human *claims*, not authenticated reviews.
Submission preflights refs against HWI-05 read-only broker; HWI-08 must
revalidate current revisions inside its eventual authorized write transaction.
No method accepts a permission token, approves a proposal, or writes to PVS.
"""
from __future__ import annotations

from contextlib import contextmanager
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
from datetime import datetime, timezone
from uuid import uuid4

from personal_wiki_core import NotebookWorkspace
from .knowledge_broker import ReadOnlyKnowledgeBroker, BrokerError


_ALLOWED_OPS = frozenset({'create', 'revise', 'link', 'retire'})
_ALLOWED_RELATIONS = frozenset({'supports', 'contradicts', 'depends_on', 'supersedes',
                               'derived_from', 'references', 'restored_from'})
_EXTERNAL_REF = re.compile(r'^(?:journal|evidence|run|tool|external|human|fixture):[A-Za-z0-9._:/-]{1,220}$')
_DIGEST = re.compile(r'^[0-9a-f]{64}$')
_ID = re.compile(r'^proposal:[0-9a-f]{32}$')
_RESERVED = frozenset({'human_authorized','pvs_approved','execution_authorized',
                       'actor_authenticated','evidence_authenticated','approval',
                       'authorization','authority','auto_accept'})
_SCHEMA = '''
CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE proposals (
 proposal_id TEXT PRIMARY KEY,
 digest TEXT NOT NULL UNIQUE,
 record_json TEXT NOT NULL,
 submitted_at TEXT NOT NULL
);
CREATE TABLE events (
 event_id INTEGER PRIMARY KEY AUTOINCREMENT,
 proposal_id TEXT NOT NULL REFERENCES proposals(proposal_id),
 kind TEXT NOT NULL CHECK(kind IN ('SUBMITTED','REJECTED','WITHDRAWN')),
 actor_claim TEXT NOT NULL,
 reason TEXT NOT NULL,
 happened_at TEXT NOT NULL,
 previous_sha256 TEXT NOT NULL,
 event_sha256 TEXT NOT NULL UNIQUE
);
CREATE INDEX events_by_proposal ON events(proposal_id,event_id);
CREATE TRIGGER prevent_proposal_update BEFORE UPDATE ON proposals BEGIN SELECT RAISE(ABORT,'proposals immutable'); END;
CREATE TRIGGER prevent_proposal_delete BEFORE DELETE ON proposals BEGIN SELECT RAISE(ABORT,'proposals immutable'); END;
CREATE TRIGGER prevent_event_update BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT,'events immutable'); END;
CREATE TRIGGER prevent_event_delete BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT,'events immutable'); END;
'''


class ProposalError(ValueError):
    """Malformed, duplicate, out-of-scope, or uncertain proposal request."""


class DuplicateProposal(ProposalError):
    """Exactly the same proposal has already been recorded."""


class ProposalLedgerError(ProposalError):
    """Proposal ledger path, structure, or history is not trustworthy."""


def _canon(data: object) -> str:
    return json.dumps(data, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


def _bounded(value: str, name: str, maximum: int) -> str:
    if type(value) is not str or not value.strip() or len(value) > maximum or '\x00' in value:
        raise ProposalError(f'Expected nonempty {name} of at most {maximum} characters')
    return value.strip()


def _fields(value: object) -> dict:
    if type(value) is not dict or len(value) > 24:
        raise ProposalError('fields must be a bounded object')
    out = {}
    for key, val in value.items():
        if (type(key) is not str or not 1 <= len(key) <= 64
                or key.lower() in _RESERVED
                or key.lower() in {'title','text','tags','created','modified','parent'}
                or key.lower().startswith('pvs_')):
            raise ProposalError('Invalid or authority-looking field name')
        if type(val) not in (str, bool, int, float, type(None)):
            raise ProposalError('Only scalar typed fields supported in HWI-07')
        if type(val) is float:
            import math
            if not math.isfinite(val):
                raise ProposalError('Non-finite scalar field')
        if type(val) is str and len(val) > 512:
            raise ProposalError('Field string too long')
        out[key] = val
    return out


def _document(value: object) -> dict:
    if type(value) is not dict or set(value) != {'title','text','tags','fields'}:
        raise ProposalError('Full proposed note requires title, text, tags, fields')
    title = _bounded(value['title'], 'title', 180)
    text = value['text']
    if type(text) is not str or len(text) > 4096:
        raise ProposalError('Proposed text must be a string of <=4096 characters')
    tags = value['tags']
    if type(tags) is not list or len(tags) > 30 or len(set(map(str, tags))) != len(tags):
        raise ProposalError('Tags must be a unique bounded list')
    if any(type(t) is not str or not t or len(t) > 80 for t in tags):
        raise ProposalError('Invalid tag')
    if any(t.lower() == 'pvs' or t.startswith('$:/') for t in tags) or title.startswith('$:/'):
        raise ProposalError('Managed/system records cannot be proposed through ordinary ledger')
    return {'title':title, 'text':text, 'tags':tags, 'fields':_fields(value['fields'])}


def _verify_db_file(path: Path) -> None:
    if path.is_symlink():
        raise ProposalLedgerError('Symlink ledger is forbidden')
    if path.exists():
        info = path.stat(follow_symlinks=False)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ProposalLedgerError('Ledger must be a private regular single-link file')
        if os.name == 'posix' and info.st_mode & 0o077:
            raise ProposalLedgerError('Ledger permissions must be 0600')


def _event_hash(event: dict) -> str:
    return _sha('HWI07-event-v1\x00' + _canon(event))


class KnowledgeProposalLedger:
    """Private proposal-only SQLite queue bound to one *physical* wiki instance.

    `create=True` creates a separate `proposals/` folder and ledger database.
    The HWI-03 workspace name, not a model-supplied path, chooses the ledger.
    No connection, SQL executor, wiki writer, or approval interface is exposed.
    """

    def __init__(self, workspace: NotebookWorkspace, notebook_name: str, *, create: bool = False):
        if not isinstance(workspace, NotebookWorkspace) or type(create) is not bool:
            raise ProposalLedgerError('Trusted NotebookWorkspace and boolean create flag required')
        # Verify name and notebook pair via trusted workspace, then obtain its physical scope.
        workspace.notebook_path(notebook_name)
        with ReadOnlyKnowledgeBroker(workspace, notebook_name) as broker:
            scope = broker.namespace
        folder = workspace.root / 'proposals'
        if create:
            folder.mkdir(mode=0o700, exist_ok=True)
        if folder.is_symlink() or not folder.is_dir():
            raise ProposalLedgerError('Private proposal folder missing or invalid')
        if os.name == 'posix' and folder.stat().st_mode & 0o077:
            raise ProposalLedgerError('Proposal folder must have permissions 0700')
        db_path = folder / (notebook_name + '.proposals.sqlite')
        _verify_db_file(db_path)
        if not create and not db_path.exists():
            raise ProposalLedgerError('Ledger missing (no implicit creation)')
        created = not db_path.exists()
        if created:
            # A private working directory makes this single-UID filesystem operation
            # safe from untrusted *names*, not hostile sibling processes of same UID.
            fd = os.open(db_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY |
                         getattr(os, 'O_NOFOLLOW', 0), 0o600)
            os.close(fd)
        try:
            conn = sqlite3.connect(str(db_path), timeout=5, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute('PRAGMA foreign_keys=ON')
            conn.execute('PRAGMA synchronous=FULL')
            conn.execute('PRAGMA journal_mode=DELETE')
            if created:
                conn.executescript(_SCHEMA)
                conn.executemany('INSERT INTO meta(key,value) VALUES(?,?)',
                                 [('version','HWI07-v1'), ('notebook_scope',scope)])
            meta = dict(conn.execute('SELECT key,value FROM meta'))
            if meta != {'version':'HWI07-v1','notebook_scope':scope}:
                raise ProposalLedgerError('Ledger belongs to a different physical notebook or version')
            self.__conn = conn
            self.__workspace = workspace
            self.namespace = scope
            self.notebook_name = notebook_name
            self._closed = False
            self.verify()
        except BaseException:
            if 'conn' in locals(): conn.close()
            # An unusable new ledger is left for manual inspection, not silently deleted.
            raise

    def close(self) -> None:
        if not self._closed:
            self.__conn.close()
            self._closed = True

    def __enter__(self) -> 'KnowledgeProposalLedger':
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def _conn(self):
        if self._closed:
            raise ProposalLedgerError('Ledger closed')
        return self.__conn

    def _ensure_broker(self, broker: ReadOnlyKnowledgeBroker) -> None:
        if not isinstance(broker, ReadOnlyKnowledgeBroker) or broker.namespace != self.namespace:
            raise ProposalError('Fresh read-only broker from the same notebook is required')
        broker._check_open()

    def _source_refs(self, broker, source_refs):
        if type(source_refs) not in (list, tuple) or not 1 <= len(source_refs) <= 12:
            raise ProposalError('1 to 12 source references required')
        validated = []
        for ref in source_refs:
            ref = _bounded(ref,'source reference',240)
            if not (ref.startswith('hwi05://') or _EXTERNAL_REF.fullmatch(ref)):
                raise ProposalError('Source references must be named references, not paths or prose')
            if ref.startswith('hwi05://'):
                # Explicit historical retrieval is allowed as *evidence*, not live authority.
                # An old revision is evidence about the past, never a current write target.
                broker.revision(ref)
            validated.append(ref)
        if len(set(validated)) != len(validated):
            raise ProposalError('Duplicate source reference')
        return validated

    @staticmethod
    def _complete_read(broker, ref):
        state = broker.read(ref)
        if (state['text_truncated'] or state['fields_truncated'] or state['title_truncated']
                or state.get('tags_truncated', False) or len(state['tags']) >= 30):
            raise ProposalError('Current note cannot be fully presented for review')
        return state

    def submit(self, broker: ReadOnlyKnowledgeBroker, *, operation: str, reason: str,
               source_refs: list[str], author_origin: str = 'agent',
               target_ref: str | None = None, expected_revision_sha256: str | None = None,
               proposed: dict | None = None) -> dict:
        """Use a new read snapshot even if the caller's broker is stale.

        This is only a submission-time preflight; HWI-08 must still perform
        compare-and-swap inside the independently authorized write operation.
        """
        self._ensure_broker(broker)
        with ReadOnlyKnowledgeBroker(self.__workspace, self.notebook_name) as fresh:
            self._ensure_broker(fresh)
            return self._submit_checked(fresh, operation=operation, reason=reason,
                source_refs=source_refs, author_origin=author_origin,
                target_ref=target_ref, expected_revision_sha256=expected_revision_sha256,
                proposed=proposed)

    def _submit_checked(self, broker: ReadOnlyKnowledgeBroker, *, operation: str, reason: str,
               source_refs: list[str], author_origin: str = 'agent',
               target_ref: str | None = None, expected_revision_sha256: str | None = None,
               proposed: dict | None = None) -> dict:
        """Record a reviewable proposal. NEVER change the wiki or authorize it.

        `create` has expected_revision_sha256=None and target_ref=None.
        `revise/link/retire` require exact current target revision and digest.
        `link` proposed shape: {relation, to_ref}; `retire` proposed=None.
        """
        self._ensure_broker(broker)
        if operation not in _ALLOWED_OPS:
            raise ProposalError('Unsupported proposal operation')
        if author_origin not in ('agent','human'):
            raise ProposalError('Author origin must be a claim of agent or human')
        reason = _bounded(reason,'reason',8192)
        sources = self._source_refs(broker, source_refs)
        before, target_id = None, None
        if operation == 'create':
            if target_ref is not None or expected_revision_sha256 is not None:
                raise ProposalError('Create must not invent existing revision or identity')
            after = _document(proposed)
        else:
            if not isinstance(target_ref,str) or not isinstance(expected_revision_sha256,str) or not _DIGEST.fullmatch(expected_revision_sha256):
                raise ProposalError('Current target reference and expected revision digest required')
            current = self._complete_read(broker,target_ref)
            if current['revision_sha256'] != expected_revision_sha256:
                raise ProposalError('Stale revision digest')
            target_id = current['knowledge_id']
            before = {k:current[k] for k in ('title','text','tags','fields')}
            if operation == 'revise':
                after = _document(proposed)
            elif operation == 'retire':
                if proposed is not None:
                    raise ProposalError('Retire has no replacement payload')
                after = None
            else:
                if type(proposed) is not dict or set(proposed) != {'relation','to_ref'}:
                    raise ProposalError('Link requires relation and target revision reference')
                if proposed['relation'] not in _ALLOWED_RELATIONS:
                    raise ProposalError('Unknown link relation')
                to_record = self._complete_read(broker, proposed['to_ref'])
                if to_record['knowledge_id'] == target_id:
                    raise ProposalError('Self-link is not supported')
                after = {'relation': proposed['relation'], 'to_ref':to_record['ref'],
                         'to_revision_sha256':to_record['revision_sha256'],
                         'to_knowledge_id':to_record['knowledge_id']}
        if operation != 'link' and operation != 'retire':
            if len(_canon(after)) > 9500:
                raise ProposalError('Proposed document exceeds record size limit')
        # One immutable content payload bound to the notebook's physical namespace.
        record = {
            'schema_version':'hwi.contract.v0.1', 'record_type':'Proposal',
            'operation':operation,'author_origin':author_origin,
            'notebook_scope':self.namespace, 'target_ref':target_ref,
            'target_knowledge_id':target_id, 'expected_revision_sha256':expected_revision_sha256,
            'proposed_revision_sha256':_sha(_canon({'operation':operation,'after':after})),
            'reason':reason,'source_refs':sources,'before':before,'after':after,
            'labels':{'human_authorized':False,'actor_authenticated':False,
                      'pvs_approved':False,'execution_authorized':False,
                      'evidence_authenticated':False}}
        digest = _sha('HWI07-proposal-v1\x00' + _canon(record))
        conn = self._conn()
        conn.execute('BEGIN IMMEDIATE')
        try:
            if conn.execute('SELECT 1 FROM proposals WHERE digest=?',(digest,)).fetchone():
                raise DuplicateProposal('Exact proposal already recorded; retrieve existing record')
            pid = 'proposal:' + uuid4().hex
            submitted = _timestamp()
            payload = _canon(record)
            conn.execute('INSERT INTO proposals(proposal_id,digest,record_json,submitted_at) VALUES(?,?,?,?)',
                         (pid,digest,payload,submitted))
            self._append_event(conn,pid,'SUBMITTED',author_origin,'sha256:' + digest,when=submitted)
            conn.execute('COMMIT')
        except BaseException:
            conn.execute('ROLLBACK')
            raise
        return self.get(pid)

    @staticmethod
    def _append_event(conn, pid, kind, actor_claim, reason, *, when=None):
        previous = conn.execute('SELECT event_sha256 FROM events ORDER BY event_id DESC LIMIT 1').fetchone()
        prior = previous[0] if previous else '0'*64
        when = _timestamp() if when is None else when
        event = {'proposal_id':pid,'kind':kind,'actor_claim':actor_claim,
                 'reason':reason,'happened_at':when,'previous_sha256':prior}
        sig = _event_hash(event)
        conn.execute('INSERT INTO events(proposal_id,kind,actor_claim,reason,happened_at,previous_sha256,event_sha256) VALUES(?,?,?,?,?,?,?)',
                     (pid,kind,actor_claim,reason,when,prior,sig))

    def _lookup(self, proposal_id):
        if type(proposal_id) is not str or _ID.fullmatch(proposal_id) is None:
            raise ProposalError('Invalid proposal ID')
        row = self._conn().execute('SELECT * FROM proposals WHERE proposal_id=?', (proposal_id,)).fetchone()
        if row is None:
            raise ProposalError('Unknown proposal ID')
        return row

    def get(self, proposal_id: str) -> dict:
        row = self._lookup(proposal_id)
        event = self._conn().execute('SELECT kind FROM events WHERE proposal_id=? ORDER BY event_id DESC LIMIT 1',
                                     (proposal_id,)).fetchone()
        if event is None:
            raise ProposalLedgerError('Proposal has no ledger event')
        record = json.loads(row['record_json'])
        return {'envelope_schema':'hwi.proposal.envelope.v1',
                'proposal_id':proposal_id,'content_digest':row['digest'],
                'submitted_at':row['submitted_at'], 'state':event['kind'],
                'record':record,'approved':False,'human_authorized':False,
                'may_execute':False,'may_mutate_wiki':False}

    def list_proposals(self, *, limit=20, offset=0) -> list[dict]:
        if type(limit) is not int or not 1 <= limit <= 100 or type(offset) is not int or not 0 <= offset <= 10000:
            raise ProposalError('Invalid listing bounds')
        rows = self._conn().execute('SELECT proposal_id FROM proposals ORDER BY submitted_at,proposal_id LIMIT ? OFFSET ?',
                                    (limit,offset)).fetchall()
        return [self.get(row[0]) for row in rows]

    @contextmanager
    def _hold_submitted_for_application(self, proposal_id: str):
        """Serialize an HWI-08 write against reject/withdraw across connections.

        Lock order is proposal-ledger SQLite writer -> wiki SQLite writer.
        The ledger transaction spans the wiki commit, so closure cannot *precede*
        an application while the authorized executor is in progress. This is
        NOT a transaction across two SQLite stores; uncertain commits still
        require HWI-09 reconciliation and must never be automatically retried.
        """
        conn = self._conn()
        conn.execute('BEGIN IMMEDIATE')
        try:
            entry = self.get(proposal_id)
            if entry['state'] != 'SUBMITTED':
                raise ProposalError('Only submitted proposals can be applied')
            yield entry
            conn.execute('COMMIT')
        except BaseException:
            conn.execute('ROLLBACK')
            raise

    def _has_wiki_receipt(self, proposal_id: str) -> bool:
        """Fresh read under ledger writer lock; a local consistency check only."""
        with self.__workspace.open_notebook(self.notebook_name, readonly=True) as wiki:
            conn = wiki._db.conn
            if not conn.execute("SELECT 1 FROM hist.sqlite_master "
                                "WHERE type='table' AND name='hwi08_receipts'").fetchone():
                return False
            return conn.execute('SELECT 1 FROM hist.hwi08_receipts WHERE proposal_id=?',
                                (proposal_id,)).fetchone() is not None

    def _close_proposal(self, proposal_id, kind, *, actor_claim, reason):
        self._lookup(proposal_id)
        actor_claim = _bounded(actor_claim,'actor claim',120)
        reason = _bounded(reason,'reason',8192)
        conn = self._conn()
        conn.execute('BEGIN IMMEDIATE')
        try:
            event = conn.execute('SELECT kind FROM events WHERE proposal_id=? ORDER BY event_id DESC LIMIT 1',(proposal_id,)).fetchone()
            if event is None or event['kind'] != 'SUBMITTED':
                raise ProposalError('Only submitted proposals can be closed')
            # Uses the same ledger writer lock held by apply_signed_review.
            # An application receipt is an irreversible local observation,
            # not permission to rewrite history by closing the proposal.
            if self._has_wiki_receipt(proposal_id):
                raise ProposalError('Applied proposal cannot be rejected or withdrawn')
            self._append_event(conn,proposal_id,kind,actor_claim,reason)
            conn.execute('COMMIT')
        except BaseException:
            conn.execute('ROLLBACK')
            raise
        return self.get(proposal_id)

    def reject(self, proposal_id: str, *, actor_claim: str, reason: str) -> dict:
        """Administrative rejection *claim*, not verified human signature."""
        return self._close_proposal(proposal_id,'REJECTED',actor_claim=actor_claim,reason=reason)

    def withdraw(self, proposal_id: str, *, actor_claim: str, reason: str) -> dict:
        return self._close_proposal(proposal_id,'WITHDRAWN',actor_claim=actor_claim,reason=reason)

    def review_view(self, proposal_id: str) -> dict:
        """Human-facing, untrusted before/after summary and bounded unified diff."""
        entry = self.get(proposal_id)
        record = entry['record']
        before, after = record['before'], record['after']
        diff = '\n'.join(difflib.unified_diff(
            json.dumps(before,sort_keys=True,ensure_ascii=False,indent=2).splitlines() if before is not None else [],
            json.dumps(after,sort_keys=True,ensure_ascii=False,indent=2).splitlines() if after is not None else [],
            fromfile='observed-before (untrusted)',tofile='proposed-after (untrusted)',lineterm=''))
        return {'proposal_id':proposal_id,'state':entry['state'],'operation':record['operation'],
                'target_ref':record['target_ref'],'expected_revision_sha256':record['expected_revision_sha256'],
                'source_refs':record['source_refs'],'reason':record['reason'],
                'diff':diff,'before':before,'after':after,
                'note':'Unverified proposal only. Diff is not an authorization or execution request.',
                'may_mutate_wiki':False,'human_authorized':False}

    def verify(self) -> dict:
        """Local consistency check, not cryptographic custody or human attestation."""
        conn = self._conn()
        if conn.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ProposalLedgerError('SQLite integrity check failed')
        seen = set()
        proposal_rows = {}
        rows = conn.execute('SELECT * FROM proposals ORDER BY proposal_id').fetchall()
        for row in rows:
            if row['proposal_id'] in seen: raise ProposalLedgerError('Duplicate proposal ID')
            seen.add(row['proposal_id'])
            proposal_rows[row['proposal_id']] = row
            data = json.loads(row['record_json'])
            if data.get('notebook_scope') != self.namespace or data.get('labels',{}).get('human_authorized') is not False:
                raise ProposalLedgerError('Unexpected namespace or authority field')
            if row['digest'] != _sha('HWI07-proposal-v1\x00' + _canon(data)):
                raise ProposalLedgerError('Proposal digest mismatch')
        prior = '0'*64
        states = {}
        for row in conn.execute('SELECT * FROM events ORDER BY event_id'):
            if row['proposal_id'] not in seen or row['previous_sha256'] != prior:
                raise ProposalLedgerError('Missing proposal or broken event lineage')
            event = {k:row[k] for k in ('proposal_id','kind','actor_claim','reason','happened_at','previous_sha256')}
            if row['event_sha256'] != _event_hash(event):
                raise ProposalLedgerError('Event digest mismatch')
            old = states.get(row['proposal_id'])
            if (old is None and row['kind'] != 'SUBMITTED') or (old is not None and (old != 'SUBMITTED' or row['kind'] == 'SUBMITTED')):
                raise ProposalLedgerError('Invalid proposal state transition')
            if old is None:
                submitted = proposal_rows[row['proposal_id']]
                payload = json.loads(submitted['record_json'])
                if (row['reason'] != 'sha256:' + submitted['digest'] or
                    row['actor_claim'] != payload['author_origin'] or
                    row['happened_at'] != submitted['submitted_at']):
                    raise ProposalLedgerError('Submission event does not bind proposal identity/digest/time')
            states[row['proposal_id']] = row['kind']
            prior = row['event_sha256']
        if set(states) != seen:
            raise ProposalLedgerError('Proposal missing submitted event')
        return {'verified':True,'proposals':len(rows),'events':sum(1 for _ in conn.execute('SELECT event_id FROM events')),
                'last_event_sha256':prior,'authority_verified':False}
