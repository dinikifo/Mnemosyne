"""C9: pinned, read-only trial planning and signed observation audit.

An evidence audit is not evidence that the observed model ran or that a human
witnessed the run. This module never starts a model or the agent, writes to
PVS/wiki/journal, enrolls a credential, or grants execution authority.
"""
from __future__ import annotations

import hashlib
import json
import re
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .operator_handoff import inspect_hwi_operator_handoff

_HEX64 = re.compile(r'^[0-9a-f]{64}$')
_HEX32 = re.compile(r'^[0-9a-f]{32}$')
_NAME = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9_.:/+-]{0,127}$')
_PLAN_KEYS = frozenset({'schema', 'status', 'agent_id', 'baseline', 'model',
                        'trial_nonce', 'plan_sha256'})
_BASELINE_KEYS = frozenset({'state_sha256', 'journal_head', 'journal_count'})
_MODEL_KEYS = frozenset({'provider', 'name', 'digest_sha256', 'base_url', 'runtime_version'})
_OBS_KEYS = frozenset({'schema', 'phase', 'plan_sha256', 'process_nonce',
                       'state_sha256', 'journal_head', 'journal_count',
                       'model_name', 'model_digest_sha256', 'runtime_version',
                       'guard_result', 'model_calls_reported', 'trace_sha256'})
_MAX_TRACE_BYTES = 4 * 1024 * 1024


class HwiRestartTrialError(ValueError):
    """Malformed or inconsistent operator trial evidence."""


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()


def _hex64(value):
    return type(value) is str and _HEX64.fullmatch(value) is not None


def _blocked(status):
    return {'schema': 'hwi.restart.trial.audit.v1', 'status': status,
            'human_review_required': True, 'model_execution_proven': False,
            'operator_reprovisioning_required': True,
            'memory_approved': False, 'execution_authorized': False,
            'automatic_retry_allowed': False, 'integration_accepted': False}


def _valid_model(model, *, expected_base_url=None):
    if type(model) is not dict or set(model) != _MODEL_KEYS:
        return False
    if (model['provider'] != 'ollama' or type(model['name']) is not str
            or _NAME.fullmatch(model['name']) is None
            or not _hex64(model['digest_sha256'])
            or type(model['runtime_version']) is not str
            or not 1 <= len(model['runtime_version']) <= 100
            or type(model['base_url']) is not str):
        return False
    if expected_base_url is not None and model['base_url'] != expected_base_url:
        return False
    try:
        url = urlsplit(model['base_url'])
        return (url.scheme == 'http' and url.hostname in ('localhost', '127.0.0.1', '::1')
                and 1 <= (url.port or 11434) <= 65535 and not url.username
                and not url.password and not url.path.rstrip('/')
                and not url.query and not url.fragment)
    except ValueError:
        return False


def prepare_hwi_restart_trial_plan(*, handoff_kwargs, model_identity, trial_nonce):
    """Create a reproducible trial *proposal*, after a fresh C8 read-only check.

    The model digest is an *operator-supplied pin*, not a verified inspection of
    a running model. This function does not contact Ollama or start a session.
    """
    if (type(handoff_kwargs) is not dict or not _hex64(trial_nonce)
            or not _valid_model(model_identity,
                expected_base_url=getattr(handoff_kwargs.get('config'), 'ollama_base_url', None))):
        return _blocked('BLOCKED_INVALID_TRIAL_INPUT')
    try:
        report = inspect_hwi_operator_handoff(**handoff_kwargs)
    except Exception:
        return _blocked('BLOCKED_HANDOFF_VERIFICATION_UNAVAILABLE')
    # A process interrupt is propagated; it cannot become a successful report.
    if report.get('status') != 'READY_FOR_OPERATOR_REPROVISIONING':
        return _blocked('BLOCKED_HANDOFF_' + report.get('status', 'UNAVAILABLE'))
    baseline = {'state_sha256': report['observed_state_sha256'],
                'journal_head': report['observed_journal_head'],
                'journal_count': report['observed_journal_count']}
    plan = {'schema': 'hwi.restart.trial.plan.v1',
            'status': 'INSPECTED_FOR_OPERATOR_TRIAL_ONLY',
            'agent_id': report['agent_id'], 'baseline': baseline,
            'model': dict(model_identity), 'trial_nonce': trial_nonce}
    plan['plan_sha256'] = _hash(plan)
    return plan


def trial_witness_message(*, plan_sha256, observations):
    """Exact public signing bytes; the signing private key remains external."""
    return b'HWI-C9-RESTART-TRIAL-WITNESS-v1\0' + json.dumps(
        {'plan_sha256': plan_sha256, 'observations': observations},
        sort_keys=True, ensure_ascii=False, separators=(',', ':'),
        allow_nan=False).encode('utf-8')


def _validate_observation(ob, phase, plan):
    if type(ob) is not dict or set(ob) != _OBS_KEYS:
        return False
    baseline = plan['baseline']; model = plan['model']
    return (ob['schema'] == 'hwi.restart.trial.observation.v1'
        and ob['phase'] == phase
        and ob['plan_sha256'] == plan['plan_sha256']
        and type(ob['process_nonce']) is str and _HEX32.fullmatch(ob['process_nonce']) is not None
        and ob['state_sha256'] == baseline['state_sha256']
        and ob['journal_head'] == baseline['journal_head']
        and type(ob['journal_count']) is int and ob['journal_count'] == baseline['journal_count']
        and ob['model_name'] == model['name']
        and ob['model_digest_sha256'] == model['digest_sha256']
        and ob['runtime_version'] == model['runtime_version']
        and ob['guard_result'] == 'REPORTED_PASS'
        and type(ob['model_calls_reported']) is int and 1 <= ob['model_calls_reported'] <= 1000
        and _hex64(ob['trace_sha256']))


def inspect_signed_hwi_restart_trial(*, plan, observations, witness_public_key_hex,
                                     expected_witness_key_sha256, signature_hex, traces):
    """Verify signed *claims* and retained trace bytes, without granting authority.

    `traces` contains exact externally retained bytes for PRE_RESTART and
    POST_RESTART. The auditor verifies integrity, not that these bytes came
    from a genuine Ollama invocation or a separate physical operator.
    """
    blocked = _blocked('BLOCKED_TRIAL_EVIDENCE')
    try:
        if (type(plan) is not dict or set(plan) != _PLAN_KEYS
                or plan['schema'] != 'hwi.restart.trial.plan.v1'
                or plan['status'] != 'INSPECTED_FOR_OPERATOR_TRIAL_ONLY'
                or type(plan['agent_id']) is not str or not plan['agent_id']
                or type(plan['baseline']) is not dict
                or set(plan['baseline']) != _BASELINE_KEYS
                or not _hex64(plan['baseline']['state_sha256'])
                or not _hex64(plan['baseline']['journal_head'])
                or type(plan['baseline']['journal_count']) is not int
                or plan['baseline']['journal_count'] < 1
                or not _valid_model(plan['model'])
                or not _hex64(plan['trial_nonce'])
                or not _hex64(plan['plan_sha256'])
                or _hash({k: v for k, v in plan.items() if k != 'plan_sha256'}) != plan['plan_sha256']):
            return blocked
        if (type(observations) is not list or len(observations) != 2
                or not _validate_observation(observations[0], 'PRE_RESTART', plan)
                or not _validate_observation(observations[1], 'POST_RESTART', plan)
                or observations[0]['process_nonce'] == observations[1]['process_nonce']):
            return blocked
        if (type(traces) is not dict or set(traces) != {'PRE_RESTART', 'POST_RESTART'}):
            return blocked
        for ob in observations:
            payload = traces[ob['phase']]
            if (type(payload) is not bytes or not 1 <= len(payload) <= _MAX_TRACE_BYTES
                    or hashlib.sha256(payload).hexdigest() != ob['trace_sha256']):
                return blocked
        if (not _hex64(expected_witness_key_sha256)
                or type(witness_public_key_hex) is not str
                or type(signature_hex) is not str):
            return blocked
        public_key = bytes.fromhex(witness_public_key_hex)
        signature = bytes.fromhex(signature_hex)
        if (len(public_key) != 32 or len(signature) != 64
                or hashlib.sha256(public_key).hexdigest() != expected_witness_key_sha256):
            return blocked
        Ed25519PublicKey.from_public_bytes(public_key).verify(signature,
            trial_witness_message(plan_sha256=plan['plan_sha256'], observations=observations))
    except (ValueError, TypeError, KeyError, InvalidSignature, OverflowError):
        return blocked
    # This is an authenticated report of claims. It is not observed model
    # execution, independent witness identity, memory approval, or restart permission.
    result = _blocked('SIGNED_TRIAL_CLAIMS_CONSISTENT_NOT_INDEPENDENTLY_VALIDATED')
    result.update({'plan_sha256': plan['plan_sha256'],
                   'witness_public_key_sha256': expected_witness_key_sha256,
                   'trace_hashes': [ob['trace_sha256'] for ob in observations],
                   'distinct_processes_reported': True,
                   'model_digest_consistent': True})
    return result
