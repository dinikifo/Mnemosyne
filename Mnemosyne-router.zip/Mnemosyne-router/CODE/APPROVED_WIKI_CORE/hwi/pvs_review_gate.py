"""C5 offline handoff: C4 signed admission -> independent PVS review -> M8 selection.

Only original PVS code may write a review; only the original credential-aware
selector may approve text for a governed prompt. This module is read-only and
must never be registered as an AutoGPT Lite message provider or execution tool.
All pins require independent custody outside the agent; local tests cannot prove
reviewer identity, real-world independence, or truth.
"""
from __future__ import annotations

import hashlib
from copy import deepcopy

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .proposals import _canon
from .pvs_admission import admission_operator_message
from .semantic_review import prepare_semantic_review_packet
from .journal_grounding import prepare_journal_grounded_candidate
from .pvs_handoff import select_protected_wiki_memory

_RECEIPT_KEYS = frozenset({
    'schema','status','plan_sha256','operator_key_sha256','operator_signature_hex',
    'draft_sha256','pvs_proposal_target_id','pvs_proposal_count',
    'pvs_proposal_target_pin','source_witness_sha256','pvs_approved',
    'prompt_eligible','execution_authorized','receipt_stored_in_pvs',
    'external_custody_established','lineage_manifest','lineage_signature_hex',
    'lineage_origins_sha256','receipt_sha256'})
_REVIEW_EXTRA_KEYS = frozenset({'review_target_id','review_project_id','expected_review_target_pin'})
_SHA_CHARS = set('0123456789abcdef')


class PvsReviewGateError(ValueError):
    """Refused stale/missing C4 evidence or independent PVS review/selection."""


def _digest(value):
    return hashlib.sha256(_canon(value).encode('utf-8')).hexdigest()


def _sha(value):
    if type(value) is not str or len(value) != 64 or any(x not in _SHA_CHARS for x in value):
        raise PvsReviewGateError('Independently retained lowercase SHA-256 is required')
    return value


def _fresh_source_packet(source_kwargs, pvs_context, packet, plan):
    """Allow only the PVS versioner head to advance for review-target setup.

    The original witnessed source-target revision and journal are immutable. The
    versioner's current pin may change when the original PVS M4 review project
    is initialized; this does not rewrite the source witness. Recompute all
    remaining source and semantic-packet fields before comparing exact bytes.
    """
    current_source = dict(source_kwargs,
        expected_source_versioner_pin=pvs_context['expected_versioner_pin'])
    current_witness = prepare_journal_grounded_candidate(**current_source)
    witnessed = deepcopy(current_witness)
    witnessed['pvs_source']['versioner_pin'] = source_kwargs['expected_source_versioner_pin']
    witnessed['witness_sha256'] = _digest({k:v for k,v in witnessed.items()
                                           if k != 'witness_sha256'})
    if witnessed['witness_sha256'] != plan['witness_sha256']:
        raise PvsReviewGateError('Original C2 source witness changed outside versioner registration')
    current_packet = prepare_semantic_review_packet(
        source_kwargs=current_source,
        expected_witness_sha256=current_witness['witness_sha256'])
    current_packet['pvs_source']['versioner_pin'] = source_kwargs['expected_source_versioner_pin']
    current_packet['witness_sha256'] = plan['witness_sha256']
    current_packet['packet_sha256'] = _digest({k:v for k,v in current_packet.items()
                                              if k != 'packet_sha256'})
    if current_packet != packet or packet['packet_sha256'] != plan['packet_sha256']:
        raise PvsReviewGateError('Wiki, journal or original semantic-review packet changed')
    return witnessed


def _check_admission(*, receipt, expected_receipt_sha256, plan,
                     operator_public_key, expected_operator_key_sha256,
                     draft, source_kwargs, packet, pvs_context, externally_pinned_origins):
    """Reverify C4 signing and real PVS stored draft without another write."""
    from research_memory.pvs_memory_proposals import verify_proposals

    _sha(expected_receipt_sha256)
    _sha(expected_operator_key_sha256)
    if type(receipt) is not dict or set(receipt) != _RECEIPT_KEYS:
        raise PvsReviewGateError('Exact C4 receipt shape required')
    body = {k:v for k,v in receipt.items() if k != 'receipt_sha256'}
    if (receipt['receipt_sha256'] != expected_receipt_sha256
            or _digest(body) != expected_receipt_sha256
            or receipt['schema'] != 'hwi.pvs.admission.receipt.v2'
            or receipt['status'] != 'STORED_UNREVIEWED_NO_MEMORY_APPROVAL'
            or any(receipt[x] is not False for x in (
                'pvs_approved','prompt_eligible','execution_authorized',
                'receipt_stored_in_pvs','external_custody_established'))):
        raise PvsReviewGateError('C4 receipt missing integrity or falsely claims approval')
    if (type(operator_public_key) is not bytes or len(operator_public_key) != 32
            or hashlib.sha256(operator_public_key).hexdigest() != expected_operator_key_sha256
            or receipt['operator_key_sha256'] != expected_operator_key_sha256
            or type(receipt['operator_signature_hex']) is not str
            or len(receipt['operator_signature_hex']) != 128):
        raise PvsReviewGateError('Operator key or signed storage receipt not independently bound')
    if receipt['plan_sha256'] != plan.get('plan_sha256'):
        raise PvsReviewGateError('Operator plan differs from signed receipt')
    message = admission_operator_message(plan, expected_plan_sha256=receipt['plan_sha256'])
    try:
        signature = bytes.fromhex(receipt['operator_signature_hex'])
        if len(signature) != 64:
            raise ValueError('Signature length')
        Ed25519PublicKey.from_public_bytes(operator_public_key).verify(signature, message)
    except (InvalidSignature, ValueError) as exc:
        raise PvsReviewGateError('C4 storage-only operator signature invalid') from exc
    if (type(pvs_context) is not dict or type(draft) is not dict
            or type(source_kwargs) is not dict or type(packet) is not dict):
        raise PvsReviewGateError('Exact source, proposal and review documents required')
    if (pvs_context.get('workspace') is not source_kwargs.get('pvs_workspace')
            or pvs_context.get('journal') is not source_kwargs.get('journal')
            or pvs_context.get('source_target_id') != plan['pvs_source_target_id']
            or pvs_context.get('proposal_target_id') != plan['pvs_proposal_target_id']
            or pvs_context.get('proposal_project_id') != plan['pvs_proposal_project_id']
            or pvs_context.get('source_project_id') != plan['pvs_source_project_id']
            or pvs_context.get('actor') != plan['pvs_actor']
            or pvs_context.get('versioner_id') != plan['pvs_versioner_id']
            or pvs_context.get('expected_source_head') != plan['pvs_source_head_sha256']
            or pvs_context['journal'].agent_id != plan['pvs_agent_id']):
        raise PvsReviewGateError('PVS context does not match the signed source/operator plan')
    if (plan['witness_sha256'] != receipt['source_witness_sha256']
            or plan['draft_sha256'] != receipt['draft_sha256']
            or draft.get('content_sha256') != receipt['draft_sha256']
            or receipt['pvs_proposal_target_id'] != pvs_context['proposal_target_id']
            or plan['pvs_proposal_count_before'] + 1 != receipt['pvs_proposal_count']
            or receipt['pvs_proposal_target_pin'] != pvs_context.get('expected_proposal_target_pin')
            or plan['candidate_text_sha256'] != hashlib.sha256(
                draft['candidate']['candidate_text'].encode('utf-8')).hexdigest()):
        raise PvsReviewGateError('C4 plan/receipt does not bind exact recorded candidate')
    # PVS M4 review-target registration advances the versioner head. Refresh
    # with the caller's independent current pin, but permit no source/claim change.
    witnessed = _fresh_source_packet(source_kwargs, pvs_context, packet, plan)
    # The original C4 signature and its bytes are unchanged. A new C13
    # operator signature must be independently rechecked at every later
    # review/selection. The origin map is supplied out-of-band by the trusted
    # operator; its digest in the receipt forbids quiet substitution.
    from .provenance_gate import verify_signed_admission_lineage, ProvenanceGateError
    try:
        if (type(externally_pinned_origins) is not dict
                or _digest(externally_pinned_origins) != receipt['lineage_origins_sha256']):
            raise ProvenanceGateError('Independent origin pins differ from signed admission receipt')
        verify_signed_admission_lineage(
            manifest=receipt['lineage_manifest'],
            expected_lineage_sha256=receipt['lineage_manifest']['lineage_sha256'],
            plan=plan, witness=witnessed,
            externally_pinned_origins=externally_pinned_origins,
            signature_hex=receipt['lineage_signature_hex'],
            operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256)
    except (KeyError, TypeError, ValueError, ProvenanceGateError) as exc:
        raise PvsReviewGateError('C13 signed lineage not recoverable or currently valid') from exc
    checked = verify_proposals(**pvs_context)
    if (checked['proposal_count'] != receipt['pvs_proposal_count']
            or checked['latest_draft'] != draft
            or checked['proposal_sha256'][-1] is None
            or checked['prompt_eligible'] is not False
            or checked['human_approved'] is not False):
        raise PvsReviewGateError('Stored PVS proposal does not match unreviewed signed admission')
    return checked


def _check_review_context(pvs_context, review_context, reviewer_public_key,
                          expected_operator_key_sha256, semantic_reviewer_key_sha256):
    if (type(review_context) is not dict
            or set(review_context) != set(pvs_context) | _REVIEW_EXTRA_KEYS
            or any((review_context[k] is not pvs_context[k]) if k in ('workspace','journal')
                   else (review_context[k] != pvs_context[k]) for k in pvs_context)
            or type(reviewer_public_key) is not bytes or len(reviewer_public_key) != 32
            or hashlib.sha256(reviewer_public_key).hexdigest() in (
                expected_operator_key_sha256, semantic_reviewer_key_sha256)):
        raise PvsReviewGateError('Independent reviewer, matching PVS context and head pins required')
    if (type(review_context['review_target_id']) is not str
            or review_context['review_target_id'] in (
                review_context['proposal_target_id'], review_context['source_target_id'])):
        raise PvsReviewGateError('Review must use a separate PVS review target')


def prepare_independent_pvs_review(*, admission_receipt: dict,
                                   expected_admission_receipt_sha256: str,
                                   admission_plan: dict, operator_public_key: bytes,
                                   expected_operator_key_sha256: str,
                                   draft: dict, source_kwargs: dict, packet: dict,
                                   pvs_context: dict, review_context: dict,
                                   reviewer_public_key: bytes,
                                   externally_pinned_origins: dict) -> dict:
    """Prepare an ORIGINAL PVS M4 reviewer request; no PVS writes or signing."""
    try:
        _check_admission(receipt=admission_receipt,
            expected_receipt_sha256=expected_admission_receipt_sha256,
            plan=admission_plan, operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256,
            draft=draft, source_kwargs=source_kwargs, packet=packet,
            pvs_context=pvs_context, externally_pinned_origins=externally_pinned_origins)
        _check_review_context(pvs_context, review_context, reviewer_public_key,
                              expected_operator_key_sha256,
                              admission_plan['semantic_reviewer_key_sha256'])
        from research_memory.pvs_memory_review import prepare_review_request
        request = prepare_review_request(**review_context, public_key=reviewer_public_key)
        if (request['draft_sha256'] != draft['content_sha256']
                or request['candidate_text'] != draft['candidate']['candidate_text']
                or request['proposal_index'] != admission_receipt['pvs_proposal_count']
                or request['proposal_pin'] != admission_receipt['pvs_proposal_target_pin']):
            raise PvsReviewGateError('PVS review request not bound to admitted candidate')
        # Reread source/proposal pins after request generation. The nonce makes
        # requests non-repeatable; historical review evidence is pinned by caller.
        _check_admission(receipt=admission_receipt,
            expected_receipt_sha256=expected_admission_receipt_sha256,
            plan=admission_plan, operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256,
            draft=draft, source_kwargs=source_kwargs, packet=packet,
            pvs_context=pvs_context, externally_pinned_origins=externally_pinned_origins)
        return {'schema':'hwi.pvs.review.handoff.v1',
                'status':'AWAITING_INDEPENDENT_PVS_REVIEW',
                'request':request,
                'request_sha256':_digest(request),
                'admission_receipt_sha256':expected_admission_receipt_sha256,
                'pvs_review_target_pin':deepcopy(review_context['expected_review_target_pin']),
                'prompt_eligible':False, 'pvs_approved':False,
                'execution_authorized':False, 'human_identity_established':False,
                'external_custody_established':False}
    except PvsReviewGateError:
        raise
    except Exception as exc:
        raise PvsReviewGateError('PVS review handoff refused: missing or stale evidence') from exc


def inspect_independent_pvs_selection(*, admission_receipt: dict,
                                      expected_admission_receipt_sha256: str,
                                      admission_plan: dict, operator_public_key: bytes,
                                      expected_operator_key_sha256: str,
                                      draft: dict, source_kwargs: dict, packet: dict,
                                      pvs_context: dict, review_context: dict,
                                      reviewer_public_key: bytes, selector: object,
                                      externally_pinned_origins: dict) -> dict:
    """Read-only exact admitted-draft selection; no runtime prompt or PVS write."""
    try:
        _check_admission(receipt=admission_receipt,
            expected_receipt_sha256=expected_admission_receipt_sha256,
            plan=admission_plan, operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256,
            draft=draft, source_kwargs=source_kwargs, packet=packet,
            pvs_context=pvs_context, externally_pinned_origins=externally_pinned_origins)
        _check_review_context(pvs_context, review_context, reviewer_public_key,
                              expected_operator_key_sha256,
                              admission_plan['semantic_reviewer_key_sha256'])
        from research_memory.pvs_memory_review import verify_reviews
        from research_memory.pvs_memory_selector import GovernedMemorySelector
        if (type(selector) is not GovernedMemorySelector
                or selector.workspace is not pvs_context['workspace']
                or selector.journal is not pvs_context['journal']
                or selector.public_key != reviewer_public_key
                or selector.credential_registry is None
                or selector.args != {k: v for k,v in review_context.items()
                                   if k not in ('workspace','journal')}):
            raise PvsReviewGateError('Exact credential-enforced pinned selector required')
        # Do not report a clean empty memory when the enrollment/revocation
        # registry itself is missing or invalid. The M8 selector has the same
        # independently pinned status control.
        from research_memory.pvs_memory_credentials import verify_reviewer_status
        key_status = verify_reviewer_status(**selector.credential_registry,
            reviewer_public_key=reviewer_public_key,
            agent_id=selector.journal.agent_id,
            review_target_id=selector.args['review_target_id'])
        state = verify_reviews(**review_context, public_key=reviewer_public_key)
        if not state['candidate_reviewed_for_future_m5']:
            _check_admission(receipt=admission_receipt,
                expected_receipt_sha256=expected_admission_receipt_sha256,
                plan=admission_plan, operator_public_key=operator_public_key,
                expected_operator_key_sha256=expected_operator_key_sha256,
                draft=draft, source_kwargs=source_kwargs, packet=packet,
                pvs_context=pvs_context, externally_pinned_origins=externally_pinned_origins)
            if verify_reviewer_status(**selector.credential_registry,
                reviewer_public_key=reviewer_public_key,
                agent_id=selector.journal.agent_id,
                review_target_id=selector.args['review_target_id']) != key_status:
                raise PvsReviewGateError('Credential status changed during review inspection')
            return {'schema':'hwi.pvs.review.selection.v1',
                    'status':'NO_APPROVED_MEMORY', 'memory_text_sha256':None,
                    'pvs_approved_for_memory':False, 'llm_prompt_attached':False,
                    'execution_authorized':False}
        latest = pvs_context['workspace'].inspect(review_context['review_target_id'])['data']['reviews'][-1]['signed']
        if (latest['request']['draft_sha256'] != admission_receipt['draft_sha256']
                or latest['request']['proposal_index'] != admission_receipt['pvs_proposal_count']
                or latest['request']['proposal_pin'] != admission_receipt['pvs_proposal_target_pin']
                or latest['request']['candidate_text'] != draft['candidate']['candidate_text']):
            raise PvsReviewGateError('Current PVS reviewer decision not bound to signed admission')
        chosen = select_protected_wiki_memory(
            source_kwargs['workspace'], source_kwargs['notebook_name'],
            source_kwargs['ledger'], source_kwargs['proposal_id'],
            review_signature_hex=source_kwargs['review_signature_hex'],
            reviewer_public_key=source_kwargs['reviewer_public_key'],
            expected_review_artifact_sha256=source_kwargs['expected_review_artifact_sha256'],
            expected_memory_text_sha256=admission_plan['candidate_text_sha256'],
            selector=selector)
        _check_admission(receipt=admission_receipt,
            expected_receipt_sha256=expected_admission_receipt_sha256,
            plan=admission_plan, operator_public_key=operator_public_key,
            expected_operator_key_sha256=expected_operator_key_sha256,
            draft=draft, source_kwargs=source_kwargs, packet=packet,
            pvs_context=pvs_context, externally_pinned_origins=externally_pinned_origins)
        # The PVS selector re-verifies the PVS heads and credentials at each
        # invocation; no authority is carried forward from this report.
        return {'schema':'hwi.pvs.review.selection.v1',
                'status':'CURRENT_PVS_APPROVAL_MATCHED',
                'memory_text_sha256':chosen['memory_text_sha256'],
                'pvs_review_fingerprint':chosen['pvs_review_fingerprint'],
                'pvs_approved_for_memory':True, 'llm_prompt_attached':False,
                'execution_authorized':False,
                'real_world_human_identity_established':False}
    except PvsReviewGateError:
        raise
    except Exception as exc:
        raise PvsReviewGateError('Protected PVS review/selection refused: manual inspection required') from exc
