"""Allow running as: python -m autogpt_lite"""
from autogpt_lite.main import main

main()
