"""Token counting utilities.

Uses a simple heuristic by default (words * 1.3) to avoid heavy dependencies.
If tiktoken is available, uses cl100k_base as a better approximation.
"""

from __future__ import annotations

_encoder = None


def _get_encoder():
    global _encoder
    if _encoder is None:
        try:
            import tiktoken
            _encoder = tiktoken.get_encoding("cl100k_base")
        except ImportError:
            _encoder = False  # sentinel: not available
    return _encoder


def count_tokens(text: str) -> int:
    """Estimate token count for a string."""
    enc = _get_encoder()
    if enc:
        return len(enc.encode(text))
    # Fallback heuristic: ~1.3 tokens per word (reasonable for English)
    return int(len(text.split()) * 1.3)


def truncate_to_tokens(text: str, max_tokens: int) -> str:
    """Truncate text to approximately max_tokens.

    Handles zero and negative values safely by returning empty string.
    """
    if max_tokens <= 0:
        return ""
    enc = _get_encoder()
    if enc:
        tokens = enc.encode(text)
        if len(tokens) <= max_tokens:
            return text
        return enc.decode(tokens[:max_tokens]) + "\n... [truncated]"
    # Fallback: approximate by words
    words = text.split()
    max_words = int(max_tokens / 1.3)
    if max_words <= 0:
        return ""
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words]) + "\n... [truncated]"
