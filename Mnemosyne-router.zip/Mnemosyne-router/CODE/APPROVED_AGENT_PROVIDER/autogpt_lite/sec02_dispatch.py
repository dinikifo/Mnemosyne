"""SEC-02 R4 closed pilot gate. NO QSECD tool execution authority.

The inactive R1 policy and offline R2/R3 proofs have no live authorization
meaning. This module is deliberately deny-only. Future approved capability
must be introduced by a separately reviewed change, not by agent arguments.
"""
from __future__ import annotations

import hashlib
import json


class Sec02PilotBlocked(RuntimeError):
    pass


def request_identity(proposal, *, resolved_name: str) -> str:
    """Hash of reviewed request (descriptive identifier, not authenticating)."""
    raw = json.dumps({
        "schema": "sec02.dispatch-review.v1",
        "resolved_command": resolved_name,
        "requested_command": proposal.use_tool.name,
        "arguments": proposal.use_tool.arguments,
        "proposal": proposal.raw_message,
    }, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def pilot_preflight(kernel, proposal) -> str:
    """Resolve aliases for diagnosis; refuse dispatch regardless of source."""
    commands = kernel.collect_commands()
    matches = []
    for cmd in commands:
        if proposal.use_tool.name == cmd.name or proposal.use_tool.name in cmd.aliases:
            matches.append(cmd)
    if len(matches) != 1 or matches[0].execute is None:
        return "SEC02_UNRESOLVED_COMMAND: denied, no reviewed executable"
    try:
        digest = request_identity(proposal, resolved_name=matches[0].name)
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return "SEC02_INVALID_REQUEST_IDENTITY: denied, noncanonical arguments"
    return ("SEC02_NO_EFFECTIVE_POLICY: refused reviewed command "
            + matches[0].name + " request_sha256=" + digest
            + "; QSECD candidate policy is offline only")


def pilot_dispatch_check(kernel, proposal) -> str:
    # Same resolver at the last execution boundary, not merely displayed name.
    return pilot_preflight(kernel, proposal)
