"""Component kernel (spec §6).

Manages component registration, topological ordering, and protocol pipeline
execution with per-component fault isolation.

Current implementation provides:
- Deterministic topological ordering via run_after dependencies.
- Per-component exception catching (a failing component does not crash the
  pipeline; the failure is logged and the next component runs).
- Dynamic enable/disable filtering.

NOT currently implemented (acceptable deviations for a lightweight build):
- Pipeline-level restart signals.
- Per-endpoint retry semantics.
- Typed pipeline failure/recovery classes.

These could be added if closer Classic fidelity is required.
"""

from __future__ import annotations

import logging
from typing import Any, TypeVar

from .components.base import (
    AfterExecute,
    AfterParse,
    CommandProvider,
    Component,
    DirectiveProvider,
    ExecutionFailure,
    MessageProvider,
)
from .models import ActionProposal, ActionResult, Command, Directives
from .interaction import render_operator_literal

logger = logging.getLogger(__name__)

T = TypeVar("T")


class RequiredEvidenceError(RuntimeError):
    """A required MessageProvider failed; the agent MUST NOT request a proposal."""


class ComponentDependencyError(RuntimeError):
    """A component graph cannot be safely attached or ordered."""


class ComponentKernel:
    """Hosts pluggable components and runs protocol pipelines (spec §6).

    Provides best-effort pipeline execution with per-component fault
    isolation.  A failing component is logged and skipped; it does not
    halt the pipeline.
    """

    def __init__(self):
        self._components: list[Component] = []
        self._ordered = False

    def register(self, component: Component) -> None:
        """Add a component. Order is resolved lazily."""
        self._components.append(component)
        self._ordered = False

    def attach_all(self, agent: Any) -> None:
        """Attach all components to the agent and resolve ordering."""
        self._resolve_order()
        for comp in self._components:
            comp.attach(agent)

    # -------------------------------------------------------------------
    # Ordering (spec §6.3) — topological sort on run_after
    # -------------------------------------------------------------------

    def _resolve_order(self) -> None:
        """Topological sort based on run_after declarations."""
        if self._ordered:
            return

        type_to_comp: dict[type, Component] = {}
        for c in self._components:
            if type(c) in type_to_comp:
                raise ComponentDependencyError(
                    f"Duplicate component type: {type(c).__name__}")
            type_to_comp[type(c)] = c
        for c in self._components:
            for dep in c.run_after:
                if dep not in type_to_comp:
                    raise ComponentDependencyError(
                        f"Missing dependency {getattr(dep, '__name__', repr(dep))} "
                        f"for {type(c).__name__}")

        visited: set[type] = set()
        result: list[Component] = []
        visiting: set[type] = set()

        def visit(comp_type: type) -> None:
            if comp_type in visited:
                return
            if comp_type in visiting:
                raise ComponentDependencyError(
                    f"Circular dependency involving {comp_type.__name__}")
            visiting.add(comp_type)
            comp = type_to_comp.get(comp_type)
            if comp:
                for dep in comp.run_after:
                    visit(dep)
                visited.add(comp_type)
                result.append(comp)
            visiting.discard(comp_type)

        for comp_type in list(type_to_comp.keys()):
            visit(comp_type)

        self._components = result
        self._ordered = True

    # -------------------------------------------------------------------
    # Pipeline execution (spec §6.4)
    # -------------------------------------------------------------------

    def _active(self, protocol: type) -> list[Component]:
        """Return components implementing `protocol` that are enabled."""
        self._resolve_order()
        return [c for c in self._components if isinstance(c, protocol) and c.enabled]

    def collect_directives(self) -> Directives:
        """Run DirectiveProvider pipeline → merged Directives."""
        merged = Directives()
        for comp in self._active(DirectiveProvider):
            try:
                merged = merged.merge(comp.get_directives())  # type: ignore
            except Exception as e:
                logger.warning("DirectiveProvider %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))
        return merged

    def collect_commands(self) -> list[Command]:
        """Run CommandProvider pipeline → command list with shadowing (spec §11.3)."""
        commands: dict[str, Command] = {}
        for comp in self._active(CommandProvider):
            try:
                for cmd in comp.get_commands():  # type: ignore
                    if cmd.enabled:
                        # Later registrations shadow earlier ones
                        commands[cmd.name] = cmd
                        for alias in cmd.aliases:
                            commands[alias] = cmd
            except Exception as e:
                logger.warning("CommandProvider %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))
        return list({id(c): c for c in commands.values()}.values())

    def collect_messages(self) -> list[str]:
        """Run MessageProvider pipeline → list of prompt messages."""
        messages: list[str] = []
        for comp in self._active(MessageProvider):
            try:
                messages.extend(comp.get_messages())  # type: ignore
            except Exception as e:
                if getattr(comp, "required", False):
                    raise RequiredEvidenceError(
                        f"Required evidence unavailable from {render_operator_literal(str(comp.component_name))}"
                    ) from e
                logger.warning("MessageProvider %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))
        return messages

    def run_after_parse(self, proposal: ActionProposal) -> None:
        """Run AfterParse pipeline."""
        for comp in self._active(AfterParse):
            try:
                comp.after_parse(proposal)  # type: ignore
            except Exception as e:
                logger.warning("AfterParse %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))

    def run_after_execute(self, result: ActionResult) -> None:
        """Run AfterExecute pipeline."""
        for comp in self._active(AfterExecute):
            try:
                comp.after_execute(result)  # type: ignore
            except Exception as e:
                logger.warning("AfterExecute %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))

    def run_execution_failure(self, error: Exception) -> None:
        """Run ExecutionFailure pipeline."""
        for comp in self._active(ExecutionFailure):
            try:
                comp.on_execution_failure(error)  # type: ignore
            except Exception as e:
                logger.warning("ExecutionFailure %s failed: %s",
                               render_operator_literal(str(comp.component_name)),
                               render_operator_literal(str(e)))
