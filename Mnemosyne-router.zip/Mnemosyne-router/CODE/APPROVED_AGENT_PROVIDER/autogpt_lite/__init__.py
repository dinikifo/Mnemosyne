"""AutoGPT Lite — Lightweight AutoGPT Classic for local LLMs."""

__version__ = "0.1.0"
