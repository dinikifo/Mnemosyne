"""SEC-01 experimental per-execution Toulmin + human review gate.

This is *in-process governance*, not an authenticated security boundary or OS
sandbox.  The executor must be isolated separately from authoritative PVS data.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = "sec01-execution-v1"
MAX_SCRIPT_BYTES = 65536
MAX_ARGUMENT_BYTES = 4000


class Sec01PolicyBlocked(RuntimeError):
    """The proposal was invalid, evidence could not be recorded, or a check failed."""


class Sec01Denied(RuntimeError):
    """The owner explicitly refused this exact execution."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical(data: dict) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _text(value: object, key: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise Sec01PolicyBlocked(f"SEC01_INVALID_TOULMIN: missing {key}")
    if len(value.encode("utf-8")) > MAX_ARGUMENT_BYTES:
        raise Sec01PolicyBlocked(f"SEC01_INVALID_TOULMIN: {key} too large")
    return value.strip()


@dataclass(frozen=True)
class ToulminArgument:
    claim: str
    grounds: str
    warrant: str
    backing: str
    qualifier: str
    rebuttal: str

    @classmethod
    def from_values(cls, **values: object) -> "ToulminArgument":
        return cls(**{key: _text(values.get(key), key) for key in (
            "claim", "grounds", "warrant", "backing", "qualifier", "rebuttal")})


def _escape_terminal(s: str) -> str:
    """Prevent control sequences in model-generated code/arguments reaching the TTY."""
    return "".join(c if c.isprintable() and c not in "\x1b\r" else
                   "\\u%04x" % ord(c) for c in s)


class ConsoleAuthorizer:
    """Prompts the person at the controlling terminal; never reads model stdin.

    No unattended approval mechanism or persisted grant exists.  This does not
    authenticate the owner: a compromised same-UID process may attack the TTY.
    """
    def authorize(self, *, request: dict, script: str) -> bool:
        try:
            with open("/dev/tty", "r+", encoding="utf-8") as tty:
                if not tty.isatty():
                    raise Sec01PolicyBlocked("SEC01_NO_TTY: owner terminal required")
                tty.write("\n=== SEC-01: HUMAN EXECUTION REVIEW ===\n")
                tty.write("Agent-provided Toulmin claims are UNVERIFIED.\n")
                tty.write("Not a sandbox; subprocess keeps the agent's OS permissions.\n")
                tty.write(json.dumps(request, indent=2, ensure_ascii=True) + "\n")
                tty.write("--- FULL PYTHON SCRIPT (escaped controls) ---\n")
                for index, line in enumerate(script.split("\n"), 1):
                    tty.write(f"{index:04d}: {_escape_terminal(line)}\n")
                tty.write("--- END SCRIPT ---\n")
                token = "APPROVE " + request["request_digest"][:16]
                tty.write(f"To authorize ONLY this invocation, type exactly: {token}\n")
                tty.write("Any other input, EOF, or interruption denies execution.\n> ")
                tty.flush()
                entered = tty.readline()
                return entered.rstrip("\r\n") == token
        except Sec01PolicyBlocked:
            raise
        except (OSError, UnicodeError) as exc:
            raise Sec01PolicyBlocked("SEC01_NO_TTY: unable to obtain independent human approval") from exc


class AuditJournal:
    """Best-effort local evidence; same-UID code can tamper, so not independent proof."""
    def __init__(self, agent_data_dir: str, workspace: Path):
        root = Path(agent_data_dir).absolute()
        if root.is_symlink() or not root.is_dir():
            raise Sec01PolicyBlocked("SEC01_JOURNAL: agent data directory unavailable or linked")
        resolved = root.resolve()
        if resolved == workspace or resolved.is_relative_to(workspace):
            raise Sec01PolicyBlocked("SEC01_JOURNAL: audit must be outside the workspace")
        self.directory = resolved / "sec01"
        if self.directory.is_symlink():
            raise Sec01PolicyBlocked("SEC01_JOURNAL: linked audit directory")
        try:
            self.directory.mkdir(mode=0o700, exist_ok=True)
            os.chmod(self.directory, 0o700)
            if not self.directory.is_dir():
                raise Sec01PolicyBlocked("SEC01_JOURNAL: not a directory")
        except OSError as exc:
            raise Sec01PolicyBlocked("SEC01_JOURNAL: cannot prepare audit directory") from exc
        self.path = self.directory / "events.jsonl"
        self.artifacts = self.directory / "scripts"
        if self.path.is_symlink() or self.artifacts.is_symlink():
            raise Sec01PolicyBlocked("SEC01_JOURNAL: linked audit file or artifact directory")

    def event(self, request_id: str, status: str, **details: object) -> None:
        row = {"schema": SCHEMA, "time_utc": datetime.now(timezone.utc).isoformat(),
               "request_id": request_id, "status": status, **details}
        b = _canonical(row) + b"\n"
        flags = os.O_APPEND | os.O_WRONLY | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
        try:
            fd = os.open(self.path, flags, 0o600)
            try:
                if not os.path.isfile(self.path):
                    raise OSError("not a regular audit file")
                os.fchmod(fd, 0o600)
                # Write the entire record, even if os.write is partial.
                with os.fdopen(fd, "ab", closefd=False) as stream:
                    stream.write(b)
                    stream.flush()
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError as exc:
            raise Sec01PolicyBlocked("SEC01_JOURNAL: unable to durably record event") from exc

    def script(self, code: bytes, digest: str) -> str:
        try:
            self.artifacts.mkdir(mode=0o700, exist_ok=True)
            os.chmod(self.artifacts, 0o700)
            path = self.artifacts / f"{digest}.py"
            if path.is_symlink():
                raise OSError("linked script artifact")
            if path.exists():
                if sha256_bytes(path.read_bytes()) != digest:
                    raise OSError("script artifact mismatch")
            else:
                fd = os.open(path, os.O_EXCL | os.O_CREAT | os.O_WRONLY |
                             getattr(os, "O_NOFOLLOW", 0), 0o600)
                try:
                    with os.fdopen(fd, "wb", closefd=False) as stream:
                        stream.write(code)
                        stream.flush()
                    os.fsync(fd)
                finally:
                    os.close(fd)
            return str(path)
        except OSError as exc:
            raise Sec01PolicyBlocked("SEC01_ARTIFACT: cannot preserve exact script") from exc


class ExecutionGate:
    def __init__(self, *, agent_data_dir: str, workspace: Path, timeout: int,
                 environment: dict[str, str], interpreter: str):
        self.workspace = workspace
        self.timeout = timeout
        self.environment = dict(environment)
        self.interpreter = interpreter
        self.journal = AuditJournal(agent_data_dir, workspace)
        self.request_id = secrets.token_hex(16)
        self.script_sha256: str | None = None

    def approve(self, *, code: object, claim: object, grounds: object,
                warrant: object, backing: object, qualifier: object,
                rebuttal: object) -> dict:
        # Reject malformed Unicode without losing the rejected-attempt record.
        try:
            raw = code.encode("utf-8") if isinstance(code, str) else b""
        except UnicodeEncodeError:
            raw = b""
        digest = sha256_bytes(raw) if raw else None
        self.script_sha256 = digest
        self.journal.event(self.request_id, "ATTEMPT", script_sha256=digest)
        try:
            if not isinstance(code, str) or not code.strip() or not raw or len(raw) > MAX_SCRIPT_BYTES:
                raise Sec01PolicyBlocked("SEC01_SCRIPT: nonempty Python source <= 65536 bytes required")
            argument = ToulminArgument.from_values(
                claim=claim, grounds=grounds, warrant=warrant, backing=backing,
                qualifier=qualifier, rebuttal=rebuttal)
            if self.workspace.is_symlink() or not self.workspace.is_dir():
                raise Sec01PolicyBlocked("SEC01_WORKSPACE: directory unavailable or linked")
            artifact_path = self.journal.script(raw, digest)
            payload = {
                "schema": SCHEMA, "request_id": self.request_id,
                "script_sha256": digest,
                "script_bytes": len(raw), "artifact_path": artifact_path,
                "toulmin": vars(argument),
                "execution": {"interpreter": self.interpreter,
                              "argv": [self.interpreter, "-u", "<temporary exact-script.py>"],
                              "working_directory": str(self.workspace),
                              "timeout_seconds": self.timeout,
                              "environment": self.environment,
                              "isolation": "PROCESS_ONLY_NOT_OS_SANDBOX",
                              "network": "NOT_OS_BLOCKED"},
            }
            payload["request_digest"] = sha256_bytes(_canonical(payload))
            self.journal.event(self.request_id, "REVIEW_REQUIRED", request_digest=payload["request_digest"],
                               script_sha256=digest)
            allowed = ConsoleAuthorizer().authorize(request=payload, script=code)
            if not allowed:
                self.journal.event(self.request_id, "DENIED", request_digest=payload["request_digest"])
                raise Sec01Denied("SEC01_DENIED: owner did not authorize this execution")
            self.journal.event(self.request_id, "APPROVED", request_digest=payload["request_digest"])
            return payload
        except Sec01Denied:
            raise
        except Sec01PolicyBlocked as exc:
            self.journal.event(self.request_id, "BLOCKED", reason=str(exc))
            raise

    def started(self, request: dict) -> None:
        self.journal.event(self.request_id, "EXECUTION_STARTED", request_digest=request["request_digest"])

    def completed(self, *, status: str, exit_code: int | None = None,
                  stdout: str = "", stderr: str = "", diagnostic: str = "") -> None:
        self.journal.event(
            self.request_id, status, exit_code=exit_code,
            stdout_sha256=sha256_bytes(stdout.encode("utf-8", errors="replace")),
            stderr_sha256=sha256_bytes(stderr.encode("utf-8", errors="replace")),
            stdout_excerpt=stdout[:2048], stderr_excerpt=stderr[:2048],
            diagnostic=diagnostic[:1024], script_sha256=self.script_sha256)
