"""Operator interaction port and two adapters (RC-03).

This is a presentation/input abstraction, NOT independent authorization or
an isolation boundary. SEC-02 verification and dispatch remain unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
import math
import re
import secrets
from typing import Protocol

from .models import ActionProposal, ToolInvocation


class DecisionKind(str, Enum):
    APPROVE = "APPROVE"
    DENY = "DENY"
    STOP = "STOP"


def _validate_json_action(value: object, seen: set[int] | None = None) -> None:
    """Reject lossy JSON coercions, non-finite floats, and cyclic structures."""
    if value is None or type(value) in (str, int, bool):
        return
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError("Non-finite action argument")
        return
    if type(value) not in (list, dict):
        raise ValueError("Action arguments must contain exact JSON types")
    if seen is None:
        seen = set()
    if id(value) in seen:
        raise ValueError("Cyclic action arguments")
    seen.add(id(value))
    try:
        if type(value) is list:
            for element in value:
                _validate_json_action(element, seen)
        else:
            for key, item in value.items():
                if type(key) is not str:
                    raise ValueError("Action argument keys must be strings")
                _validate_json_action(item, seen)
    finally:
        seen.remove(id(value))


def action_fingerprint(proposal: ActionProposal) -> tuple[str, str]:
    """Canonical JSON action bytes and digest; rejects non-JSON tool arguments.

    Only the executable action, not untrusted reasoning, is authorization-bound.
    This is an integrity check inside one process, not human authentication.
    """
    if type(proposal) is not ActionProposal or type(proposal.use_tool) is not ToolInvocation:
        raise ValueError("Invalid proposal for authorization")
    tool = proposal.use_tool
    if type(tool.name) is not str or type(tool.arguments) is not dict:
        raise ValueError("Invalid tool invocation for authorization")
    _validate_json_action(tool.arguments)
    try:
        encoded = json.dumps(
            {"name": tool.name, "arguments": tool.arguments},
            ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False,
        )
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise ValueError("Tool arguments cannot be safely fingerprinted") from exc
    return encoded, hashlib.sha256(encoded.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class AuthorizationRequest:
    """One-use display/approval correlation, never a security principal."""
    request_id: str
    proposal_digest: str
    action_text: str
    canonical_action: str

    @classmethod
    def from_proposal(cls, proposal: ActionProposal) -> AuthorizationRequest:
        canonical, digest = action_fingerprint(proposal)
        snapshot = json.loads(canonical)
        # Operator-visible text is derived from the same canonical action,
        # but uses ASCII-only JSON escapes for ALL model-controlled strings.
        # A bound digest is not sufficient if terminal control or bidi bytes
        # can change what an operator sees on /dev/tty.
        name = snapshot["name"]
        visible_name = (name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", name)
                        else json.dumps(name, ensure_ascii=True))
        args = ", ".join(
            f"{json.dumps(k, ensure_ascii=True)}={json.dumps(v, ensure_ascii=True, sort_keys=True)}"
            for k, v in snapshot["arguments"].items()
        )
        return cls(secrets.token_hex(16), digest,
                   f"Action: {visible_name}({args})", canonical)

    def matches(self, proposal: ActionProposal) -> bool:
        try:
            return action_fingerprint(proposal)[1] == self.proposal_digest
        except ValueError:
            return False


def render_operator_literal(value: str) -> str:
    """Render untrusted operator-facing text as printable ASCII literals.

    JSON string quoting escapes ESC, C0/C1 controls, bidi marks, quotes,
    line breaks and non-ASCII without changing the underlying proposal or
    authorization digest.  No terminal escape sequence is sent verbatim.
    """
    if type(value) is not str:
        raise TypeError("Operator-visible model text must be a string")
    return json.dumps(value, ensure_ascii=True)[1:-1]


def log_operator_exception(log, message: str, error: BaseException) -> None:
    """Log an exception without forwarding untrusted control bytes to a terminal.

    Keep the operator-facing error succinct at ERROR level, while retaining
    the complete traceback at DEBUG level in escaped, inspectable form.
    This does not sanitize third-party handlers that bypass this helper.
    """
    import traceback

    log.error("%s: %s", message, render_operator_literal(str(error)))
    if log.isEnabledFor(10):
        trace = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        log.debug("Escaped traceback: %s", render_operator_literal(trace))


@dataclass(frozen=True)
class OperatorDecision:
    kind: DecisionKind
    feedback: str | None = None
    request_id: str | None = None
    proposal_digest: str | None = None

    def __post_init__(self) -> None:
        if type(self.kind) is not DecisionKind:
            raise ValueError("decision must use a known DecisionKind")
        if self.kind is DecisionKind.APPROVE and self.feedback is not None:
            raise ValueError("approved decision must not contain feedback")
        if self.kind is DecisionKind.STOP and self.feedback is not None:
            raise ValueError("stop decision must not contain feedback")
        if self.feedback is not None and type(self.feedback) is not str:
            raise ValueError("feedback must be text")
        if self.request_id is not None and type(self.request_id) is not str:
            raise ValueError("request identity must be text")
        if self.proposal_digest is not None and type(self.proposal_digest) is not str:
            raise ValueError("proposal digest must be text")
        if (self.request_id is None) != (self.proposal_digest is None):
            raise ValueError("request ID and proposal digest must be supplied together")


@dataclass(frozen=True)
class InteractionEvent:
    text: str
    kind: str = "STATUS"
    end: str = "\n"
    flush: bool = False


class InteractionPort(Protocol):
    def emit(self, event: InteractionEvent) -> None: ...
    def authorize_action(self, request: AuthorizationRequest | None = None) -> OperatorDecision: ...
    def ask_question(self, prompt: str) -> str | None: ...


class TerminalInteraction:
    """Terminal-only adapter. A piped stdin never grants authorization."""

    def emit(self, event: InteractionEvent) -> None:
        print(event.text, end=event.end, flush=event.flush)

    def authorize_action(self, request: AuthorizationRequest | None = None) -> OperatorDecision:
        self.emit(InteractionEvent("\n  Options: [yes] execute once / [no] deny / [quit] stop"))
        try:
            with open("/dev/tty", "r+", encoding="utf-8") as tty:
                if not tty.isatty():
                    return OperatorDecision(DecisionKind.DENY, "No interactive controlling terminal; action not authorized.")
                # Approval details and input must share the same controlling
                # terminal, even when runtime status output is redirected.
                if request is not None:
                    # A short write is not proof the operator saw the whole
                    # action. Refuse, rather than prompting for blind consent.
                    for line in (f"\n  ⚡ {request.action_text}\n",
                                 f"  Request: {request.request_id}\n",
                                 f"  Digest: {request.proposal_digest}\n",
                                 "  Options: [yes] execute once / [no] deny / [quit] stop\n"):
                        if tty.write(line) != len(line):
                            return OperatorDecision(DecisionKind.DENY,
                                                    "Unable to display complete authorization request.")
                question = "Authorize exactly this displayed action? [yes/no/quit] "
                # Older unbound test/legacy adapter calls do not carry an
                # executable request. Keep their historical best-effort text
                # behavior; enforce complete display for request-bound consent.
                written = tty.write(question)
                if request is not None and written != len(question):
                    return OperatorDecision(DecisionKind.DENY,
                                            "Unable to display complete authorization prompt.")
                tty.flush()
                answer = tty.readline()
                if answer == "":
                    return OperatorDecision(DecisionKind.DENY, "Terminal input ended; action not authorized.")
                choice = answer.strip().lower()
                if choice == "yes":
                    return OperatorDecision(DecisionKind.APPROVE,
                                            request_id=request.request_id if request else None,
                                            proposal_digest=request.proposal_digest if request else None)
                if choice == "quit":
                    return OperatorDecision(DecisionKind.STOP)
                if choice == "no":
                    feedback_prompt = "Optional feedback: "
                    written = tty.write(feedback_prompt)
                    if request is not None and written != len(feedback_prompt):
                        return OperatorDecision(DecisionKind.DENY,
                                                "Unable to display complete feedback prompt.")
                    tty.flush()
                    feedback = tty.readline().strip()
                    return OperatorDecision(DecisionKind.DENY, feedback or "Action denied by operator.")
                return OperatorDecision(DecisionKind.DENY, "Unrecognized authorization; explicit 'yes' required.")
        except (OSError, UnicodeError):
            return OperatorDecision(DecisionKind.DENY, "Controlling terminal unavailable; action not authorized.")
        except KeyboardInterrupt:
            return OperatorDecision(DecisionKind.STOP)

    def ask_question(self, prompt: str) -> str | None:
        try:
            return input(prompt)
        except (EOFError, KeyboardInterrupt):
            return None


@dataclass
class TestInteraction:
    """Deterministic in-process test adapter; never a trusted human principal."""
    decisions: list[OperatorDecision] = field(default_factory=list)
    answers: list[str | None] = field(default_factory=list)
    events: list[InteractionEvent] = field(default_factory=list)
    authorization_requests: int = 0
    questions: list[str] = field(default_factory=list)
    requests: list[AuthorizationRequest] = field(default_factory=list)

    def emit(self, event: InteractionEvent) -> None:
        self.events.append(event)

    def authorize_action(self, request: AuthorizationRequest | None = None) -> OperatorDecision:
        self.authorization_requests += 1
        if request is not None:
            self.requests.append(request)
        if not self.decisions:
            return OperatorDecision(DecisionKind.DENY, "No test decision supplied; action not authorized.")
        return self.decisions.pop(0)

    def ask_question(self, prompt: str) -> str | None:
        self.questions.append(prompt)
        if not self.answers:
            return None
        return self.answers.pop(0)
