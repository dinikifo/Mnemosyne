"""Agent runtime (spec §3 item 3, §9).

Implements the canonical Classic state machine:
READY -> PROPOSE -> DISPLAY -> AUTHORIZE -> EXECUTE_OR_INTERRUPT -> RECORD -> PAUSED

With escape transitions to TERMINATED, FINISHED, ABORTED.
"""

from __future__ import annotations

import json
import logging
import re
import signal
import threading
from typing import Optional

from .kernel import ComponentKernel, RequiredEvidenceError
from .llm.provider import LLMProvider
from .models import (
    ActionProposal,
    ActionResult,
    AgentConfig,
    AgentState,
    Episode,
    ResultStatus,
    Thoughts,
    ToolInvocation,
)
from .persistence.store import AgentStore
from .persistence.recovery import (RecoveryRequired, pending_state_issue,
                                   require_runtime_readiness,
                                   require_runtime_journal_head)
from .prompt import build_planning_messages
from .utils.tokens import count_tokens
from .sec01_governance import Sec01Denied
from .sec02_dispatch import Sec02PilotBlocked, pilot_preflight, pilot_dispatch_check
from .interaction import (InteractionEvent, InteractionPort, TerminalInteraction,
                          OperatorDecision, DecisionKind, AuthorizationRequest,
                          render_operator_literal, log_operator_exception)
from .workflow import WorkflowEvent, next_pending_phase

logger = logging.getLogger(__name__)


class AgentRuntime:
    """The core agent runtime implementing the Classic execution cycle.

    Coordinates agent state, component kernel and one supervised cycle.
    Operator presentation/input are delegated to an interaction port.
    """

    def __init__(
        self,
        config: AgentConfig,
        llm: LLMProvider,
        state: Optional[AgentState] = None,
        *,
        interaction: InteractionPort | None = None,
    ):
        self.config = config
        # A pilot instance must not revert to legacy command dispatch merely
        # because its *mutable* configuration is changed after construction.
        # This latch is a defense-in-depth API invariant, NOT isolation from
        # arbitrary Python running inside the agent's own process.
        self._sec02_pilot_at_creation = bool(config.sec02_pilot)
        self._memory_governance_at_creation = bool(config.governed_memory_required)
        self._hwi_at_creation = bool(config.hwi_verified_memory_required)
        self.llm = llm
        self.interaction: InteractionPort = interaction if interaction is not None else TerminalInteraction()
        self.state = state or AgentState()
        self.kernel = ComponentKernel()
        self.store = AgentStore(config.agent_data_dir)

        # Runtime flags
        self._terminated = False
        self._finish_reason: str = ""
        self._consecutive_failures = 0
        self._checkpoint_failure = False
        self._archive_failed = False
        self._authorization_request: AuthorizationRequest | None = None
        self._dispatch_approval: AuthorizationRequest | None = None
        self._display_request: AuthorizationRequest | None = None

        # Graceful interrupt handling (spec §17.3)
        self._original_sigint = signal.getsignal(signal.SIGINT)

    def _output(self, message: str, *, end: str = "\n", flush: bool = False,
                kind: str = "STATUS") -> None:
        """Emit a typed presentation event; the runtime does not write to a TTY."""
        self.interaction.emit(InteractionEvent(message, kind=kind, end=end, flush=flush))

    def _sec02_closed(self) -> bool:
        """Determine closed-pilot behavior from the construction latch as well."""
        return self._sec02_pilot_at_creation or self.config.sec02_pilot

    def _memory_governance_required(self) -> bool:
        saved = self.state.saved_config
        return bool(self._memory_governance_at_creation
                    or self.config.governed_memory_required
                    or (isinstance(saved, dict)
                        and saved.get("governed_memory_required") is True))

    def _hwi_memory_required(self) -> bool:
        saved = self.state.saved_config
        return bool(self._hwi_at_creation or self.config.hwi_verified_memory_required
                    or (isinstance(saved, dict)
                        and saved.get("hwi_verified_memory_required") is True))

    def _assert_memory_governance_integrity(self) -> None:
        if self._hwi_memory_required():
            if (not self.config.hwi_verified_memory_required
                    or not self.config.governed_memory_required or not self._sec02_closed()):
                raise Sec02PilotBlocked("HWI_C6_REQUIRED_PROFILE_MISSING_OR_DOWNGRADED")
            from research_memory.pvs_memory_selector import GovernedMemoryComponent
            hwi_providers = [c for c in self.kernel._components
                             if type(c) is GovernedMemoryComponent and c.enabled]
            from hwi.runtime_guard import HwiProtectedSelectionGuard
            if (len(hwi_providers) != 1
                    or type(hwi_providers[0].hwi_guard) is not HwiProtectedSelectionGuard
                    or hwi_providers[0].hwi_guard.selector is not hwi_providers[0].selector):
                raise Sec02PilotBlocked("HWI_C6_OPERATOR_GUARD_REQUIRED")
        if not self._memory_governance_required():
            return
        from .components.history import ActionHistoryComponent
        from research_memory.pvs_memory_selector import GovernedMemoryComponent
        if (not self.config.governed_memory_required or not self._sec02_closed()
                or not self.config.memory_journal_dir or self.state.context
                or self.state.directives.constraints or self.state.directives.resources
                or self.state.directives.best_practices):
            raise Sec02PilotBlocked("M5_GOVERNED_MEMORY_MODE_MISSING_OR_DOWNGRADED")
        providers = self.kernel._components
        if (sum(type(c) is GovernedMemoryComponent and c.enabled for c in providers) != 1
                or sum(type(c) is ActionHistoryComponent and c.enabled for c in providers) != 1):
            raise Sec02PilotBlocked("M5_VERIFIED_PROVIDER_REQUIRED")
        from .components.system import SystemComponent
        from .components.user_interaction import UserInteractionComponent
        approved = (SystemComponent, ActionHistoryComponent,
                    UserInteractionComponent, GovernedMemoryComponent)
        if any(type(c) not in approved for c in providers):
            raise Sec02PilotBlocked("M5_UNREVIEWED_PROMPT_PROVIDER")

    def _assert_sec02_pilot_integrity(self) -> None:
        """Refuse indirect kernel registration and pilot configuration downgrade.

        Run before any component protocol pipeline, not merely at dispatch.
        This is an application invariant, not a boundary against Python code
        with arbitrary memory/method modification in this same process.
        """
        if not self._sec02_closed():
            return
        if not self.config.sec02_pilot:
            raise Sec02PilotBlocked("SEC02_PILOT_MODE_DOWNGRADE")
        if (self.config.enable_code_execution or self.config.enable_web_search
                or self.config.enable_file_manager or self.config.markdown_rag_root):
            raise Sec02PilotBlocked("SEC02_UNSAFE_PILOT_CONFIGURATION")
        from .components.system import SystemComponent
        from .components.history import ActionHistoryComponent
        from .components.user_interaction import UserInteractionComponent
        from .components.context import ContextComponent
        approved = (SystemComponent, ActionHistoryComponent,
                    UserInteractionComponent, ContextComponent)
        if self._memory_governance_required():
            from research_memory.pvs_memory_selector import GovernedMemoryComponent
            approved = (SystemComponent, ActionHistoryComponent,
                        UserInteractionComponent, GovernedMemoryComponent)
        # Validate raw kernel registrations, rather than a post-shadowing
        # command catalog that might conceal a second provider or hook.
        if any(type(comp) not in approved for comp in self.kernel._components):
            raise Sec02PilotBlocked("SEC02_UNREVIEWED_KERNEL_COMPONENT")

    # -------------------------------------------------------------------
    # Component registration
    # -------------------------------------------------------------------

    def register_component(self, component) -> None:
        """Register components, disallowing unreviewed hooks in SEC-02 pilot."""
        if self._sec02_closed():
            from .components.system import SystemComponent
            from .components.history import ActionHistoryComponent
            from .components.user_interaction import UserInteractionComponent
            from .components.context import ContextComponent
            permitted = (SystemComponent, ActionHistoryComponent,
                         UserInteractionComponent, ContextComponent)
            if self._memory_governance_required():
                from research_memory.pvs_memory_selector import GovernedMemoryComponent
                permitted = (SystemComponent, ActionHistoryComponent,
                             UserInteractionComponent, GovernedMemoryComponent)
            if type(component) not in permitted:
                raise Sec02PilotBlocked("SEC02_UNREVIEWED_COMPONENT")
        self.kernel.register(component)

    def initialize(self) -> None:
        """Attach components only when no unreconciled source action is pending."""
        self._assert_sec02_pilot_integrity()
        self._assert_memory_governance_integrity()
        require_runtime_readiness(
            self.state, journal_enabled=bool(self.config.memory_journal_dir)
        )
        if self.config.memory_journal_dir:
            # A genuinely new, empty agent may create its first journal during
            # attach. Saved or already-existing source must be verified first.
            is_new_agent = (
                self.store.load(self.state.agent_id) is None
                and not self.store.agent_directory_exists(self.state.agent_id)
                and not self.state.history
                and self.state.current_episode is None
                and self.state.journal_receipt is None
                and self.state.cycle_count == 0
                and self.state.pending_phase is None
            )
            require_runtime_journal_head(
                self.state, self.config.memory_journal_dir,
                allow_new_agent_bootstrap=is_new_agent,
                preserve_journal_error=True,
            )
        self.kernel.attach_all(self)
        # Anchor the initial or resumed source head before any model call.
        # Also prevents a new agent's first journal append from being orphaned
        # by an early process crash before the first tool cycle.
        if self.config.memory_journal_dir:
            self._checkpoint()
        logger.info(
            "Agent %s initialized with task: %s",
            render_operator_literal(str(self.state.agent_id)),
            render_operator_literal(str(self.state.task)),
        )

    # -------------------------------------------------------------------
    # Main execution loop (spec §9)
    # -------------------------------------------------------------------

    def run(self) -> None:
        """Perform one foreground supervised cycle (Python main thread only)."""
        # The current architecture owns SIGINT process-wide. Fail explicitly
        # before any IO/model activity rather than crashing in signal.signal().
        if threading.current_thread() is not threading.main_thread():
            raise RuntimeError("AgentRuntime.run requires the main thread for SIGINT ownership")
        # A failed durable checkpoint poisons this runtime instance until
        # separately verified recovery. The current in-memory state may be
        # newer than persisted evidence; never retry a model call in-process.
        if self._checkpoint_failure:
            raise RecoveryRequired(
                "Previous checkpoint failed; refusing runtime retry until recovery"
            )
        # The application API may call run() without initialize(). Enforce the
        # same persisted recovery gate *before* signals, output, or checkpointing.
        require_runtime_readiness(
            self.state, journal_enabled=bool(self.config.memory_journal_dir)
        )
        if self.config.memory_journal_dir:
            # This is independent of initialize()/component attachment: direct
            # application API callers must verify the source *before* inference.
            require_runtime_journal_head(self.state, self.config.memory_journal_dir)
        # Install interrupt handler
        signal.signal(signal.SIGINT, self._handle_interrupt)

        self._output(f"\n{'='*60}")
        self._output(f"  AutoGPT Lite — Agent {render_operator_literal(str(self.state.agent_id))}")
        self._output(f"  Task: {render_operator_literal(str(self.state.task))}")
        self._output(f"  Model: {render_operator_literal(str(self.config.smart_llm))}")
        self._output(f"{'='*60}\n")

        try:
            # Readiness was already enforced before entering this try/finally.
            # Recovery is a separate owner-initiated operation. Do not turn
            # a resumed uncertain or interrupted action into another proposal.
            if self.state.current_episode and not self.state.current_episode.is_complete:
                self._handle_resume_edge_case()
            elif not self._terminated:
                self._run_one_cycle()
            # No loop: the next proposal requires a separate --resume run.

        except KeyboardInterrupt:
            self._output("\n\n⚠️  Hard interrupt — saving state and exiting.")
        finally:
            try:
                # Never overwrite a durable pre-execution marker with an
                # unjournaled in-memory result after a failed checkpoint.
                if not self._checkpoint_failure:
                    self._checkpoint()
                else:
                    logger.error("Unsafe checkpoint failure: leaving last durable state intact")
            finally:
                signal.signal(signal.SIGINT, self._original_sigint)

        if self._finish_reason:
            self._output(f"\n✅ Agent finished: {render_operator_literal(str(self._finish_reason))}")
        elif self._terminated:
            self._output("\n🛑 Agent stopped.")
        else:
            self._output(f"\n⏸️  Agent paused after one action attempt. "
                  f"Resume explicitly with --resume {self.state.agent_id}.")

    def _checkpoint(self) -> None:
        """Durably save agent state anchored to the source journal, when enabled.

        The caller must checkpoint the AUTHORIZED_UNCERTAIN intent *before*
        dispatching an external tool. Atomic publication avoids torn state JSON.
        There is no atomic transaction between the journal, state and tool.
        """
        if self._checkpoint_failure:
            raise RecoveryRequired("Previous checkpoint failed; refusing another save")
        try:
            if self.config.memory_journal_dir:
                from .persistence.episode_journal import EpisodeJournal
                journal = EpisodeJournal(self.config.memory_journal_dir,
                                         self.state.agent_id, create=False)
                report = journal.capture_history(self.state.history)
                self.state.journal_receipt = {
                    "schema": "episode-journal-receipt-v1",
                    "count": report["captured_count"],
                    "head": report["head"],
                }
            self._snapshot_config_to_state()
            self.store.save(self.state)
        except Exception as exc:
            self._checkpoint_failure = True
            log_operator_exception(logger, "Durable checkpoint failed; do not resume automatically", exc)
            raise

    def _snapshot_config_to_state(self) -> None:
        """Persist behavioral config fields for resume fidelity."""
        self.state.saved_config = {
            "smart_llm": self.config.smart_llm,
            "fast_llm": self.config.fast_llm,
            "ollama_base_url": self.config.ollama_base_url,
            "send_token_limit": self.config.send_token_limit,
            "max_result_tokens": self.config.max_result_tokens,
            "workspace_dir": self.config.workspace_dir,
            "memory_journal_dir": self.config.memory_journal_dir,
            "markdown_rag_root": self.config.markdown_rag_root,
            "markdown_rag_required": self.config.markdown_rag_required,
            "enable_code_execution": self.config.enable_code_execution,
            "enable_web_search": self.config.enable_web_search,
            "enable_file_manager": self.config.enable_file_manager,
            "sec02_pilot": self.config.sec02_pilot,
            "governed_memory_required": self._memory_governance_required(),
            "hwi_verified_memory_required": self._hwi_memory_required(),
        }

    def _run_one_cycle(self) -> None:
        """Execute one full cycle: propose → display → authorize → execute → record."""
        self._assert_sec02_pilot_integrity()
        self._assert_memory_governance_integrity()
        self.state.cycle_count += 1
        cycle = self.state.cycle_count

        self._output(f"\n--- Cycle {cycle} ---")

        # Phase 1: Proposal (spec §9.1)
        proposal = self._propose()
        if proposal is None:
            return  # Parse failure handled internally

        # SEC-02 direct answers are not commands. There is deliberately no
        # tool lookup, human execution prompt, or authorization receipt here.
        # Record the answer as a labeled non-executable history episode.
        if self._sec02_closed() and proposal.use_tool.name == "sec02.answer_only":
            self._record_answer_only(proposal)
            return

        # Record the in-flight episode BEFORE authorization/execution (Issue 3 fix).
        # This makes the pending action resumable if the process crashes mid-cycle.
        # Freeze what the operator will be asked to approve *before* the
        # durable proposal checkpoint. Closed SEC-02 pilot never authorizes.
        auth_request = (None if self._sec02_closed()
                        else AuthorizationRequest.from_proposal(proposal))
        self.state.current_episode = Episode(action=proposal)
        self.state.pending_phase = next_pending_phase(self.state.pending_phase, WorkflowEvent.PROPOSE)
        self._checkpoint()  # durable pre-authorization state
        if auth_request is not None and not auth_request.matches(proposal):
            self._checkpoint_failure = True  # preserve last durable proposal
            raise RecoveryRequired("Proposal changed after pre-authorization checkpoint")

        # Phase 2: Display (spec §9.2)
        # Keep the existing single-argument presentation seam for test and
        # UI adapters; the default implementation reads the frozen request.
        self._display_request = auth_request
        try:
            self._display(proposal)
        finally:
            self._display_request = None
        if auth_request is not None and not auth_request.matches(proposal):
            self._checkpoint_failure = True  # do not save mutated in-memory action
            raise RecoveryRequired("Proposal changed after display; recovery required")

        # SEC-02 R4: closed pilot gate runs BEFORE the terminal prompt.
        # There is no effective/approved policy and no allowed capability.
        # A displayed alias cannot become a live command, even with "yes".
        if self._sec02_closed():
            # _display() and other application hooks may have changed the
            # kernel. Check again before resolving a command or asking a human.
            self._assert_sec02_pilot_integrity()
            reason = pilot_preflight(self.kernel, proposal)
            self._record(proposal, ActionResult.error(reason))
            return

        # Phase 3: Authorization (spec §9.3)
        self._authorization_request = auth_request
        try:
            authorized, feedback = self._authorize()
        finally:
            self._authorization_request = None

        if auth_request is None or not auth_request.matches(proposal):
            self._checkpoint_failure = True
            raise RecoveryRequired("Proposal changed during authorization; recovery required")

        if authorized:
            # A crash after this checkpoint makes the outcome INDETERMINATE;
            # the operation is never automatically replayed on restart.
            self.state.pending_phase = next_pending_phase(self.state.pending_phase, WorkflowEvent.INTENT_CHECKPOINT)
            self._checkpoint()  # MUST succeed before tool dispatch
            # A checkpoint hook or nested argument mutation must not change
            # the approved action between consent and final dispatch.
            if not auth_request.matches(proposal):
                self._checkpoint_failure = True
                raise RecoveryRequired("Authorized proposal mutated before dispatch")
            self._dispatch_approval = auth_request
            try:
                result = self._execute(proposal)
            finally:
                self._dispatch_approval = None
            if not auth_request.matches(proposal):
                self._checkpoint_failure = True
                raise RecoveryRequired("Authorized proposal mutated during execution")
        else:
            if feedback is None:
                # Owner requested exit: record refusal of this proposal, not
                # an execution result. No dispatch occurred.
                self._terminated = True
                feedback = "Operator ended this invocation without authorizing the action."
            result = ActionResult.interrupted(feedback)

        # Phase 5: Record (spec §9.5)
        self._record(proposal, result)

    # -------------------------------------------------------------------
    # Phase 1: Proposal (spec §9.1)
    # -------------------------------------------------------------------

    def _propose(self) -> Optional[ActionProposal]:
        """Build prompt, call LLM, parse structured ActionProposal."""
        self._assert_sec02_pilot_integrity()
        self._assert_memory_governance_integrity()
        # Gather from component pipelines
        directives = self.kernel.collect_directives()
        directives = self.state.directives.merge(directives)

        commands = self.kernel.collect_commands()
        try:
            component_messages = self.kernel.collect_messages()
        except RequiredEvidenceError as exc:
            log_operator_exception(logger, "Required evidence unavailable; refusing to call planner", exc)
            self.state.evidence_failure = "EVIDENCE_UNAVAILABLE"
            self._terminated = True
            self._checkpoint()  # durable operator-visible stop, before authorization
            return None

        # In governed-memory mode never silently truncate signed memory data.
        try:
            messages = build_planning_messages(
                state=self.state,
                directives=directives,
                commands=commands,
                component_messages=component_messages,
                token_limit=self.config.send_token_limit,
                sec02_answer_only=self._sec02_closed(),
                governed_context_strict=self._memory_governance_required(),
            )
        except ValueError as exc:
            log_operator_exception(logger, "Governed memory context cannot fit without truncation", exc)
            self.state.evidence_failure = "M5_PROMPT_BUDGET_EXCEEDED"
            self._terminated = True
            self._checkpoint()
            return None

        # Call LLM
        self._output("  🧠 Thinking...", end="", flush=True)
        try:
            response = self.llm.chat(
                messages=messages,
                model=self.config.smart_llm,
                temperature=0.7,
                max_tokens=1024,
                json_mode=True,
            )
        except Exception as e:
            self._output(f" error: {render_operator_literal(str(e))}")
            self._consecutive_failures += 1
            if self._consecutive_failures >= self.config.max_consecutive_failures:
                self._output(f"  ❌ {self._consecutive_failures} consecutive failures — terminating.")
                self._terminated = True
            return None

        self._output(" done.")

        # Parse response into ActionProposal (spec §10.2)
        self._assert_sec02_pilot_integrity()
        proposal = self._parse_proposal(response.content, self.kernel.collect_commands())
        if proposal is None:
            self._consecutive_failures += 1
            if self._consecutive_failures >= self.config.max_consecutive_failures:
                self._output(f"  ❌ {self._consecutive_failures} consecutive parse failures — terminating (spec §17.1).")
                self._terminated = True
            return None

        # Reset failure counter on valid parse
        self._consecutive_failures = 0

        # SEC-02 review-only pilot must not run optional hooks before the
        # mandatory admission decision (they can have arbitrary side effects).
        if not self._sec02_closed():
            self.kernel.run_after_parse(proposal)

        return proposal

    def _parse_proposal(self, raw: str, commands: list) -> Optional[ActionProposal]:
        """Parse LLM JSON output into an ActionProposal."""
        try:
            # Try to extract JSON from the response
            data = self._extract_json(raw)
            if data is None:
                self._output("  ⚠️  Could not parse JSON from LLM response.")
                logger.debug("Raw response: %s", render_operator_literal(str(raw[:500])))
                return None

            # Extract thoughts
            thoughts_data = data.get("thoughts", {})
            thoughts = Thoughts(
                observations=str(thoughts_data.get("observations", "")),
                text=str(thoughts_data.get("text", "")),
                reasoning=str(thoughts_data.get("reasoning", "")),
                self_criticism=str(thoughts_data.get("self_criticism", "")),
                plan=str(thoughts_data.get("plan", "")),
                speak=str(thoughts_data.get("speak", "")),
            )

            # Extract command
            cmd_data = data.get("command", data.get("use_tool", {}))
            if "answer" in data:
                # A distinct output type, not a command in the trusted registry.
                # Reject mixed answer/command records instead of silently
                # choosing the harmless-looking half of a compound request.
                answer = data["answer"]
                if (not self._sec02_closed() or "command" in data or "use_tool" in data
                        or type(answer) is not dict or set(answer) != {"text"}
                        or type(answer["text"]) is not str
                        or not answer["text"].strip()
                        or len(answer["text"]) > 4096
                        or any((ord(ch) < 32 and ch not in "\n\t") or ord(ch) == 127
                               for ch in answer["text"])):
                    self._output("  ⚠️  Invalid SEC-02 non-executable answer format.")
                    return None
                return ActionProposal(
                    thoughts=thoughts,
                    use_tool=ToolInvocation(name="sec02.answer_only",
                                            arguments={"text": answer["text"]}),
                    raw_message=raw,
                )
            if not cmd_data or "name" not in cmd_data:
                self._output("  ⚠️  No command found in LLM response.")
                return None

            tool_name = cmd_data["name"]
            tool_args = cmd_data.get("args", cmd_data.get("arguments", {}))
            if not isinstance(tool_args, dict):
                tool_args = {}

            # Validate command exists
            valid_names = set()
            for cmd in commands:
                valid_names.add(cmd.name)
                valid_names.update(cmd.aliases)

            if tool_name not in valid_names:
                self._output(f"  ⚠️  Unknown command: '{render_operator_literal(str(tool_name))}'")
                return None

            return ActionProposal(
                thoughts=thoughts,
                use_tool=ToolInvocation(name=tool_name, arguments=tool_args),
                raw_message=raw,
            )

        except Exception as e:
            logger.warning("Proposal parse error: %s", render_operator_literal(str(e)))
            return None

    @staticmethod
    def _extract_json(text: str) -> Optional[dict]:
        """Extract a JSON object from potentially messy LLM output."""
        # Try direct parse first
        text = text.strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        # Try to find JSON within markdown code blocks
        match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass

        # Try to find the outermost { ... }
        start = text.find("{")
        if start >= 0:
            depth = 0
            for i in range(start, len(text)):
                if text[i] == "{":
                    depth += 1
                elif text[i] == "}":
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(text[start : i + 1])
                        except json.JSONDecodeError:
                            break

        return None

    def _record_answer_only(self, proposal: ActionProposal) -> None:
        """Record one model response, without authorizing or dispatching a tool.

        The synthetic action name is a persisted event label, not an installed
        Command. It is never passed to `_execute`, and all direct `_execute`
        calls in this pilot remain refused. Answers are model-generated text,
        not verified claims or demonstrations of external effects.
        """
        self._assert_sec02_pilot_integrity()
        if (not self._sec02_closed() or proposal.use_tool.name != "sec02.answer_only"
                or set(proposal.use_tool.arguments) != {"text"}):
            raise Sec02PilotBlocked("SEC02_INVALID_ANSWER_ONLY_EVENT")
        answer = proposal.use_tool.arguments["text"]
        if (type(answer) is not str or not answer.strip() or len(answer) > 4096
                or any((ord(ch) < 32 and ch not in "\n\t") or ord(ch) == 127
                       for ch in answer)):
            raise Sec02PilotBlocked("SEC02_INVALID_ANSWER_ONLY_CONTENT")
        # An answer cannot resolve an outstanding authorized intent. Compute
        # the transition before appending history or clearing pending state.
        if self.state.pending_phase == "AUTHORIZED_UNCERTAIN":
            raise RecoveryRequired(
                "An uncertain authorized action cannot be cleared by an answer-only episode"
            )
        if self.state.current_episode is not None:
            raise RecoveryRequired(
                "An answer-only episode cannot supersede an in-flight proposal"
            )
        next_phase = next_pending_phase(self.state.pending_phase, WorkflowEvent.RECORD)
        issue = pending_state_issue(self.state)
        if issue:
            raise RecoveryRequired(issue)
        event = Episode(action=proposal, result=ActionResult.success(answer),
                        summary="SEC02_NON_EXECUTABLE_ANSWER_ONLY")
        self.state.history.append(event)
        self.state.current_episode = None
        self.state.pending_phase = next_phase
        self._checkpoint()  # commit before displaying; failure never dispatches
        self._output("  💬 Answer (no tools executed): " + render_operator_literal(answer))

    # -------------------------------------------------------------------
    # Phase 2: Display (spec §9.2)
    # -------------------------------------------------------------------

    def _display(self, proposal: ActionProposal, *,
                 authorization_request: AuthorizationRequest | None = None) -> None:
        """Display the proposal to the operator."""
        if authorization_request is None:
            authorization_request = self._display_request
        t = proposal.thoughts
        if t.speak:
            self._output(f"  💬 {render_operator_literal(t.speak)}")
        if t.reasoning:
            self._output(f"  💭 Reasoning: {render_operator_literal(t.reasoning)}")
        if t.self_criticism:
            self._output(f"  🔍 Self-criticism: {render_operator_literal(t.self_criticism)}")
        if t.plan:
            self._output(f"  📋 Plan: {render_operator_literal(t.plan)}")

        if authorization_request is not None:
            self._output(f"  ⚡ {authorization_request.action_text}")
        else:
            tool = proposal.use_tool
            args_str = ", ".join(
                f"{render_operator_literal(str(k))}={render_operator_literal(repr(v))}"
                for k, v in tool.arguments.items()
            )
            self._output(f"  ⚡ Action: {render_operator_literal(tool.name)}({args_str})")

    # -------------------------------------------------------------------
    # Phase 3: Authorization (spec §9.3)
    # -------------------------------------------------------------------

    def _authorize(self, request: AuthorizationRequest | None = None) -> tuple[bool, Optional[str]]:
        """Require request-bound consent during runtime; no SEC-02 authority."""
        if request is None:
            request = self._authorization_request
        try:
            decision = (self.interaction.authorize_action(request) if request is not None
                        else self.interaction.authorize_action())
        except KeyboardInterrupt:
            return False, None
        except Exception as exc:
            log_operator_exception(logger, "Interaction adapter failed during authorization", exc)
            return False, "Interaction unavailable; action not authorized."
        if type(decision) is not OperatorDecision:
            return False, "Invalid operator decision; action not authorized."
        if decision.kind is DecisionKind.APPROVE:
            if request is not None and (decision.request_id != request.request_id
                                        or decision.proposal_digest != request.proposal_digest):
                return False, "Approval was missing or bound to another proposal."
            return True, None
        if decision.kind is DecisionKind.STOP:
            return False, None
        if decision.kind is DecisionKind.DENY:
            return False, decision.feedback or "Action denied by operator."
        # Foreign or malformed implementations must fail closed.
        return False, "Invalid operator decision; action not authorized."

    # -------------------------------------------------------------------
    # Phase 4: Execute (spec §9.4)
    # -------------------------------------------------------------------

    def _execute(self, proposal: ActionProposal) -> ActionResult:
        """Execute the selected command."""
        if self._sec02_closed():
            # Validate the raw registry first: collect_commands() can call a
            # provider, and provider code itself may cause host side effects.
            self._assert_sec02_pilot_integrity()
            return ActionResult.error(pilot_dispatch_check(self.kernel, proposal))
        # Runtime-mediated dispatch uses exactly the canonical action bound
        # to the operator decision; never a live mutable argument dictionary.
        binding = self._dispatch_approval
        if binding is not None:
            if not binding.matches(proposal):
                self._checkpoint_failure = True
                raise RecoveryRequired("Authorized proposal mutated during dispatch")
            snapshot = json.loads(binding.canonical_action)
            tool_name, tool_arguments = snapshot["name"], snapshot["arguments"]
        else:
            # Historical direct _execute() callers (including SEC-01 tests)
            # use the existing independent execution/governance path. This is
            # not an authenticated external API or an SEC-02 bypass.
            tool_name, tool_arguments = proposal.use_tool.name, proposal.use_tool.arguments

        # Refresh and resolve command (spec §11.2)
        commands = self.kernel.collect_commands()
        cmd_map = {}
        for cmd in commands:
            cmd_map[cmd.name] = cmd
            for alias in cmd.aliases:
                cmd_map[alias] = cmd

        if binding is not None and not binding.matches(proposal):
            self._checkpoint_failure = True
            raise RecoveryRequired("Authorized proposal mutated during command resolution")
        cmd = cmd_map.get(tool_name)
        if cmd is None:
            return ActionResult.error(f"Command '{tool_name}' not found.")
        if cmd.execute is None:
            return ActionResult.error(f"Command '{tool_name}' has no executor.")

        if binding is not None and not binding.matches(proposal):
            self._checkpoint_failure = True
            raise RecoveryRequired("Authorized proposal mutated during command resolution")
        self._output(f"  ⏳ Executing {render_operator_literal(tool_name)}...", end="", flush=True)
        if binding is not None and not binding.matches(proposal):
            self._checkpoint_failure = True
            raise RecoveryRequired("Authorized proposal mutated before command call")
        try:
            output = cmd.execute(**tool_arguments)
            self._output(" done.")

            # Oversized output handling (spec §11.5)
            if count_tokens(str(output)) > self.config.max_result_tokens:
                return ActionResult.error(
                    f"Output too large ({count_tokens(str(output))} tokens). "
                    "Try a more specific query or different approach."
                )

            return ActionResult.success(str(output))

        except Sec01Denied as e:
            self._output(" human authorization refused.")
            return ActionResult.interrupted(str(e))
        except TypeError as e:
            self._output(f" argument error.")
            return ActionResult.error(
                f"Invalid arguments for '{tool_name}': {e}"
            )
        except Exception as e:
            self._output(f" error.")
            log_operator_exception(logger, "Command execution failed", e)
            self.kernel.run_execution_failure(e)
            return ActionResult.error(f"Execution error: {e}")

    # -------------------------------------------------------------------
    # Phase 5: Record (spec §9.5)
    # -------------------------------------------------------------------

    def _record(self, proposal: ActionProposal, result: ActionResult) -> None:
        """Record the episode and run post-execution hooks."""
        # Transition validation must not occur after history mutation, result
        # emission, or optional external hooks.
        next_phase = next_pending_phase(self.state.pending_phase, WorkflowEvent.RECORD)
        issue = pending_state_issue(self.state)
        if issue:
            raise RecoveryRequired(issue)
        episode = Episode(action=proposal, result=result)
        self.state.history.append(episode)

        # Display result
        if result.status == ResultStatus.SUCCESS:
            out = result.outputs or "ok"
            if len(out) > 200:
                out = out[:200] + "..."
            self._output(f"  ✅ Result: {render_operator_literal(str(out))}")
        elif result.status == ResultStatus.ERROR:
            self._output(f"  ❌ Error: {render_operator_literal(str(result.reason))}")
        else:
            self._output(f"  ⏸️  Interrupted: {render_operator_literal(str(result.feedback))}")

        # Run AfterExecute hooks; kernel isolates individual failures, so a
        # history-journal hook sets _terminated on its own archive failure.
        if not self._sec02_closed():
            # Optional hooks are not part of the pilot's trusted preflight.
            self.kernel.run_after_execute(result)
        if self._archive_failed:
            self._checkpoint_failure = True
            return  # leave last durable intent unchanged; never resume this run
        self.state.current_episode = None
        self.state.pending_phase = next_phase
        self._checkpoint()

    # -------------------------------------------------------------------
    # Interrupt handling (spec §17.3)
    # -------------------------------------------------------------------

    def _handle_interrupt(self, signum, frame) -> None:
        """Stop this invocation; never downgrade to an auto-running mode."""
        raise KeyboardInterrupt

    # -------------------------------------------------------------------
    # Resume edge case (spec §15.4)
    # -------------------------------------------------------------------

    def _handle_resume_edge_case(self) -> None:
        """Handle resume with an unfinished in-flight episode (spec §15.4).

        This fires when the agent was interrupted mid-cycle (after proposal,
        before result).  Two sub-cases:
          a) The pending action was 'finish' → offer to re-terminate or continue.
          b) The pending action was any other command → inform operator and
             record as interrupted so the planner can retry.
        """
        ep = self.state.current_episode
        if ep is None or ep.is_complete:
            return

        # An interrupted pre-authorization proposal can be resolved locally
        # only without a journal. Recheck before mutation: never downgrade
        # AUTHORIZED_UNCERTAIN or journal-backed pending actions into a retry.
        require_runtime_readiness(
            self.state, journal_enabled=bool(self.config.memory_journal_dir)
        )
        resolved_phase = next_pending_phase(
            self.state.pending_phase, WorkflowEvent.RECORD
        )

        tool_name = ep.action.use_tool.name
        tool_args = ep.action.use_tool.arguments

        if tool_name == "finish":
            reason = tool_args.get("reason", "unknown")
            self._output(f"  ℹ️  Agent previously self-terminated (reason: {render_operator_literal(str(reason))})")
            self._output(f"     but the termination was not fully finalized.")
            feedback = (self.interaction.ask_question(
                "  Continue with new instructions? "
                "(or press Enter to accept termination): ") or "").strip()
            if feedback:
                ep.result = ActionResult.interrupted(feedback)
                self.state.history.append(ep)
                self.state.current_episode = None
            else:
                self._terminated = True
                self._finish_reason = reason
                self.state.current_episode = None
        else:
            self._output(f"  ℹ️  Resuming with an incomplete episode from a prior session.")
            self._output(f"     Pending action was: {render_operator_literal(str(tool_name))}({render_operator_literal(repr(tool_args))})")
            self._output(f"     Recording it as interrupted so the planner can decide next steps.")
            ep.result = ActionResult.interrupted(
                "Action was not completed because the agent was interrupted mid-cycle."
            )
            self.state.history.append(ep)
            self.state.current_episode = None

        # Establish the complete in-memory state before any more interaction.
        # run() checkpoints phase and episode/history together; failed saves
        # preserve the preceding durable proposal without inventing recovery.
        self.state.pending_phase = resolved_phase
        if tool_name == "finish" and feedback:
            self._output(f"  ▶️  Resuming with feedback: {render_operator_literal(feedback)}")
