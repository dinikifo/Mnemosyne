"""Small, pure checks over the EXISTING persisted episode-phase field (RC-04).

This is not a new workflow engine or source of authorization. The existing
AgentState.pending_phase strings and checkpoint order remain authoritative.
"""
from __future__ import annotations

from enum import Enum


class WorkflowTransitionError(ValueError):
    """Refuse an impossible or unrecognized local transition."""


class WorkflowEvent(str, Enum):
    PROPOSE = "PROPOSE"
    INTENT_CHECKPOINT = "INTENT_CHECKPOINT"
    RECORD = "RECORD"


KNOWN_PHASES = frozenset((None, "PROPOSED", "AUTHORIZED_UNCERTAIN"))


def next_pending_phase(current: str | None, event: WorkflowEvent) -> str | None:
    """Compute a phase update; never touch storage, approval, tools or receipts.

    RECORD from None supports legacy direct error/answer recording, while
    RECORD from PROPOSED covers denied or SEC-02-blocked proposals.  A stored
    AUTHORIZED_UNCERTAIN marker must still be reconciled by the existing
    recovery path; this helper does not authorize restart or automatic retry.
    """
    if current not in KNOWN_PHASES or type(event) is not WorkflowEvent:
        raise WorkflowTransitionError("Unrecognized proposal workflow phase/event")
    if event is WorkflowEvent.PROPOSE and current is None:
        return "PROPOSED"
    if event is WorkflowEvent.INTENT_CHECKPOINT and current == "PROPOSED":
        return "AUTHORIZED_UNCERTAIN"
    if event is WorkflowEvent.RECORD:
        return None
    raise WorkflowTransitionError(f"Invalid proposal transition from {current!r}: {event.value}")
