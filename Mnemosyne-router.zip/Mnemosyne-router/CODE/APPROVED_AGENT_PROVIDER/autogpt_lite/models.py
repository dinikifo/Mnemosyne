"""Core data models for AutoGPT Lite.

Implements spec sections 5.1–5.9: AgentConfig, AgentState, Directives,
Command, ActionProposal, Thoughts, ActionResult, Episode, ContextItem.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional


# ---------------------------------------------------------------------------
# 5.6 Thoughts
# ---------------------------------------------------------------------------

@dataclass
class Thoughts:
    """Structured introspection payload from the planner."""
    observations: str = ""
    text: str = ""
    reasoning: str = ""
    self_criticism: str = ""
    plan: str = ""
    speak: str = ""


# ---------------------------------------------------------------------------
# 5.5 ActionProposal
# ---------------------------------------------------------------------------

@dataclass
class ToolInvocation:
    """A single tool call: name + structured arguments."""
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class ActionProposal:
    """Planner output for one cycle (spec §5.5)."""
    thoughts: Thoughts
    use_tool: ToolInvocation
    raw_message: str = ""  # internal only, excluded from planner schema


# ---------------------------------------------------------------------------
# 5.7 ActionResult
# ---------------------------------------------------------------------------

class ResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    INTERRUPTED_BY_HUMAN = "interrupted_by_human"


@dataclass
class ActionResult:
    """Normalized result envelope (spec §5.7)."""
    status: ResultStatus
    outputs: Optional[str] = None
    reason: Optional[str] = None
    feedback: Optional[str] = None

    @classmethod
    def success(cls, outputs: str) -> ActionResult:
        return cls(status=ResultStatus.SUCCESS, outputs=outputs)

    @classmethod
    def error(cls, reason: str) -> ActionResult:
        return cls(status=ResultStatus.ERROR, reason=reason)

    @classmethod
    def interrupted(cls, feedback: str) -> ActionResult:
        return cls(status=ResultStatus.INTERRUPTED_BY_HUMAN, feedback=feedback)


# ---------------------------------------------------------------------------
# 5.8 Episode
# ---------------------------------------------------------------------------

@dataclass
class Episode:
    """One step in the execution history (spec §5.8)."""
    action: ActionProposal
    result: Optional[ActionResult] = None
    summary: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    # Appended after existing fields to preserve old positional constructor calls.
    # Only populated once the opt-in source journal acknowledges an episode.
    source_seq: Optional[int] = None
    source_sha256: Optional[str] = None

    @property
    def is_complete(self) -> bool:
        return self.result is not None


# ---------------------------------------------------------------------------
# 5.9 ContextItem
# ---------------------------------------------------------------------------

@dataclass
class ContextItem:
    """A prompt-visible working-set item (spec §5.9)."""
    item_type: str  # "file" or "folder"
    path: str
    content: str = ""
    description: str = ""


# ---------------------------------------------------------------------------
# 5.4 Command
# ---------------------------------------------------------------------------

@dataclass
class Command:
    """An executable tool entry exposed to the planner (spec §5.4)."""
    name: str
    description: str
    parameters: dict[str, str] = field(default_factory=dict)
    execute: Optional[Callable[..., str]] = None
    aliases: list[str] = field(default_factory=list)
    enabled: bool = True

    def to_schema(self) -> dict[str, Any]:
        """Convert to a schema dict for prompt injection."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                k: {"type": v, "required": True}
                for k, v in self.parameters.items()
            },
        }


# ---------------------------------------------------------------------------
# 5.3 Directives
# ---------------------------------------------------------------------------

@dataclass
class Directives:
    """Planner guidance (spec §5.3)."""
    constraints: list[str] = field(default_factory=list)
    resources: list[str] = field(default_factory=list)
    best_practices: list[str] = field(default_factory=list)

    def merge(self, other: Directives) -> Directives:
        """Merge another set of directives into this one."""
        return Directives(
            constraints=self.constraints + other.constraints,
            resources=self.resources + other.resources,
            best_practices=self.best_practices + other.best_practices,
        )


# ---------------------------------------------------------------------------
# 5.2 AgentState
# ---------------------------------------------------------------------------

@dataclass
class AIProfile:
    """The agent's persona."""
    name: str = "AutoGPT Lite"
    role: str = "a general-purpose AI assistant agent"
    goals: list[str] = field(default_factory=list)


@dataclass
class AgentState:
    """Persistent agent settings and working state (spec §5.2)."""
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    task: str = ""
    ai_profile: AIProfile = field(default_factory=AIProfile)
    directives: Directives = field(default_factory=Directives)
    history: list[Episode] = field(default_factory=list)
    context: list[ContextItem] = field(default_factory=list)
    current_episode: Optional[Episode] = None
    cycle_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    # Runtime config snapshot for resume fidelity.
    # Persisted fields: smart_llm, fast_llm, send_token_limit, max_result_tokens,
    # workspace_dir, enable_code_execution, enable_web_search, enable_file_manager.
    # Legacy continuous-mode fields are ignored and never resumed.
    saved_config: Optional[dict] = None
    # AM03: observed journal head at most recent durable state checkpoint.
    journal_receipt: Optional[dict] = None
    # Proposed is pre-authorization; AUTHORIZED_UNCERTAIN is a write-ahead marker.
    # Never infer an authorized tool did NOT execute following a crash.
    pending_phase: Optional[str] = None
    # Evidence-required planning halted. Operator must reconcile before resume.
    evidence_failure: Optional[str] = None


# ---------------------------------------------------------------------------
# 5.1 AgentConfig
# ---------------------------------------------------------------------------

@dataclass
class AgentConfig:
    """Runtime behavior configuration (spec §5.1)."""
    fast_llm: str = "llama3.2:3b"
    smart_llm: str = "llama3.2:3b"
    ollama_base_url: str = "http://localhost:11434"
    use_functions_api: bool = False  # Ollama JSON mode instead
    send_token_limit: int = 3072
    max_result_tokens: int = 1024  # ~1/3 of send_token_limit
    max_consecutive_failures: int = 3
    # Explicit opt-in; never store private episode journals in the code workspace.
    memory_journal_dir: Optional[str] = None
    markdown_rag_root: Optional[str] = None
    # Defaults to fail-closed when a corpus is configured; opt out explicitly.
    markdown_rag_required: bool = True
    agent_data_dir: str = "./agents"
    workspace_dir: str = "./workspace"
    enable_code_execution: bool = True
    enable_web_search: bool = False
    enable_file_manager: bool = True
    # SEC-02 R4: opt-in, sticky, fail-closed *review-only* profile.
    # No QSECD capability can execute until a later accepted policy milestone.
    sec02_pilot: bool = False
    # M5: opt-in, sticky, read-only verified PVS memory for SEC-02 pilot only.
    governed_memory_required: bool = False
    # HWI C6: sticky, operator-provisioned C5 evidence guard for governed prompt data.
    hwi_verified_memory_required: bool = False
