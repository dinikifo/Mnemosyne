"""Ollama LLM provider implementation.

Communicates with a local Ollama instance via its HTTP API.
Optimized for low-end hardware: short timeouts, retry logic, streaming disabled
by default to reduce memory pressure.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Optional

import requests

from .provider import LLMMessage, LLMProvider, LLMResponse
from ..interaction import render_operator_literal

logger = logging.getLogger(__name__)


class OllamaProvider(LLMProvider):
    """LLM provider backed by a local Ollama server."""

    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        # Generous timeout for slow hardware — Pi 5 can take 60s+ for 3B models
        self._session.timeout = 300

    def chat(
        self,
        messages: list[LLMMessage],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        json_mode: bool = False,
    ) -> LLMResponse:
        """Send a chat completion request to Ollama."""
        payload: dict = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        if json_mode:
            payload["format"] = "json"

        url = f"{self.base_url}/api/chat"
        logger.debug("Ollama request: model=%s messages=%d json_mode=%s",
                      render_operator_literal(str(model)), len(messages), json_mode)

        start = time.monotonic()
        try:
            resp = self._session.post(url, json=payload, timeout=300)
            resp.raise_for_status()
        except requests.ConnectionError:
            raise ConnectionError(
                f"Cannot connect to Ollama at {self.base_url}. "
                "Is `ollama serve` running?"
            )
        except requests.Timeout:
            raise TimeoutError(
                f"Ollama request timed out after 300s. "
                "The model may be too large for your hardware."
            )
        except requests.HTTPError as e:
            if resp.status_code == 404:
                raise RuntimeError(
                    f"Model '{model}' not found by Ollama. "
                    f"Pull it with: ollama pull {model}"
                )
            raise RuntimeError(f"Ollama HTTP error: {e}")

        elapsed = time.monotonic() - start
        data = resp.json()

        content = data.get("message", {}).get("content", "")
        prompt_tokens = data.get("prompt_eval_count", 0)
        completion_tokens = data.get("eval_count", 0)

        logger.info(
            "Ollama response: model=%s tokens=%d+%d time=%.1fs",
            render_operator_literal(str(model)), prompt_tokens, completion_tokens, elapsed,
        )

        return LLMResponse(
            content=content,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )

    def validate(self) -> bool:
        """Check Ollama is reachable and list available models."""
        try:
            resp = self._session.get(f"{self.base_url}/api/tags", timeout=10)
            resp.raise_for_status()
            models = [m["name"] for m in resp.json().get("models", [])]
            if models:
                logger.info("Ollama available models: %s", render_operator_literal(", ".join(models)))
            else:
                logger.warning("Ollama is running but no models are pulled.")
            return True
        except Exception as e:
            logger.error("Ollama validation failed: %s", render_operator_literal(str(e)))
            return False

    def list_models(self) -> list[str]:
        """Return names of locally available models."""
        try:
            resp = self._session.get(f"{self.base_url}/api/tags", timeout=10)
            resp.raise_for_status()
            return [m["name"] for m in resp.json().get("models", [])]
        except Exception:
            return []
