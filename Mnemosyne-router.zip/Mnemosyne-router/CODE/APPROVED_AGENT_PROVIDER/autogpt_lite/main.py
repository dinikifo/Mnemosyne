"""AutoGPT Lite — Entry point and CLI (spec §8 Boot sequence).

Implements the boot sequence:
1. Load configuration
2. Initialize storage
3. Configure logging
4. Validate LLM credentials
5. Create LLM provider
6. Discover saved agents
7. Resume or create new agent
8. Apply component configuration
9. Enter interaction loop
10. Persist state on termination
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

from .agent import AgentRuntime
from .components.code_executor import CodeExecutorComponent
from .components.context import ContextComponent
from .components.file_manager import FileManagerComponent
from .components.history import ActionHistoryComponent
from .components.system import SystemComponent
from .components.user_interaction import UserInteractionComponent
from .components.web_search import WebSearchComponent
from .llm.ollama import OllamaProvider
from .models import AgentConfig, AgentState, AIProfile
from .persistence.store import AgentStore
from .interaction import render_operator_literal


def _saved_cycle_display(agent: dict) -> str:
    """Render untrusted cycle metadata, visibly flagging invalid saved state.

    AgentStore does not silently coerce counters or declare malformed records
    verified. Keep the original value visible only as escaped diagnostic text.
    """
    count = agent.get("cycle_count")
    if type(count) is int and count >= 0 and agent.get("cycle_count_valid") is not False:
        return str(count)
    return "INVALID: " + render_operator_literal(str(count))


def _saved_cycle_is_valid(state: AgentState) -> bool:
    return type(state.cycle_count) is int and state.cycle_count >= 0


def _saved_task_display(agent: dict, limit: int) -> str:
    """Display untrusted saved task metadata without assuming string type.

    Invalid values are explicitly marked and shown only as short, escaped
    diagnostics. No value is coerced into a runnable task or saved back.
    """
    task = agent.get("task")
    if agent.get("task_valid") is False or type(task) is not str:
        return "INVALID: " + render_operator_literal(repr(task)[:limit])
    shortened = task[:limit] + ("..." if len(task) > limit else "")
    return render_operator_literal(shortened)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="autogpt-lite",
        description="AutoGPT Lite — Lightweight autonomous agent for local LLMs",
    )
    parser.add_argument(
        "--task", "-t",
        help="Task description for a new agent",
    )
    parser.add_argument(
        "--resume", "-r",
        metavar="AGENT_ID",
        help="Resume a saved agent by ID",
    )
    parser.add_argument(
        "--list-agents", "-l",
        action="store_true",
        help="List saved agents and exit",
    )
    parser.add_argument(
        "--smart-model",
        default=os.environ.get("SMART_MODEL", "llama3.2:3b"),
        help="Model for planning (default: llama3.2:3b)",
    )
    parser.add_argument(
        "--fast-model",
        default=os.environ.get("FAST_MODEL", "llama3.2:3b"),
        help="Model for summarization (default: llama3.2:3b)",
    )
    parser.add_argument(
        "--ollama-url",
        default=os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434"),
        help="Ollama API URL",
    )
    parser.add_argument(
        "--token-limit",
        type=int,
        default=int(os.environ.get("SEND_TOKEN_LIMIT", "3072")),
        help="Max prompt tokens (default: 3072)",
    )
    parser.add_argument(
        "--data-dir",
        default=os.environ.get("AGENT_DATA_DIR", "./agents"),
        help="Agent persistence directory",
    )
    parser.add_argument(
        "--memory-journal-dir",
        default=os.environ.get("MEMORY_JOURNAL_DIR"),
        help="Absolute external directory for opt-in preserved source episodes",
    )
    parser.add_argument(
        "--markdown-rag-root",
        default=os.environ.get("MARKDOWN_RAG_ROOT"),
        help="Absolute external read-only Markdown directory (opt-in)",
    )
    parser.add_argument(
        "--markdown-rag-best-effort",
        action="store_true",
        help="Opt out of fail-closed evidence retrieval; unsafe for evidence-dependent actions",
    )
    parser.add_argument(
        "--workspace",
        default=os.environ.get("WORKSPACE_DIR", "./workspace"),
        help="Agent workspace directory",
    )
    parser.add_argument(
        "--sec02-pilot", action="store_true", default=True,
        help="SEC-02 closed pilot (already the CLI default): refuse all tool execution",
    )
    parser.add_argument(
        "--enable-web-search",
        action="store_true",
        default=False,
        help="Enable web search component",
    )
    parser.add_argument(
        "--disable-code-execution",
        action="store_true",
        default=False,
        help="Disable code execution component",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable debug logging",
    )
    return parser.parse_args()


def setup_logging(verbose: bool = False) -> None:
    """Step 3: Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    # Quiet down noisy libs
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


def build_config(args: argparse.Namespace) -> AgentConfig:
    """Step 1: Load configuration."""
    config = AgentConfig(
        smart_llm=args.smart_model,
        fast_llm=args.fast_model,
        ollama_base_url=args.ollama_url,
        send_token_limit=args.token_limit,
        max_result_tokens=args.token_limit // 3,
        agent_data_dir=args.data_dir,
        memory_journal_dir=args.memory_journal_dir,
        markdown_rag_root=args.markdown_rag_root,
        markdown_rag_required=not args.markdown_rag_best_effort,
        workspace_dir=args.workspace,
        enable_code_execution=not args.disable_code_execution,
        enable_web_search=args.enable_web_search,
        sec02_pilot=True,  # SEC-02 CLI always fail-closed until R5 authorizes a reviewed capability
    )

    return config


def build_agent(config: AgentConfig, llm: OllamaProvider, state: AgentState, *,
                governed_memory_provider=None) -> AgentRuntime:
    """Step 8: Create agent runtime and register components (spec §7)."""
    if config.hwi_verified_memory_required and not config.governed_memory_required:
        raise ValueError("HWI C6 requires governed-memory mode")
    agent = AgentRuntime(config=config, llm=llm, state=state)

    # Register components in deterministic order
    agent.register_component(SystemComponent())
    agent.register_component(ActionHistoryComponent(
        recent_steps=3,
        summary_token_budget=min(512, config.send_token_limit // 6),
    ))
    agent.register_component(UserInteractionComponent())

    if config.enable_file_manager:
        agent.register_component(FileManagerComponent())

    if config.enable_code_execution:
        agent.register_component(CodeExecutorComponent(
            timeout=30,
            allow_shell=False,  # Shell disabled by default for safety
        ))

    if config.enable_web_search:
        agent.register_component(WebSearchComponent())

    if not config.governed_memory_required:
        agent.register_component(ContextComponent())
    # M5 opt-in operator provisioner. Never read reviewer authority or pins
    # from model output, saved state or an untrusted agent workspace.
    if governed_memory_provider is not None:
        if not config.governed_memory_required:
            raise ValueError("PVS memory provider requires governed-memory mode")
        agent.register_component(governed_memory_provider)
    # The ordinary CLI intentionally has no trusted enrollment/provisioning
    # facility; governed mode fails closed if no provider was attached.
    if config.markdown_rag_root:
        from research_memory.markdown_agent import MarkdownRAGComponent
        agent.register_component(MarkdownRAGComponent(
            config.markdown_rag_root, required=config.markdown_rag_required))

    return agent


def main() -> None:
    """Main entry point — implements the boot sequence (spec §8)."""
    args = parse_args()

    # Step 3: Configure logging
    setup_logging(args.verbose)
    logger = logging.getLogger(__name__)

    # Step 1: Load configuration
    config = build_config(args)

    # Step 2: Initialize storage
    Path(config.agent_data_dir).mkdir(parents=True, exist_ok=True)
    Path(config.workspace_dir).mkdir(parents=True, exist_ok=True)

    store = AgentStore(config.agent_data_dir)

    # Handle local-only commands before requiring LLM connectivity.
    if args.list_agents:
        agents = store.list_agents()
        if not agents:
            print("No saved agents.")
        else:
            print(f"{'ID':<10} {'Cycles':<8} {'Task'}")
            print("-" * 60)
            for a in agents:
                print(f"{render_operator_literal(str(a['agent_id'])):<10} {_saved_cycle_display(a):<8} {_saved_task_display(a, 45)}")
        sys.exit(0)

    # Step 6 & 7: Discover agents, resume or create new.
    # This happens BEFORE provider construction so that saved config
    # (including ollama_base_url) can influence which backend we connect to.
    if args.resume:
        from .persistence.store import StateRecoveryError
        try:
            state = store.load(args.resume)
        except StateRecoveryError:
            print("❌ Existing agent state is unreadable or inconsistent; manual recovery required.")
            sys.exit(2)
        if state is None:
            print(f"❌ Agent '{render_operator_literal(str(args.resume))}' not found.")
            sys.exit(1)
        print(f"▶️  Resuming agent {render_operator_literal(str(state.agent_id))} (cycle {render_operator_literal(str(state.cycle_count))})")
    elif args.task:
        state = AgentState(task=args.task)
        print(f"🆕 New agent {render_operator_literal(str(state.agent_id))}")
    else:
        # Interactive: list agents and ask
        agents = store.list_agents()
        if agents:
            print("\nSaved agents:")
            for i, a in enumerate(agents, 1):
                print(f"  {i}. [{render_operator_literal(str(a['agent_id']))}] {_saved_task_display(a, 50)} (cycle {_saved_cycle_display(a)})")
            print(f"  {len(agents)+1}. Create new agent")

            try:
                choice = input("\nSelect: ").strip()
                if choice.isdigit() and 1 <= int(choice) <= len(agents):
                    agent_id = agents[int(choice) - 1]["agent_id"]
                    from .persistence.store import StateRecoveryError
                    try:
                        state = store.load(agent_id)
                    except StateRecoveryError:
                        print("❌ Existing agent state cannot be verified; manual recovery required.")
                        sys.exit(2)
                    if state is None:
                        print("Failed to load agent.")
                        sys.exit(1)
                else:
                    task = input("Enter task: ").strip()
                    if not task:
                        print("No task provided.")
                        sys.exit(1)
                    state = AgentState(task=task)
            except (EOFError, KeyboardInterrupt):
                print("\nExiting.")
                sys.exit(0)
        else:
            try:
                task = input("Enter task: ").strip()
                if not task:
                    print("No task provided.")
                    sys.exit(1)
                state = AgentState(task=task)
            except (EOFError, KeyboardInterrupt):
                print("\nExiting.")
                sys.exit(0)

    if not _saved_cycle_is_valid(state):
        print("❌ Saved cycle metadata is invalid; manual recovery required.")
        sys.exit(2)
    if type(state.task) is not str:
        print("❌ Saved task metadata is invalid; manual recovery required.")
        sys.exit(2)

    # Restore persisted config BEFORE provider construction and agent build.
    # This ensures: (a) ollama_base_url connects to the right backend,
    # (b) feature toggles determine which components are registered,
    # (c) model names are validated against the effective config.
    _restore_config_before_build(config, state, args)

    # SEC-02's review-only profile is sticky on resume. The candidate rulebook
    # is not effective; its runtime dispatch gate denies all tools, even finish.
    if config.sec02_pilot:
        config.enable_code_execution = False
        config.enable_file_manager = False
        config.enable_web_search = False
        config.markdown_rag_root = None

    # IM14: reject unsafe RAG/tool combinations before contacting Ollama.
    if config.markdown_rag_root and config.enable_code_execution:
        print("❌ Markdown RAG requires --disable-code-execution.")
        print("   This is not an OS sandbox; isolate sources from the agent UID for live use.")
        sys.exit(2)
    if state.evidence_failure:
        print("❌ Prior required-evidence failure; manual source inspection and reconciliation needed.")
        sys.exit(2)

    # AM03: fail locally and visibly before contacting the model or making
    # another proposal when an earlier tool outcome may be uncertain.
    if args.resume and config.memory_journal_dir:
        from .persistence.recovery import inspect_recovery
        from .persistence.episode_journal import JournalError
        try:
            recovery = inspect_recovery(state, config.memory_journal_dir)
        except (JournalError, OSError, ValueError):
            print("❌ Source journal unavailable; manual recovery inspection required.")
            sys.exit(2)
        if recovery["status"] not in ("READY_VERIFIED", "LEGACY_SOURCE_SCOPE_LIMITED"):
            print(f"❌ Recovery hold: {render_operator_literal(str(recovery['status']))}")
            print("   Inspect the saved state and journal; do not automatically retry tools.")
            sys.exit(2)

    # Step 4 & 5: Create and validate LLM provider using effective config.
    llm = OllamaProvider(base_url=config.ollama_base_url)
    print(f"🔌 Connecting to Ollama at {render_operator_literal(str(config.ollama_base_url))}...")
    if not llm.validate():
        print("❌ Cannot connect to Ollama. Is it running?")
        print(f"   Expected URL: {render_operator_literal(str(config.ollama_base_url))}")
        print("   Start with: ollama serve")
        sys.exit(1)

    # Validate models against the effective (possibly restored) config.
    available = llm.list_models()
    if available:
        for role, attr in [("smart", "smart_llm"), ("fast", "fast_llm")]:
            model_name = getattr(config, attr)
            if model_name in available:
                continue  # exact match, all good

            # Try prefix match (e.g. "llama3.2" matches "llama3.2:3b")
            base = model_name.split(":")[0]
            matches = [m for m in available if m.startswith(base)]
            if matches:
                print(f"⚠️  Model '{render_operator_literal(str(model_name))}' not found, using '{render_operator_literal(str(matches[0]))}' for {role} role.")
                setattr(config, attr, matches[0])
            else:
                # No match at all — fall back to first available model
                fallback = available[0]
                print(f"⚠️  Model '{render_operator_literal(str(model_name))}' not found locally.")
                print(f"   Falling back to '{render_operator_literal(str(fallback))}' for {role} role.")
                print(f"   To use the intended model: ollama pull {render_operator_literal(str(model_name))}")
                setattr(config, attr, fallback)
    else:
        print("⚠️  No models found in Ollama. Pull one first:")
        print(f"   ollama pull {render_operator_literal(str(config.smart_llm))}")
        sys.exit(1)

    # Step 8: Build agent with components (uses effective config)
    agent = build_agent(config, llm, state)

    # Initialize components
    agent.initialize()

    # Step 9: Enter interaction loop
    agent.run()

    # Step 10 is handled inside agent.run() on termination


def _restore_config_before_build(
    config: AgentConfig, state: AgentState, args: argparse.Namespace,
) -> None:
    """Restore persisted config fields into the live config before
    components are constructed.

    Precedence rules:
    - If the operator passed an explicit CLI flag, that wins.
    - Otherwise, if a value was saved in the agent state, restore it.
    - Otherwise, keep the default.

    Legacy continuous execution fields are never restored. Every invocation
    remains a single supervised action attempt.
    """
    saved = state.saved_config
    # A saved SEC-02 pilot cannot be downgraded by omitting the CLI flag.
    # This is a same-UID process control, not cryptographic source authority.
    if isinstance(saved, dict) and saved.get("sec02_pilot") is True:
        config.sec02_pilot = True
    if isinstance(saved, dict) and saved.get("governed_memory_required") is True:
        config.governed_memory_required = True
    if isinstance(saved, dict) and saved.get("hwi_verified_memory_required") is True:
        config.hwi_verified_memory_required = True
    if not saved:
        return

    defaults = AgentConfig()

    # Backend URL: restore unless CLI explicitly set it
    if config.ollama_base_url == defaults.ollama_base_url and "ollama_base_url" in saved:
        old_url = config.ollama_base_url
        config.ollama_base_url = saved["ollama_base_url"]
        if config.ollama_base_url != old_url:
            print(f"  ℹ️  Restoring Ollama URL from saved config: {render_operator_literal(str(config.ollama_base_url))}")

    # Model names: restore unless CLI explicitly set them
    if config.smart_llm == defaults.smart_llm and "smart_llm" in saved:
        config.smart_llm = saved["smart_llm"]
    if config.fast_llm == defaults.fast_llm and "fast_llm" in saved:
        config.fast_llm = saved["fast_llm"]

    # Token limits: restore unless CLI explicitly set them
    if config.send_token_limit == defaults.send_token_limit and "send_token_limit" in saved:
        config.send_token_limit = saved["send_token_limit"]
        config.max_result_tokens = saved.get(
            "max_result_tokens", saved["send_token_limit"] // 3
        )

    # Workspace: restore unless CLI explicitly set it
    if config.memory_journal_dir is None and "memory_journal_dir" in saved:
        config.memory_journal_dir = saved["memory_journal_dir"]
    if config.markdown_rag_root is None and "markdown_rag_root" in saved:
        config.markdown_rag_root = saved["markdown_rag_root"]
    if "markdown_rag_required" in saved and not getattr(args, "markdown_rag_best_effort", False):
        config.markdown_rag_required = saved["markdown_rag_required"]
    if config.workspace_dir == defaults.workspace_dir and "workspace_dir" in saved:
        config.workspace_dir = saved["workspace_dir"]
        # Ensure the restored workspace exists
        Path(config.workspace_dir).mkdir(parents=True, exist_ok=True)

    # Feature toggles: restore unless CLI explicitly changed them
    if config.enable_code_execution == defaults.enable_code_execution and "enable_code_execution" in saved:
        config.enable_code_execution = saved["enable_code_execution"]
    if config.enable_web_search == defaults.enable_web_search and "enable_web_search" in saved:
        config.enable_web_search = saved["enable_web_search"]
    if config.enable_file_manager == defaults.enable_file_manager and "enable_file_manager" in saved:
        config.enable_file_manager = saved["enable_file_manager"]


if __name__ == "__main__":
    main()
