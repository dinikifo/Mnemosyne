"""Prompt builder (spec §10).

Constructs the one-shot next-action planning prompt from:
- User task
- Current directives
- Available command catalog
- Component messages (history, context, clock, etc.)
- Instruction to choose exactly one command
"""

from __future__ import annotations

import json
from typing import Any

from .models import AgentState, Command, Directives
from .llm.provider import LLMMessage
from .utils.tokens import count_tokens


# ---------------------------------------------------------------------------
# Response schema that the LLM must follow
# ---------------------------------------------------------------------------

RESPONSE_SCHEMA = {
    "thoughts": {
        "observations": "What you observe about the current situation",
        "text": "Your main thought",
        "reasoning": "Why you chose this action",
        "self_criticism": "What could go wrong or what you might be missing",
        "plan": "Your short-term plan (1-3 steps)",
        "speak": "A brief message to the user about what you're doing",
    },
    "command": {
        "name": "the_command_name",
        "args": {"arg_name": "value"},
    },
}


def build_system_prompt(
    state: AgentState,
    directives: Directives,
    commands: list[Command],
    *,
    sec02_answer_only: bool = False,
) -> str:
    """Build the system prompt with task, directives, and command catalog."""
    parts: list[str] = []

    # Identity
    parts.append(
        f"You are {state.ai_profile.name}, {state.ai_profile.role}.\n"
        f"Your task: {state.task}"
    )

    # Directives (spec §10.1)
    if directives.constraints:
        parts.append("## Constraints\n" + "\n".join(
            f"- {c}" for c in directives.constraints
        ))

    if directives.resources:
        parts.append("## Resources\n" + "\n".join(
            f"- {r}" for r in directives.resources
        ))

    if directives.best_practices:
        parts.append("## Best Practices\n" + "\n".join(
            f"- {b}" for b in directives.best_practices
        ))

    # Command catalog (spec §10.1)
    parts.append("## Available Commands\n" + _format_commands(commands))

    # In the closed SEC-02 pilot, a direct answer is a non-executable
    # response variant, not an installed tool. It may not claim fresh tool
    # evidence. All command proposals still pass the existing deny-only gate.
    if sec02_answer_only:
        parts.append(
            "## SEC-02 Closed Pilot\n"
            "No tools can execute in this profile. For an answer that needs no "
            "external execution or unverified facts, return only a JSON object: "
            '{"answer":{"text":"Your direct answer"},"thoughts":{}}. '
            "Do not include command, use_tool, code, calls, or tool arguments in "
            "an answer-only response. If the request requires a tool, use the "
            "normal command proposal format; it will be refused before human "
            "approval. Never claim a tool or QSECD test ran when it did not."
        )
        return "\n\n".join(parts)

    # Response format instruction
    parts.append(
        "## Response Format\n"
        "You must respond with ONLY a valid JSON object matching this schema. "
        "No additional text before or after the JSON.\n\n"
        f"```json\n{json.dumps(RESPONSE_SCHEMA, indent=2)}\n```\n\n"
        "IMPORTANT:\n"
        '- "command.name" must be exactly one of the listed command names.\n'
        '- "command.args" must contain the required arguments for that command.\n'
        "- Choose exactly ONE command per response.\n"
        "- Respond with ONLY the JSON object, nothing else."
    )

    return "\n\n".join(parts)


def build_planning_messages(
    state: AgentState,
    directives: Directives,
    commands: list[Command],
    component_messages: list[str],
    token_limit: int,
    *,
    sec02_answer_only: bool = False,
    governed_context_strict: bool = False,
) -> list[LLMMessage]:
    """Build the full message list for the planning LLM call (spec §10.1).

    Returns a list of messages that fit within the token budget.
    """
    messages: list[LLMMessage] = []

    # System prompt
    system = build_system_prompt(state, directives, commands,
                                 sec02_answer_only=sec02_answer_only)
    messages.append(LLMMessage(role="system", content=system))

    # Component messages (history, context, clock, etc.)
    # These go as a user message to keep the system prompt clean
    if component_messages:
        context_text = "\n\n".join(component_messages)
        messages.append(LLMMessage(role="user", content=context_text))

    # Final instruction
    messages.append(LLMMessage(
        role="user",
        content=(
            ("Based on the available information, give a direct answer as "
             'JSON {"answer":{"text":"..."},"thoughts":{}} if no tool is needed. '
             "Otherwise propose exactly one command (which SEC-02 will refuse). "
             "Never claim an external action was executed."
             if sec02_answer_only else
             "Based on the above information, determine the best next action. "
             "Respond with a single JSON object following the response format. "
             "Choose exactly one command.")
        ),
    ))

    # Multi-stage token budget enforcement.
    # Stage 1: trim component messages (history, context).
    # Stage 2: compact command descriptions.
    # Stage 3: warn and proceed best-effort (the LLM provider may
    #          truncate or reject, but we do not hard-fail here because
    #          a slightly-over-budget prompt is better than no prompt).
    total = sum(count_tokens(m.content) for m in messages)
    if governed_context_strict and total > token_limit:
        raise ValueError("Governed memory prompt exceeds budget; no truncation allowed")

    if total > token_limit and len(messages) > 2:
        # Stage 1: trim the component messages section
        overage = total - token_limit
        ctx_msg = messages[1]
        ctx_tokens = count_tokens(ctx_msg.content)
        target = max(200, ctx_tokens - overage)
        from .utils.tokens import truncate_to_tokens
        messages[1] = LLMMessage(
            role="user",
            content=truncate_to_tokens(ctx_msg.content, target),
        )
        total = sum(count_tokens(m.content) for m in messages)

    if total > token_limit:
        # Stage 2: compact command descriptions in the system prompt
        compact_commands = [
            Command(
                name=cmd.name,
                description=cmd.description[:60] + "..." if len(cmd.description) > 60 else cmd.description,
                parameters=cmd.parameters,
            )
            for cmd in commands
        ]
        compact_system = build_system_prompt(state, directives, compact_commands,
                                            sec02_answer_only=sec02_answer_only)
        messages[0] = LLMMessage(role="system", content=compact_system)
        total = sum(count_tokens(m.content) for m in messages)

    if total > token_limit:
        # Stage 3: still over budget after all trimming.  Log a warning
        # and proceed best-effort.  Rationale: the Ollama backend will
        # truncate or error on its own; hard-failing here would prevent
        # the agent from doing anything when the task description is
        # inherently long.  The operator can increase --token-limit.
        import logging
        logging.getLogger(__name__).warning(
            "Prompt still exceeds token limit after trimming (%d > %d). "
            "The LLM may truncate or reject this request. "
            "Consider increasing --token-limit or shortening the task.",
            total, token_limit,
        )

    return messages


def _format_commands(commands: list[Command]) -> str:
    """Format the command catalog for the prompt."""
    if not commands:
        return "No commands available."

    lines = []
    for cmd in commands:
        params = ", ".join(
            f"{k}: {v}" for k, v in cmd.parameters.items()
        )
        lines.append(f"- **{cmd.name}**({params}): {cmd.description}")

    return "\n".join(lines)
