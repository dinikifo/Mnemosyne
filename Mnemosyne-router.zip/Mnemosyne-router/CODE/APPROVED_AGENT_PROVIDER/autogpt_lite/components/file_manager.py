"""File manager component (spec §7 FileManagerComponent).

Provides file read, write, and list commands within the workspace.
"""

from __future__ import annotations

import os
from pathlib import Path

from .base import CommandProvider, Component
from ..models import Command
from ..utils.tokens import truncate_to_tokens


class FileManagerComponent(Component, CommandProvider):
    """File operations within the workspace."""

    component_name = "file_manager"

    def get_commands(self) -> list[Command]:
        return [
            Command(
                name="read_file",
                description="Read the contents of a file.",
                parameters={"path": "string"},
                execute=self._read_file,
            ),
            Command(
                name="write_file",
                description="Write content to a file. Creates the file if it doesn't exist.",
                parameters={"path": "string", "content": "string"},
                execute=self._write_file,
            ),
            Command(
                name="append_file",
                description="Append content to the end of a file.",
                parameters={"path": "string", "content": "string"},
                execute=self._append_file,
            ),
            Command(
                name="list_files",
                description="List files and folders in a directory.",
                parameters={"path": "string"},
                execute=self._list_files,
            ),
            Command(
                name="delete_file",
                description="Delete a file.",
                parameters={"path": "string"},
                execute=self._delete_file,
            ),
        ]

    def _resolve(self, path: str) -> Path:
        """Resolve a path relative to the workspace.

        Uses Path.is_relative_to() for safe ancestry checking.
        """
        workspace = Path(self.agent.config.workspace_dir).resolve()
        resolved = (workspace / path).resolve()
        if not resolved.is_relative_to(workspace):
            raise ValueError(f"Path escapes workspace: {path}")
        return resolved

    def _read_file(self, path: str) -> str:
        resolved = self._resolve(path)
        if not resolved.exists():
            return f"Error: file '{path}' does not exist."
        try:
            content = resolved.read_text(errors="replace")
            max_tokens = self.agent.config.max_result_tokens
            return truncate_to_tokens(content, max_tokens)
        except Exception as e:
            return f"Error reading '{path}': {e}"

    def _write_file(self, path: str, content: str = "") -> str:
        resolved = self._resolve(path)
        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.write_text(content)
            return f"File '{path}' written ({len(content)} chars)."
        except Exception as e:
            return f"Error writing '{path}': {e}"

    def _append_file(self, path: str, content: str = "") -> str:
        resolved = self._resolve(path)
        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            with open(resolved, "a") as f:
                f.write(content)
            return f"Appended to '{path}' ({len(content)} chars)."
        except Exception as e:
            return f"Error appending to '{path}': {e}"

    def _list_files(self, path: str = ".") -> str:
        resolved = self._resolve(path)
        if not resolved.is_dir():
            return f"Error: '{path}' is not a directory."
        try:
            entries = []
            for entry in sorted(resolved.iterdir()):
                prefix = "[dir]  " if entry.is_dir() else "[file] "
                size = ""
                if entry.is_file():
                    size = f" ({entry.stat().st_size} bytes)"
                entries.append(f"{prefix}{entry.name}{size}")
            if not entries:
                return f"Directory '{path}' is empty."
            return "\n".join(entries[:100])
        except Exception as e:
            return f"Error listing '{path}': {e}"

    def _delete_file(self, path: str) -> str:
        resolved = self._resolve(path)
        if not resolved.exists():
            return f"Error: '{path}' does not exist."
        if resolved.is_dir():
            return f"Error: '{path}' is a directory. Cannot delete directories."
        try:
            resolved.unlink()
            return f"Deleted '{path}'."
        except Exception as e:
            return f"Error deleting '{path}': {e}"
