"""System component (spec §7 SystemComponent, §12).

Provides baseline behavioral constraints, clock message, and the built-in
`finish` command for agent self-termination.
"""

from __future__ import annotations

from datetime import datetime

from .base import (
    CommandProvider,
    Component,
    DirectiveProvider,
    MessageProvider,
)
from ..models import Command, Directives


class SystemComponent(Component, DirectiveProvider, CommandProvider, MessageProvider):
    """System policy layer (spec §12)."""

    component_name = "system"

    def get_directives(self) -> Directives:
        """Baseline behavioral constraints (spec §12.1)."""
        return Directives(
            constraints=[
                "Only use the commands listed below.",
                "Do not create background jobs, webhooks, or long-running processes.",
                "Do not assume direct control over the physical world.",
                "Use your internal knowledge efficiently before seeking external info.",
                "Self-review and self-criticize your actions before proposing.",
                "Minimize costly or slow operations.",
            ],
            resources=[
                "You can read and write files in the workspace.",
                "You have access to all commands listed in the command catalog.",
            ],
            best_practices=[
                "Break complex tasks into smaller steps.",
                "Verify results after each action.",
                "If stuck, try a different approach rather than repeating the same action.",
                "Use the 'finish' command when the task is complete.",
            ],
        )

    def get_commands(self) -> list[Command]:
        """The built-in finish command (spec §12.3)."""
        return [
            Command(
                name="finish",
                description="Signal that the task is complete. Use when you have "
                            "accomplished the user's goal or cannot make further progress.",
                parameters={"reason": "string"},
                execute=self._finish,
            ),
        ]

    def get_messages(self) -> list[str]:
        """Clock message (spec §12.2)."""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return [f"Current date and time: {now}"]

    def _finish(self, reason: str = "Task completed.") -> str:
        """Execute the finish command — sets agent terminated flag."""
        self.agent._terminated = True
        self.agent._finish_reason = reason
        return f"Agent finishing: {reason}"
