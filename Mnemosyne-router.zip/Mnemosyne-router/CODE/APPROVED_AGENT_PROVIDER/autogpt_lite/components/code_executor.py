"""SEC-01 experimental Python executor: each invocation needs a Toulmin case
and fresh operator authorization at /dev/tty before any subprocess launch.

This is not OS-level containment: run the agent under a VM/container or separate
least-privilege OS account with only a disposable workspace accessible.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

from .base import CommandProvider, Component, DirectiveProvider
from ..models import Command, Directives
from ..sec01_governance import ExecutionGate, Sec01PolicyBlocked
from ..utils.tokens import truncate_to_tokens

_RESTRICTED_ENV = {
    "PATH": "/usr/local/bin:/usr/bin:/bin",
    "LANG": "C.UTF-8",
    "HOME": "/tmp",
    "PYTHONDONTWRITEBYTECODE": "1",
}


class CodeExecutorComponent(Component, CommandProvider, DirectiveProvider):
    component_name = "code_executor"
    run_after = []

    def __init__(self, timeout: int = 30, allow_shell: bool = False):
        super().__init__()
        if allow_shell:
            raise Sec01PolicyBlocked("SEC01_SHELL_DISABLED: no alternate executable path")
        if not isinstance(timeout, int) or timeout < 1:
            raise ValueError("timeout must be a positive integer")
        self.timeout = timeout
        self.allow_shell = False

    def get_directives(self) -> Directives:
        return Directives(constraints=[
            "Every execute_python invocation must include all six Toulmin fields: "
            "claim, grounds, warrant, backing, qualifier and rebuttal. "
            "They are assertions for a human to review, NOT machine-certified evidence.",
            "Each execution is independently reviewed by a human at /dev/tty; "
            "continuous mode and previous approval do not authorize Python.",
            "Python execution is process-level only, NOT an OS sandbox. "
            "Do not access unrelated data, network, or privileged resources.",
        ])

    def get_commands(self) -> list[Command]:
        return [Command(
            name="execute_python",
            description=("Propose Python source and a six-part Toulmin argument. "
                         "Requires fresh interactive human approval for every run; "
                         "refusal/noninteractive invocation blocks execution."),
            parameters={"code": "string", "claim": "string", "grounds": "string",
                        "warrant": "string", "backing": "string", "qualifier": "string",
                        "rebuttal": "string"},
            execute=self._execute_python,
        )]

    def _execute_python(self, code: str, claim: str = "", grounds: str = "",
                        warrant: str = "", backing: str = "", qualifier: str = "",
                        rebuttal: str = "") -> str:
        """Gate at the actual executor; cannot be skipped by continuous mode."""
        # Establish the journal before checking workspace state so rejected
        # attempts remain inspectable (when the journal is available).
        workspace = Path(self.agent.config.workspace_dir).absolute()
        gate = ExecutionGate(agent_data_dir=self.agent.config.agent_data_dir,
                             workspace=workspace, timeout=self.timeout,
                             interpreter=sys.executable, environment=_RESTRICTED_ENV)
        request = gate.approve(code=code, claim=claim, grounds=grounds,
                               warrant=warrant, backing=backing,
                               qualifier=qualifier, rebuttal=rebuttal)
        script_path = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", suffix=".py", dir=workspace,
                                             delete=False) as f:
                f.write(code.encode("utf-8"))
                f.flush()
                os.fsync(f.fileno())
                script_path = Path(f.name)
            if script_path.read_bytes() != code.encode("utf-8"):
                raise Sec01PolicyBlocked("SEC01_SCRIPT_CHANGED: source mismatch")
            gate.started(request)
            result = subprocess.run(
                [sys.executable, "-u", str(script_path)],
                capture_output=True, text=True, timeout=self.timeout,
                cwd=str(workspace), env=_RESTRICTED_ENV, shell=False,
            )
            gate.completed(status="EXECUTION_FINISHED" if result.returncode == 0 else "EXECUTION_FAILED",
                           exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
            output = self._format_output(result)
            if result.returncode:
                raise Sec01PolicyBlocked("SEC01_SCRIPT_FAILED: " + output)
            return f"SEC01 request {request['request_id']} script sha256={request['script_sha256']}\n{output}"
        except subprocess.TimeoutExpired as exc:
            gate.completed(status="EXECUTION_TIMEOUT", diagnostic=f"exceeded {self.timeout}s")
            raise Sec01PolicyBlocked(f"SEC01_TIMEOUT: exceeded {self.timeout}s") from exc
        except Sec01PolicyBlocked:
            raise
        except Exception as exc:
            gate.completed(status="EXECUTION_EXCEPTION", diagnostic=f"{type(exc).__name__}: {exc}")
            raise Sec01PolicyBlocked("SEC01_EXECUTION_EXCEPTION: " + str(exc)) from exc
        finally:
            if script_path is not None:
                script_path.unlink(missing_ok=True)

    def _execute_shell(self, command: str) -> str:
        raise Sec01PolicyBlocked("SEC01_SHELL_DISABLED: shell cannot bypass Python governance")

    def _format_output(self, result: subprocess.CompletedProcess) -> str:
        output = result.stdout or ""
        if result.stderr:
            output += ("\n--- stderr ---\n" if output else "") + result.stderr
        if result.returncode:
            output += f"\n[Exit code: {result.returncode}]"
        if not output.strip():
            output = "[No output produced]"
        return truncate_to_tokens(output, self.agent.config.max_result_tokens)
