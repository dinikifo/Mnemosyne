"""User interaction component (spec §7 UserInteractionComponent).

Provides the ask_user command for the agent to request information
from the human operator during execution.
"""

from __future__ import annotations

from .base import CommandProvider, Component
from ..models import Command
from ..interaction import render_operator_literal


class UserInteractionComponent(Component, CommandProvider):
    """Allows the agent to ask the user questions."""

    component_name = "user_interaction"

    def get_commands(self) -> list[Command]:
        return [
            Command(
                name="ask_user",
                description="Ask the user a question and wait for their response. "
                            "Use when you need clarification or additional information.",
                parameters={"question": "string"},
                execute=self._ask_user,
            ),
        ]

    def _ask_user(self, question: str) -> str:
        """Prompt the user for input."""
        self.agent._output(f"\n🤖 Agent asks: {render_operator_literal(str(question))}")
        answer = self.agent.interaction.ask_question("Your answer: ")
        if answer is None:
            return "User did not respond (input interrupted)."
        answer = answer.strip()
        if not answer:
            return "User provided no answer."
        return f"User responded: {answer}"
