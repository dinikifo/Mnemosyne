"""Component base classes and protocol ABCs (spec §6).

Defines the protocol roles that components can implement:
- DirectiveProvider  (§6.1a)
- CommandProvider    (§6.1b)
- MessageProvider    (§6.1c)
- AfterParse        (§6.1d)
- AfterExecute      (§6.1e)
- ExecutionFailure  (§6.1f)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from ..models import (
    ActionProposal,
    ActionResult,
    Command,
    Directives,
)

if TYPE_CHECKING:
    from ..agent import AgentRuntime


class Component:
    """Base class for all agent components.

    Components declare ordering via `run_after` and can be enabled/disabled.
    """

    component_name: str = "unnamed"
    run_after: list[type] = []  # component classes this should run after
    enabled: bool = True

    def attach(self, agent: AgentRuntime) -> None:
        """Called when the component is attached to an agent. Override for setup."""
        self.agent = agent


# ---------------------------------------------------------------------------
# Protocol roles (spec §6.1)
# ---------------------------------------------------------------------------

class DirectiveProvider(ABC):
    """Contributes constraints, resources, and best practices (§6.1a)."""

    @abstractmethod
    def get_directives(self) -> Directives:
        ...


class CommandProvider(ABC):
    """Contributes executable commands (§6.1b)."""

    @abstractmethod
    def get_commands(self) -> list[Command]:
        ...


class MessageProvider(ABC):
    """Contributes prompt-visible messages (§6.1c)."""

    @abstractmethod
    def get_messages(self) -> list[str]:
        ...


class AfterParse(ABC):
    """Receives parsed planner output before execution (§6.1d)."""

    @abstractmethod
    def after_parse(self, proposal: ActionProposal) -> None:
        ...


class AfterExecute(ABC):
    """Receives the result after tool execution (§6.1e)."""

    @abstractmethod
    def after_execute(self, result: ActionResult) -> None:
        ...


class ExecutionFailure(ABC):
    """Optional failure hook (§6.1f)."""

    @abstractmethod
    def on_execution_failure(self, error: Exception) -> None:
        ...
