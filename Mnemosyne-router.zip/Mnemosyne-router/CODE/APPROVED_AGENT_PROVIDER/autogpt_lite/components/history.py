"""Action history component (spec §7 ActionHistoryComponent, §13).

Maintains the episodic execution log with:
- Recent steps in full detail
- Older steps compressed into LLM-generated summaries
- Token-budget-aware injection into prompts
"""

from __future__ import annotations

from ..interaction import log_operator_exception

import logging
from typing import TYPE_CHECKING

from .base import AfterExecute, Component, MessageProvider
from ..models import ActionResult, Episode, ResultStatus
from ..utils.tokens import count_tokens, truncate_to_tokens

if TYPE_CHECKING:
    from ..agent import AgentRuntime

logger = logging.getLogger(__name__)

# On low-end hardware, keep fewer detailed steps to save tokens
DEFAULT_RECENT_STEPS = 3
DEFAULT_SUMMARY_TOKEN_BUDGET = 512


class ActionHistoryComponent(Component, MessageProvider, AfterExecute):
    """Episodic action history with summary compression (spec §13)."""

    component_name = "action_history"

    def __init__(
        self,
        recent_steps: int = DEFAULT_RECENT_STEPS,
        summary_token_budget: int = DEFAULT_SUMMARY_TOKEN_BUDGET,
    ):
        super().__init__()
        self.recent_steps = recent_steps
        self.summary_token_budget = summary_token_budget
        self._running_summary: str = ""
        self._source_journal = None

    def attach(self, agent: AgentRuntime) -> None:
        super().attach(agent)
        # Research journal is opt-in. Its failures must stop destructive pruning.
        if agent.config.memory_journal_dir:
            from ..persistence.episode_journal import EpisodeJournal, JournalError
            from pathlib import Path
            root = Path(agent.config.memory_journal_dir)
            # Explicit external location; never under workspace or state directory.
            for excluded in (Path(agent.config.workspace_dir).resolve(),
                             Path(agent.config.agent_data_dir).resolve()):
                if root.resolve() == excluded or excluded in root.resolve().parents:
                    raise JournalError("Source journal must be outside workspace and agent state")
            existing_source = (agent.state.journal_receipt is not None or
                               any(ep.source_seq is not None for ep in agent.state.history))
            self._source_journal = EpisodeJournal(
                str(root), agent.state.agent_id, create=not existing_source)
            # A state receipt from a prior checkpoint is an independent anchor.
            # Journal-ahead and journal-behind states both need human review.
            from ..persistence.recovery import verify_receipt
            verify_receipt(agent.state.journal_receipt, self._source_journal)
            # Archive surviving existing history and validate prior anchors before
            # any planning prompt or new tool execution.
            self._source_journal.capture_history(agent.state.history)
        elif any(ep.source_seq is not None for ep in agent.state.history):
            raise RuntimeError("A journal-backed agent cannot resume without its journal path")
        # Restore summary from any existing history
        self._rebuild_summary_if_needed()

    def _rebuild_summary_if_needed(self) -> None:
        """On resume, regenerate summary from older episodes."""
        if getattr(self.agent, "_memory_governance_required", lambda: False)():
            return  # No independent LLM-generated memory in governed mode.
        history = self.agent.state.history
        if len(history) > self.recent_steps and not self._running_summary:
            older = history[: -self.recent_steps]
            self._running_summary = self._summarize_episodes(older)

    # -------------------------------------------------------------------
    # MessageProvider — inject history into prompt
    # -------------------------------------------------------------------

    def get_messages(self) -> list[str]:
        """Inject history into the planning prompt (spec §13.1)."""
        if getattr(self.agent, "_memory_governance_required", lambda: False)():
            return []  # Raw history/auto summaries are not approved M5 memory.
        messages: list[str] = []
        history = self.agent.state.history

        # Summarized older history
        if self._running_summary:
            messages.append(
                f"## Previous Actions Summary\n{self._running_summary}"
            )

        # Recent steps in full detail
        recent = history[-self.recent_steps:] if history else []
        if recent:
            lines = ["## Recent Actions"]
            for i, ep in enumerate(recent, 1):
                tool = ep.action.use_tool
                result_str = self._format_result(ep.result) if ep.result else "pending"
                lines.append(
                    f"Step {len(history) - len(recent) + i}: "
                    f"{tool.name}({self._format_args(tool.arguments)}) → {result_str}"
                )
                if ep.action.thoughts.reasoning:
                    lines.append(f"  Reasoning: {ep.action.thoughts.reasoning}")
            messages.append("\n".join(lines))

        return messages

    # -------------------------------------------------------------------
    # AfterExecute — record and compress
    # -------------------------------------------------------------------

    def after_execute(self, result: ActionResult) -> None:
        """After each execution, check if we need to compress history."""
        history = self.agent.state.history
        if self._source_journal is not None:
            try:
                self._source_journal.capture_history(history)
            except Exception as exc:
                # Kernel catches hook exceptions, so stop the runtime ourselves.
                # The unarchived episode stays in state; no pruning is attempted.
                self.agent._archive_failed = True
                self.agent._terminated = True
                log_operator_exception(logger, "Source capture failed; stopping agent without pruning", exc)
                raise
        if len(history) > self.recent_steps + 2:
            self._compress()

    def _compress(self) -> None:
        """Summarize older episodes and prune persisted state (spec §13.2).

        When older episodes exceed the summary token budget, they are
        replaced in the history list with a single synthetic 'summary
        checkpoint' episode.  This bounds both prompt size AND persisted
        state size.
        """
        if getattr(self.agent, "_memory_governance_required", lambda: False)():
            return  # Preserve source evidence; never auto-promote/prune.
        history = self.agent.state.history
        if len(history) <= self.recent_steps:
            return

        older = history[: -self.recent_steps]
        older_text = self._episodes_to_text(older)

        # If within budget, keep episodes as-is; summarize for prompt only
        if count_tokens(older_text) <= self.summary_token_budget:
            self._running_summary = older_text
            return

        # Never destroy source events until the entire current in-memory history
        # has been durably acknowledged and verified by the external journal.
        if self._source_journal is not None:
            try:
                self._source_journal.capture_history(history)
            except Exception as exc:
                self.agent._archive_failed = True
                self.agent._terminated = True
                log_operator_exception(logger, "Unverified history: refusing destructive pruning", exc)
                raise

        # Generate a compressed summary
        self._running_summary = self._llm_summarize(older_text)

        # ISSUE 8 FIX: Replace older episodes with a single summary
        # checkpoint episode to prevent unbounded state.json growth.
        from ..models import ActionProposal, ActionResult, Thoughts, ToolInvocation
        summary_episode = Episode(
            action=ActionProposal(
                thoughts=Thoughts(text="[history checkpoint]"),
                use_tool=ToolInvocation(
                    name="_history_summary",
                    arguments={"cycles_summarized": len(older)},
                ),
            ),
            result=ActionResult.success(self._running_summary),
            summary=self._running_summary,
        )

        # Replace all older episodes with the single summary checkpoint
        recent = history[-self.recent_steps:]
        self.agent.state.history = [summary_episode] + recent

    def _llm_summarize(self, text: str) -> str:
        """Use the fast LLM to compress history."""
        from ..llm.provider import LLMMessage
        from ..interaction import render_operator_literal

        try:
            response = self.agent.llm.chat(
                messages=[
                    LLMMessage(
                        role="system",
                        content=(
                            "Summarize the following action history into a concise "
                            "paragraph. Focus on: what was attempted, what succeeded, "
                            "what failed, and what the current state is. Be brief."
                        ),
                    ),
                    LLMMessage(role="user", content=text),
                ],
                model=self.agent.config.fast_llm,
                temperature=0.3,
                max_tokens=256,
            )
            summary = response.content.strip()
            # Enforce budget
            return truncate_to_tokens(summary, self.summary_token_budget)
        except Exception as e:
            logger.warning("History summarization failed: %s", render_operator_literal(str(e)))
            # Fallback: truncate raw text
            return truncate_to_tokens(text, self.summary_token_budget)

    def _summarize_episodes(self, episodes: list[Episode]) -> str:
        """Convert a list of episodes to a summary string."""
        text = self._episodes_to_text(episodes)
        if count_tokens(text) <= self.summary_token_budget:
            return text
        return self._llm_summarize(text)

    # -------------------------------------------------------------------
    # Formatting helpers
    # -------------------------------------------------------------------

    @staticmethod
    def _episodes_to_text(episodes: list[Episode]) -> str:
        lines = []
        for i, ep in enumerate(episodes, 1):
            tool = ep.action.use_tool
            result_str = ActionHistoryComponent._format_result(ep.result) if ep.result else "no result"
            lines.append(f"Step {i}: {tool.name}({ActionHistoryComponent._format_args(tool.arguments)}) → {result_str}")
        return "\n".join(lines)

    @staticmethod
    def _format_result(result: ActionResult) -> str:
        if result.status == ResultStatus.SUCCESS:
            out = result.outputs or "ok"
            if len(out) > 200:
                return out[:200] + "..."
            return out
        elif result.status == ResultStatus.ERROR:
            return f"ERROR: {result.reason}"
        else:
            return f"INTERRUPTED: {result.feedback}"

    @staticmethod
    def _format_args(args: dict) -> str:
        if not args:
            return ""
        parts = []
        for k, v in args.items():
            s = str(v)
            if len(s) > 80:
                s = s[:80] + "..."
            parts.append(f"{k}={s!r}")
        return ", ".join(parts)
