"""Web search component (spec §7 WebSearchComponent).

Optional component providing web search via DuckDuckGo (no API key needed).
Install: pip install duckduckgo-search

Kept lightweight for Pi compatibility.
"""

from __future__ import annotations

from .base import CommandProvider, Component, DirectiveProvider
from ..models import Command, Directives


class WebSearchComponent(Component, CommandProvider, DirectiveProvider):
    """Web search via DuckDuckGo."""

    component_name = "web_search"

    def get_directives(self) -> Directives:
        return Directives(
            resources=["You can search the web for current information."],
            best_practices=[
                "Only search the web when your internal knowledge is insufficient.",
                "Use specific, targeted search queries.",
            ],
        )

    def get_commands(self) -> list[Command]:
        return [
            Command(
                name="web_search",
                description="Search the web using DuckDuckGo. Returns top results "
                            "with titles, URLs, and snippets.",
                parameters={"query": "string"},
                execute=self._search,
            ),
        ]

    def _search(self, query: str) -> str:
        try:
            from duckduckgo_search import DDGS
        except ImportError:
            return (
                "Error: duckduckgo-search not installed. "
                "Install with: pip install duckduckgo-search"
            )

        try:
            with DDGS() as ddgs:
                results = list(ddgs.text(query, max_results=5))

            if not results:
                return f"No results found for '{query}'."

            lines = []
            for i, r in enumerate(results, 1):
                lines.append(f"{i}. {r.get('title', 'No title')}")
                lines.append(f"   URL: {r.get('href', 'N/A')}")
                lines.append(f"   {r.get('body', 'No snippet')}")
                lines.append("")

            return "\n".join(lines)
        except Exception as e:
            return f"Search error: {e}"
