"""Context component (spec §7 ContextComponent, §14).

Manages the explicit prompt context working set — files and folders pinned
for visibility in future planning prompts.
"""

from __future__ import annotations

import os
from pathlib import Path

from .base import CommandProvider, Component, MessageProvider
from ..models import Command, ContextItem
from ..utils.tokens import count_tokens, truncate_to_tokens


class ContextComponent(Component, CommandProvider, MessageProvider):
    """Explicit prompt context management (spec §14)."""

    component_name = "context"

    def get_commands(self) -> list[Command]:
        return [
            Command(
                name="open_file",
                description="Open a file and pin it to your working context. "
                            "Creates the file if it doesn't exist.",
                parameters={"path": "string"},
                execute=self._open_file,
            ),
            Command(
                name="open_folder",
                description="Open a folder listing and pin it to your working context. "
                            "The folder must already exist.",
                parameters={"path": "string"},
                execute=self._open_folder,
            ),
            Command(
                name="close_context",
                description="Remove a file or folder from your working context.",
                parameters={"path": "string"},
                execute=self._close_context,
            ),
        ]

    def get_messages(self) -> list[str]:
        """Inject pinned context items into the prompt (spec §14.1)."""
        if not self.agent.state.context:
            return []

        lines = ["## Working Context (pinned items)"]
        token_budget = self.agent.config.send_token_limit // 4  # ~25% for context
        used = 0

        for item in self.agent.state.context:
            header = f"### [{item.item_type}] {item.path}"
            content = item.content
            item_tokens = count_tokens(header + content)

            if used + item_tokens > token_budget:
                remaining = max(0, token_budget - used - 50)
                content = truncate_to_tokens(content, remaining)

            lines.append(header)
            if content:
                lines.append(content)
            used += count_tokens(header + content)

            if used >= token_budget:
                lines.append("... [context truncated due to token budget]")
                break

        return ["\n".join(lines)]

    # -------------------------------------------------------------------
    # Command implementations
    # -------------------------------------------------------------------

    def _resolve_path(self, path: str) -> Path:
        """Resolve a path relative to the workspace.

        Uses Path.is_relative_to() for safe ancestry checking, which is
        immune to the prefix-collision bug (e.g. /tmp/ws vs /tmp/ws2).
        """
        workspace = Path(self.agent.config.workspace_dir).resolve()
        resolved = (workspace / path).resolve()
        # Safe ancestry check (Python 3.9+) — not vulnerable to prefix collision
        if not resolved.is_relative_to(workspace):
            raise ValueError(f"Path escapes workspace: {path}")
        return resolved

    def _open_file(self, path: str) -> str:
        """Open/create a file and add to context (spec §14.3)."""
        resolved = self._resolve_path(path)

        # Create if it doesn't exist
        if not resolved.exists():
            resolved.parent.mkdir(parents=True, exist_ok=True)
            resolved.touch()

        try:
            content = resolved.read_text(errors="replace")
        except Exception as e:
            return f"Error reading {path}: {e}"

        # Remove existing entry for this path
        self.agent.state.context = [
            c for c in self.agent.state.context if c.path != path
        ]

        # Truncate large files
        max_tokens = self.agent.config.send_token_limit // 6
        content = truncate_to_tokens(content, max_tokens)

        self.agent.state.context.append(
            ContextItem(item_type="file", path=path, content=content)
        )
        lines = content.count("\n") + 1
        return f"File '{path}' opened ({lines} lines). It is now in your working context."

    def _open_folder(self, path: str) -> str:
        """Open a folder listing and add to context (spec §14.3)."""
        resolved = self._resolve_path(path)

        if not resolved.is_dir():
            return f"Error: folder '{path}' does not exist."

        entries = []
        try:
            for entry in sorted(resolved.iterdir()):
                prefix = "📁 " if entry.is_dir() else "📄 "
                entries.append(prefix + entry.name)
        except PermissionError:
            return f"Error: permission denied for '{path}'."

        content = "\n".join(entries[:50])  # Limit listing size
        if len(list(resolved.iterdir())) > 50:
            content += f"\n... and {len(list(resolved.iterdir())) - 50} more items"

        # Remove existing
        self.agent.state.context = [
            c for c in self.agent.state.context if c.path != path
        ]

        self.agent.state.context.append(
            ContextItem(item_type="folder", path=path, content=content)
        )
        return f"Folder '{path}' opened ({len(entries)} items). It is now in your working context."

    def _close_context(self, path: str) -> str:
        """Remove a context item (spec §14.2)."""
        before = len(self.agent.state.context)
        self.agent.state.context = [
            c for c in self.agent.state.context if c.path != path
        ]
        if len(self.agent.state.context) < before:
            return f"Removed '{path}' from working context."
        return f"'{path}' was not in working context."
