"""Small typed application boundary for the existing supervised runtime (RC-04).

Queries return detached presentation snapshots, never signed records or mutable
AgentState objects. The only command delegates to the existing AgentRuntime.run
path, including its PVS/SEC-02 checks and one-cycle limit. This interface does
not verify human authorization or extend execution capabilities.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .agent import AgentRuntime


@dataclass(frozen=True)
class GetRuntimeStatus:
    """Read the current in-memory status; has no filesystem side effects."""


@dataclass(frozen=True)
class GetPendingProposal:
    """Read a display-only snapshot of the pending proposal, if any."""


@dataclass(frozen=True)
class RunSupervisedCycle:
    """Request the existing at-most-one-cycle runtime operation."""


@dataclass(frozen=True)
class RuntimeStatusView:
    agent_id: str
    task: str
    cycle_count: int
    pending_phase: str | None
    has_pending_episode: bool
    evidence_failure: str | None
    last_result_status: str | None
    # Deliberately NO authorized/approved field. This view is non-authoritative.


@dataclass(frozen=True)
class ProposalView:
    tool_name: str
    arguments: tuple[tuple[str, str], ...]
    speak: str
    reasoning: str
    plan: str
    # Display snapshot, NOT the reviewed action or a signed receipt.


class ApplicationBoundary:
    """Transport-independent queries and a supervised-cycle command."""

    def __init__(self, runtime: AgentRuntime) -> None:
        self._runtime = runtime

    def query(self, request: GetRuntimeStatus | GetPendingProposal) -> RuntimeStatusView | ProposalView | None:
        if type(request) is GetRuntimeStatus:
            state = self._runtime.state
            last = state.history[-1].result if state.history else None
            return RuntimeStatusView(
                agent_id=state.agent_id,
                task=state.task,
                cycle_count=state.cycle_count,
                pending_phase=state.pending_phase,
                has_pending_episode=state.current_episode is not None,
                evidence_failure=state.evidence_failure,
                last_result_status=(last.status.value if last is not None else None),
            )
        if type(request) is GetPendingProposal:
            episode = self._runtime.state.current_episode
            if episode is None:
                return None
            proposal = episode.action
            tool = proposal.use_tool
            thoughts = proposal.thoughts
            return ProposalView(
                tool_name=tool.name,
                arguments=tuple(sorted((str(key), repr(value)) for key, value in tool.arguments.items())),
                speak=thoughts.speak or "",
                reasoning=thoughts.reasoning or "",
                plan=thoughts.plan or "",
            )
        raise TypeError("Unknown application query")

    def command(self, request: RunSupervisedCycle) -> RuntimeStatusView:
        if type(request) is not RunSupervisedCycle:
            raise TypeError("Unknown application command")
        # No alternative dispatcher, no new approval path, no exception masking.
        self._runtime.run()
        result = self.query(GetRuntimeStatus())
        assert isinstance(result, RuntimeStatusView)
        return result
