"""SEC-02 R4.2: standalone, one-use consent binding for offline review.

No active QSECD policy, dispatch permission, authentication or execution here.
This module is not connected to the live CLI. A returned receipt is NOT a
security token or a permit to run a command; future R5 dispatch MUST perform
an independent trusted admission and last-line policy/effect check.
"""
from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any, Callable


class ReviewBindingError(ValueError):
    """Bad, stale, replayed or non-canonical review material."""


class ReviewRefused(RuntimeError):
    """The human did not explicitly authorize the exact presented review."""


def canonical_review(review: dict[str, Any]) -> bytes:
    """Snapshot complete JSON review: request, program, evidence and argument.

    Digesting only a script hash is insufficient: arguments, source pins,
    policy, environment, tool resolution and input values also matter.
    """
    if not isinstance(review, dict) or set(review) != {
        "request", "program", "admission", "argument_a", "resolved_command", "environment"
    }:
        raise ReviewBindingError("REVIEW_SHAPE: missing or unexpected binding fields")
    if not isinstance(review["resolved_command"], str) or not review["resolved_command"]:
        raise ReviewBindingError("COMMAND_IDENTITY: missing resolved command")
    for key in ("request", "program", "admission", "argument_a", "environment"):
        if not isinstance(review[key], dict):
            raise ReviewBindingError("REVIEW_SHAPE: expected a structured " + key)
    try:
        raw = json.dumps(review, sort_keys=True, ensure_ascii=True,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
        if json.loads(raw) != review:
            raise ReviewBindingError("NONCANONICAL_REVIEW: key coercion or unstable values")
        return raw
    except (TypeError, ValueError, OverflowError, UnicodeError, RecursionError) as ex:
        raise ReviewBindingError("NONCANONICAL_REVIEW: cannot bind this review") from ex


def review_digest(review: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_review(review)).hexdigest()


class OneUseReview:
    """Bind a single human decision to a frozen snapshot, without executing.

    This only demonstrates a future approval primitive. It cannot confer
    admission, survive restart as approval, or dispatch commands.
    """

    def __init__(self, review: dict[str, Any], *, nonce: str | None = None):
        self._snapshot = canonical_review(review)
        self.digest = hashlib.sha256(self._snapshot).hexdigest()
        self._nonce = nonce if nonce is not None else secrets.token_hex(12)
        if not isinstance(self._nonce, str) or len(self._nonce) < 12 or not self._nonce.isalnum():
            raise ReviewBindingError("INVALID_CHALLENGE")
        self._approved = False
        self._consumed = False
        self._attempted = False

    def approve_once(self, *, open_tty: Callable[..., Any] = open) -> bool:
        """Fresh explicit `yes <challenge>` on controlling tty, no stdin fallback.

        Intended to be called only on a non-dispatched, offline review. The
        injected opener exists for tests; never pass agent-controlled hooks.
        """
        if self._attempted:
            raise ReviewRefused("REVIEW_ALREADY_ATTEMPTED: new request required")
        self._attempted = True
        self._approved = False
        try:
            with open_tty("/dev/tty", "r+", encoding="utf-8") as tty:
                if not tty.isatty():
                    raise ReviewRefused("NO_CONTROLLING_TTY")
                snapshot = json.loads(self._snapshot)
                command = snapshot["resolved_command"]
                tty.write("SEC-02 OFFLINE REVIEW — NOT an execution permit\n")
                tty.write("Resolved command: " + command + "\n")
                tty.write("Complete review SHA-256: " + self.digest + "\n")
                tty.write("Frozen review JSON follows (including request, program, admission, Toulmin and environment):\n")
                tty.write(self._snapshot.decode("utf-8") + "\n")
                tty.write("Type yes " + self._nonce + " to acknowledge this exact review; anything else refuses: ")
                tty.flush()
                answer = tty.readline()
                if answer != "yes " + self._nonce + "\n":
                    raise ReviewRefused("NO_EXPLICIT_MATCHING_APPROVAL")
                self._approved = True
                return True
        except ReviewRefused:
            raise
        except (OSError, UnicodeError) as ex:
            raise ReviewRefused("NO_CONTROLLING_TTY") from ex
        except KeyboardInterrupt as ex:
            raise ReviewRefused("INTERRUPTED") from ex

    def consume(self, current_review: dict[str, Any]) -> dict[str, Any]:
        """One-time consent receipt, not a dispatch ticket or policy decision.

        Check the current full review before consuming; no use after restart.
        Consuming invalidates this object before any caller can use the receipt.
        """
        if self._consumed or not self._approved or not self._attempted:
            raise ReviewRefused("NO_FRESH_UNUSED_APPROVAL")
        current = canonical_review(current_review)
        if current != self._snapshot:
            self._approved = False
            self._consumed = True
            raise ReviewBindingError("REVIEW_CHANGED: request, source, proof, argument, program or environment differs")
        self._approved = False
        self._consumed = True
        return {
            "schema": "sec02.offline-consent.v1",
            "review_sha256": self.digest,
            "consumed": True,
            "execution_authorized": False,
            "policy_admitted": False,
        }
