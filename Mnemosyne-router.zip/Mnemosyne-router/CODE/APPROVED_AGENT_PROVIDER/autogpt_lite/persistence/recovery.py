"""Bounded AM03 crash/restart classification (read-only inspection).

This is not exactly-once execution or an automatic repair tool.  A stored
AUTHORIZED_UNCERTAIN intent is never declared NOT_EXECUTED by inference.
"""
from __future__ import annotations

from pathlib import Path

from .episode_journal import EpisodeJournal, JournalError, digest, episode_payload


class RecoveryRequired(RuntimeError):
    """Operator reconciliation is required before agent actions can continue."""


def pending_state_issue(state) -> str | None:
    """Detect invalid persisted phase/episode combinations without side effects.

    Valid incomplete PROPOSED episodes and legacy unphased-pending recovery
    classifications remain unchanged. A missing or already-completed episode
    cannot support a PROPOSED phase, even with a matching journal receipt.
    """
    phase = state.pending_phase
    if phase == "PROPOSED":
        if state.current_episode is None:
            return "Orphaned PROPOSED intent; manual reconciliation required"
        if state.current_episode.result is not None:
            return "Completed episode marked PROPOSED; manual reconciliation required"
    if phase == "AUTHORIZED_UNCERTAIN" and state.current_episode is None:
        return "Orphaned AUTHORIZED_UNCERTAIN intent; manual reconciliation required"
    if phase not in (None, "PROPOSED", "AUTHORIZED_UNCERTAIN"):
        return "Unrecognized persisted proposal phase; manual reconciliation required"
    return None


def require_runtime_readiness(state, *, journal_enabled: bool) -> None:
    """Fail closed before model inference, independent of CLI/UI entry point."""
    if state.evidence_failure:
        raise RecoveryRequired(
            "Required evidence failed in a previous cycle; operator must inspect "
            "and explicitly reconcile the persisted evidence_failure before restart"
        )
    issue = pending_state_issue(state)
    if issue:
        raise RecoveryRequired(issue)
    if state.current_episode is not None and (
        journal_enabled or state.pending_phase == "AUTHORIZED_UNCERTAIN"
    ):
        raise RecoveryRequired(
            "Prior episode has no verified terminal receipt; external tool effects "
            "may be INDETERMINATE. Inspect recovery evidence before resuming."
        )


def verify_receipt(receipt: dict | None, journal: EpisodeJournal) -> dict:
    """Check journal against previously persisted state receipt without writes."""
    events = journal.replay()
    count = len(events)
    head = events[-1].entry_sha256 if events else None
    if receipt is None:
        return {"status": "LEGACY_NO_INDEPENDENT_HEAD", "count": count, "head": head}
    if (not isinstance(receipt, dict)
            or receipt.get("schema") != "episode-journal-receipt-v1"
            or type(receipt.get("count")) is not int
            or receipt["count"] < 0
            or (receipt.get("head") is not None
                and (not isinstance(receipt["head"], str)
                     or len(receipt["head"]) != 64))):
        raise RecoveryRequired("Invalid saved journal receipt")
    if count != receipt["count"] or head != receipt.get("head"):
        raise RecoveryRequired(
            "Journal/state checkpoint mismatch (ahead, behind, or altered); "
            "do not retry tools; manual reconciliation required"
        )
    return {"status": "VERIFIED", "count": count, "head": head}


def require_runtime_journal_head(
    state, journal_root: str, *, allow_new_agent_bootstrap: bool = False,
    preserve_journal_error: bool = False,
) -> None:
    """Validate the saved journal head before any model/agent activity.

    This is a read-only *entry-point gate*, not recovery or a checkpoint. A
    newly-created agent with no prior source can bootstrap a missing journal
    only during initialize(), after its absence was checked by the caller.
    Unknown legacy source is never silently promoted to a verified receipt.
    """
    if state.journal_receipt is None:
        if allow_new_agent_bootstrap:
            root = Path(journal_root)
            if (root.is_absolute() and not root.is_symlink()
                    and not (root / state.agent_id).exists()
                    and not (root / state.agent_id).is_symlink()):
                return  # attach() creates the first empty journal, then saves a head
        raise RecoveryRequired(
            "Journal source has no independent journal receipt; existing or legacy source requires "
            "manual reconciliation before model inference"
        )
    try:
        journal = EpisodeJournal(journal_root, state.agent_id, create=False)
        report = verify_receipt(state.journal_receipt, journal)
    except JournalError as exc:
        if preserve_journal_error:
            raise  # Retain the established initialize() journal error contract.
        raise RecoveryRequired(f"Journal readiness failed: {exc}") from exc
    except RecoveryRequired as exc:
        raise RecoveryRequired(f"Journal readiness failed: {exc}") from exc
    if report["status"] != "VERIFIED":
        raise RecoveryRequired(
            "Legacy journal source has no verified independent head; "
            "manual reconciliation required"
        )

    # A matching head must also describe the retained episode source.  The
    # recovery inspector uses this exact same read-only validator.
    try:
        verify_retained_source(state, journal, report)
    except JournalError as exc:
        if preserve_journal_error:
            raise
        raise RecoveryRequired(f"Journal readiness failed: {exc}") from exc


def verify_retained_source(state, journal: EpisodeJournal, report: dict) -> None:
    """Verify the retained state against an independently verified journal head.

    No journal append, history mutation, checkpoint, or automatic recovery.
    Legacy receipts remain classified separately by the caller.
    """
    if report["status"] != "VERIFIED":
        return
    try:
        events = journal.replay()
        if (len(events) != report["count"] or
                (events[-1].entry_sha256 if events else None) != report["head"]):
            raise RecoveryRequired("Journal changed during read-only preflight")
        marked = [ep for ep in state.history
                  if ep.source_seq is not None
                  and ep.action.use_tool.name != "_history_summary"]
        if any(ep.source_seq is None and ep.action.use_tool.name != "_history_summary"
               for ep in state.history):
            raise RecoveryRequired(
                "Journal receipt does not cover retained unarchived actions"
            )
        numbers = [ep.source_seq for ep in marked]
        if (any(type(n) is not int or n < 1 for n in numbers)
                or (numbers and numbers != list(range(numbers[0], numbers[0] + len(numbers))))):
            raise RecoveryRequired("Journal retained-source sequence invalid")
        if events and (not numbers or numbers[-1] != len(events)):
            raise RecoveryRequired("Journal receipt has no matching retained source head")
        if numbers and (not events or numbers[-1] != len(events)):
            raise RecoveryRequired("Journal retained source is ahead of recorded head")
        for ep in marked:
            expected = events[ep.source_seq - 1]
            if (digest(episode_payload(ep)) != expected.episode_sha256
                    or ep.source_sha256 != expected.episode_sha256):
                raise RecoveryRequired("Journal retained source does not match event")
    except JournalError:
        raise


def inspect_recovery(state, journal_root: str) -> dict:
    """Return a redacted diagnosis without modifying journal or source state."""
    journal = EpisodeJournal(journal_root, state.agent_id, create=False)
    try:
        receipt = verify_receipt(state.journal_receipt, journal)
        verify_retained_source(state, journal, receipt)
    except (JournalError, RecoveryRequired) as exc:
        return {
            "agent_id": state.agent_id,
            "status": "BLOCKED_JOURNAL_MISMATCH",
            "reason": str(exc),
            "action": "MANUAL_INSPECTION_ONLY",
        }
    issue = pending_state_issue(state)
    if issue or state.evidence_failure:
        return {
            "agent_id": state.agent_id,
            "status": "RECOVERY_REQUIRED",
            "reason": issue or "Persisted evidence_failure requires operator reconciliation",
            "journal": receipt["status"],
            "action": "MANUAL_INSPECTION_ONLY; DO_NOT_AUTO_RETRY",
        }
    pending = state.current_episode
    if pending is not None:
        return {
            "agent_id": state.agent_id,
            "status": ("PENDING_PROPOSAL_REVIEW" if state.pending_phase == "PROPOSED"
                       else "INDETERMINATE_EFFECT"),
            "phase": state.pending_phase or "LEGACY_UNPHASED_PENDING",
            "command": pending.action.use_tool.name,
            "journal": receipt["status"],
            "action": "DO_NOT_AUTO_RETRY; REQUEST_HUMAN_RECONCILIATION",
        }
    return {
        "agent_id": state.agent_id,
        "status": ("READY_VERIFIED" if receipt["status"] == "VERIFIED"
                   else "LEGACY_SOURCE_SCOPE_LIMITED"),
        "journal": receipt["status"],
        "count": receipt["count"],
        "action": "NO_AUTOMATIC_RECOVERY_NEEDED",
    }
