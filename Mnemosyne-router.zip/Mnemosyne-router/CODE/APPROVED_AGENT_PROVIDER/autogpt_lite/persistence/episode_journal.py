"""Opt-in, research-stage append-only journal for captured AutoGPT Lite episodes.

The journal preserves *recorded agent episodes*, not a complete chat transcript,
and it does not authenticate actors or guarantee exactly-once external effects.
It intentionally does not provide summary approval or crash/restart semantics.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path

from ..models import ActionProposal, ActionResult, Episode, ResultStatus, Thoughts, ToolInvocation

SCHEMA = "autogpt-lite-captured-episode-v1"
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
_EVENT_RE = re.compile(r"^([0-9]{12})\.json$")


class JournalError(RuntimeError):
    """The source history is not verifiably captured; never prune on this error."""


def canonical(value: object) -> bytes:
    """Strict deterministic JSON, without permissive NaN or string coercion."""
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def digest(value: object) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def episode_payload(ep: Episode) -> dict:
    """The full captured Episode dataclass (unlike legacy state.json, includes raw_message)."""
    return {
        "action": {
            "thoughts": asdict(ep.action.thoughts),
            "use_tool": {"name": ep.action.use_tool.name,
                         "arguments": ep.action.use_tool.arguments},
            "raw_message": ep.action.raw_message,
        },
        "result": (None if ep.result is None else {
            "status": ep.result.status.value,
            "outputs": ep.result.outputs,
            "reason": ep.result.reason,
            "feedback": ep.result.feedback,
        }),
        "summary": ep.summary,
        "timestamp": ep.timestamp,
    }


def restore_episode(payload: dict) -> Episode:
    action = payload["action"]
    result = payload["result"]
    return Episode(
        action=ActionProposal(
            thoughts=Thoughts(**action["thoughts"]),
            use_tool=ToolInvocation(**action["use_tool"]),
            raw_message=action["raw_message"],
        ),
        result=(None if result is None else ActionResult(
            status=ResultStatus(result["status"]), outputs=result["outputs"],
            reason=result["reason"], feedback=result["feedback"])),
        summary=payload["summary"], timestamp=payload["timestamp"],
    )


@dataclass(frozen=True)
class JournalEvent:
    seq: int
    entry_sha256: str
    episode_sha256: str
    episode: Episode
    source_scope: str


class EpisodeJournal:
    def __init__(self, root: str, agent_id: str, *, create: bool = True):
        if not root or not Path(root).is_absolute():
            raise JournalError("Journal root must be an explicit absolute external path")
        if not _ID_RE.fullmatch(agent_id):
            raise JournalError("Invalid agent ID")
        self.root = Path(root)
        self.agent_id = agent_id
        self.agent_dir = self.root / agent_id
        self.events_dir = self.agent_dir / "events"
        for directory in (self.root, self.agent_dir, self.events_dir):
            if directory.is_symlink():
                raise JournalError(f"Symlinked journal directory is forbidden: {directory}")
            if create:
                directory.mkdir(mode=0o700, parents=False, exist_ok=True)
            elif not directory.is_dir():
                raise JournalError("Journal path does not exist; verification is read-only")
        self._assert_dirs()

    def _assert_dirs(self) -> None:
        for directory in (self.root, self.agent_dir, self.events_dir):
            if directory.is_symlink() or not directory.is_dir():
                raise JournalError("Journal directory moved, missing, or symlinked")

    def _paths(self) -> list[Path]:
        self._assert_dirs()
        paths = []
        for path in self.events_dir.iterdir():
            if path.name.startswith(".pending-"):
                # An orphan temp file means an interrupted append: do not assume completeness.
                raise JournalError("Interrupted journal append: unresolved pending file")
            if not _EVENT_RE.fullmatch(path.name) or path.is_symlink() or not path.is_file():
                raise JournalError(f"Unexpected journal entry: {path.name}")
            paths.append(path)
        return sorted(paths)

    def replay(self, expected_head: str | None = None) -> list[JournalEvent]:
        """Verify every entry and hash link; expected_head detects an absent tail."""
        found = []
        previous = None
        for seq, path in enumerate(self._paths(), 1):
            if path.name != f"{seq:012d}.json":
                raise JournalError(f"Missing or duplicate event sequence at {seq}")
            try:
                row = json.loads(path.read_bytes())
                if not isinstance(row, dict):
                    raise ValueError("entry must be an object")
                supplied_hash = row.pop("entry_sha256")
                if digest(row) != supplied_hash:
                    raise ValueError("entry digest mismatch")
                if (row["schema"] != SCHEMA or row["agent_id"] != self.agent_id
                        or row["seq"] != seq or row["previous_entry_sha256"] != previous):
                    raise ValueError("entry chain or identity mismatch")
                if digest(row["episode"]) != row["episode_sha256"]:
                    raise ValueError("episode digest mismatch")
                ep = restore_episode(row["episode"])
                # Reject incomplete or synthetic episodes in a journal of source actions.
                if ep.result is None or ep.action.use_tool.name == "_history_summary":
                    raise ValueError("incomplete/synthetic episode in source journal")
                if row["source_scope"] not in (
                    "LEGACY_CHECKPOINT_GAP", "CAPTURED_EPISODES_ONLY",
                    "INHERITED_FROM_FIRST_ENTRY"):
                    raise ValueError("unknown source scope")
                if (seq == 1) == (row["source_scope"] == "INHERITED_FROM_FIRST_ENTRY"):
                    raise ValueError("invalid first/subsequent source scope")
                found.append(JournalEvent(seq, supplied_hash, row["episode_sha256"],
                                          ep, row["source_scope"]))
                previous = supplied_hash
            except (ValueError, KeyError, TypeError, UnicodeDecodeError, AttributeError) as exc:
                raise JournalError(f"Unverifiable journal entry #{seq}: {exc}") from exc
        if expected_head is not None and previous != expected_head:
            raise JournalError("Journal head differs from expected revision")
        return found

    def append(self, episode: Episode, *, scope: str = "CAPTURED_EPISODES_ONLY") -> JournalEvent:
        """Publish a new entry without overwriting any old one; verify before append."""
        if episode.result is None or episode.action.use_tool.name == "_history_summary":
            raise JournalError("Cannot archive incomplete or synthetic episode as an action")
        prior = self.replay()
        seq = len(prior) + 1
        ep_data = episode_payload(episode)
        body = {
            "schema": SCHEMA,
            "agent_id": self.agent_id,
            "seq": seq,
            "previous_entry_sha256": prior[-1].entry_sha256 if prior else None,
            "source_scope": (scope if not prior else "INHERITED_FROM_FIRST_ENTRY"),
            "episode_sha256": digest(ep_data),
            "episode": ep_data,
        }
        entry_sha = digest(body)
        encoded = canonical({**body, "entry_sha256": entry_sha}) + b"\n"
        self._assert_dirs()
        temp_name = None
        target = self.events_dir / f"{seq:012d}.json"
        try:
            fd, temp_name = tempfile.mkstemp(prefix=".pending-", dir=self.events_dir)
            with os.fdopen(fd, "wb") as out:
                out.write(encoded)
                out.flush()
                os.fsync(out.fileno())
            os.link(temp_name, target)  # O_EXCL-like: refuses a competing writer's path
            os.unlink(temp_name)
            temp_name = None
            # Best-effort directory sync (POSIX); AM03 will test crash boundaries.
            dir_fd = os.open(self.events_dir, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError as exc:
            raise JournalError(f"Journal append failed: {exc}") from exc
        finally:
            if temp_name is not None:
                try:
                    os.unlink(temp_name)
                except OSError:
                    pass
        return JournalEvent(seq, entry_sha, body["episode_sha256"], episode,
                            body["source_scope"])

    def capture_history(self, history: list[Episode]) -> dict:
        """Archive only previously-unarchived episodes, verifying any retained anchors.

        Prior source with no matching retained marker cannot be inferred from
        an old state.json. On such ambiguity we fail closed instead.
        """
        prior = self.replay()
        marked = [ep for ep in history if ep.source_seq is not None
                  and ep.action.use_tool.name != "_history_summary"]
        if marked:
            if any(type(ep.source_seq) is not int or ep.source_seq < 1 for ep in marked):
                raise JournalError("Invalid retained episode sequence")
            numbers = [ep.source_seq for ep in marked]
            if numbers != list(range(numbers[0], numbers[0] + len(numbers))):
                raise JournalError("Retained episode sequence is not contiguous")
            if not prior or numbers[-1] != len(prior):
                raise JournalError("Retained episode history is not anchored at journal head")
            for ep in marked:
                if ep.source_seq is None or ep.source_seq < 1:
                    raise JournalError("Invalid retained episode sequence")
                saved = prior[ep.source_seq - 1]
                if (saved.episode_sha256 != digest(episode_payload(ep))
                        or ep.source_sha256 != saved.episode_sha256):
                    raise JournalError("Retained episode does not match archived source")
        elif prior:
            raise JournalError("Unanchored state with existing journal; manual recovery required")

        saw_new = False
        appended = 0
        legacy_gap = any(ep.action.use_tool.name == "_history_summary" for ep in history)
        first_scope = "LEGACY_CHECKPOINT_GAP" if legacy_gap else "CAPTURED_EPISODES_ONLY"
        for ep in history:
            if ep.action.use_tool.name == "_history_summary":
                continue
            if ep.source_seq is not None:
                if saw_new:
                    raise JournalError("Previously archived event follows new event")
                continue
            saw_new = True
            entry = self.append(ep, scope=first_scope)
            ep.source_seq = entry.seq
            ep.source_sha256 = entry.episode_sha256
            appended += 1
        current = self.replay()
        return {
            "agent_id": self.agent_id,
            "source_kind": "RECORDED_ACTION_EPISODES_NOT_FULL_CHAT",
            "captured_count": len(current),
            "newly_captured": appended,
            "source_scope": (current[0].source_scope if current else first_scope),
            "head": current[-1].entry_sha256 if current else None,
            "verified": True,
        }
