"""Persistence layer (spec §15).

JSON file-based persistence with resume semantics.
Layout: {agent_data_dir}/{agent_id}/state.json
"""

from __future__ import annotations

import json
import logging
import os
import re
import secrets
import stat
from dataclasses import asdict
from pathlib import Path
from typing import Optional

from ..models import (
    ActionProposal,
    ActionResult,
    AgentConfig,
    AgentState,
    AIProfile,
    ContextItem,
    Directives,
    Episode,
    ResultStatus,
    Thoughts,
    ToolInvocation,
)

logger = logging.getLogger(__name__)


class StateRecoveryError(RuntimeError):
    """Existing state is corrupt or ambiguous; never silently start a fresh agent."""


def _fsync_directory(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


# Match EpisodeJournal's agent identifier syntax so the two stores cannot
# interpret the same identifier as different filesystem paths.
_AGENT_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
_DIRECTORY_FLAGS = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
_FILE_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)


def _validate_agent_id(agent_id: str) -> str:
    if not isinstance(agent_id, str) or _AGENT_ID.fullmatch(agent_id) is None:
        raise StateRecoveryError("Invalid agent ID: expected 1–80 ASCII letters, digits, _ or -")
    return agent_id


def _assert_no_symlink_ancestors(directory: Path) -> None:
    # This rejects a redirected workspace before any mkdir/open. Later agent
    # operations use directory descriptors, not path concatenation.
    for candidate in (directory, *directory.parents):
        if candidate.is_symlink():
            raise StateRecoveryError("Symlinked state directory or ancestor is forbidden")


class AgentStore:
    """JSON state store restricted to simple agent IDs under one owned root.

    File operations are anchored to opened directory descriptors. This avoids
    following an agent-owned symlink and prevents '../' escaping the root.
    The configured root must remain in an operator-controlled filesystem.
    """

    def __init__(self, data_dir: str = "./agents"):
        self.data_dir = Path(os.path.abspath(data_dir))
        _assert_no_symlink_ancestors(self.data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        _assert_no_symlink_ancestors(self.data_dir)

    def _root_fd(self) -> int:
        _assert_no_symlink_ancestors(self.data_dir)
        try:
            return os.open(self.data_dir, _DIRECTORY_FLAGS)
        except OSError as exc:
            raise StateRecoveryError("Agent store root is not a trusted directory") from exc

    @staticmethod
    def _agent_fd(root_fd: int, agent_id: str, *, create: bool = False) -> int:
        if create:
            try:
                os.mkdir(agent_id, mode=0o700, dir_fd=root_fd)
            except FileExistsError:
                pass
        return os.open(agent_id, _DIRECTORY_FLAGS, dir_fd=root_fd)

    @staticmethod
    def _open_state(agent_fd: int) -> int:
        fd = os.open("state.json", _FILE_FLAGS, dir_fd=agent_fd)
        if not stat.S_ISREG(os.fstat(fd).st_mode) or os.fstat(fd).st_nlink != 1:
            os.close(fd)
            raise StateRecoveryError("State file must be a single-link regular file")
        return fd

    def save(self, state: AgentState) -> None:
        """Atomic state replacement without following agent or file symlinks."""
        agent_id = _validate_agent_id(state.agent_id)
        # A serialization failure must not create a new agent directory.
        encoded = (json.dumps(self._serialize(state), indent=2, ensure_ascii=False,
                              allow_nan=False) + "\n").encode("utf-8")
        root_fd = self._root_fd()
        try:
            try:
                agent_fd = self._agent_fd(root_fd, agent_id, create=True)
            except OSError as exc:
                raise StateRecoveryError("Agent directory is missing or untrusted") from exc
            try:
                try:
                    existing_fd = self._open_state(agent_fd)
                except FileNotFoundError:
                    pass
                except OSError as exc:
                    raise StateRecoveryError("Symlinked or untrusted state file is forbidden") from exc
                else:
                    os.close(existing_fd)
                temp_name = ".state-pending-" + secrets.token_hex(16)
                fd = os.open(temp_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=agent_fd)
                try:
                    with os.fdopen(fd, "wb") as output:
                        output.write(encoded)
                        output.flush()
                        os.fsync(output.fileno())
                    # os.replace replaces a path entry, never follows a target
                    # symlink. Check the existing state before replacement.
                    try:
                        existing_fd = self._open_state(agent_fd)
                    except FileNotFoundError:
                        pass
                    else:
                        os.close(existing_fd)
                    os.replace(temp_name, "state.json", src_dir_fd=agent_fd,
                               dst_dir_fd=agent_fd)
                    os.fsync(agent_fd)
                finally:
                    try:
                        os.unlink(temp_name, dir_fd=agent_fd)
                    except FileNotFoundError:
                        pass
            finally:
                os.close(agent_fd)
        finally:
            os.close(root_fd)
        logger.info("Saved agent %s", agent_id)

    def agent_directory_exists(self, agent_id: str) -> bool:
        """Read-only existence check under the trusted store root.

        Unlike load(), an existing directory without state.json is *not*
        evidence that this identity is new. Reject untrusted symlinked paths.
        This check does not claim cross-process atomicity with later creation.
        """
        agent_id = _validate_agent_id(agent_id)
        root_fd = self._root_fd()
        try:
            try:
                agent_fd = self._agent_fd(root_fd, agent_id)
            except FileNotFoundError:
                return False
            except OSError as exc:
                raise StateRecoveryError("Existing agent directory is untrusted") from exc
            else:
                os.close(agent_fd)
                return True
        finally:
            os.close(root_fd)

    def load(self, agent_id: str) -> Optional[AgentState]:
        """Load only a verified state file inside the selected agent directory."""
        agent_id = _validate_agent_id(agent_id)
        root_fd = self._root_fd()
        try:
            try:
                agent_fd = self._agent_fd(root_fd, agent_id)
            except FileNotFoundError:
                return None
            except OSError as exc:
                raise StateRecoveryError("Agent directory is untrusted") from exc
            try:
                try:
                    state_fd = self._open_state(agent_fd)
                except FileNotFoundError:
                    return None
                with os.fdopen(state_fd, "r", encoding="utf-8") as state_file:
                    data = json.load(state_file)
                # Saved task is a required executable-context string. A missing
                # or malformed value may be inspected via list_agents(), but
                # must not silently become a runnable task on resume.
                if not isinstance(data, dict) or type(data.get("task")) is not str:
                    raise ValueError("Saved task metadata is not a string")
                state = self._deserialize(data)
                if state.agent_id != agent_id:
                    raise ValueError("Requested identity differs from stored identity")
                return state
            except Exception as exc:
                if isinstance(exc, StateRecoveryError):
                    raise
                raise StateRecoveryError(
                    f"Existing state {agent_id} cannot be trusted; manual inspection required"
                ) from exc
            finally:
                os.close(agent_fd)
        finally:
            os.close(root_fd)

    def list_agents(self) -> list[dict]:
        """Discover verified states without following links outside the root."""
        agents = []
        root_fd = self._root_fd()
        try:
            for agent_id in sorted(os.listdir(root_fd)):
                if _AGENT_ID.fullmatch(agent_id) is None:
                    continue
                try:
                    agent_fd = self._agent_fd(root_fd, agent_id)
                except OSError:
                    continue
                try:
                    try:
                        state_fd = self._open_state(agent_fd)
                        with os.fdopen(state_fd, "r", encoding="utf-8") as state_file:
                            data = json.load(state_file)
                        if not isinstance(data, dict) or data.get("agent_id") != agent_id:
                            continue
                        cycle_count = data.get("cycle_count", 0)
                        task = data.get("task", "unknown")
                        agents.append({
                            "agent_id": agent_id,
                            "task": task,
                            # Read-only discovery preserves the original value
                            # for diagnosis, without advertising malformed or
                            # absent task fields as trusted executable context.
                            "task_valid": "task" in data and type(task) is str,
                            "cycle_count": cycle_count,
                            # A malformed counter must never be advertised as
                            # verified or trusted just because JSON parsed.
                            "cycle_count_valid": (
                                type(cycle_count) is int and cycle_count >= 0
                            ),
                            "created_at": data.get("created_at", ""),
                        })
                    except (ValueError, OSError, TypeError, UnicodeError, StateRecoveryError):
                        continue
                finally:
                    os.close(agent_fd)
        finally:
            os.close(root_fd)
        return agents

    def delete(self, agent_id: str) -> bool:
        """Delete only a verified state and its otherwise empty agent directory.

        Unexpected contents or a corrupt/mismatched state require manual
        inspection. This never recursively deletes arbitrary user files.
        """
        agent_id = _validate_agent_id(agent_id)
        root_fd = self._root_fd()
        try:
            try:
                agent_fd = self._agent_fd(root_fd, agent_id)
            except FileNotFoundError:
                return False
            except OSError as exc:
                raise StateRecoveryError("Agent directory is untrusted") from exc
            try:
                if set(os.listdir(agent_fd)) != {"state.json"}:
                    raise StateRecoveryError("Unknown or interrupted agent files; manual inspection required")
                try:
                    state_fd = self._open_state(agent_fd)
                    with os.fdopen(state_fd, "r", encoding="utf-8") as state_file:
                        record = json.load(state_file)
                        required = {"agent_id", "ai_profile", "directives", "history",
                                    "context", "cycle_count", "created_at"}
                        if not isinstance(record, dict) or not required.issubset(record):
                            raise ValueError("Incomplete state record")
                        saved_id = self._deserialize(record).agent_id
                except (ValueError, KeyError, OSError, TypeError, AttributeError, UnicodeError) as exc:
                    raise StateRecoveryError("Cannot verify state before deletion") from exc
                if saved_id != agent_id:
                    raise StateRecoveryError("State identity mismatch; deletion refused")
                os.unlink("state.json", dir_fd=agent_fd)
                # If a concurrent writer adds files, rmdir will fail safely.
                os.rmdir(agent_id, dir_fd=root_fd)
                os.fsync(root_fd)
                return True
            finally:
                os.close(agent_fd)
        finally:
            os.close(root_fd)

    # -------------------------------------------------------------------
    # Serialization / Deserialization
    # -------------------------------------------------------------------

    def _serialize(self, state: AgentState) -> dict:
        """Convert AgentState to a JSON-serializable dict."""
        return {
            "agent_id": state.agent_id,
            "task": state.task,
            "ai_profile": asdict(state.ai_profile),
            "directives": asdict(state.directives),
            "history": [self._serialize_episode(ep) for ep in state.history],
            "context": [asdict(c) for c in state.context],
            "current_episode": (
                self._serialize_episode(state.current_episode)
                if state.current_episode else None
            ),
            "cycle_count": state.cycle_count,
            "created_at": state.created_at,
            # Runtime config persisted for resume fidelity (Issue 3).
            # These are the fields needed for behavioral continuity.
            # Legacy continuous-mode settings are never restored or honored.
            "config": state.saved_config if hasattr(state, 'saved_config') and state.saved_config else None,
            "journal_receipt": state.journal_receipt,
            "pending_phase": state.pending_phase,
            "evidence_failure": state.evidence_failure,
        }

    def _serialize_episode(self, ep: Episode) -> dict:
        return {
            "action": {
                "thoughts": asdict(ep.action.thoughts),
                "use_tool": {
                    "name": ep.action.use_tool.name,
                    "arguments": ep.action.use_tool.arguments,
                },
                "raw_message": ep.action.raw_message,
            },
            "result": (
                {
                    "status": ep.result.status.value,
                    "outputs": ep.result.outputs,
                    "reason": ep.result.reason,
                    "feedback": ep.result.feedback,
                }
                if ep.result else None
            ),
            "summary": ep.summary,
            "source_seq": ep.source_seq,
            "source_sha256": ep.source_sha256,
            "timestamp": ep.timestamp,
        }

    def _deserialize(self, data: dict) -> AgentState:
        return AgentState(
            agent_id=data["agent_id"],
            task=data.get("task", ""),
            ai_profile=AIProfile(**data.get("ai_profile", {})),
            directives=Directives(**data.get("directives", {})),
            history=[self._deserialize_episode(e) for e in data.get("history", [])],
            context=[ContextItem(**c) for c in data.get("context", [])],
            current_episode=(
                self._deserialize_episode(data["current_episode"])
                if data.get("current_episode") else None
            ),
            cycle_count=data.get("cycle_count", 0),
            created_at=data.get("created_at", ""),
            saved_config=data.get("config"),
            journal_receipt=data.get("journal_receipt"),
            pending_phase=data.get("pending_phase"),
            evidence_failure=data.get("evidence_failure"),
        )

    def _deserialize_episode(self, data: dict) -> Episode:
        action_data = data["action"]
        result_data = data.get("result")

        action = ActionProposal(
            thoughts=Thoughts(**action_data["thoughts"]),
            use_tool=ToolInvocation(**action_data["use_tool"]),
            raw_message=action_data.get("raw_message", ""),
        )

        result = None
        if result_data:
            result = ActionResult(
                status=ResultStatus(result_data["status"]),
                outputs=result_data.get("outputs"),
                reason=result_data.get("reason"),
                feedback=result_data.get("feedback"),
            )

        return Episode(
            action=action,
            result=result,
            summary=data.get("summary"),
            source_seq=data.get("source_seq"),
            source_sha256=data.get("source_sha256"),
            timestamp=data.get("timestamp", ""),
        )
