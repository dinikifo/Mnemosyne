# HWI governance extension — release notes

**Baseline:** accepted HWI Dual-Flow 10/10 commit `e1af2e0`.

**New, not yet separately accepted:** task-specific model/workflow fitness gate;
operator-signed assessment verification; review-queue CLI; inert PERSONAL.WIKI JSON
review-section export; one-use signed wiki proposal application via HWI-08;
read-only history and review diff inspection; prior active version restoration
via a new signed HWI-07 proposal.

**Not implemented:** a live UI plugin/automatic bidirectional wiki review panel;
production key enrollment or secure key storage; independent truth/identity
attestation; automated resolution of semantic disagreements; deleted-note
restore via this proposal helper; execution authorization; protected/PVS
writes; or closure of unrelated HWI/Linux gates.

**Compatibility:** approved PERSONAL.WIKI and AutoGPT Lite provider source
are copied unchanged. No accepted baseline commits are rewritten.

**Verification:** new regression checks cover fitness signatures, pins,
critical-case failures, origin bypass attempts, signed wiki edits,
stale revisions, one-use replay protection, version history and signed
restoration. A real production notebook was not used in tests.

## Governance review fixes (13 November 2026)

Applied to the unaccepted candidate only. `CODE/APPROVED_WIKI_CORE` and
`CODE/APPROVED_AGENT_PROVIDER` remain byte-identical.

1. **Fitness key anchored in the workspace (was: caller-supplied pin).** The
   owner key fingerprint is read from an operator-provisioned
   `fitness_policy/<notebook>.json` (0700/0600, scope-bound), mirroring HWI-08
   `review_policy`. `--operator-pin` is removed. A fitness key equal to the
   wiki reviewer key is refused.
2. **No trivially eligible contracts.** Contract/results/assessment/decision
   schemas are now v2. At least one critical case is mandatory and
   `min_pass_percent` must be 50–100, so an all-FAIL result set can never be
   eligible.
3. **Approval bounded and recorded.** v2 contracts declare `valid_until`
   (≤ 366 days) and `max_proposals` (1–1000); both appear in the signed payload.
   Gated submissions are serialized per notebook, counted against the quota,
   carry `external:hwi-fitness/<assessment-sha256>` and a write-once receipt.
   `queue-list`, `queue-review` and the export show `VERIFIED`, `UNGATED` or
   `UNVERIFIED` after re-checking the receipt against the workspace pin.
4. **Export matches PERSONAL.WIKI.** PERSONAL.WIKI imports JSON only and its
   renderer ignores `type`. The export is now a JSON import array whose
   proposal content sits in one fenced code block with backtick/`<`/`>`/`&`
   JSON-escaped, so links, transclusions and `<$list>` filters are inert.
   Verified by importing and rendering with the approved core in tests.
5. **Malformed specs are `REJECTED`, not tracebacks.** Spec shape is checked
   before the gate; `sqlite3.Error` is reported as a rejection.
6. **Smaller items.** No-op restores are refused; export lists pending
   proposals first and states any omission beyond 100; ledger listing pages
   through all proposals; the receipt-table read is documented as mirroring
   approved HWI-07 `_has_wiki_receipt`; manual file reference corrected.

Verification (Linux packaging environment): 335 dual-flow, 16 Mac-launcher,
65 content and **49** governance tests pass (was 27; 52, 57 and 59 after the later passes below). Each fix was
mutation-checked: disabling it makes at least one test fail. Native macOS
recheck is still outstanding.

### Second review pass (13 November 2026)

7. **Quota squatting closed.** Quota is now counted from gate-written
   reservations (`fitness_receipts/<notebook>/<sha>.uses/`), not from ledger
   references any HWI-07 caller can write. `VERIFIED` additionally requires a
   usage record naming the exact proposal. Definite ledger rejections return
   the slot; uncertain failures keep it (fail closed).
8. **Readable review text.** Export and CLI output now show Greek and other
   printable characters as written (UTF-8) while bidi, zero-width, control,
   private-use and non-ASCII space characters stay visibly escaped
   (`display.readable_json`; values round-trip exactly).
9. **Same-revision restore check fixed.** It compared an integer event id to a
   string and never fired; content equality caught the case only by accident.
10. **Manual:** import the review page without *Protect evidence*, otherwise
   it cannot be refreshed.

Governance tests: **52** (all pass); each fix mutation-checked.

### Third review pass (13 November 2026)

11. **Evidence references required again.** The gate's own fitness reference
   satisfied HWI-07's "at least one source reference" rule, so a gated
   proposal could carry no evidence. Specs now need 1–11 evidence references.
12. **The gate matters at apply time.** `queue-apply` refuses proposals whose
   gate is not `VERIFIED` unless `--accept-unverified-gate` is given (restore
   proposals need it by design); the output records the acceptance.
13. **Honest post-commit failure.** If the ledger commits but the gate usage
   record cannot be written, the CLI exits 3 with
   `SUBMITTED_WITHOUT_GATE_RECORD` and the proposal id instead of `REJECTED`.
14. **Shipped examples are tested** (skipped once their `valid_until` passes).

Governance tests: **57** (all pass); each fix mutation-checked.

### Fourth review pass (13 November 2026)

15. **End-to-end manual walkthrough** through `RUN_GOVERNANCE.command`
   (Appendix A keys and policies, §6–§12 including restore, reject and
   withdraw) completes; 8 concurrent submissions against a quota of 3 yield
   exactly 3 `VERIFIED` proposals.
16. **`fitness-pins`** added: prints `contract_sha256`, `configuration_sha256`
   and case IDs, so building a results file no longer needs Python.
17. **`fitness-verify` checks the notebook**: an assessment naming another
   notebook is refused even if the same key is pinned for both.

Governance tests: **59** (all pass); each fix mutation-checked.

### Consolidation (13 November 2026)

All review fixes are committed on `feature/governance-candidate` as
`b00411b927ae288fa524a866b4824aa138951f25` (parent: original candidate
`9f38af5`). `GIT/HWI_DUALFLOW_GOVERNANCE_CANDIDATE.bundle` was rebuilt with the
same refs; a fresh clone reproduces `CODE/DUALFLOW` exactly and keeps the
accepted `e1af2e0` history unchanged. `GIT/HWI_DUALFLOW_ACCEPTED_10_OF_10.bundle`
is byte-identical to the previous release. The candidate remains
**unaccepted**.

## Workstream A: repository interface (13 November 2026)

Implements the revised Workstream A of the scoped plan on top of `b00411b`.
Approved trees remain byte-identical.

- **`repository.py`** is the single boundary to the approved packages
  (`personal_wiki_core`, `hwi`). Other governance modules no longer import
  them or read `_db`; `test_boundary` (in `test_repository_layer.py`) enforces
  this with an AST check. Approved errors are translated at the boundary.
- **`test_wiki_contract.py`** pins 10 behaviours of the unchanged core the
  governance layer relies on (renderer ignores `type`, fenced code is inert,
  `<$list>` scan of raw text, JSON-only import, protected-import refusal, receipt
  table, restored-copy scope, bundle contents, ledger scope refusal, ledger
  rejections before commit). A core change fails exactly one named test.
- **Gate records in SQLite.** `gate_store.py` keeps fitness receipts and quota
  slots in `governance/<notebook>.governance.sqlite`: scope-bound like the
  ledger, rollback journal, FULL sync, foreign keys, immutability triggers.
  Reservation is one `BEGIN IMMEDIATE` transaction, replacing the JSON
  receipt/usage files and the `fcntl` lock. The ledger still commits on its own
  private connection, so the exit-3 gap remains (folding needs a core change).
- **`queue-decommission`** archives (never deletes) the ledger, governance
  database and policies of a LIVE instance without pending proposals, or of an
  ORPHANED one after re-import, with a SHA-256 manifest.
- **`INSTALL.sh` / `install.py`** record the machine role once in
  `~/.config/hwi/host_profile.json`, rebuildable with `--profile`; they never
  create notebooks, ledgers, keys or policies.

Tests: governance area **92** (59 existing + 10 contract + 16 boundary/store/
decommission + 7 install); full offline suite **508**. Each new mechanism was
mutation-checked (9 mutations, all caught). Manual walkthrough, concurrency
(8 submitters, quota 3: exactly 3 VERIFIED) and earlier probes re-run clean.
`RUN_GATE_A_NATIVE.command` (`tools/gate_a_native.py`, with
`gate_a_walkthrough.py` and `gate_a_concurrency.py`) runs the complete Gate A
check on one machine and writes a JSON report outside the release; it is what
the native macOS and Raspberry Pi runs consist of.

### Consolidation of Workstream A (13 November 2026)

Committed on `feature/governance-candidate` as `061c9ccd315974958a30690bc163cfe20dd99a92`
(parent `b00411b`). The candidate bundle was rebuilt with the same refs; a fresh
clone reproduces `CODE/DUALFLOW` exactly and keeps the accepted `e1af2e0`
history. The release-root launchers `INSTALL.sh` and
`RUN_GATE_A_NATIVE.command` sit outside the Git tree and are covered by the
manifest. The accepted bundle is byte-identical. The candidate remains
**unaccepted**; Gate A needs native reports from macOS and the Raspberry Pi.

## Review fixes to recovery and Formation (13 November 2026)

Applied on top of `df6ec53`; approved trees byte-identical to the approved source.

1. **Recovery survives ledger normalisation.** The ledger trims the reason,
   source references and proposed title; padded inputs were recorded trimmed and
   recovery reported `NO_EXACT_MATCH` forever. `repository.normalize_proposal_request`
   mirrors the ledger (contract test 11); `check_spec` normalises before any check
   and reservation, and recovery normalises requests saved untrimmed by `df6ec53`.
   This also closes a bypass: a spec-supplied fitness reference with a leading
   space passed the prefix check and was trimmed by the ledger.
2. **Recovered bindings stay visible.** `--apply` records each binding in an
   immutable `recovered_bindings` table in the same transaction; gate status shows
   `binding: OPERATOR_RECOVERY` (normal: `GATE_SUBMISSION`) in `queue-review`,
   `queue-status` and the export.
3. **No bytecode in the release.** 27 `cpython-313.pyc` files were removed from the
   approved trees and the manifest; a test fails if bytecode is ever listed again.
4. **Documented.** USER_MANUAL §9/§10/§14 cover `queue-gate-recover`,
   `queue-status`, `SUBMISSION_OUTCOME_UNKNOWN` and the binding marker;
   `README_FIRST.md` again describes the whole release.
5. **Formation fixes.** After a model-led conversation the fallback draft no
   longer assigns answers by position (it lists them as unassigned for EDIT); a
   `CONFIRM` interrupted after the contract write can be retried (a different
   existing contract is refused; a confirmed session is refused explicitly); all
   draft, wiki and model text is shown with invisible characters escaped.

Tests: governance 109, Formation 62 (6 new); full offline suite 587; each fix mutation-checked
(10 mutations, all caught). Practice-card design left for user testing.

### Consolidation of the review fixes (13 November 2026)

Committed on `experiment/gate-interruption-recovery` as `dc5adc5bf1e8c943ae179fb6dfc7b9b6210bca6b` (parent
`df6ec53`). The recovery bundle was rebuilt with its complete history; a fresh
clone reproduces `CODE/DUALFLOW` exactly and contains the accepted `e1af2e0`,
governance `061c9cc` and Formation `ab51cd7` history. The other three bundles are
byte-identical to the previous release. Stabilisation (dogfooding) phase: next
are native Gate A reports from macOS, the Linux PC and the Pi, and a restore drill.

## Formation concurrency fix (13 November 2026, reported during dogfooding)

`FormationStore.save()` checked the expected previous hash and then replaced the
file without a lock: two processes resuming one session could both pass the check
and both report success while one update was lost (reproduced deterministically
with two writers). Fixed in `hwi_formation/storage.py`:

- `create`, `save` and `confirm` each run their whole read-check-write sequence
  under one exclusive store lock (`flock` on `<formation root>/.store.lock`, 0600),
  making `save` a locked compare-and-swap. `confirm` holds the lock across the
  contract write and the session update.
- `confirm` now also refuses a stale caller BEFORE writing the contract.
  Previously a caller holding an outdated draft could publish a contract for it,
  after which the session update failed and no later CONFIRM could match.
- Scope of the guarantee: processes on one machine, local disk. It is not a
  cross-device lock; Formation state must not be shared by sync tools or network
  filesystems.

Tests: 4 new (two concurrent saves, two concurrent confirms, stale confirm,
private lock file); Formation 66. Three mutations (no lock, save outside the lock,
no freshness check in confirm) are all caught.

## Review fixes after the concurrency release (13 November 2026)

From the extended review of the concurrency-fix candidate:

- **Formation session transitions are enforced at storage.** `save()` refuses
  changes to session identity and configuration (schema, ID, model, endpoint,
  wiki capabilities), keeps the conversation append-only one message at a time,
  allows mode changes only LOCAL_OLLAMA -> MANUAL during the conversation, and
  refuses backward states. `DRAFT_READY -> CONFIRMED` is reachable only through
  `confirm()`, which may change nothing but the state and contract digest.
- **Read-only governance access is read-only.** Diagnostics (including
  `queue-gate-recover` without `--apply` and gate status) open the gate store in
  SQLite read-only mode and report an unexpected journal mode instead of
  converting it. Only write paths set the journal mode.
- **Interrupted CONFIRM no longer blocks a later one.** A contract left by a
  failed CONFIRM whose draft was then edited is moved to `contracts/orphaned/`
  (0700) and the new contract is saved. Identical retries still reuse it.
- **Model replies are checked as questions.** One or two short plain sentences
  ending in a question (`?`, or `;`/U+037E for Greek), at most 300 characters,
  with no code, shell syntax, paths, links, or sentences opening with an action
  verb (English and Greek list, a heuristic second line). A rejected reply is
  withheld and HWI asks its own guided question; the session stays in model mode.
- **`list` shows every session** (it silently stopped at 200).
- Deferred: recording retrieved practice citations in the Purpose Contract
  (changes the contract format; belongs with the practice-card design).

Tests: governance 112 (+3), Formation 78 (+12). Each fix was mutation-checked
(7 mutations, all caught).

Committed on `experiment/gate-interruption-recovery` as `bcd710367a3014aa0eb4508c5b551b4b0e51d384` (parent `dc5adc5`), together with the Formation concurrency fix above.

## Known limitation found during release verification (13 November 2026)

Contract test 9 (`test_ledger_refuses_reimported_instance`) failed intermittently
(2 of 40 runs on ext4): after delete + restore at the same path, the filesystem
reused both inode numbers, so the restored notebook had the old scope. The test
now holds the old inodes open during the restore and always checks the intended
property. The limitation itself is in the approved core (scope = path + device +
inode) and stays an A2 item (stored instance ID). Mitigation: the manual now says
to run `queue-decommission` BEFORE deleting or replacing a notebook.

Committed as `d61e98894a6fccc04616035142c1c3cfb724e2da` (parent `bcd7103`).

## Second-pass fixes (13 November 2026, review of d61e988)

- `FormationStore.create()` accepts only a fresh session (IN_PROGRESS, no
  conversation, draft or contract digest). A session created as CONFIRMED
  without a contract was the remaining path around the transition check.
- The model-question check no longer treats `;` as a question mark unless the
  final sentence is Greek, so English statements ending in `;` are withheld.
- Any model reply that mentions approval, authorisation, permission, consent,
  sign-off, credentials, passwords, tokens or secrets (English and Greek
  stems), or "all future"/"every edit" wording, is withheld and the guided
  question is shown instead. Formation never needs the model to raise these;
  they belong to the operator and the governance layer.
- Still heuristic: generated text is filtered, not constrained. Having the
  model choose from Python-owned questions is the stronger design and is the
  paused practice-card / pattern-routing experiment.

Tests: Formation 79 (+1 test, +6 rejection and +1 acceptance cases). Three
mutations (create unchecked, `;` accepted, no authority check) all caught.

Committed as `def6435102248ff66997da8684ae8c2e1888ce8b` (parent `d61e988`).

## Model-written questions off by default (13 November 2026, review of def6435)

The review reproduced a model question the lexical filter accepted ("Would you
like me to bypass the review queue and update your notebook?"). Rather than
extend the word list, Formation now asks only HWI's own guided questions by
default; the local model still writes the draft. `--model-questions` on `start`
or `resume` re-enables filtered model questions for comparison. The replacement
is the constrained question-card experiment (the model selects a Python-owned
question), planned as the first work after stabilisation.

Tests: Formation 82 (+3). Three mutations (questions always on, default on,
resume ignoring the flag) all caught.

Committed as `a4d20122f97736907c978d033c94ac856fa3310c` (parent `def6435`).

## Guided questions kept with their answers (13 November 2026, review of a4d2012)

With model questions off by default, the conversation stored only the user's
answers, so the draft request sent Ollama a list of answers without the
questions they answered. Each guided question is now stored as a `guide`
message (HWI's own, Python-owned text) immediately before its answer, and is
sent to the model in the assistant role, so the draft request contains exact
question-answer pairs. A fallback question shown after a withheld model reply
is stored the same way and asked once. Sessions written before this change
still load and continue. The operator-guided draft maps answers exactly as
before.

`BUILD_VERIFICATION.json`: the per-suite results now match the total.

Tests: Formation 86 (+4). Four mutations (guide not stored, guide not sent to
the model, stored guide re-asked as new, fallback shown twice) all caught.

Committed as `c4f35475dfab03b9fb43a22ed8821051b441c486` (parent `a4d2012`).

## Resuming at a model question (13 November 2026, review of c4f3547)

A session paused right after a model-written question resumed with a bare
`You>` prompt. Now: with `--model-questions`, the stored question is shown
again after passing the question check once more; without the flag, or if it
fails the check (for example a question saved before the filter existed), HWI
says so once and asks its own guided question instead, stored with the answer
like any other. A model question shown live in the same run is still followed
by a plain `You>` prompt, not repeated.

Tests: Formation 90 (+4). Five mutations all caught.

Committed as `46339d35249cc9b8de494664604f964b66fcb27f` (parent `c4f3547`).

## First native Gate A run on macOS (13 November 2026)

Gate A on the Mac failed in the offline step: four tests in
`tools/test_dualflow_model.py` (added in `c320f8b`, never run on a Mac) built a
wiki workspace on an unresolved temporary path. macOS puts temporary folders
behind the `/var -> /private/var` symlink, and the wiki core correctly refuses
symlinked workspaces. The test now resolves the path first. All suites were
re-run on Linux with `TMPDIR` pointing through a symlink to reproduce the
macOS condition: 618/618 pass.

The same verification run hit the inode-reuse case (see the known limitation
above) in `test_reimported_instance_is_orphaned_and_archivable`; that test now
holds the old inodes open during the restore, like contract test 9 (30/30
repeated runs pass). No product code changed.

Committed as `e536e48dbe5a39dd5f8154f89e359e944ad5d2e9` (parent `46339d3`).

## Second native Gate A run on macOS (13 November 2026)

617/618 passed on the Mac. `test_model_outage_falls_back_without_fake_approval`
simulated an Ollama outage only on model questions; since model questions are
off by default (`a4d2012`), the draft request went to whatever listened on
127.0.0.1:11434. On Linux nothing did, so the test passed by accident; on the
Mac a real Ollama answered. The test now simulates the outage on the draft
request too. All suites were re-run on Linux with a recording fake Ollama on
port 11434: no test contacts it, and 618/618 pass. No product code changed.

Committed as `79c45eaa585c75ba31ec4d7e10ec5706be6928be` (parent `e536e48`).

## Formation conversation as an explicit state machine (13 November 2026)

The conversation loop had grown hidden state (`pending`, `shown`, `noted`,
`resumed_question`) and each of the last review rounds found another missed
combination. It is now an explicit state machine in `hwi_formation/dialogue.py`
(pure functions; the CLI only performs effects). Behaviour is unchanged: all 90
existing Formation tests pass without modification. New: 18 tests (one per
transition, state derivation at every resume point, 1,500 randomised
conversations against invariants). Reintroducing each historical bug
(guided question not stored, bare prompt on resume, fallback shown twice,
stored model question not re-checked, outage not switching to manual,
fallback or model question not stored) is caught by the new tests alone.

`tools/prerelease_checks.py` now ships with the release: all offline suites
with a symlinked temporary folder (as on macOS) and with a recording fake
Ollama listening on port 11434 (no test may contact it). Against `e536e48`,
the release that failed on the Mac, it reports the stray chat request.

Tests: Formation 108 (+18); total 636.

Committed as `47b9e7fe9d64a7cdb6a9d725e3191c46cf715ddd` (parent `79c45ea`).
