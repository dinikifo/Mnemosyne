#!/usr/bin/env python3
"""Check hashes AND exact file inventory in extracted diagnostic-rule snapshot."""
from hashlib import sha256
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
manifest = root / 'MANIFEST.sha256'
rows = manifest.read_text('utf-8').splitlines()
expected = {}
for row in rows:
    digest, marker, name = row.partition('  ')
    if not marker or len(digest) != 64 or name in expected:
        raise SystemExit('Invalid diagnostic-rule manifest')
    expected[name] = digest
actual = {str(p.relative_to(root).as_posix()) for p in root.rglob('*') if p.is_file()}
if actual != set(expected) | {'MANIFEST.sha256'}:
    missing = sorted(set(expected) - actual)
    extra = sorted(actual - set(expected) - {'MANIFEST.sha256'})
    raise SystemExit(f'diagnostic-rule inventory mismatch: missing={missing} extra={extra}')
for name, digest in expected.items():
    if sha256((root / name).read_bytes()).hexdigest() != digest:
        raise SystemExit(f'diagnostic-rule integrity failure: {name}')
print(f'diagnostic-rule verified {len(expected)} payload files')
