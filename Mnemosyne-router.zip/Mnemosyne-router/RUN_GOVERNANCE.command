#!/bin/bash
# Operator invoked only. No implicit notebook creation or authorization.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$ROOT/CODE/DUALFLOW:$ROOT/CODE/APPROVED_WIKI_CORE:$ROOT/CODE/APPROVED_AGENT_PROVIDER${PYTHONPATH:+:$PYTHONPATH}"
PY="${HWI_PYTHON:-python3}"
exec "$PY" -B -m hwi_governance "$@"
